# Home Depot Roofing Business

- Conversation ID: 6849c88d-e2f0-800c-b43e-c8d1409d98e4
- Created: 2025-06-11T18:20:47.865563

---

**user:**

So a friend of mine and I were talking about roofing materials and how the roofing company that I work for was actually saving money by buying shingles from Home Depot rather than like ABC or SRS or one of the big, you know, construction material distributors. They were actually getting it cheaper from Home Depot and buying it bulk, which made me think like they have like pro membership, all that. You can be like a membership and you get rewards. So if you&#x27;re buying big time in bulk from Home Depot, going through like that rewards account and stacking up those rewards, which I, from what I understand to you also kind of like builds your credit rating, if you will, with them. Cause I know that like when I buy stuff, they always want me to apply for the Home Depot credit card based on the amount of points. Like, and it made me, is there a little business somewhere in there where like you can focus your time on from Home Depot and delivering it for these roofing companies, right? If this is a margin there to say, you just need a flatbed truck with one of the cranes on it for roof loading.

---

**assistant:**

That&#x27;s actually a pretty interesting insight! Leveraging Home Depot&#x27;s pro memberships and rewards system could indeed be a strategic advantage, especially if you&#x27;re buying in bulk. Not only do you get the cost savings, but there&#x27;s also that potential for building credit and stacking rewards. And you&#x27;re right—there could be a niche business model in there, helping smaller roofing companies streamline their supply chain. It&#x27;s definitely worth exploring further!

---

