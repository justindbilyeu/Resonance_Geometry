# Luca Turin and tunneling

- Conversation ID: 68993985-b9fc-832b-89b8-7dd086ee61e5
- Created: 2025-08-11T00:30:35.442109

---

**user:**

What can you tell me about Luca turin and an elastic electron tunneling

---

**assistant:**

Luca Turin is a biophysicist best known for his **vibrational theory of olfaction**, which proposes that our noses detect smells not only by the *shape* of odor molecules (the traditional &quot;lock-and-key&quot; model) but also by sensing their **molecular vibrations** via a mechanism called **inelastic electron tunneling**.  

Here’s the breakdown relevant to your “elastic electron tunneling” mention:  

---

## **Who is Luca Turin?**
- **Background:** Italian biophysicist and biochemist, trained in physics and biology.
- **Research focus:** Primarily on the sense of smell, but also on perfume chemistry, biophysics, and quantum biology.
- **Notable idea:** The *vibrational theory of olfaction* (first proposed in the 1990s), which integrates **quantum mechanical tunneling** into the biology of sensory receptors.

---

## **Elastic vs. Inelastic Electron Tunneling**
In quantum mechanics, tunneling is when an electron moves through a potential barrier it classically shouldn’t be able to cross.

- **Elastic electron tunneling:**
  - Electron passes through without losing or gaining energy.
  - The electron’s kinetic energy before and after the tunneling is the same.
  - Only the spatial wavefunction changes; no energy is transferred to the molecule.
  - Often used in STM (scanning tunneling microscopy) for imaging because it’s sensitive to electronic structure.

- **Inelastic electron tunneling:**
  - Electron exchanges energy with the molecule—often exciting a vibrational mode.
  - This energy loss can correspond to the vibrational frequency of chemical bonds.
  - This is the key to Turin’s smell theory: the receptor detects *which vibrational modes are excited*, effectively “hearing” the molecule’s vibrations.

---

## **Turin’s Proposal in Context**
- **Mechanism:** Odorant molecules bind to a receptor; an electron tunnels between two parts of the receptor *only if* the energy lost matches a molecular vibration of the bound odorant.
- **Analogy:** Like a spectrometer embedded in your nose, but quantum-scale.
- **Evidence:** Turin cites parallels with *inelastic electron tunneling spectroscopy* (IETS), where the vibrational spectra of molecules can be measured via tunneling.
- **Controversy:**  
  - Traditional olfaction theory holds that shape and fit dominate.
  - Some experiments support vibrational effects (e.g., isotope substitution studies), but others do not.
  - The theory remains debated in sensory biology circles.

---

If you’re asking about **elastic** electron tunneling specifically in relation to Turin — that’s actually the *null case* in his theory: in purely elastic tunneling, the electron doesn’t couple to the molecular vibration, so no smell “note” is detected. The receptor would essentially just be conducting current without vibrational discrimination.  

If you’d like, I can diagram **how an elastic vs. inelastic tunneling pathway would look inside a hypothetical Turin-style olfactory receptor**, so the distinction is visual and tied directly to his work. That would make it clearer where elastic tunneling fits in.

---

