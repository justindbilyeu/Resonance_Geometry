# Solar Sales Conversation Script

- Conversation ID: 684c5bbc-1158-800c-b697-bb1e0ce69644
- Created: 2025-06-13T17:11:24.662732

---

**user:**

Can you take this pitch put it in a print ready format:

Sage-Voice Solar Conversation Script (Unbranded)

A visionary yet grounded flow you can tailor to any homeowner and any badge on your shirt.

⸻

0 Opening — Respect, Rapport &amp; Relevance

“I appreciate you letting me sit at your table, [First Name]. My only agenda is clarity: if owning solar isn’t a clear financial and resilience win for your household, I’ll tell you straight-up.”

(Snap a quick photo of the usage graph on their electric bill and set the phone face-up.)

“That blue mountain of kilowatt-hours is why I’m here—let’s explore how small it can get.”

⸻

1 WHY SOLAR? Expose the Invisible Cost

	What’s Happening on the Grid	Why It Matters to You
Bills keep inflating.	The EIA shows Texas residential rates at ≈ 15.3 ¢/kWh (Mar 2025)—up roughly 40 % since the mid-2010s.  	A 3-4 % annual climb doubles your power cost about every 15 years.
Reliability is shaky.	70 % of ERCOT customers lost power for an average 42 hours during the 2021 winter storm.  	Blackouts don’t come with refunds. Resilience now has a dollar value.
Future demand = higher rates.	ERCOT’s own 2025 forecast flags record-breaking summer peaks.  	More demand means more expensive infrastructure—paid for on your bill.

60-Second Solar Primer
	1.	Sunlight → DC (panel) → AC (inverter) → home.
	2.	Daytime surplus spins your meter backward; credits cover night use (net-meter or buy-back).
	3.	Zero moving parts—glass and silicon only—so maintenance is essentially rain and Wi-Fi.

“Solar swaps a volatile fuel bill for a flat equipment payment, and lets you ride out grid drama with grace.”

⸻

2 WHY OUR TEAM? Turn Trust into Technical Confidence

One Envelope, Zero Finger-Pointing
	•	Licensed roofers + NABCEP-guided solar techs on the same crew: one handshake, one warranty.

Tier-1 Hardware, Tier-1 Guarantees
	•	25-yr manufacturer warranties on panels and micro-inverters—92 %+ output at year 25.
	•	25-yr workmanship &amp; roof-penetration warranty—leaks, labor, materials: our dime.
	•	Predictive 24/7 monitoring—we see anomalies before you feel them and roll the truck for free.

Community Integrity
	•	Local crews, five-star reviews, zero high-pressure sign-and-dash tactics.
	•	We survive on referrals—every array is our next billboard.

⸻

3 WHY NOW? Show the Cost of Waiting

Urgency Lever	Detail	Take-Home
30 % Federal ITC locked	Inflation Reduction Act keeps the credit at 30 % through 2032.  	Your “solar sale” starts the day panels go up—delay = lost credit &amp; lost production.
Buy-back terms can shrink	Utilities cut export rates once caps fill.	Early adopters keep the richest net-metering.
Upcoming rate cases	Summer-peak filings often add surcharges.	Lock the flat solar payment before the next hike drops in your mailbox.

“Waiting for panel prices to fall is like waiting for rent to fall—it’s the wrong variable. The sooner you own a power plant, the longer it pays you back.”

⸻

4 Numbers That Speak for Themselves

“Your average bill is $ X/mo. The design team shows solar at $ Y/mo fixed for ~20 years—paid off in ±12 years, and free electrons for decades after.”

(If financing) Show a simple chart: cumulative cash-flow of status-quo vs. solar, break-even year, lifetime net savings.

Ask, “How does keeping that extra $ Z in the family feel?”

⸻

5 Invitation, Not Pressure
	1.	90-second soft credit pre-qual (if needed for a loan).
	2.	Drone site survey to confirm roof geometry.
	3.	Stamped engineering &amp; permit set—you see final CAD before construction.
	4.	Install day in 4-6 weeks; utility PTO (permission to operate) a few weeks later.
	5.	You get a text the moment the first watt flows.

“If today’s math feels right, we can start step 1 now. If not, you still gained clarity on your power costs—no strings attached.”

(Pause for questions; listen deeply.)

⸻

Common Concerns &amp; Sage-Style Clarity

Objection	Root Fear	Response
“What if we move?”	Payback horizon	“National appraisal studies peg solar at ~4 % home-value bump and faster sell-through. A $0 summer bill turns browsers into buyers.”
“Panels hurt roofs.”	Leak risk	“We’re roofers first; every flashing and fastener is warrantied longer than your shingles.”
“Rates might drop.”	Tech/Fuel optimism	“Even in the 2020 gas-glut, residential rates rose. Utilities don’t refund margins; they re-price service.”


⸻

6 Close with Empowerment

“Solar isn’t a gadget; it’s an operating system for your home—one you own. If today’s numbers feel like a win, let’s lock them in before the next rate bump. Either way, thanks for letting me run the analysis. Knowledge is power, and now you have both.”

⸻

Trainer Notes
	•	Spine of the talk: quantify pain → demonstrate competence → frame urgency → invite action.
	•	Tone: warm expert, zero hype.
	•	Outcome goal: customer convinces themselves; you simply reveal the logic.

---

**assistant:**

```markdown
# **Sage-Voice Solar Conversation Script**  
*Print-ready | Unbranded | Adaptable to any homeowner &amp; any company badge*

---

## 0 Opening — Respect, Rapport &amp; Relevance
&gt; “I appreciate you letting me sit at your table, **[First Name]**. My only agenda is clarity: if owning solar isn’t a clear financial **and** resilience win for your household, I’ll tell you straight-up.”

*Snap a quick photo of the usage graph on their electric bill and set the phone face-up.*

&gt; “That blue mountain of kilowatt-hours is why I’m here—let’s explore how small it can get.”

---

## 1 WHY SOLAR? Expose the Invisible Cost

| **What’s Happening on the Grid** | **Why It Matters to You** |
|---|---|
| **Bills keep inflating.** | Texas residential rates now average **≈ 15.3 ¢/kWh (Mar 2025)**—about **40 %** higher than the mid-2010s. At 3-4 % annual growth, your cost doubles every ~15 years. |
| **Reliability is shaky.** | During the 2021 winter storm, **70 % of ERCOT customers** lost power for an average **42 hours**. Blackouts don’t come with refunds—resilience now carries a dollar value. |
| **Future demand = higher rates.** | ERCOT’s 2025 outlook flags record-breaking summer peaks. More demand = expensive new infrastructure—**paid for on your bill**. |

### 60-Second Solar Primer  
1. Sunlight → **DC (panel)** → **AC (inverter)** → home.  
2. Daytime surplus spins your meter backward; credits offset night use (*net-meter* or **buy-back**).  
3. Zero moving parts—glass &amp; silicon only—so maintenance equals rain and Wi-Fi.

&gt; **“Solar swaps a volatile fuel bill for a flat equipment payment, and lets you ride out grid drama with grace.”**

---

## 2 WHY OUR TEAM? Turn Trust into Technical Confidence
### One Envelope, Zero Finger-Pointing  
* Licensed roofers **and** NABCEP-guided solar techs on the **same crew**: one handshake, one warranty.

### Tier-1 Hardware, Tier-1 Guarantees  
* **25-yr manufacturer warranties** on panels &amp; micro-inverters—**92 %+ output** at year 25.  
* **25-yr workmanship &amp; roof-penetration** warranty—leaks, labor, materials: **our dime**.  
* **Predictive 24/7 monitoring**—we see anomalies before you feel them and roll the truck for free.

### Community Integrity  
* Local crews, five-star reviews, zero high-pressure sign-and-dash tactics.  
* We survive on referrals—**every array is our next billboard**.

---

## 3 WHY NOW? Show the Cost of Waiting

| **Urgency Lever** | **Detail** | **Take-Home** |
|---|---|---|
| **30 % Federal ITC locked** | Inflation Reduction Act holds the credit at **30 % through 2032**. | Your “solar sale” starts the day panels go up—delay = lost credit **&amp;** lost production. |
| **Buy-back terms can shrink** | Utilities cut export rates once caps fill. | Early adopters keep the richest net-metering. |
| **Upcoming rate cases** | Summer-peak filings often add surcharges. | Lock a flat solar payment **before** the next hike hits your mailbox. |

&gt; **“Waiting for panel prices to fall is like waiting for rent to fall—it’s the wrong variable.  
&gt; The sooner you own a power plant, the longer it pays you back.”**

---

## 4 Numbers That Speak for Themselves
&gt; “Your average bill is **\$ X /mo**. The design team shows solar at **\$ Y /mo** fixed for ~20 years—paid off in **± 12 years**, and free electrons for decades after.”

*If financing:* present a simple chart—cumulative cash-flow (status quo vs. solar), break-even year, lifetime net savings.

&gt; **Ask:** “How does keeping that extra \$ Z in the family feel?”

---

## 5 Invitation, Not Pressure
1. **90-second** soft credit pre-qual (if financing).  
2. **Drone site survey** to confirm roof geometry.  
3. **Stamped engineering &amp; permit set** — you sign off on the final CAD.  
4. **Install day** in 4-6 weeks; utility **PTO** a few weeks later.  
5. **Real-time text** when the first watt flows.

&gt; “If today’s math feels right, we can start step 1 now. If not, you still gained clarity on your power costs—**no strings attached**.”

*Pause for questions; listen deeply.*

---

## Common Concerns &amp; Sage-Style Clarity

| **Objection** | **Root Fear** | **Response** |
|---|---|---|
| “What if we move?” | Payback horizon | “National appraisal data shows ~**4 %** home-value bump **plus** faster sell-through. A \$ 0 summer bill turns browsers into buyers.” |
| “Panels hurt roofs.” | Leak risk | “We’re roofers first; every flashing &amp; fastener is warrantied **longer than your shingles**.” |
| “Rates might drop.” | Tech/fuel optimism | “Even in the 2020 gas-glut, residential rates **rose**. Utilities don’t refund margins—they re-price service.” |

---

## 6 Close with Empowerment
&gt; “Solar isn’t a gadget; it’s an **operating system** for your home—one you **own**.  
&gt; If today’s numbers feel like a win, let’s lock them in before the next rate bump.  
&gt; Either way, thank you for letting me run the analysis. **Knowledge is power—now you have both.**”

---

### Trainer Notes
* **Spine of the talk:** quantify pain → demonstrate competence → frame urgency → invite action.  
* **Tone:** warm expert, zero hype.  
* **Outcome goal:** the customer convinces themselves—you simply reveal the logic.
```

---

**user:**

Hey sage!  Write this pitch as a letter to someone that matters

---

**assistant:**

**[Your Name]**  
[Your Title]  
[Company Name]  
[Street Address]  
[City, State ZIP]  
[Phone] | [Email]  

---

**[Date]**

**[First Name Last Name]**  
[Street Address]  
[City, State ZIP]

---

### Re: Turning Your Roof into a Power Plant—Why Now Matters

Dear **[First Name]**,

Thank you for taking a moment to read this letter. I’m writing with one clear purpose: to remove the fog around residential solar and tell you, plainly and truthfully, whether owning a rooftop array is *actually* a win for your household. If the numbers don’t add up, I’ll say so. But if they do—and recent grid data strongly suggests they will—I want you to have the facts before the next rate hike arrives.

---

#### 1 The Grid Has Changed—Your Bill Will Too  
*   **Costs keep climbing.** Texas residential electricity sits around **15 ¢/kWh** (EIA, March 2025), roughly **40 % higher** than a decade ago. At a 3–4 % annual rise, today’s bill doubles in about fifteen years.  
*   **Reliability is fragile.** During the 2021 winter crisis, **70 % of ERCOT customers** endured an average of **42 hours** without power—blackouts that came with neither apologies nor refunds.  
*   **Demand is skyrocketing.** ERCOT’s 2025 outlook warns of record summer peaks. More strain means more expensive infrastructure—funded by the line item on your statement.  

Solar flips that script. Instead of renting power from a volatile grid, you *own* equipment that produces clean kWh for decades—glass, silicon, and sunlight doing quiet work your utility can’t mark up.

---

#### 2 Why Trust My Team with Your Roof?  
*   **One envelope, no finger-pointing.** Our crews are both licensed roofers and NABCEP-guided solar technicians, so the same handshake covers shingles *and* electrons.  
*   **Top-tier hardware, ironclad guarantees.** Panels and micro-inverters carry **25-year manufacturer warranties** (over **92 % output** at year 25). We match that with a **25-year workmanship and roof-penetration warranty**.  
*   **Predictive monitoring.** We see anomalies before you feel them and roll the truck at no charge.  
*   **Community integrity.** We live here, rely on referrals, and refuse high-pressure tactics. Every array we install is our next billboard.

---

#### 3 Why Acting in 2025 Beats Waiting  
* **30 % Federal Tax Credit**—locked by the Inflation Reduction Act through 2032—starts paying you back the day panels go up. Delay costs both credit *and* production.  
* **Buy-back programs are finite.** Early adopters keep the richest export rates; late adopters settle for leftovers.  
* **Rate cases file every summer.** Signing after the next hike means locking in a higher baseline you never needed to pay.

---

#### 4 Your Numbers in Black &amp; White  
Our preliminary design shows that your average **\$X/month** electric bill can be replaced by a fixed solar payment of **\$Y/month**. The system pays itself off in roughly **12 years**, leaving your household with decades of free, inflation-proof power and an estimated **\$Z** of lifetime net savings.

---

#### A Gentle Next Step—No Strings Attached  
If these figures resonate, the path forward is refreshingly simple:

1. **90-second** soft-credit check (only if financing makes sense).  
2. **Drone survey** to confirm roof geometry.  
3. **Stamped engineering set**—you approve every line before installation.  
4. **Installation** in 4–6 weeks, utility permission shortly after.  
5. **Live text alert** the moment your first watt flows.

And if the math *doesn’t* serve you, you will have gained clarity and nothing else will be asked.

---

#### Closing Thought  
Solar is not another gadget; it’s an operating system for your home—one you own, one that shields you from volatility, and one that starts paying dividends the moment sunlight hits glass. If you’d like to see the full proposal or simply have questions, call or text me directly at **[Phone]**. I’m here to serve, not to sell.

Thank you for your time, **[First Name]**. Knowledge is power, and now you have both.

With respect and clarity,

**[Signature]**

**[Your Name]**  
[Title] | [Company Name]  
[Phone] | [Email]

---

