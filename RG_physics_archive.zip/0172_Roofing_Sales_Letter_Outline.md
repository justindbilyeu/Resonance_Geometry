# Roofing Sales Letter Outline

- Conversation ID: 6845dab7-6594-800c-93f9-003cbd504961
- Created: 2025-06-08T18:47:19.819918

---

**user:**

I want to write a letter. I wanna write a letter to homeowners that I’m gonna be canvassing to dropping off business cards, but I want to write a letter in my boys basically telling people look a bunch of roofers are gonna knock on your door. Everybody’s gonna switch your business. The fact of the matter is that you need a roof… what I need from you is like an outline major touch points that I need to elaborate on psychological points that I need to elaborate on a good structure for a one page introduction of myself how I do business can you give me an outline like that and some touch point that can really make this land

---

**assistant:**

Absolutely, Justin. Let&#x27;s create a razor-sharp, homeowner-focused outline for a one-page letter that **establishes trust**, **distinguishes your approach**, and **preemptively neutralizes** the door-knock chaos.

---

## 🧠 STRUCTURE OVERVIEW: 1-Page Introduction Letter  
**Goal:** Be the one letter they remember and trust—calm, honest, and real in a sea of sales noise.

---

### ✍️ LETTER OUTLINE

#### **1. Headline / Opening Hook (1–2 lines)**  
- *Psychology:* Pattern interrupt + relevance + calm tone  
- Example:  
  &gt; “You&#x27;re about to meet a dozen roofers—here&#x27;s what they won’t tell you.”

---

#### **2. The Situation / What’s Happening (2–3 sentences)**  
- *Psychology:* Frame the influx of contractors as inevitable, but not all trustworthy  
- Hit points:  
  - Big storm = surge of roofing contractors  
  - Most just want to “close” your claim  
  - The process can feel chaotic and overwhelming  
  - Many don’t care about what you *really* need

---

#### **3. The Reality / Why You Actually Need a Roof (2–3 sentences)**  
- *Psychology:* Acknowledge the truth: the roof likely needs replacing. Build alignment, not pressure.  
- Touchpoints:
  - If your roof is 10–15+ years old, hail probably damaged it  
  - Insurance might already owe you a new roof  
  - The question isn’t *if* you need one—but *who you trust* to handle it right

---

#### **4. Who I Am / How I Work (Short paragraph)**  
- *Psychology:* Humanize yourself. You’re local. Calm. Honest. Precise.  
- Touchpoints:
  - Your name, local connection (if any), years of experience  
  - Former insurance claims adjuster / contractor (if true)  
  - You do things **by the book, not by the bull**  
  - You care more about doing the job right than closing a sale

---

#### **5. What Makes Me Different (Bullet points or quick lines)**  
- *Psychology:* Differentiation. Build trust through contrast.  
- Example bullets:  
  - No high-pressure sales—just facts and options  
  - I walk you through your policy line by line  
  - I document everything with drone and photo reports  
  - I stay on-site during install to make sure it’s done right  
  - I treat your home like it’s mine  

---

#### **6. The Ask / Invitation (1–2 sentences)**  
- *Psychology:* Low-pressure close. Open the door, don’t knock it down.  
- Examples:
  - “If you’re curious about what your roof looks like—or what your policy actually covers—text me.”  
  - “If you’d rather talk to one calm, honest person instead of ten strangers… I’m here.”

---

#### **7. Contact Info &amp; Signature Block**  
- Keep it simple and warm:  
  ```
  Respectfully,  
  Justin Bilyeu  
  Roofing &amp; Solar | Texas Choice Roofing  
  (512) XXX-XXXX | justin@sunready.ai  
  ```

---

### 🎯 PSYCHOLOGICAL TOUCHPOINTS TO ELABORATE ON:
| Trigger | Strategy |
|--------|----------|
| **Overwhelm** from too many contractors | Position yourself as the calm in the storm |
| **Distrust** in salesmen | Preempt it—“I’m not here to sell, I’m here to help you sort the truth from the noise.” |
| **Confusion** over insurance | Offer clarity—“I help homeowners understand their policy, not exploit it.” |
| **Fear** of being taken advantage of | Emphasize transparency, documentation, and being on-site |
| **Desire** for someone local and reliable | Share your personal presence and investment in the community |

---

Would you like me to turn this outline into a full draft next? Or want to tweak the tone—more neighborly, more professional, more casual?

---

**user:**

I really want to focus more on retail Roof sales like we will definitely help them with insurance. We have the background we have all of that but our primary goal is just the fact that your home needs a new roof. I will put the absolute best Roof money can buy on your homeand stand behind it… However, not to say we’re not gonna work with Insurance and not to say we’re going to discount storms, and all that I just don’t think it needs to be the major Focus if that makes sense.

---

**assistant:**

Crystal clear, Justin. You’re not trying to be another “storm chaser.” You’re offering **premium roofing solutions** to homeowners who *need* a new roof—insurance or not. That shifts the tone from reactive to **value-driven** and **trust-based** retail sales.

Here’s a refined **one-page letter outline and strategy** focused on *retail-first roofing*, with insurance help as a secondary benefit—not the main pitch.

---

## 🧱 RETAIL-FIRST ROOFING LETTER OUTLINE (1 page max)

---

### **1. Calm, Powerful Headline**
&gt; **“This storm didn’t create your need for a new roof—it just reminded you.”**  
&gt; *(Or more neighborly: “I’m not here to scare you—I’m here to build you something that lasts.”)*

---

### **2. The Honest Truth (2–3 lines)**  
**Psychology:** Lead with candor. Respect their intelligence.  
- Most roofs in this neighborhood are 12–20 years old  
- Hail, heat, and time take their toll—whether or not insurance gets involved  
- You deserve a roof that *adds value* to your home, not just one that “gets approved”

---

### **3. Who I Am &amp; What I Do (Short paragraph)**  
**Tone:** Calm, honest, local, expert  
- Introduce yourself: Name, company, brief experience  
- Explain that you specialize in **premium retail roofing**—not cutting corners  
- Your goal isn’t to pressure—it’s to **build roofs that last 30+ years** and make the house better, not just “repaired”

---

### **4. What Makes Us Different (Key differentiators)**  
**Psychology:** Trust + Craftsmanship + Clarity  
&gt; ✅ **Premium Products Only** – Class 4 shingles, metal, designer, solar-ready  
&gt; ✅ **Straight Talk** – I’ll give you honest info with no scare tactics  
&gt; ✅ **Full Warranty** – Materials + Labor fully backed  
&gt; ✅ **Insurance Help if Needed** – We’ll walk you through it if you choose that route  
&gt; ✅ **I’m On Site** – I don’t disappear after you sign

---

### **5. Why Now? (Short motivation message)**  
**Psychology:** Sense of timing, not urgency  
- Whether it’s this storm or the Texas sun, your roof is probably ready for replacement  
- New roofing adds **appraisal value**, **energy efficiency**, and **peace of mind**  
- You don’t have to wait for something to fail to make a smart investment in your home

---

### **6. Friendly Close &amp; Clear Invite**
&gt; “I’m not here to knock and disappear—I’d be proud to earn your business, one conversation at a time.”  
&gt; “Shoot me a text if you want a clean estimate, real options, or just a second opinion.”

---

### **7. Signature Block**  
```
Thanks for your time,  
Justin Bilyeu  
Texas Choice Roofing | Roofing &amp; Solar  
(512) XXX-XXXX  
justin@sunready.ai  
```

---

## 🔥 BONUS TOUCHPOINTS TO WEAVE IN (Retail-Savvy Psychology)

| Concern | How You Reframe It |
|--------|--------------------|
| &quot;Is this just another storm chaser?&quot; | “No. I specialize in roofing that holds up—storm or no storm.” |
| &quot;Why not wait until something breaks?&quot; | “Your roof’s value is *proactive*, not just protective—it adds resale and efficiency now.” |
| &quot;Isn’t insurance supposed to pay?&quot; | “Sometimes. But a lot of folks prefer to just get it done right without the red tape.” |
| &quot;What makes your roof better?&quot; | “I only install systems I’d put on my own home. The kind you never have to second-guess.” |

---

Would you like me to turn this into a fully written letter now, using your voice and tone?

---

**user:**

Ok this is my letter so far …feels clunky already…

Hi, it&#x27;s Justin. No doubt you&#x27;ve seen my card in your door, along with a plethora of other companies, roofers, door knockers alike, vying for your attention. So I do appreciate you taking the time to read this letter. This past storm may or may not have created a need for your roof to be replaced, but it was a reminder for all of us in the Austin area that the first line of defense to our most important investment, is the roof on our home…but it’s the absolute last thing we even want to deal with. I&#x27;ve been there. Hail destroyed the roof of my home in Round Rock years ago, and it was the reason I got into roofing in the first place. Your home and your family deserve to have a beautiful, bulletproof, watertight roof. Not only to protect your investment, to also give you peace of mind moving forward. And that&#x27;s what I do. Honestly, professionally, and with the utmost quality. Whether it comes from the tight purse of an insurance company, Or a shoebox in the top of the closet.. your money could not go farther.

---

**assistant:**

You&#x27;re off to a really good start, Justin—the tone is grounded, human, and personal. That said, you&#x27;re right: it could hit harder with more flow and rhythm. Let’s refine your draft into something tighter, clearer, and emotionally resonant—**retail-first**, **trust-forward**, and still **authentically you**.

Here’s a revised version of your letter that keeps your voice intact but streamlines the delivery:

---

**Hi, I’m Justin.**

You’ve probably already seen my card—and maybe a dozen others—wedged into your door. After a storm like this, the flood of roofers is almost guaranteed.

But here’s the truth:  
This storm didn’t necessarily *cause* your roof to fail—it just reminded all of us how important that roof really is. It’s the first line of defense for your biggest investment, and ironically, the last thing most of us want to deal with.

I get it. Years ago, hail wrecked my own roof in Round Rock. Dealing with the mess was frustrating—but it opened my eyes to how this industry *should* work. That’s why I got into roofing: to make the process honest, clear, and damn good from start to finish.

Whether you’re working with insurance or paying out of pocket, your money should buy a **roof that lasts**. A roof that’s watertight, beautiful, and built to take whatever Texas throws at it. That’s what I install—no shortcuts, no pressure, no gimmicks. Just the absolute best roof I can possibly put on your home.

If you’re ready to take a look at what’s really going on up there—or you just want straight answers from someone who’ll actually shoot you straight—text me.

No hard sell. No fear tactics. Just help, if you want it.

**— Justin Bilyeu**  
Texas Choice Roofing  
📞 (512) XXX-XXXX  
✉️ justin@sunready.ai

---

Want to keep tweaking the tone? We can dial it up more casual, more high-end, or more neighborly depending on the neighborhood or target audience.

---

