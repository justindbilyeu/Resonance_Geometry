# TriSource node schematic

- Conversation ID: 68d1e1a7-4610-8324-b865-b3f54d409f05
- Created: 2025-09-22T23:54:15.881920

---

**user:**

Image Prompt


You are generating engineering schematics for the eMSSC² project (SunShare / TriSource / MSSC). eMSSC² integrates:
	1.	SPMD: solar photothermal desal (UNIST LSMO inverse-L cartridges)
	2.	MSSC: microbial sump→bog→soil wetland loop for brine polishing &amp; irrigation
	3.	AWG: atmospheric water capture (optional)
Water goes through QA (EC/T/UV) then to clean storage. Brine/salt goes to edge collection then wetland/halophytes.

Output format: SVG (vector), 1600×1000 px (landscape).
Style: minimal, technical, legible; thin strokes; neutral grayscale with one accent color (#0B84F3). Sans-serif labels (Inter or Roboto).
Accessibility: 14–16 px labels, high contrast, clear legend.
Deliver: single &lt;svg&gt;…&lt;/svg&gt; block; no base64, no external fonts.
Layers/Groups: &lt;g id=&quot;…&quot;&gt; with semantic names (e.g., g-spmd, g-mssc, g-qa, g-storage).
Repo path &amp; name to embed in : 05-technical-resources/figures/&lt;filename&gt;.svg.
Include a neat legend, north arrow if layout, and a footer note: “eMSSC² — draft schematic YYYY-MM”.

Create an SVG block diagram titled trisource_node.svg that shows three inputs converging to storage with QA and brine handling.

Blocks (left→right flow):
	•	AWG module (optional input)
	•	SPMD (Solar Desal) with sublabels: “inverse-L absorber”, “edge salt trough”
	•	MSSC Wetland Loop with sub-blocks stacked: “Pond (sump) → Bog (biofilter) → Soil/Irrigation”
	•	QA &amp; Post-Treatment: “EC/T sensor”, “UV or chlorine”, “Remineralization”
	•	Clean Water Storage

Flows:
	•	Blue arrows for clean water; gray arrows for process/heat; orange arrows for brine/salt to wetland.
	•	From SPMD: split outputs → blue to QA, orange to “Salt Edge Collection → Wetland/Halophytes”.
	•	Optionally show dashed arrow: “Condenser heat → optional AWG regen”.

Annotations:
	•	Small badges: “&lt;7 kWh/day aux” near QA/pumps; “Target 60–65 L/day” near storage.
	•	Legend for arrow colors; note: “Field derate: 40–50% vs lab”.

Grouping IDs: g-awg, g-spmd, g-mssc, g-qa, g-storage, g-legend.
Ensure neat alignment, equal spacing, and readable labels.

---

**assistant:**

```svg
&lt;svg xmlns=&quot;http://www.w3.org/2000/svg&quot; width=&quot;1600&quot; height=&quot;1000&quot; viewBox=&quot;0 0 1600 1000&quot; role=&quot;img&quot; aria-labelledby=&quot;title desc&quot;&gt;
  &lt;title&gt;trisource_node.svg — eMSSC² TriSource Node Schematic&lt;/title&gt;
  &lt;desc&gt;Repository path: 05-technical-resources/figures/trisource_node.svg — Minimal engineering block diagram showing AWG, SPMD solar desal, MSSC wetland loop, QA/post-treatment, and clean storage. Blue = clean water, gray = process/heat, orange = brine/salt. eMSSC² — draft schematic 2025-09.&lt;/desc&gt;

  &lt;style&gt;
    :root {
      --blue:#0B84F3;
      --gray:#555;
      --lightgray:#C7C7C7;
      --orange:#F58A1F;
      --text:#111;
      --bg:#fff;
    }
    text, tspan { font-family: Inter, Roboto, Helvetica, Arial, sans-serif; fill: var(--text); font-size:16px; }
    .subtitle { font-size:14px; fill:#333; }
    .small { font-size:14px; }
    .hdr { font-weight:600; }
    .box { fill:#fff; stroke:#111; stroke-width:1.5; rx:10; }
    .subbox { fill:#fafafa; stroke:#999; stroke-width:1.2; rx:8; }
    .arrow { fill: none; stroke-width:2.5; }
    .blue { stroke: var(--blue); }
    .gray { stroke: var(--gray); }
    .orange { stroke: var(--orange); }
    .dashed { stroke-dasharray:8 6; }
    .badge { fill:#f2f7ff; stroke:var(--blue); stroke-width:1; rx:6; }
    .note { fill:#fff8ef; stroke:var(--orange); stroke-width:1; rx:6; }
    .legend-box { fill:#fff; stroke:#999; stroke-width:1; rx:8; }
    .titlebar { font-size:20px; font-weight:700; }
    .footer { font-size:13px; fill:#444; }
  &lt;/style&gt;

  &lt;!-- Arrowheads --&gt;
  &lt;defs&gt;
    &lt;marker id=&quot;arrow-blue&quot; markerWidth=&quot;12&quot; markerHeight=&quot;12&quot; refX=&quot;10&quot; refY=&quot;6&quot; orient=&quot;auto&quot;&gt;
      &lt;path d=&quot;M0,0 L12,6 L0,12 z&quot; fill=&quot;#0B84F3&quot;/&gt;
    &lt;/marker&gt;
    &lt;marker id=&quot;arrow-gray&quot; markerWidth=&quot;12&quot; markerHeight=&quot;12&quot; refX=&quot;10&quot; refY=&quot;6&quot; orient=&quot;auto&quot;&gt;
      &lt;path d=&quot;M0,0 L12,6 L0,12 z&quot; fill=&quot;#555&quot;/&gt;
    &lt;/marker&gt;
    &lt;marker id=&quot;arrow-orange&quot; markerWidth=&quot;12&quot; markerHeight=&quot;12&quot; refX=&quot;10&quot; refY=&quot;6&quot; orient=&quot;auto&quot;&gt;
      &lt;path d=&quot;M0,0 L12,6 L0,12 z&quot; fill=&quot;#F58A1F&quot;/&gt;
    &lt;/marker&gt;
  &lt;/defs&gt;

  &lt;!-- Title --&gt;
  &lt;g id=&quot;g-title&quot;&gt;
    &lt;text x=&quot;40&quot; y=&quot;54&quot; class=&quot;titlebar&quot;&gt;eMSSC² — TriSource Node (AWG + SPMD Solar Desal + MSSC → QA → Clean Storage)&lt;/text&gt;
    &lt;text x=&quot;40&quot; y=&quot;78&quot; class=&quot;subtitle&quot;&gt;Repo: 05-technical-resources/figures/trisource_node.svg&lt;/text&gt;
  &lt;/g&gt;

  &lt;!-- Optional AWG --&gt;
  &lt;g id=&quot;g-awg&quot;&gt;
    &lt;rect x=&quot;80&quot; y=&quot;160&quot; width=&quot;240&quot; height=&quot;180&quot; class=&quot;box&quot;/&gt;
    &lt;text x=&quot;200&quot; y=&quot;190&quot; text-anchor=&quot;middle&quot; class=&quot;hdr&quot;&gt;AWG Module&lt;/text&gt;
    &lt;text x=&quot;200&quot; y=&quot;214&quot; text-anchor=&quot;middle&quot; class=&quot;subtitle&quot;&gt;(optional input)&lt;/text&gt;
    &lt;rect x=&quot;100&quot; y=&quot;230&quot; width=&quot;200&quot; height=&quot;90&quot; class=&quot;subbox&quot;/&gt;
    &lt;text x=&quot;200&quot; y=&quot;260&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot;&gt;Desiccant / Condenser&lt;/text&gt;
    &lt;text x=&quot;200&quot; y=&quot;282&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot;&gt;Airflow + Regeneration&lt;/text&gt;
  &lt;/g&gt;

  &lt;!-- SPMD Solar Desal --&gt;
  &lt;g id=&quot;g-spmd&quot;&gt;
    &lt;rect x=&quot;360&quot; y=&quot;140&quot; width=&quot;300&quot; height=&quot;220&quot; class=&quot;box&quot;/&gt;
    &lt;text x=&quot;510&quot; y=&quot;170&quot; text-anchor=&quot;middle&quot; class=&quot;hdr&quot;&gt;SPMD — Solar Desal&lt;/text&gt;
    &lt;rect x=&quot;380&quot; y=&quot;188&quot; width=&quot;260&quot; height=&quot;60&quot; class=&quot;subbox&quot;/&gt;
    &lt;text x=&quot;510&quot; y=&quot;218&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot;&gt;inverse-L absorber&lt;/text&gt;
    &lt;rect x=&quot;380&quot; y=&quot;258&quot; width=&quot;260&quot; height=&quot;60&quot; class=&quot;subbox&quot;/&gt;
    &lt;text x=&quot;510&quot; y=&quot;288&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot;&gt;edge salt trough&lt;/text&gt;
  &lt;/g&gt;

  &lt;!-- MSSC Wetland Loop --&gt;
  &lt;g id=&quot;g-mssc&quot;&gt;
    &lt;rect x=&quot;720&quot; y=&quot;120&quot; width=&quot;300&quot; height=&quot;300&quot; class=&quot;box&quot;/&gt;
    &lt;text x=&quot;870&quot; y=&quot;150&quot; text-anchor=&quot;middle&quot; class=&quot;hdr&quot;&gt;MSSC — Wetland Loop&lt;/text&gt;
    &lt;rect x=&quot;740&quot; y=&quot;170&quot; width=&quot;260&quot; height=&quot;80&quot; class=&quot;subbox&quot;/&gt;
    &lt;text x=&quot;870&quot; y=&quot;202&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot;&gt;Pond (sump)&lt;/text&gt;
    &lt;text x=&quot;870&quot; y=&quot;224&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot;&gt;→ flow balance&lt;/text&gt;

    &lt;rect x=&quot;740&quot; y=&quot;260&quot; width=&quot;260&quot; height=&quot;80&quot; class=&quot;subbox&quot;/&gt;
    &lt;text x=&quot;870&quot; y=&quot;292&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot;&gt;Bog (biofilter)&lt;/text&gt;
    &lt;text x=&quot;870&quot; y=&quot;314&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot;&gt;microbial polishing&lt;/text&gt;

    &lt;rect x=&quot;740&quot; y=&quot;350&quot; width=&quot;260&quot; height=&quot;50&quot; class=&quot;subbox&quot;/&gt;
    &lt;text x=&quot;870&quot; y=&quot;380&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot;&gt;Soil / Irrigation&lt;/text&gt;

    &lt;!-- Brine destination note --&gt;
    &lt;rect x=&quot;720&quot; y=&quot;440&quot; width=&quot;300&quot; height=&quot;52&quot; class=&quot;note&quot;/&gt;
    &lt;text x=&quot;870&quot; y=&quot;471&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot;&gt;Salt Edge Collection → Wetland / Halophytes&lt;/text&gt;
  &lt;/g&gt;

  &lt;!-- QA &amp; Post-Treatment --&gt;
  &lt;g id=&quot;g-qa&quot;&gt;
    &lt;rect x=&quot;1080&quot; y=&quot;180&quot; width=&quot;260&quot; height=&quot;240&quot; class=&quot;box&quot;/&gt;
    &lt;text x=&quot;1210&quot; y=&quot;210&quot; text-anchor=&quot;middle&quot; class=&quot;hdr&quot;&gt;QA &amp;amp; Post-Treatment&lt;/text&gt;

    &lt;rect x=&quot;1100&quot; y=&quot;230&quot; width=&quot;220&quot; height=&quot;46&quot; class=&quot;subbox&quot;/&gt;
    &lt;text x=&quot;1210&quot; y=&quot;258&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot;&gt;EC/T sensor&lt;/text&gt;

    &lt;rect x=&quot;1100&quot; y=&quot;282&quot; width=&quot;220&quot; height=&quot;46&quot; class=&quot;subbox&quot;/&gt;
    &lt;text x=&quot;1210&quot; y=&quot;310&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot;&gt;UV or chlorine&lt;/text&gt;

    &lt;rect x=&quot;1100&quot; y=&quot;334&quot; width=&quot;220&quot; height=&quot;46&quot; class=&quot;subbox&quot;/&gt;
    &lt;text x=&quot;1210&quot; y=&quot;362&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot;&gt;Remineralization&lt;/text&gt;

    &lt;!-- Aux power badge --&gt;
    &lt;rect x=&quot;1090&quot; y=&quot;430&quot; width=&quot;160&quot; height=&quot;30&quot; class=&quot;badge&quot;/&gt;
    &lt;text x=&quot;1170&quot; y=&quot;450&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot;&gt;&amp;lt;7 kWh/day aux&lt;/text&gt;
  &lt;/g&gt;

  &lt;!-- Clean Water Storage --&gt;
  &lt;g id=&quot;g-storage&quot;&gt;
    &lt;rect x=&quot;1380&quot; y=&quot;200&quot; width=&quot;160&quot; height=&quot;220&quot; class=&quot;box&quot;/&gt;
    &lt;text x=&quot;1460&quot; y=&quot;230&quot; text-anchor=&quot;middle&quot; class=&quot;hdr&quot;&gt;Clean Water&lt;/text&gt;
    &lt;text x=&quot;1460&quot; y=&quot;254&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot;&gt;Storage&lt;/text&gt;
    &lt;!-- Target badge --&gt;
    &lt;rect x=&quot;1370&quot; y=&quot;440&quot; width=&quot;200&quot; height=&quot;30&quot; class=&quot;badge&quot;/&gt;
    &lt;text x=&quot;1470&quot; y=&quot;460&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot;&gt;Target 60–65 L/day&lt;/text&gt;
  &lt;/g&gt;

  &lt;!-- FLOW ARROWS --&gt;

  &lt;!-- Clean water: AWG → QA --&gt;
  &lt;path class=&quot;arrow blue&quot; marker-end=&quot;url(#arrow-blue)&quot; d=&quot;M320,250 L1070,250&quot;/&gt;

  &lt;!-- Clean water: SPMD → QA --&gt;
  &lt;path class=&quot;arrow blue&quot; marker-end=&quot;url(#arrow-blue)&quot; d=&quot;M660,240 L1070,240&quot;/&gt;

  &lt;!-- Clean water: MSSC → QA --&gt;
  &lt;path class=&quot;arrow blue&quot; marker-end=&quot;url(#arrow-blue)&quot; d=&quot;M1020,360 L1070,360&quot;/&gt;
  &lt;path class=&quot;arrow blue&quot; d=&quot;M1020,360 L900,360&quot; marker-end=&quot;url(#arrow-blue)&quot;/&gt;
  &lt;text x=&quot;960&quot; y=&quot;352&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot; fill=&quot;#0B84F3&quot;&gt;polished water&lt;/text&gt;

  &lt;!-- QA → Storage --&gt;
  &lt;path class=&quot;arrow blue&quot; marker-end=&quot;url(#arrow-blue)&quot; d=&quot;M1340,300 L1370,300&quot;/&gt;
  &lt;text x=&quot;1355&quot; y=&quot;290&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot; fill=&quot;#0B84F3&quot;&gt;to storage&lt;/text&gt;

  &lt;!-- Brine/Salt: SPMD → Wetland/Halophytes --&gt;
  &lt;path class=&quot;arrow orange&quot; marker-end=&quot;url(#arrow-orange)&quot; d=&quot;M510,320 C510,420 720,420 720,466&quot;/&gt;
  &lt;text x=&quot;560&quot; y=&quot;410&quot; class=&quot;small&quot; fill=&quot;#F58A1F&quot;&gt;brine / salt&lt;/text&gt;

  &lt;!-- Process/Heat: optional AWG regeneration from SPMD condenser --&gt;
  &lt;path class=&quot;arrow gray dashed&quot; marker-end=&quot;url(#arrow-gray)&quot; d=&quot;M510,140 C510,100 200,100 200,160&quot;/&gt;
  &lt;text x=&quot;260&quot; y=&quot;106&quot; class=&quot;small&quot; fill=&quot;#555&quot;&gt;Condenser heat → optional AWG regen&lt;/text&gt;

  &lt;!-- Process/Heat (generic) e.g., solar input icon to SPMD --&gt;
  &lt;g id=&quot;g-solar-hint&quot;&gt;
    &lt;circle cx=&quot;360&quot; cy=&quot;110&quot; r=&quot;18&quot; fill=&quot;#fff&quot; stroke=&quot;#555&quot; stroke-width=&quot;1.2&quot;/&gt;
    &lt;path d=&quot;M360 86 L360 70 M360 130 L360 146 M336 110 L320 110 M400 110 L384 110 M343 93 L331 81 M377 139 L389 151 M343 127 L331 139 M377 81 L389 69&quot; stroke=&quot;#555&quot; stroke-width=&quot;1.2&quot;/&gt;
    &lt;path class=&quot;arrow gray&quot; marker-end=&quot;url(#arrow-gray)&quot; d=&quot;M378,110 L400,120&quot;/&gt;
    &lt;text x=&quot;318&quot; y=&quot;66&quot; class=&quot;small&quot; fill=&quot;#555&quot;&gt;solar&lt;/text&gt;
  &lt;/g&gt;

  &lt;!-- Labels on main arrows for clarity --&gt;
  &lt;text x=&quot;800&quot; y=&quot;230&quot; class=&quot;small&quot; fill=&quot;#0B84F3&quot;&gt;permeate / clean&lt;/text&gt;
  &lt;text x=&quot;360&quot; y=&quot;240&quot; class=&quot;small&quot; fill=&quot;#0B84F3&quot;&gt;condensate&lt;/text&gt;

  &lt;!-- North Arrow --&gt;
  &lt;g id=&quot;g-north&quot; transform=&quot;translate(1520,60)&quot;&gt;
    &lt;path d=&quot;M0,40 L0,0&quot; class=&quot;gray&quot; stroke-width=&quot;2&quot;/&gt;
    &lt;polygon points=&quot;-6,6 0,-10 6,6&quot; fill=&quot;#555&quot;/&gt;
    &lt;text x=&quot;0&quot; y=&quot;56&quot; text-anchor=&quot;middle&quot; class=&quot;small&quot;&gt;N&lt;/text&gt;
  &lt;/g&gt;

  &lt;!-- Legend --&gt;
  &lt;g id=&quot;g-legend&quot;&gt;
    &lt;rect x=&quot;40&quot; y=&quot;820&quot; width=&quot;640&quot; height=&quot;140&quot; class=&quot;legend-box&quot;/&gt;
    &lt;text x=&quot;60&quot; y=&quot;850&quot; class=&quot;hdr&quot;&gt;Legend&lt;/text&gt;

    &lt;!-- Blue --&gt;
    &lt;path class=&quot;arrow blue&quot; d=&quot;M60,875 L140,875&quot; marker-end=&quot;url(#arrow-blue)&quot;/&gt;
    &lt;text x=&quot;160&quot; y=&quot;880&quot;&gt;Clean water flow&lt;/text&gt;

    &lt;!-- Gray --&gt;
    &lt;path class=&quot;arrow gray&quot; d=&quot;M60,905 L140,905&quot; marker-end=&quot;url(#arrow-gray)&quot;/&gt;
    &lt;text x=&quot;160&quot; y=&quot;910&quot;&gt;Process / heat flow&lt;/text&gt;

    &lt;!-- Orange --&gt;
    &lt;path class=&quot;arrow orange&quot; d=&quot;M60,935 L140,935&quot; marker-end=&quot;url(#arrow-orange)&quot;/&gt;
    &lt;text x=&quot;160&quot; y=&quot;940&quot;&gt;Brine / salt to wetland&lt;/text&gt;

    &lt;!-- Dashed --&gt;
    &lt;path class=&quot;arrow gray dashed&quot; d=&quot;M360,875 L440,875&quot; marker-end=&quot;url(#arrow-gray)&quot;/&gt;
    &lt;text x=&quot;460&quot; y=&quot;880&quot;&gt;Optional / indirect (dashed)&lt;/text&gt;

    &lt;text x=&quot;360&quot; y=&quot;910&quot; class=&quot;small&quot;&gt;Note: Field derate 40–50% vs lab&lt;/text&gt;
  &lt;/g&gt;

  &lt;!-- Gridlines for neat alignment (light, unobtrusive) --&gt;
  &lt;g id=&quot;g-guides&quot; opacity=&quot;0.08&quot;&gt;
    &lt;line x1=&quot;80&quot; y1=&quot;0&quot; x2=&quot;80&quot; y2=&quot;1000&quot; stroke=&quot;var(--lightgray)&quot;/&gt;
    &lt;line x1=&quot;360&quot; y1=&quot;0&quot; x2=&quot;360&quot; y2=&quot;1000&quot; stroke=&quot;var(--lightgray)&quot;/&gt;
    &lt;line x1=&quot;720&quot; y1=&quot;0&quot; x2=&quot;720&quot; y2=&quot;1000&quot; stroke=&quot;var(--lightgray)&quot;/&gt;
    &lt;line x1=&quot;1080&quot; y1=&quot;0&quot; x2=&quot;1080&quot; y2=&quot;1000&quot; stroke=&quot;var(--lightgray)&quot;/&gt;
    &lt;line x1=&quot;1380&quot; y1=&quot;0&quot; x2=&quot;1380&quot; y2=&quot;1000&quot; stroke=&quot;var(--lightgray)&quot;/&gt;
    &lt;line x1=&quot;1540&quot; y1=&quot;0&quot; x2=&quot;1540&quot; y2=&quot;1000&quot; stroke=&quot;var(--lightgray)&quot;/&gt;
    &lt;line x1=&quot;0&quot; y1=&quot;200&quot; x2=&quot;1600&quot; y2=&quot;200&quot; stroke=&quot;var(--lightgray)&quot;/&gt;
    &lt;line x1=&quot;0&quot; y1=&quot;300&quot; x2=&quot;1600&quot; y2=&quot;300&quot; stroke=&quot;var(--lightgray)&quot;/&gt;
    &lt;line x1=&quot;0&quot; y1=&quot;360&quot; x2=&quot;1600&quot; y2=&quot;360&quot; stroke=&quot;var(--lightgray)&quot;/&gt;
    &lt;line x1=&quot;0&quot; y1=&quot;460&quot; x2=&quot;1600&quot; y2=&quot;460&quot; stroke=&quot;var(--lightgray)&quot;/&gt;
  &lt;/g&gt;

  &lt;!-- Footer --&gt;
  &lt;g id=&quot;g-footer&quot;&gt;
    &lt;text x=&quot;40&quot; y=&quot;980&quot; class=&quot;footer&quot;&gt;eMSSC² — draft schematic 2025-09&lt;/text&gt;
  &lt;/g&gt;
&lt;/svg&gt;
```

---

