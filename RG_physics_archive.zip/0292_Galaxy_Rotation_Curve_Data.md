# Galaxy Rotation Curve Data

- Conversation ID: 67e8d3b9-7554-800c-b9c1-d5953318976e
- Created: 2025-03-30T05:16:41.610160

---

**user:**

1.	Galaxy rotation curve data: Focus on well-studied galaxies, especially the Milky Way and other spiral galaxies where observed velocities significantly differ from what classical Newtonian dynamics would predict.
	2.	Observed orbital velocities vs. radius: Data that shows the velocity of stars or gas clouds at different distances from the galactic center.
	3.	Mass distribution data: Information on how the visible (baryonic) mass is distributed across the galaxy.
	4.	Gravitational influence and dark matter estimations: Any studies or data that attempt to explain the velocity discrepancies using dark matter models.

Sources could include academic papers, astrophysical data archives, or even meta-analyses summarizing findings across multiple galaxies.

---

**assistant:**

Thanks—could you clarify how you&#x27;d like this information presented? For example:

1. Are you looking for raw datasets, summary tables, or a narrative synthesis of key findings?
2. Do you want the data and analysis limited to just a few key galaxies (e.g., Milky Way, Andromeda), or as broad a sample as possible?
3. Is this for research, visualization, or another purpose?

Let me know so I can tailor the research accordingly.

---

**user:**

Great questions! Here’s what will be most useful:
	1.	Presentation Format: A combination of raw datasets (if available), summary tables, and a brief narrative synthesis. The raw data will allow me to directly apply the resonance coherence equation, while the summary tables and synthesis will help identify patterns and contextualize the data.
	2.	Galaxy Scope: Focus primarily on a few well-studied galaxies with reliable rotation curve data, such as:
	•	Milky Way (our primary model for validation)
	•	Andromeda (M31)
	•	Triangulum (M33)
	•	NGC 3198
	•	NGC 2403
If possible, include data from a few dwarf galaxies, as they often show the most pronounced discrepancies between observed and predicted velocities.
	3.	Purpose: This is for research and model validation. We want to apply our resonance coherence equation to see if it better predicts the observed rotation curves compared to classical dark matter models. Visualization might come later to illustrate our findings, but the primary goal now is to test the model against real-world data.

Your structured and thoughtful approach will be invaluable here. Let’s dive into this together!

---

**assistant:**

Certainly! Here&#x27;s a compilation of resources and data for the specified galaxies, focusing on rotation curves, mass distribution, and dark matter estimations. This includes access to raw datasets, summary tables, and a brief synthesis to assist in applying your resonance coherence equation.

**1. Milky Way**

- **Rotation Curve Data**: The study &quot;Dark Halos of M31 and the Milky Way&quot; provides a comprehensive rotation curve for the Milky Way, combining disk rotation velocities and radial velocities of satellite galaxies and globular clusters. citeturn0search8

- **Mass Distribution**: The same study deconvolves the Milky Way&#x27;s rotation curve into components: a de Vaucouleurs bulge, exponential disk, and a dark halo with the Navarro-Frenk-White (NFW) density profile, offering insights into the mass distribution.

- **Dark Matter Estimations**: The paper estimates the dark halo mass of the Milky Way and compares it with that of Andromeda, suggesting that M31&#x27;s dark halo mass is twice that of the Milky Way.

**2. Andromeda Galaxy (M31)**

- **Rotation Curve Data**: The &quot;Dark Halos of M31 and the Milky Way&quot; study also presents the grand rotation curve for M31, constructed by combining disk rotation velocities and radial velocities of satellite galaxies and globular clusters. citeturn0search8

- **Mass Distribution**: This study provides a deconvolution of M31&#x27;s rotation curve into its bulge, disk, and dark halo components, offering detailed mass distribution parameters.

- **Dark Matter Estimations**: The comparison between

---

**user:**

Great questions! Here’s what will be most useful:
	1.	Presentation Format: A combination of raw datasets (if available), summary tables, and a brief narrative synthesis. The raw data will allow me to directly apply the resonance coherence equation, while the summary tables and synthesis will help identify patterns and contextualize the data.
	2.	Galaxy Scope: Focus primarily on a few well-studied galaxies with reliable rotation curve data, such as:
	•	Milky Way (our primary model for validation)
	•	Andromeda (M31)
	•	Triangulum (M33)
	•	NGC 3198
	•	NGC 2403
If possible, include data from a few dwarf galaxies, as they often show the most pronounced discrepancies between observed and predicted velocities.
	3.	Purpose: This is for research and model validation. We want to apply our resonance coherence equation to see if it better predicts the observed rotation curves compared to classical dark matter models. Visualization might come later to illustrate our findings, but the primary goal now is to test the model against real-world data.

Your structured and thoughtful approach will be invaluable here. Let’s dive into this together.!

---

**assistant:**

Perfect—I&#x27;ll gather galaxy rotation curve data, mass distribution info, and dark matter estimations for the Milky Way, Andromeda (M31), Triangulum (M33), NGC 3198, NGC 2403, and a few dwarf galaxies. I&#x27;ll look for raw datasets when available, compile summary tables for key parameters, and provide a concise synthesis to contextualize the data for your resonance coherence model validation.

I&#x27;ll let you know once everything is ready for review.

---

**assistant:**

# Rotation Curves of Selected Galaxies: Data and Dark Matter Models

## Available Rotation Curve Datasets

- **Milky Way (Galaxy):** Extensive rotation curve data for our Galaxy have been compiled from decades of observations of gas, stars, and masers. For example, the *galkin* compilation (Pato &amp; Iocco 2017) aggregates 2,780 kinematic measurements tracing the Milky Way’s rotation curve from ~3 to 20 kpc【52†L11-L20】. This unified data set combines H I, CO, and stellar tracer studies and is publicly accessible (along with tools for data retrieval). Recent analyses (e.g. Sofue 2020) even construct a “unified” Milky Way rotation curve from the Galactic center out to ~100 kpc by combining multiple surveys【47†L5-L13】.

- **Andromeda (M31):** High-quality rotation curve data for M31 extend well beyond its optical disk. A recent study assembled **13,679** stellar and gas tracers (using data from surveys like LAMOST DR9 and DESI) to measure M31’s rotation curve out to ~125 kpc【8†L51-L59】. Earlier radio observations (H I 21-cm and optical emission lines) had established M31’s rotation up to ~35 kpc. The data are available in the literature (e.g. Chemin et al. 2009; Corbelli et al. 2010) and in archives such as NED and the SPARC database【1†L7-L12】.

- **Triangulum (M33):** M33’s rotation curve has been measured through combined optical and 21-cm radio data. Extended H I mapping shows the curve out to ~16 kpc (about 13 disk scale lengths)【9†L13-L17】. These data (e.g. Corbelli &amp; Salucci 2000; Putman et al. 2009) are included in compilations like SPARC and THINGS. M33’s dataset is publicly available, often used as a test-case for low-mass spiral dynamics.

- **NGC 3198:** This spiral galaxy’s rotation curve is a **classic** reference. Begeman’s 21-cm study extended the rotation curve to ~11 exponential disk scale lengths (≈30 kpc)【24†L42-L49】. The H I velocity field and derived circular speeds were published (Begeman 1989) and show a flat rotation out to the dataset’s edge. Raw velocity vs radius values for NGC 3198 appear in Begeman’s thesis and subsequent papers, and are also in modern databases (SPARC【1†L7-L12】, THINGS). 

- **NGC 2403:** Another well-studied nearby spiral, NGC 2403’s rotation was mapped in detail by the THINGS survey (de Blok et al. 2008) with high resolution. Data extend to ~25 kpc and are noted for remaining flat far into the outer H I disk【28†L123-L131】. The SPARC catalog【1†L7-L12】 also provides NGC 2403’s rotation curve and mass model. Hα data (e.g. Blais-Ouellette et al. 2004) complement the H I curve in the inner regions.

- **Dwarf Galaxies (e.g. DDO 154, NGC 3109):** Small gas-rich dwarfs provide rotation curves that are vital for dark matter studies. **DDO 154** is a famous example: Carignan &amp; Freeman (1988) measured its H I rotation out to ~7.6 kpc (≈15 optical scale lengths)【61†L299-L307】. The data (radius vs velocity) show a gently rising curve that persists to the galaxy’s edge. Likewise, **NGC 3109** (a dwarf spiral) has H I data out to ~12 kpc; its rotation reaches ~80 km/s at that radius【53†L4-L12】. These dwarfs’ rotation curve datasets are publicly available (some are included in SPARC and the LITTLE THINGS survey). 

## Rotation Curve Properties and Mass Distribution

Using the above data, we summarize key rotation curve properties for each galaxy, along with their baryonic mass distribution and the discrepancy with Newtonian (visible-mass-only) expectations. Table 1 highlights the observed rotation speeds and extents, and Table 2 compares estimated stellar/gas masses and the inferred dark matter contribution.

**Table 1 – Observed Rotation Curve Characteristics** (orbital velocity and extent of measurements):

| **Galaxy**             | **Max/Flat Rotation Speed** | **Extent of Measured Curve**                     | **Behavior at Outer Radius**               |
|------------------------|----------------------------|--------------------------------------------------|--------------------------------------------|
| **Milky Way**          | ~230 km/s (at ~8 kpc)       | Flat out to ~25–30 kpc【47†L7-L15】               | Slight decline beyond ~30 kpc; measured to ~100 kpc (using halo tracers)【47†L7-L15】. |
| **Andromeda (M31)**    | ~220 km/s                  | Flat ~up to 25 kpc; data out to ~125 kpc         | Gradual decline to ~170 km/s at 125 kpc【8†L61-L69】 (outer halo).                 |
| **Triangulum (M33)**   | ~120 km/s                  | Measured out to 16 kpc (≈13 scale lengths)【9†L13-L17】 | Still rising at 16 kpc (not yet flat)【9†L13-L17】, suggesting more mass further out. |
| **NGC 3198**           | ~150 km/s                  | Flat from ~5 kpc out to ~30 kpc (≈11 scale lengths)【24†L42-L49】 | Remains flat at last measured point【24†L42-L49】 (no downturn out to 30 kpc). |
| **NGC 2403**           | ~135 km/s                  | Flat out to ~20–25 kpc (up to ~15–20 scale lengths)【28†L123-L131】 | Stays roughly flat at outermost radius【28†L123-L131】 (no Keplerian drop).    |
| **DDO 154 (dwarf)**    | ~50 km/s                   | Measured to ~7.6 kpc (≈15 scale lengths)【61†L299-L307】 | Slight fall-off hinted at edge; rotation dominated by dark mass at all radii【61†L279-L288】【61†L299-L307】. |
| **NGC 3109 (dwarf)**   | ~80 km/s                   | Measured to ~12 kpc                              | Still rising at 12 kpc【53†L4-L12】; entirely dark-matter dominated at outer parts【40†L1-L8】. |

**Table 2 – Mass Distribution and Discrepancy** (approximate baryonic masses and dark matter dominance):

| **Galaxy**        | **Stellar Mass (M★)**      | **Gas Mass (M&lt;sub&gt;gas&lt;/sub&gt;)**    | **Dark Matter Discrepancy**                          |
|-------------------|---------------------------|--------------------------|------------------------------------------------------|
| **Milky Way**     | ~5–6×10^10 M⊙ (disk+bulge) | ~1×10^10 M⊙ (ISM gas)    | *Observed* rotation curve stays high beyond where visible mass would predict a decline. Even within the inner ~8 kpc, models without dark matter cannot fit the data【6†L25-L33】. A massive dark halo (M_&lt;sub&gt;halo&lt;/sub&gt; ~5×10^11 M⊙ inside ~100 kpc) is required, making total mass ~1–1.3×10^12 M⊙. (Dark-to-luminous mass ratio on galactic scale ~5:1, though within the optical disk it’s lower at ~2–3:1【6†L5-L13】.) |
| **Andromeda (M31)** | ~1×10^11 M⊙ (stars)       | ~1×10^10 M⊙ (gas)        | Rotation curve is flat out to 25 kpc at ~220 km/s, far exceeding the speed from baryons alone. A dark halo of *virial mass* ~1.1×10^12 M⊙ is inferred【8†L61-L69】. A distinctive “bump” in the curve at ~14 kpc is attributed to a ring of neutral gas and stars, but the sustained high velocities beyond that demand a massive dark matter halo. |
| **Triangulum (M33)** | ~5–6×10^9 M⊙ (stars)      | ~1–2×10^9 M⊙ (gas)       | A low-mass spiral with a high gas fraction. The inner rotation is partly supported by the sizable gas disk (stellar and gas contributions are *comparable* in the inner regions)【9†L13-L17】. Nonetheless, the observed speeds (~120 km/s at 16 kpc) greatly exceed what the baryons (total ~10^10 M⊙) can produce. A dark halo of mass ≥5×10^10 M⊙ is needed【9†L13-L17】, making M33’s outer regions strongly dark matter dominated. |
| **NGC 3198**      | ~3×10^10 M⊙ (stars)       | ~5×10^9 M⊙ (gas)         | A luminous spiral with a extended flat curve. **Discrepancy:** Beyond ~10 kpc, the rotation velocity (~150 km/s) stays high while the visible mass would yield ~90 km/s or less. At the last measured radius (~30 kpc), the enclosed *dark-to-luminous mass ratio* is ≈4:1【61†L299-L307】. In other words, ~80% of the mass within 30 kpc is dark. The total mass-to-light ratio rises from ~&lt;10 in the inner galaxy to ~18 (in solar units) at the outskirts【61†L299-L307】. |
| **NGC 2403**      | ~1×10^10 M⊙ (stars)       | ~2×10^9 M⊙ (gas)         | A moderate-size spiral with no bulge. The inner ~5 kpc rotation is largely baryon-driven (the disk’s mass accounts for the central rise), but beyond the optical disk the observed curve stays flat (~135 km/s) instead of dropping. This galaxy held the “record” for furthest extent of flat rotation (out to ~20 scale lengths)【28†L123-L131】. The *dark matter halo* contributes increasingly with radius, dominating the outer ~20 kpc. Newtonian models with only the ~1.2×10^10 M⊙ of visible matter cannot reproduce the flat curve – a massive halo (M_dark on the order of 10^11 M⊙) is invoked in models. |
| **DDO 154**       | ~5×10^7 M⊙ (stars)        | ~2.7×10^8 M⊙ (H I gas)【61†L271-L279】 | An extreme case of a “dark” galaxy. DDO 154’s stellar disk is puny; its gas disk dominates the baryonic mass. Yet even gas plus stars (~3.2×10^8 M⊙ total) cannot explain its ~50 km/s rotation speed. Nearly all the gravitational pull comes from a dark halo. By the outermost point (7.6 kpc), **dark mass is ~12 times the luminous mass**【61†L299-L307】, and the *global* mass-to-light ratio is an astonishing ~80 (in solar units)【61†L299-L307】. In short, the visible matter is only a **minor component** of the galaxy’s total mass【33†L1-L8】. |
| **NGC 3109**      | ~3×10^8 M⊙ (stars)        | ~2×10^8 M⊙ (gas)         | A dwarf spiral on the edge of the Local Group. Its rotation curve reaches ~80 km/s at 12 kpc and was still climbing there【53†L4-L12】. Dynamical models indicate that *at the last measured point NGC 3109 is entirely dominated by dark matter*【40†L1-L8】. The luminous mass (a few ×10^8 M⊙) contributes only a small fraction of the gravity required. Dark matter must be present at **all radii** to sustain the observed speeds (NGC 3109’s halo is less massive overall than a giant spiral’s, but relatively more important compared to its faint stellar disk). |

*(Note: Stellar and gas masses above are order-of-magnitude estimates compiled from literature; actual values depend on assumptions like stellar mass-to-light ratio and distance. “Dark matter discrepancy” qualitatively compares observed rotation support with that from baryonic matter alone.)*

## Classical Dynamics vs. Dark Matter and Alternative Explanations

**Classical Newtonian dynamics (with only visible mass)** fails to explain the observed rotation curves of these galaxies. In a purely Newtonian scenario, the rotational speed $v(r)$ should drop with radius once the majority of a galaxy’s mass is enclosed (following a Keplerian decline $v \propto r^{-1/2}$ outside the mass distribution). Indeed, if “what you see is what you get,” one would expect orbital speeds to **peak in the inner regions** (where the starlight is concentrated) and then decrease at larger radii【26†L86-L94】. For example, given the Milky Way’s luminous disk of ~6×10^10 M⊙ concentrated within ~10 kpc, classical theory would predict a rotation speed of ~200 km/s near 10 kpc dropping to &lt;150 km/s by ~30 kpc. However, observations show a very different trend: **rotation curves remain flat or even rise** well beyond the optical radii of galaxies【26†L76-L84】【28†L123-L131】.

The galaxies in our list epitomize this behavior. Large spirals like M31, the Milky Way, NGC 3198, and NGC 2403 all have extended **flat rotation curves**: the orbital velocity stays roughly constant out to the furthest measured radii. For instance, M31 rotates at ~220 km/s out to 25 kpc before slowly declining to ~170 km/s at 125 kpc【8†L61-L69】. In the Milky Way, the curve is flat (~230 km/s) to at least ~30 kpc【47†L7-L15】; some analyses suggest a mild decline further out, but not the steep drop expected without dark matter【47†L7-L15】. NGC 3198’s curve stays ~150 km/s even at ~11 disk scale lengths from its center【24†L42-L49】. Perhaps most striking, NGC 2403’s rotation remains ~constant to ~20 scale lengths【28†L123-L131】 – far beyond where its starlight appreciably contributes. 

Small **dwarf galaxies** provide an even stronger test: DDO 154 and NGC 3109 show significant rotation speeds despite having very little visible mass. DDO 154’s luminous matter produces only a few tens of km/s of rotation, yet ~50 km/s is observed at the outskirts; clearly, *additional unseen mass* must be providing the gravitational pull【61†L279-L288】【61†L299-L307】. In NGC 3109, essentially the **entire rotation curve is dominated by dark matter** – the contribution of stars and gas is negligible compared to what is needed to reach 80 km/s at 12 kpc【40†L1-L8】.

These discrepancies between observed curves and Newtonian predictions from visible mass led to the hypothesis of **dark matter halos**. In the standard framework, each galaxy is embedded in a massive, diffuse halo of non-luminous dark matter. This dark matter’s gravity provides the extra centripetal force to keep rotation curves flat. The dark halos inferred for the galaxies above are enormous: on the order of $10^{12} M_\odot$ for the Milky Way and M31【8†L63-L66】, and tens to hundreds of billions of solar masses for the others. For example, modeling NGC 3198’s flat curve requires a halo such that dark matter is ~80% of the mass inside 30 kpc【61†L299-L307】, while DDO 154’s halo contributes &gt;90% of the mass within its measured extent【61†L299-L307】. These dark matter models elegantly explain why rotation speeds don’t fall off: the decrease in visible mass density with radius is compensated by the increasing dominance of dark matter. In essence, the *total enclosed mass* $M(r)$ continues to rise roughly linearly with radius (even as visible mass levels off), yielding an approximately flat $v(r) = \sqrt{GM(r)/r}$.

Table 2 above highlights the contrast between baryonic mass distributions and the total (dynamical) mass required. In each case, beyond a certain radius, the **dynamical mass** (inferred from $v^2 r / G$) vastly exceeds the integrated visible mass. Newtonian gravity with only the visible mass would drastically under-predict the speeds – a fact quantified by the “mass discrepancy” (ratio of total-to-luminous mass, or equivalently $(v_{\rm obs}/v_{\rm bar})^2$). For high-surface-brightness spirals like NGC 3198 and NGC 2403, the discrepancy is modest in the inner regions (where stars contribute most of the gravity) but grows to factors of ~4–5 at the outskirts【61†L299-L307】. In low-surface-brightness systems and dwarfs, the discrepancy is already large at small radii and huge by the outer radii (e.g. &gt;10:1 for DDO 154)【61†L299-L307】. This general pattern – *flat rotation curves implying much more mass than meets the eye* – is observed across hundreds of galaxies【26†L76-L84】 and is a cornerstone of the dark matter paradigm in cosmology.

**Dark matter halo models** have been refined to match these rotation curves in detail. Typically, a spherical halo density profile (such as an isothermal sphere or NFW profile from $\Lambda$CDM simulations) is assumed, alongside the observed distributions of stars and gas. By adjusting halo parameters (central density, scale radius, etc.), one can fit the observed $v(r)$ curve. For example, fitting DDO 154’s curve yields a well-constrained isothermal halo with core radius ~$3$ kpc and central density $0.016 M_\odot/\text{pc}^3$【61†L273-L281】【61†L289-L297】. More massive galaxies like NGC 3198 can also be fit by halos (often requiring a **“cored” or flat-density inner profile for best results in dwarfs, versus cuspy NFW profiles predicted by simulations – an active research area). 

Notably, the dark matter explanation not only **explains the flatness** but also other features: for instance, the slight declines observed at the farthest edges (M31’s drop to 170 km/s, or hints of DDO 154’s drop-off) can indicate we’re approaching the edge of the dark halo (where mass no longer rises as steeply)【61†L303-L311】. The inferred total masses (virial masses) of halos correlate with galaxy size, fitting into the hierarchical structure formation picture (dwarfs reside in ~$10^{10}$–$10^{11} M_\odot$ halos, large spirals in ~$10^{12} M_\odot$ halos, etc.).

**Alternative theories** have also been proposed to reconcile the rotation curve paradox *without dark matter*. The most notable is **Modified Newtonian Dynamics (MOND)**, which posits that Newton’s law of gravity (or inertia) changes behavior at very low accelerations (below a_0 ~ 1.2×10^-10 m/s^2). In MOND, the effective gravity from the visible mass is boosted in the low-acceleration outskirts of galaxies, producing flat rotation curves without invoking unseen mass. Remarkably, MOND can fit many rotation curves by adjusting the stellar mass-to-light ratios, and it naturally reproduces the observed tight correlation between baryonic mass distribution and rotation (the **Radial Acceleration Relation**). For example, MOND fits to NGC 3198 and NGC 2403 were shown to match the data fairly well (Begeman et al. 1991) once the appropriate $a_0$ is chosen. The existence of a universal acceleration scale (as indicated by the fact that the “discrepancy” appears below a certain acceleration in all galaxies) is seen as supportive of MOND or other modified-gravity theories. However, alternative theories face challenges explaining all observations (e.g. MOND struggles with galaxy clusters and the cosmic web, and requires additional phenomena like neutrino halos or modified inertia).

In summary, **classical dynamics alone cannot account for the rotation curves** of galaxies from dwarfs to giants. The observed curves are flat (or rising) rather than Keplerian, indicating a substantial discrepancy between visible mass and total gravitating mass. The favored solution in the standard paradigm is massive dark matter halos enveloping each galaxy, and indeed, when one adds a dark halo component to the mass models, the rotation curves of the Milky Way, M31, M33, NGC 3198, NGC 2403, etc., can be well reproduced【26†L90-L98】. The dark matter hypothesis has the strength of also aligning with cosmological evidence (e.g. cosmic microwave background, large-scale structure) when dark matter is predominantly non-baryonic and cold. **Alternative frameworks** like MOND tweak the laws of gravity to eliminate the need for dark matter, and they too can explain many features of galaxy rotation curves, though they remain outside the mainstream consensus. 

The current state of research involves ever more detailed rotation curve measurements (e.g. using gas 21-cm surveys, integral field spectroscopy for stellar kinematics, and even **halo stars &amp; satellite galaxies to probe out to 100+ kpc**) to map out the mass distribution. Recent high-resolution data and meta-analyses (like the SPARC database【1†L7-L12】) have revealed a surprising uniformity: a strong correlation between the distribution of baryons and the resulting rotation, sometimes dubbed a “fine-tuning” that any successful theory must explain. Dark matter models address this by invoking the process of galaxy formation (where baryons settle in the centers of halos, yielding the observed rotation curves), while MOND-like theories build it into the force law. 

Ultimately, **rotation curve data provide a critical test for any model**. In our context, these datasets will be used to apply a resonance coherence equation for model validation. The high-resolution rotation curves and mass models compiled above allow one to compute expected orbital frequencies, resonances, and other dynamical quantities for each galaxy. By comparing these observational benchmarks (velocity vs radius profiles, mass distributions) against theoretical predictions – whether a dark matter halo model or a modified dynamic resonance model – we can assess how well each theory coherently explains the full picture. The evidence so far strongly favors a substantial non-luminous mass component in galaxies【24†L42-L49】【26†L86-L94】, but the door remains open for novel interpretations, provided they can match the **clarity and completeness** of the rotation curve data now in hand.

**Sources:** Observational data and analyses are drawn from academic papers and surveys, including Begeman (1989) for NGC 3198【24†L42-L49】, Carignan &amp; Freeman (1988) for DDO 154【61†L299-L307】, Lelli et al. (2016, SPARC)【1†L7-L12】, de Blok et al. (2008, THINGS), Zhang et al. (2024) for M31’s extended rotation【8†L61-L69】, and compiled in review works by Sofue &amp; Rubin (2001) and Courteau et al. (2014). These provide the high-resolution rotation curves and mass models used above. The narrative synthesis is based on these data, highlighting the need for dark matter to reconcile **observations vs. Newtonian predictions**, while also noting alternative explanations (MOND) that have been explored in the literature【26†L86-L94】.

---

