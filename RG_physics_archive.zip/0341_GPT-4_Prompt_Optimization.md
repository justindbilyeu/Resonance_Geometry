# GPT-4 Prompt Optimization.

- Conversation ID: acf7ce29-beeb-4cc5-ba8f-161b2e83e22f
- Created: 2023-05-01T19:14:27.415666

---

**user:**

As an expert in prompt generation with a focus on creating prompts tailored for GPT-4, you are tasked with evaluating, correcting, and optimizing prompts provided by the user. Rate each prompt on a scale of 0-10 based on its ability to generate accurate, truthful, poignant, and citable information. You will report this rating to the user, make a list of the flaws in the prompt, and ask questions of the user in order to collect information needed to optimize the prompt. When you have the information you require in order to generate the perfect prompt, put that prompt into a text box.

---

**assistant:**

To help you with this task, please provide me with the prompts that you would like me to evaluate, correct, and optimize. Once I have the prompts, I will rate them, list their flaws, and ask questions as needed to gather information for optimization.

---

**user:**

Here is the prompt:
As an expert in [Solar Energy Marketing] specializing in [residential systems], you are tasked with creating a marketing strategy targeting [roofing company owners or executives] and their sales staff. Your goal is to promote a comprehensive learning module and teaching system that will generate a new revenue stream, in the [Solar Energy] industry for their existing [Roofing] sales force, incorporating their existing customers. What additional information do you need, and what steps would you take to develop an effective marketing strategy?

---

**assistant:**

Rating: 7/10

Flaws in the prompt:
1. Overuse of brackets: The brackets can make the prompt less natural to read and might create confusion in understanding the context.
2. Ambiguity in the target audience: It is unclear if the marketing strategy should target both roofing company owners or executives and their sales staff, or if separate strategies should be created for each group.

Questions to collect information for optimization:
1. Is the goal to target both roofing company owners or executives and their sales staff, or should we focus on one specific group?
2. What is the primary objective of the learning module and teaching system? Is it to train the sales force on solar energy systems, or to help them better sell the solar energy systems?
3. Are there any unique selling points or features of the learning module and teaching system that should be highlighted in the marketing strategy?

Optimized prompt:
As an expert in Solar Energy Marketing specializing in residential systems, you are tasked with creating a marketing strategy targeting roofing company owners or executives and their sales staff. Your goal is to promote a comprehensive learning module and teaching system that will generate a new revenue stream in the Solar Energy industry for their existing Roofing sales force, incorporating their existing customers. Considering the objective of the learning module and teaching system and the unique features it offers, what additional information do you need and what steps would you take to develop an effective marketing strategy?

---

