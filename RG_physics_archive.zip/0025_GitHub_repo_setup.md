# GitHub repo setup

- Conversation ID: 68d7ca30-531c-8322-92a8-c286fca6a2b1
- Created: 2025-09-27T11:27:45.022330

---

**user:**

Hey Sage!  I created a GitHub repo that will be our main hub for building a hub for our work as Project Manager and Quality Conteol Specialist for Texas Choice Roofing. Are you ready to help?

---

**assistant:**

✅ Perfect! We’re all set to use your GitHub repo as the **main hub for Texas Choice Roofing**. I see you’ve already uploaded the starter files (`index.md`, `_config.yml`, `style.css`, etc.)【16†_config.yml†L1-L22】【17†style.css†L1-L12】【18†_config.yml†L1-L25】—so the foundation is ready.  

---

### STATE  
Next step: we’ll customize the site for **Texas Choice Roofing** by filling in your company details (bio, offers, contact info, etc.) inside `_config.yml` and `index.md`.

---

### DELIVER  
Here’s what I’ll need from you (you can skip any for now):  
- **Name(s) + Role(s):** (e.g., “John Smith — Project Manager”)  
- **Tagline:** One-sentence pitch (e.g., “Trusted roofing partner for Texas homeowners”).  
- **Contact Info:** Email, phone, calendar link (if you want).  
- **Social Links:** (LinkedIn, Facebook, etc.)  
- **Portfolio:** Any jobs/projects you want featured.  
- **Testimonials:** If you have client quotes.  
- **Headshot or Logo:** (URL or file upload).  
- **Brand Color (optional):** I see red `#C81E1E` is already set for roofing branding【18†_config.yml†L6-L10】.  

---

### VERIFY  
I see in your config file we already have some default **offers** and **skills** written specifically for roofing services【18†_config.yml†L11-L25】. Do you see those in your copy?  

---

### ASK  
👉 Do you want me to set up the site as **Lane A (1-page fast launch)** or jump straight to **Lane B (Portfolio + Testimonials)** for a fuller company hub?

---

**tool:**

All the files uploaded by the user have been fully loaded. Searching won&#x27;t provide additional information.

---

**user:**

Wait. Here is the repo:

https://github.com/justindbilyeu/PM-QC-TCR

---

**assistant:**

Got it ✅ — I see your repo here: [PM-QC-TCR](https://github.com/justindbilyeu/PM-QC-TCR)【23†source】.  

---

### STATE  
Now we’ll turn this repo into a **live GitHub Pages site** for Texas Choice Roofing project management + QC.

---

### DELIVER  
Steps (desktop):  
1. In your repo → **Settings** tab.  
2. Scroll left menu → **Pages**.  
3. Under “Build and deployment”:  
   - Source: **Deploy from branch**  
   - Branch: **main** / **root**  
4. Save → wait ~1 min.  

Your site will publish at:  
👉 **https://justindbilyeu.github.io/PM-QC-TCR/**  

---

### VERIFY  
Once you enable Pages, you’ll see a green check and the live URL at the top of Settings → Pages.  

---

### ASK  
Do you want this hub to stay **internal/project-focused** (tools, schedules, docs) or also serve as an **external-facing site** (offers, client info)?

---

**user:**

Yes this is an internal/project focused. 

Check the repo again, it only contains a readme file. This GitHub report will also or more often serve as a place for us to try and automate through Kodex prompting and LLMs to… Basically, I’m gonna be able to integrate you make some automations that like check my email update my calendar track my time and locations give reminders, etc.. Does that make sense?

---

**assistant:**

Awesome—yes, that makes total sense. We’ll keep this repo as an **internal PM + QC hub** and also scaffold it so we can plug in LLM-powered automations (email triage, calendar nudges, time/location logs, reminders).

---

### STATE  
First, we’ll turn your empty repo into a simple **dashboard + automations skeleton** so it’s useful today and ready for LLM workflows tomorrow.

---

### DELIVER  
Follow these quick “add file → paste → commit” steps. (Desktop GitHub UI)

**A) Create a clean repo structure**

1) In your repo → **Add file → Create new file**  
Create: `index.md`  
Paste:

```markdown
# Texas Choice Roofing — PM + QC Hub

Welcome! This internal hub centralizes schedules, checklists, automations, and notes.

## Quick Links
- 📅 [Schedules &amp; Calendars](docs/schedule.md)
- ✅ [Checklists &amp; SOPs](docs/checklists.md)
- 🧠 [Prompts (LLM / “Kodex” / Codex)](prompts/README.md)
- 🤖 [Automations](automations/README.md)
- 📝 [Daily Notes](docs/daily-notes.md)
- 🗂️ [Project Index](docs/projects.md)

---

### Status Board (manual notes for now)
- Today: _(add top 3 priorities)_
- Risks: _(list blockers)_
- Wins: _(log completions)_

&gt; Tip: This site can be published via GitHub Pages if you want a clean web view (optional).
```

Commit to **main**.

2) **Add docs folder and starter pages**  
Add file → Create new file: `docs/checklists.md`  
Paste:

```markdown
# Checklists &amp; SOPs

- Pre-Job Walk Checklist
- In-Progress QC Checklist
- Final Walk &amp; Photo Package
- Insurance Claim Documentation Steps
- Material Delivery &amp; Load Checklist

&gt; Add bullets under each, then convert to task lists `- [ ] item` as needed.
```

Add file → Create new file: `docs/schedule.md`
```markdown
# Schedules &amp; Calendars

**Master calendar lives in Google Calendar.**  
This page will show sync summaries from automations (e.g., tomorrow&#x27;s jobs, crew assignments).

- Upcoming jobs (auto) → _planned via automation_
- Inspections (auto) → _planned via automation_
- Time blocks (focus / drive / site)
```

Add file → Create new file: `docs/daily-notes.md`
```markdown
# Daily Notes

Use this as a rolling log. Automations can append “AM Brief” + “PM Wrap” here.

## Template
- Priorities:
- Sites today:
- Materials:
- Risks/blockers:
- Notes:
```

Add file → Create new file: `docs/projects.md`
```markdown
# Project Index

List addresses / job names, link issues or folders.

- 123 Main St — Shingle replace — [Issue #12](../issues/12)
- 456 Oak Ave — Storm repair — [Issue #15](../issues/15)
```

3) **Prompts folder (for your “Kodex/Codex” prompt packs)**  
Add file: `prompts/README.md`
```markdown
# Prompt Packs

Central place for LLM/agent prompts used in automations.

## 1) Email → AM Triage Summary
Goal: summarize unread emails, extract jobs, dates, addresses, action items.
- Style: concise bullets, label `[JOB]`, `[DATE]`, `[ADDR]`, `[ACTION]`
- Output target: `docs/daily-notes.md` under “AM Brief”

## 2) Calendar Nudge
Goal: scan calendar gaps next 3 days, suggest 30–60m focus blocks near job sites.
- Output target: comment on this repo via workflow summary

## 3) Time/Location Log Normalizer
Goal: normalize phone POSTs (Shortcuts) into: date, start/end, site, miles.
- Output target: append CSV row to `automations/time-log.csv`
```

4) **Automations folder + seed files**  
Add file: `automations/README.md`
```markdown
# Automations

This repo uses GitHub Actions on a schedule to:
- Email → AM triage summary (Gmail API + LLM)
- Calendar → Tomorrow preview
- Time/Location → From phone shortcut into CSV

&gt; Secrets needed (Settings → Secrets and variables → Actions):
- OPENAI_API_KEY (or other LLM provider)
- GMAIL_CLIENT_ID, GMAIL_CLIENT_SECRET, GMAIL_REFRESH_TOKEN
- CALENDAR_ID (Google Calendar)
```

Add file: `automations/time-log.csv`
```csv
date,start,end,site,address,miles,notes,source
```

5) **Scheduled workflow (runs in the cloud)**  
Add file: `.github/workflows/daily-digest.yml`  
Paste:

```yaml
name: Daily AM Digest
on:
  schedule:
    - cron: &quot;30 12 * * 1-6&quot;  # 12:30 UTC ≈ 7:30 AM America/Chicago (adjust as needed)
  workflow_dispatch:

permissions:
  contents: write

jobs:
  digest:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: &quot;3.11&quot;

      - name: Install deps
        run: |
          python -m pip install --upgrade pip
          pip install google-api-python-client google-auth-httplib2 google-auth-oauthlib openai python-frontmatter

      - name: Run AM digest
        env:
          OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
          GMAIL_CLIENT_ID: ${{ secrets.GMAIL_CLIENT_ID }}
          GMAIL_CLIENT_SECRET: ${{ secrets.GMAIL_CLIENT_SECRET }}
          GMAIL_REFRESH_TOKEN: ${{ secrets.GMAIL_REFRESH_TOKEN }}
          CALENDAR_ID: ${{ secrets.CALENDAR_ID }}
        run: |
          python scripts/am_digest.py

      - name: Commit updates (daily-notes, logs)
        run: |
          git config user.name &quot;pm-qc-bot&quot;
          git config user.email &quot;actions@users.noreply.github.com&quot;
          git add docs/daily-notes.md automations/time-log.csv || true
          git commit -m &quot;AM digest update&quot; || echo &quot;No changes&quot;
          git push
```

&gt; Notes: GitHub Actions can run on a schedule (`on.schedule`) and manually (`workflow_dispatch`). Cron uses **UTC** times; adjust to hit your preferred AM/PM in Central Time. citeturn3search0turn3search2  
&gt; Scheduled workflows are fine for this use case, and you can always run them by hand from the **Actions** tab. citeturn3search9

6) **Script: AM digest (email + calendar → notes)**  
Add file: `scripts/am_digest.py`
```python
import os, datetime
from pathlib import Path

# —— placeholders: you’ll wire Gmail/Calendar API auth here.
# Keep secrets in GitHub → Settings → Secrets (never commit keys).
# For now, we just append a demo section so you see the flow.

NOTES = Path(&quot;docs/daily-notes.md&quot;)
today = datetime.date.today().strftime(&quot;%Y-%m-%d&quot;)

section = f&quot;&quot;&quot;
## AM Brief — {today}

**Email Triage (demo)**  
- [JOB] Example Roof — 123 Main St — [ACTION] Confirm crew ETA  
- [JOB] Gutters — 456 Oak Ave — [ACTION] Order 5” K-style, 80ft

**Calendar (demo)**  
- 09:00–10:00: Final walk @ Main St  
- 10:30–12:00: Material check @ Oak Ave

---
&quot;&quot;&quot;

text = NOTES.read_text(encoding=&quot;utf-8&quot;) if NOTES.exists() else &quot;# Daily Notes\n\n&quot;
NOTES.write_text(text + &quot;\n&quot; + section, encoding=&quot;utf-8&quot;)
print(&quot;Wrote AM Brief to docs/daily-notes.md&quot;)
```

(We’ll swap this demo with real Gmail/Calendar reads when you’re ready to add credentials.)

7) **Optional: turn on GitHub Pages for a clean internal view**  
If you want a nicer web view of your hub (public or private depending on your plan), enable Pages:

- Repo **Settings → Pages → Deploy from branch → main / root → Save.**  
- Entry file can be `index.md`. Pages sites are static and publicly reachable by default; private publishing has plan requirements—use with care for internal info. citeturn1search4turn1search0turn1search5

---

### VERIFY  
After adding the workflow file, go to the **Actions** tab—do you see **“Daily AM Digest”** listed? If yes, click it and run **“Run workflow”** once to verify it commits to `docs/daily-notes.md`. citeturn3search9

---

### ASK  
Which do you want to wire up first for real data:  
1) **Email triage** (Gmail → AM summary),  
2) **Calendar preview**, or  
3) **Time/location logging** (from your phone via a simple shortcut → CSV)?  

Pick one and I’ll drop in the exact credentials steps + finalized script next.

---

**user:**

Let’s prompt the CODEX to do these tasks for us

---

**assistant:**

awesome — “Codex” prompt packs coming right up. We’ll write crystal-clear prompts you can paste into your repo so agents know exactly what to do.

---

### STATE  
We’ll add a **/prompts** folder with ready-to-use prompt files for: Email Triage, Calendar Preview, Time/Location Normalizer, Reminders, and Commit Summaries.

---

### DELIVER  
**Where to put these:** In your repo → **Add file → Create new file** under `prompts/…` (one file per section below).  
Each file includes: role, variables to fill, output format, and an example.

---

#### 1) `prompts/email-triage.md`
```
# Email → AM Triage Summary (System Prompt)

ROLE
You are an operations assistant for a roofing company (Texas Choice Roofing). You read unread emails and produce an actionable AM brief.

INPUT
- Email threads in plain text or JSON with fields: from, subject, snippet/body, date, labels.
- Known job keywords: addresses, claim #, crew names, material SKUs.

TASKS
1) Extract jobs, addresses, dates, customer names, vendors, and next actions.
2) Flag anything time-sensitive or missing info.
3) Group by job and order by urgency.

OUTPUT (MARKDOWN)
- Title: &quot;AM Brief — {{date}}&quot;
- Sections: **Email Triage**, **Follow-ups**, **Waiting On**, **Risks**
- Bullet format:
  - [JOB] &lt;short job name&gt; — &lt;address&gt; — [DATE] &lt;yyyy-mm-dd&gt; — [ACTION] &lt;clear next step&gt;
  - Add links if present. Keep each bullet ≤ 160 chars.

RULES
- Be concise; no fluff.
- If no job/address found, write [JOB] General.
- If date/time is implied (e.g., “tomorrow”), resolve to a specific date using {{timezone}}.

VARIABLES
- {{date}} (yyyy-mm-dd)
- {{timezone}} (e.g., America/Chicago)

EXAMPLE OUTPUT
## Email Triage
- [JOB] Main St — 123 Main St — [DATE] 2025-09-27 — [ACTION] Confirm crew ETA with Jose
- [JOB] Oak Ave — 456 Oak Ave — [ACTION] Send material order for 80’ 5&quot; K-style gutters
```

---

#### 2) `prompts/calendar-preview.md`
```
# Calendar → Tomorrow Preview (System Prompt)

ROLE
You analyze the next 1–3 days of the Google Calendar and propose a tight plan around job sites.

INPUT
- Events: title, start/end (ISO), location, description, attendees.
- Drive times (optional) or city names to infer proximity.

TASKS
1) List tomorrow’s events in order with times and locations.
2) Identify gaps ≥ 30m and suggest on-site or admin focus blocks near existing sites.
3) Call out conflicts or tight turnarounds (&lt; 15m travel).

OUTPUT (MARKDOWN)
### Calendar Preview — {{date}}
- 09:00–10:00 Final walk @ 123 Main St
- 10:30–12:00 Materials check @ 456 Oak Ave
**Suggestions**
- 12:30–1:00 On-site photos @ Oak Ave
- 3:30–4:00 Claims paperwork (remote)

RULES
- Use local time {{timezone}}.
- Keep to bullets; 6–10 lines max.

VARIABLES
- {{date}} (tomorrow’s date)
- {{timezone}}
```

---

#### 3) `prompts/time-location-normalizer.md`
```
# Time/Location Log Normalizer → CSV (System Prompt)

ROLE
You convert messy phone/location posts into a clean CSV row for a work log.

INPUT
- Free text or JSON containing: date/time, address or site name, duration or start/end, notes, odometer or miles.

TASKS
1) Parse start/end times (infer if only duration given).
2) Resolve locations to a simple site label (e.g., &quot;Main St Roof&quot;, &quot;Yard/Shop&quot;).
3) Calculate miles if start/stop odometer provided; else leave blank.
4) Return a single CSV row (no header).

OUTPUT (CSV ROW ONLY)
{{date}},{{start}},{{end}},{{site}},{{address}},{{miles}},{{notes}},phone

RULES
- Use 24h time (HH:MM).
- If a field is unknown, leave it empty but keep commas.
- Never output extra commentary—CSV row only.

EXAMPLE INPUT
&quot;9/27 8:40-10:15 @123 Main St, final walk, 12.4 mi&quot;

EXAMPLE OUTPUT
2025-09-27,08:40,10:15,Main St Roof,123 Main St,12.4,final walk,phone
```

---

#### 4) `prompts/reminder-agent.md`
```
# Reminder Agent (System Prompt)

ROLE
You convert tasks into smart reminders with due dates and nudge times.

INPUT
- Task text with optional dates/times, e.g., &quot;Email claim photos to Allstate by Fri 3pm&quot;.

TASKS
1) Extract task, hard due date/time, and urgency.
2) Propose 1–2 pre-due nudges (e.g., 24h before, 1h before).
3) Tag with a context: site/office/phone.

OUTPUT (JSON)
{
  &quot;task&quot;: &quot;&lt;string&gt;&quot;,
  &quot;due_iso&quot;: &quot;&lt;YYYY-MM-DDTHH:MM:SS-05:00&gt;&quot;,
  &quot;nudges&quot;: [&quot;&lt;ISO&gt;&quot;, &quot;&lt;ISO&gt;&quot;],
  &quot;context&quot;: &quot;&lt;site|office|phone&gt;&quot;,
  &quot;notes&quot;: &quot;&lt;short&gt;&quot;
}

RULES
- Convert relative dates to absolute using {{timezone}} and {{today}}.
- Keep notes ≤ 120 chars.
```

---

#### 5) `prompts/commit-summarizer.md`
```
# Commit Summarizer for PM/QC Bot (System Prompt)

ROLE
You read changed files and produce a crisp commit summary+changelog.

INPUT
- Git diff or list of changed files with short excerpts.

TASKS
1) Create a 1-line subject (≤ 65 chars).
2) Provide a bullet changelog grouped by area (docs, automations, prompts).
3) If the change affects schedules or checklists, add a ⚠️ note.

OUTPUT (MARKDOWN)
&lt;subject line&gt;
- docs: ...
- automations: ...
- prompts: ...
```

---

#### Optional: index for your prompt packs — `prompts/README.md`
```
# Prompt Packs (Codex)

- Email → AM Triage: email-triage.md
- Calendar Preview: calendar-preview.md
- Time/Location Normalizer: time-location-normalizer.md
- Reminder Agent: reminder-agent.md
- Commit Summarizer: commit-summarizer.md

&gt; Use these with your LLM runner (manual, script, or GitHub Action). Suggested outputs feed:
&gt; - docs/daily-notes.md
&gt; - automations/time-log.csv
&gt; - issues / PR comments
```

---

### VERIFY  
After creating these files, in GitHub click the **Code** tab → you should see a **`prompts/`** folder with the five `.md` files listed. Do you see them?

---

### ASK  
Which prompt do you want to **wire up first** with an actual workflow:  
1) **Email → AM Triage** into `docs/daily-notes.md`,  
2) **Calendar Preview** into `docs/daily-notes.md`, or  
3) **Time/Location → CSV** into `automations/time-log.csv`?  

Pick one, and I’ll drop in the exact GitHub Action step + tiny Python runner that calls the chosen prompt and writes the output to the right place.

---

**user:**

Wait. I e made an environment for CODEX to work on the repo:

https://chatgpt.com/codex/settings/environment/68d7cc9769108191bcc151d0b84a00a8

We want to prompt them to work on the repo. Do you understand?

---

**assistant:**

Yes — I understand now ✅  

You’re saying:  

- You’ve already spun up a **CODEX environment** (linked at `chatgpt.com/codex/settings/environment/...`).  
- That environment is what runs the agents (the “Codex workers”).  
- You don’t want me to just write static prompt files in the repo — you want me to **craft the right prompts to *instruct Codex*** so it can **actively work on your GitHub repo** (PM-QC-TCR) as its workspace.  

That way, instead of you copy-pasting scripts and workflows manually, Codex will receive structured instructions (prompts) to:  
- Create/edit files (`index.md`, workflows, automation scripts, prompts).  
- Push commits.  
- Wire GitHub Actions to automate email/calendar/time-logs.  

---

### STATE  
Next step is to define **Codex job prompts** that tell it *how to operate on the repo*. These are slightly different from task prompts (triage emails, calendar, etc.) — they’re **meta-instructions** for Codex on *repo work itself*.  

---

### DELIVER  
Here’s a **starter prompt you can give Codex** inside your environment (adjust names/paths as needed):  

**Prompt: Setup Repo Hub Skeleton**  
```
You are an assistant working directly inside the GitHub repo &quot;PM-QC-TCR&quot;.
Your goal: scaffold this repo into a PM/QC hub for Texas Choice Roofing.

Steps:
1. Create folders: docs/, automations/, prompts/, scripts/.
2. Add index.md at repo root with navigation to docs, prompts, automations.
3. Seed docs/checklists.md, docs/schedule.md, docs/daily-notes.md, docs/projects.md with starter templates.
4. Add automations/time-log.csv with header row.
5. Add prompts/README.md and seed at least 3 prompt files (email-triage.md, calendar-preview.md, time-location-normalizer.md).
6. Add automations/README.md with notes about GitHub Actions.
7. Create .github/workflows/daily-digest.yml with a daily cron run that executes scripts/am_digest.py.
8. Create scripts/am_digest.py that appends a demo AM Brief to docs/daily-notes.md.

Commit all with message: &quot;Initial PM/QC hub scaffold with docs, prompts, automations.&quot;
```

---

**Prompt: Extend with Workflow**  
```
You are working in PM-QC-TCR repo.
Task: Add a GitHub Actions workflow to run the &quot;calendar-preview&quot; prompt each morning.

Steps:
1. Create .github/workflows/calendar-preview.yml
2. Schedule cron at 12:30 UTC (7:30 AM CT).
3. Workflow should:
   - checkout repo
   - run a script scripts/calendar_preview.py
   - commit updates to docs/daily-notes.md

Commit message: &quot;Add calendar preview workflow.&quot;
```

---

### VERIFY  
Once Codex runs, check your repo → Code tab → you should see new folders (`docs/`, `automations/`, `prompts/`, etc.).  

---

### ASK  
👉 Do you want me to **write a full “Codex Master Prompt Pack”** (covering repo setup, workflows, scripts, and updates), so you can just drop each into Codex to progressively build this hub?

---

