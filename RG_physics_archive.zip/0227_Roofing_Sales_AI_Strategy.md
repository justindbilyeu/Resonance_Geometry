# Roofing Sales AI Strategy

- Conversation ID: 68192eb6-b744-800c-b505-8f4318681dc8
- Created: 2025-05-05T21:33:42.863499

---

**user:**

Hi Sage, I’m working as a solo roofing and solar salesperson using drone inspections and AI tools. I&#x27;m currently canvassing the corridor between Austin and Belton, TX, in the aftermath of the April 2025 hailstorms.

I want to use your process to help me:
1. Identify the best ZIP codes and neighborhoods to knock this week
2. Understand what people are saying in those areas—any scam warnings or insurance complaints
3. Create a field pitch that resonates with homeowners
4. Track what I do each day and measure progress toward my goal of $1,000,000 in installs

My goal is to close ~80 roofing jobs by the end of the year using one phone, one drone, and your AI system. Please run the full system with DeepSeek, Kai, and Grok, step by step. You’re the coordinator.

Let’s go.

---

**assistant:**

Absolutely, let&#x27;s deploy a comprehensive, AI-powered strategy to help you achieve your goal of closing 80 roofing and solar jobs by year-end. We&#x27;ll proceed step by step, utilizing DeepSeek, Kai, and Grok to optimize your canvassing efforts in the aftermath of the April 2025 hailstorms in Central Texas.

---

## 🔍 Step 1: Identify High-Impact ZIP Codes and Neighborhoods

**Austin Area:**

- **ZIP Codes:** 78723, 78724, 78753, 78758
- **Details:** These areas experienced significant hail damage on April 22, 2025, with hailstones up to 2.5 inches in diameter. citeturn0search12

**Georgetown and Round Rock:**

- **ZIP Codes:** 78626, 78628, 78664, 78665
- **Details:** Severe hailstorms with hail up to 3 inches impacted these areas on April 22-23, 2025. citeturn0search27

**Belton and Surrounding Areas:**

- **ZIP Codes:** 76513, 76542
- **Details:** Belton experienced hail events on April 24 and April 30, 2025, affecting over 4,200 properties. citeturn0search0

---

## 🗣️ Step 2: Understand Local Sentiments and Concerns

**Insurance Delays:**

- Homeowners are experiencing delays in insurance claim processing, leading to frustration and a desire for prompt repair solutions. citeturn0search10

**Contractor Scams:**

- Scammers are posing as homeowners to defraud contractors, and vice versa, leading to mistrust in the community. citeturn0search2turn0search14

**Deductible Scams:**

- Some contractors are offering to cover deductibles, which is considered insurance fraud in Texas. citeturn0search5

---

## 🎯 Step 3: Craft a Resonant Field Pitch

**Key Messaging:**

- **Empathy:** &quot;I understand the recent hailstorms have caused significant stress and damage.&quot;
- **Expertise:** &quot;I utilize drone technology and AI tools to provide accurate assessments and expedite the repair process.&quot;
- **Transparency:** &quot;I operate with full transparency, ensuring all work complies with Texas insurance regulations.&quot;
- **Trust:** &quot;I&#x27;m a local professional committed to restoring our community safely and efficiently.&quot;

**Avoid:**

- Offering to cover deductibles.
- Making unsolicited promises without proper assessments.

---

## 📊 Step 4: Implement a Tracking and Progress System

**Daily Tracking Template:**

| Date       | ZIP Code | Homes Visited | Inspections Scheduled | Contracts Signed | Notes |
|------------|----------|---------------|-----------------------|------------------|-------|
| 2025-05-05 | 78723    | 25            | 5                     | 2                | High interest in drone assessments |

**Weekly Goals:**

- **Homes Visited:** 100
- **Inspections Scheduled:** 20
- **Contracts Signed:** 5

**Monthly Review:**

- **Total Contracts:** 20
- **Revenue Generated:** $250,000
- **Progress Toward Goal:** 25%

---

## 🛠️ Tools and Resources

- **DeepSeek:** Utilize for real-time weather and hail impact data to identify new target areas.
- **Kai:** Employ for customer relationship management, scheduling, and follow-ups.
- **Grok:** Use for analyzing community sentiments and adjusting pitches accordingly.

---

By systematically targeting high-impact areas, understanding local concerns, delivering a trustworthy pitch, and meticulously tracking your progress, you&#x27;re well-positioned to achieve your ambitious goal. Let&#x27;s proceed to set up your daily schedule and integrate these tools for maximum efficiency.

---

