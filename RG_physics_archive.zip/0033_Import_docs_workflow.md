# Import docs workflow

- Conversation ID: 68d17387-4380-832d-819b-7f0e605b22c2
- Created: 2025-09-22T16:04:25.866752

---

**user:**

Can you write a workflow to import docs from https://github.com/justindbilyeu/SunShare-TriSource/tree/main/docs into https://github.com/justindbilyeu/eMSSC-squared?

---

**assistant:**

Here’s a ready-to-drop-in GitHub Actions workflow that will mirror the `docs/` folder from `justindbilyeu/SunShare-TriSource` into a subfolder of `justindbilyeu/eMSSC-squared` on a schedule (and on manual run). It checks out both repos, copies the docs, and commits only if there are changes.

Create this file in **`justindbilyeu/eMSSC-squared/.github/workflows/sync-docs.yml`**:

```yaml
name: Import docs from SunShare-TriSource

on:
  workflow_dispatch:
  schedule:
    - cron: &#x27;0 6 * * *&#x27; # daily at 06:00 UTC (adjust as needed)

permissions:
  contents: write

concurrency:
  group: sync-docs
  cancel-in-progress: false

jobs:
  sync:
    runs-on: ubuntu-latest
    env:
      # Source repo/branch and paths
      SRC_REPO: justindbilyeu/SunShare-TriSource
      SRC_REF: main         # change if the source default branch differs
      SRC_DIR: docs

      # Destination subfolder inside eMSSC-squared
      DEST_DIR: docs/SunShare-TriSource
    steps:
      - name: Checkout destination repo (eMSSC-squared)
        uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Checkout source repo (SunShare-TriSource) - sparse
        uses: actions/checkout@v4
        with:
          repository: ${{ env.SRC_REPO }}
          ref: ${{ env.SRC_REF }}
          path: _src
          fetch-depth: 0
          # Only pull the docs/ folder from the source repo
          sparse-checkout: |
            ${{ env.SRC_DIR }}
          sparse-checkout-cone-mode: true
          token: ${{ secrets.GITHUB_TOKEN }}
          # If the source repo is PRIVATE, create a Fine-grained PAT with Read access
          # to SunShare-TriSource as secret: SRC_REPO_TOKEN
          # and replace the line above with:
          # token: ${{ secrets.SRC_REPO_TOKEN }}

      - name: Sync docs into destination subfolder
        run: |
          mkdir -p &quot;${DEST_DIR}&quot;
          rsync -av --delete --exclude=&#x27;.git&#x27; &quot;_src/${SRC_DIR}/&quot; &quot;${DEST_DIR}/&quot;

      - name: Commit &amp; push if changes
        run: |
          git config user.name  &quot;github-actions[bot]&quot;
          git config user.email &quot;41898282+github-actions[bot]@users.noreply.github.com&quot;
          git add -A
          if git diff --cached --quiet; then
            echo &quot;No changes to commit.&quot;
            exit 0
          fi
          git commit -m &quot;chore(docs): sync from ${SRC_REPO}/${SRC_DIR} (@ ${SRC_REF})&quot;
          git push
```

### Notes
- By default this mirrors into `docs/SunShare-TriSource/` to avoid clobbering any existing docs. If you want it directly under `docs/`, set `DEST_DIR: docs`.
- If `SunShare-TriSource` is private, create a fine-grained PAT with read access to that repo, add it to **`eMSSC-squared`** repo secrets as `SRC_REPO_TOKEN`, and switch the `token:` line in the “Checkout source repo” step as noted in the comments.
- Adjust the cron to your preference or remove the schedule and run manually via the **Actions → Run workflow** button.

---

**user:**

Ok. Give a workflow to import from 

https://github.com/justindbilyeu/SunShare-Connect-Initiative-

---

**assistant:**

Drop this into **`justindbilyeu/eMSSC-squared/.github/workflows/sync-docs-sunshare-connect.yml`** to import the `docs/` folder from `justindbilyeu/SunShare-Connect-Initiative-`:

```yaml
name: Import docs from SunShare-Connect-Initiative-

on:
  workflow_dispatch:
  schedule:
    - cron: &#x27;0 6 * * *&#x27; # daily at 06:00 UTC

permissions:
  contents: write

concurrency:
  group: sync-docs-sunshare-connect
  cancel-in-progress: false

jobs:
  sync:
    runs-on: ubuntu-latest
    env:
      # Source repo/branch and paths
      SRC_REPO: justindbilyeu/SunShare-Connect-Initiative-
      SRC_REF: main
      SRC_DIR: docs

      # Destination subfolder inside eMSSC-squared
      DEST_DIR: docs/SunShare-Connect-Initiative
    steps:
      - name: Checkout destination repo (eMSSC-squared)
        uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Checkout source repo (SunShare-Connect-Initiative-) - sparse
        uses: actions/checkout@v4
        with:
          repository: ${{ env.SRC_REPO }}
          ref: ${{ env.SRC_REF }}
          path: _src
          fetch-depth: 0
          # Only pull the docs/ folder from the source repo
          sparse-checkout: |
            ${{ env.SRC_DIR }}
          sparse-checkout-cone-mode: true
          token: ${{ secrets.GITHUB_TOKEN }}
          # If the source repo is PRIVATE, create a Fine-grained PAT with Read access
          # to that repo as secret: SRC_REPO_TOKEN and use:
          # token: ${{ secrets.SRC_REPO_TOKEN }}

      - name: Sync docs into destination subfolder
        run: |
          if [ ! -d &quot;_src/${SRC_DIR}&quot; ]; then
            echo &quot;Source path _src/${SRC_DIR} not found. Nothing to sync.&quot;
            exit 0
          fi
          mkdir -p &quot;${DEST_DIR}&quot;
          rsync -av --delete --exclude=&#x27;.git&#x27; &quot;_src/${SRC_DIR}/&quot; &quot;${DEST_DIR}/&quot;

      - name: Commit &amp; push if changes
        run: |
          git config user.name  &quot;github-actions[bot]&quot;
          git config user.email &quot;41898282+github-actions[bot]@users.noreply.github.com&quot;
          git add -A
          if git diff --cached --quiet; then
            echo &quot;No changes to commit.&quot;
            exit 0
          fi
          git commit -m &quot;chore(docs): sync from ${SRC_REPO}/${SRC_DIR} (@ ${SRC_REF})&quot;
          git push
```

If the source uses a different branch or path, change `SRC_REF` and `SRC_DIR`. If the repo name differs (the trailing hyphen is unusual), set `SRC_REPO` to the exact owner/name.

---

**user:**

https://github.com/justindbilyeu/eMSSC2

Create a workflow to import documents from this repository

---

**assistant:**

Here’s a drop-in GitHub Actions workflow that pulls “documents” from **`justindbilyeu/eMSSC2`** into your destination repo (place this file in that repo, e.g. `justindbilyeu/eMSSC-squared/.github/workflows/sync-docs-from-eMSSC2.yml`). It looks for common docs folders (`docs`, `Documents`, `documentation`, etc.). If none are found, it falls back to top-level `*.md|*.rst|*.pdf|*.adoc` files.

```yaml
name: Import docs from eMSSC2

on:
  workflow_dispatch:
  schedule:
    - cron: &#x27;0 6 * * *&#x27; # daily at 06:00 UTC

permissions:
  contents: write

concurrency:
  group: sync-docs-from-eMSSC2
  cancel-in-progress: false

jobs:
  sync:
    runs-on: ubuntu-latest
    env:
      # Source repo (leave SRC_REF empty to use the repo&#x27;s default branch)
      SRC_REPO: justindbilyeu/eMSSC2
      SRC_REF: &quot;&quot;
      # Destination path inside this repo
      DEST_DIR: docs/eMSSC2
      # Optional: add a repo secret named SRC_REPO_TOKEN if the source repo is private
      # (Fine-grained PAT with &#x27;Contents: Read&#x27; on justindbilyeu/eMSSC2)
      SRC_REPO_TOKEN: ${{ secrets.SRC_REPO_TOKEN }}

    steps:
      - name: Checkout destination repository
        uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Clone source repository (eMSSC2)
        shell: bash
        run: |
          set -euo pipefail
          if [ -n &quot;${SRC_REPO_TOKEN:-}&quot; ]; then
            # Route https://github.com/* through a tokenized URL (avoids leaking token in logs)
            git config --global url.&quot;https://${SRC_REPO_TOKEN}@github.com/&quot;.insteadOf &quot;https://github.com/&quot;
          fi
          if [ -n &quot;${SRC_REF:-}&quot; ]; then
            git clone --depth 1 --branch &quot;${SRC_REF}&quot; &quot;https://github.com/${SRC_REPO}.git&quot; _src
          else
            git clone --depth 1 &quot;https://github.com/${SRC_REPO}.git&quot; _src
          fi

      - name: Select and stage documentation for sync
        shell: bash
        run: |
          set -euo pipefail
          SRC_ROOT=&quot;_src&quot;
          STAGE_DIR=&quot;_import&quot;
          mkdir -p &quot;${STAGE_DIR}&quot;

          # Common docs directories to try (in priority order)
          CANDIDATES=( &quot;docs&quot; &quot;Documents&quot; &quot;documentation&quot; &quot;Documentation&quot; &quot;doc&quot; &quot;Doc&quot; )
          FOUND_DIR=&quot;&quot;

          for d in &quot;${CANDIDATES[@]}&quot;; do
            if [ -d &quot;${SRC_ROOT}/${d}&quot; ]; then
              FOUND_DIR=&quot;${SRC_ROOT}/${d}&quot;
              break
            fi
          done

          if [ -n &quot;${FOUND_DIR}&quot; ]; then
            echo &quot;Found docs directory: ${FOUND_DIR}&quot;
            rsync -a --exclude=&#x27;.git&#x27; &quot;${FOUND_DIR}/&quot; &quot;${STAGE_DIR}/&quot;
          else
            echo &quot;No docs directory found; collecting top-level documentation files.&quot;
            shopt -s nullglob
            FILES=( &quot;${SRC_ROOT}&quot;/*.md &quot;${SRC_ROOT}&quot;/*.rst &quot;${SRC_ROOT}&quot;/*.pdf &quot;${SRC_ROOT}&quot;/*.adoc )
            if [ &quot;${#FILES[@]}&quot; -eq 0 ]; then
              echo &quot;No documentation files found; nothing to sync.&quot;
              # Create an empty stage so rsync --delete can clean dest if needed
              true
            else
              cp -a &quot;${FILES[@]}&quot; &quot;${STAGE_DIR}/&quot;
            fi
          fi

          mkdir -p &quot;${DEST_DIR}&quot;
          # Mirror the staged docs into the destination (delete removed files)
          rsync -av --delete &quot;${STAGE_DIR}/&quot; &quot;${DEST_DIR}/&quot;

      - name: Commit &amp; push if changes
        shell: bash
        run: |
          set -euo pipefail
          git config user.name  &quot;github-actions[bot]&quot;
          git config user.email &quot;41898282+github-actions[bot]@users.noreply.github.com&quot;
          git add -A
          if git diff --cached --quiet; then
            echo &quot;No changes to commit.&quot;
            exit 0
          fi
          git commit -m &quot;chore(docs): sync from ${SRC_REPO} ${SRC_REF:+(@ ${SRC_REF})}&quot;
          git push
```

**Notes**
- Change `DEST_DIR` if you want the docs somewhere else (e.g., set to `docs` to merge directly).
- If `eMSSC2` is private, create a fine-grained PAT with **Contents: Read** access to that repo, add it to the **destination** repo as `SRC_REPO_TOKEN` (Repository → Settings → Secrets and variables → Actions), and it will be used automatically.
- If you need a specific branch, set `SRC_REF` (e.g., `SRC_REF: main`). Leaving it empty uses the repo’s default branch.

---

