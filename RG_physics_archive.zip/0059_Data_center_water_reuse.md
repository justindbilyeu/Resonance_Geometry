# Data center water reuse

- Conversation ID: 68b37401-be0c-8320-a9a5-dda08cd122d7
- Created: 2025-08-30T21:58:27.288586

---

**user:**

I&#x27;m thinking about these data centers that are being put all over the country, like there&#x27;s one in, I think it&#x27;s North Dakota, that&#x27;s like 400 megawatts. There&#x27;s several in Texas. I&#x27;m thinking about those data centers and how how much water they use for cooling and how much power they use. Is there anybody out there working on like harvesting humidity and the solar energy and maybe using some kind of wastewater like what we&#x27;re building with this project but like on a scale that could potentially be used in those data centers? Question mark? Like a way to reuse the water that they consume for cooling with our system? Is there anybody working on something like that?

---

**assistant:**

# Scoping &amp; Alignment

**What you’re asking:** who’s already working on *closed-loop water* for hyperscale data centers (cooling-water reuse, reclaimed/“purple” water, plume/humidity harvesting, solar/waste-heat desal), and whether a Tri-Source-style system could plug in at that scale.

**Frame:** hyperscalers are moving fast on three fronts—(1) *use alternative sources* (reclaimed/treated effluent, seawater), (2) *use less or zero cooling water* (direct-to-chip, dry/air systems), and (3) *recover what’s lost* (blowdown recycling, plume capture). AWG (air humidity → water) exists, but at data-center scale it’s a top-off, not a primary source.

---

## Quick Answer

- **Yes—this is an active space.**  
  Hyperscalers (Microsoft, Amazon, Google), water majors (Veolia/SUEZ), and start-ups (Infinite Cooling, SkyH2O) are all deploying or piloting pieces of the puzzle: reclaimed water supply, on-site reuse/ZLD, plume recovery, and waste-heat-driven purification. citeturn3search10turn3search0turn7search1turn4search0

- **Reclaimed/treated wastewater is already standardizing.**  
  Examples: Loudoun Water (VA) supplies reclaimed water to data centers; San Antonio (TX) SAWS reclaimed water serves Microsoft sites; Google Douglas County (GA) polishes secondary effluent for cooling. citeturn7search5turn7search6turn4search9

- **Water-light / water-free cooling is accelerating.**  
  Microsoft’s latest design aims for **zero water for cooling** and reports average WUE ≈ **0.30 L/kWh** globally, with further cuts underway. (AWS claims even lower WUE at some sites.) Translation: some new builds won’t *need* much make-up water. citeturn1search11turn3search0turn3search11

- **Recover what you evaporate: plume capture is real.**  
  MIT-spun technology (Infinite Cooling) and membrane-condenser approaches capture water from cooling-tower plumes; DOE/NETL and SERDP/ESTCP are funding demos. citeturn6search3turn6search12turn6search16

- **Waste-heat → desal/cleanup is promising and under study.**  
  Membrane distillation (MD) runs on **low-grade heat** from servers/liquid loops; recent analyses model MD driven by data-center waste heat for desal/reuse. That’s the closest analog to our Tri-Source thermal loop. citeturn5search1turn5search4turn5search0

- **AWG (humidity harvesting) exists at industrial scale, but…**  
  Units like SkyH2O’s *Maximus* claim ~10,500 L/day (~2,775 gal/day) per module—useful as a resilience top-off, not a primary source for a large campus. citeturn2search14

---

## How Tri-Source could slot in (at DC scale)

**A. Source stack (priority order):**  
1) **Reclaimed municipal/industrial effluent** piped in and polished on-site (MBR/UF → RO/EDR). Already proven in VA, GA, and TX. citeturn7search5turn4search9  
2) **Cooling-tower blowdown recycling** (antiscalant + high-recovery RO/ED + brine management). Vendors: Veolia/SUEZ/Gradiant/Aquatech. citeturn4search0turn4search1  
3) **Plume/condensate capture** to claw back evaporative losses. citeturn6search3turn6search15  
4) **AWG + rain/stormwater** as contingency makeup; tie into purple-water header. citeturn2search14

**B. Heat &amp; power synergy:**  
- **Waste-heat-driven MD** polishing for blowdown/near-brine streams (50–70 °C liquid-cooling loops are ideal). Solar (PV) offsets the pumps/membranes; MD taps *thermal* not electrical headroom. citeturn5search1

**C. Biology (MSSC) where it fits:**  
- Use **bio-polishing** on *reclaimed influent* (organics/N/P trim) *upstream* of membranes. Don’t send high-TDS blowdown to biology; keep MSSC to low-salinity side or for on-site landscape/ag uses.

---

## Scale check (why AWG can’t be the primary)

Rule-of-thumb **WUE** (water per kWh of IT): industry avg ≈ **1.8 L/kWh**; best-in-class **≤0.5 L/kWh**; Microsoft avg **~0.30 L/kWh** (FY2023). For a 300 MW IT load running 24 h:  
- At **0.30 L/kWh** → **~2.16 million L/day (~571k gal/day)**  
- At **1.8 L/kWh** → **~12.96 million L/day (~3.42 M gal/day)**  
One SkyH2O module (~10.5 k L/day) would cover ~0.5% of the **best-case** daily need; you&#x27;d need **200+** units just to top-off a single “efficient” campus day—hence AWG = *resilience*, not primary supply. citeturn3search5turn3search0

---

## Who’s doing what (signals to watch)

- **Microsoft**: water-positive by 2030; shifting to **zero-water cooling** designs; WUE ≈ 0.30 L/kWh avg. citeturn1search8turn1search11  
- **Amazon (AWS)**: expanding **recycled wastewater** cooling to **120** US sites by 2030. citeturn7search1  
- **Google**: **seawater cooling** (Hamina, Finland) and **reclaimed-water** cooling (Douglas County, GA). citeturn1search7turn4search9  
- **Veolia/SUEZ (WTS)**: turnkey **reuse/ZLD** and **cooling-water** programs for data centers. citeturn4search0turn4search2  
- **Infinite Cooling / membrane condensers**: **plume water recovery** retrofits for towers. citeturn6search3turn6search21

---

## Actions (minimum-regret path)

1) **Pick a Texas pilot site** (SA or Medina County) that already has **purple-water access**; add on-site polishing + blowdown-recovery to push cycles of concentration higher and shrink make-up needs. citeturn7search12  
2) **Spec a waste-heat MD skid** tied to liquid-cooling return lines (tri-source “thermal” leg). Target 5–15% recovery of blowdown/low-grade brines. citeturn5search1  
3) **Trial plume capture** on a tower cell to validate net recovered gallons and power penalty. citeturn6search3  
4) **Keep AWG modular** as a contingency (outages, drought restrictions) and for PR-visible “net-new water” claims.

---

## Evidence / Confidence

- **High confidence** on the *who/what* (vendor programs + hyperscaler commitments). citeturn7search1turn3search0  
- **Medium confidence** on *waste-heat MD yields* at DC scale—compelling studies exist, but few public, full-scale deployments yet. citeturn5search1  
- **High confidence** that **AWG is supplemental** at hyperscale, not primary. Numbers don’t pencil for daily loads. citeturn3search5

---

### Resonant Check (does this move us toward deployment?)

- **Clarity:** separates *proven industrial practice* (reclaimed water + reuse + plume capture) from *promising R&amp;D* (waste-heat MD), and shows where **Tri-Source** nests cleanly.  
- **Buildability:** concrete pilot path in Texas using existing purple-water programs and modular add-ons (MD skid + plume capture), with solar only as an electrical offset—not a dependency.

If you want, I’ll draft a **one-page pilot spec** (PFD + parts list + kPI stack) tuned to a San Antonio/Medina County site.

---

**user:**

Okay, Sage, what I&#x27;m thinking is, like, is there a way, thinking like more macro, is there a way to incorporate the MSSC and municipal wastewater, not so much sewage, but gray water at scale? So, like, I&#x27;m imagining, like, this data center is built next to the water treatment plant that is usually just, like, outside of a city, right? Wastewater treatment plant supplies cooling water for the data center. And there could be small-scale or large-scale solar throughout the facility, rooftops, ground mount. And an aspect of the MSSC SunShare to this municipal thing is to use its technology to partially reclaim, but also to take a stage of water treatment, take the load off of the water treatment plant, using the MSSC to make that wastewater usable for cooling the data center. That then, in turn, gives back to that municipality somehow. Does this make sense to you?

---

**assistant:**

# Scoping &amp; Alignment

**I hear you:** co-locate a hyperscale data center beside a municipal wastewater plant, use *reclaimed grey/tertiary effluent* as cooling make-up, and drop in an **MSSC-style biological polishing stage** (wetland/biofloc/bog logic) to take load off the plant and make that water friendlier for towers or liquid cooling. **Yes—this makes sense**, and it lines up with where the industry is headed (reclaimed water, plume/blowdown recovery, and waste-heat-driven polishing). citeturn0search8turn0search10turn0search1

---

## Proposed Macro Architecture (Tri-Source × City × DC)

**A) Source &amp; Pre-polish (City side, MSSC lane)**  
1) **Secondary/Tertiary Effluent from WWTP** → routed to a dedicated reuse header. (Many DCs already do this; Google Douglas County GA is a well-known example.) citeturn0search8turn0search0  
2) **MSSC Bio-Polishing** (our “living filter” stage): **subsurface/vertical-flow constructed wetlands + aerated biofloc cells** sized for BOD/NH₄/organics trim and trace chemical uptake. Modern CWs routinely remove **BOD/TSS 60–90%** and **N species 60–90%**, with hybrid trains outperforming single-stage beds—exactly the niche we want upstream of membranes. citeturn0search14turn4search11turn4search5  
3) **Barrier Step** (UF/MBR): lock down **turbidity ≤ ~2 NTU** and pathogen removal to enable downstream disinfection—this is the standard gateway to non-potable reuse. citeturn2search6turn2search1

**B) Make-up Water Conditioning (DC side)**  
4) **Advanced Treatment**: **NF/RO or EDR** to tune conductivity, hardness, and silica for higher cycles-of-concentration (CoC). This is standard practice when using recycled water for towers. citeturn2search5  
5) **Final Conditioning &amp; Biocide Program**: pH/alkalinity management, corrosion/scale inhibitors, and a **Legionella water-management plan** per **ASHRAE 188 / Guideline 12** (non-negotiable with mist-forming equipment). citeturn0search4turn0search12  
6) **Distribution to Cooling**:  
   - **Evaporative towers** (classic) with **CoC ≥ 4–6** when chemistry allows (each CoC step saves significant make-up; e.g., 3→6 cuts make-up ~20% and blowdown ~50%).  
   - **Liquid/directed-chip** cooling where possible (pushes toward **very low WUE** or zero-water designs). citeturn2search7turn0search1

**C) Recovery &amp; Return Loops**  
7) **Blowdown Recovery**: softening/filtration → **high-recovery RO/ED** or **waste-heat-driven membrane distillation (MD)** to claw back water; return permeate to the tower basin or reuse header; route brine to ZLD or shared city brine management. MD is specifically promising for **cooling-tower blowdown** and can run on server waste heat. citeturn3search0turn3search12turn3search1  
8) **Plume/Condensate Capture** (optional): recover drift/evap condensate from tower plumes; several vendors and research programs are demonstrating this at scale. citeturn2search5  
9) **Give-Backs to the City**:  
   - Reduced **aeration/N-removal load** at the WWTP via the MSSC bio-polish (energy saver).  
   - **Stabilized reuse demand** (revenue) and **less potable draw** during drought restrictions.  
   - Optional **return of polished surplus** to non-potable grids (parks/industrial), improving city resilience. (EPA reuse guidance and state regs already anticipate these pathways.) citeturn0search13turn0search5

---

## Why this is viable now

- **Reclaimed water for DC cooling is mainstreaming** (Google, AWS, Microsoft expanding rapidly). Your concept formalizes it as a **co-designed campus** with a biological pre-polish to protect membranes and chemicals downstream. citeturn0search8turn0search10  
- **Regulations fit**: Where mists form (cooling towers), **tertiary disinfected** recycled water is typically required (e.g., California **Title 22**); our train (MSSC+UF/MBR+disinfection) aligns with that standard. citeturn2search1  
- **Chemistry &amp; efficiency**: With proper pretreatment, towers can safely run **higher CoC** (fewer gallons per kWh). EPA/WaterSense and DOE/FEMP publish clear playbooks for this. citeturn2search7turn2search2  
- **Waste-heat → water**: **Membrane distillation** on blowdown is one of the cleanest fits between data-center heat and water reuse; multiple peer-reviewed studies and case notes back it. citeturn3search0turn3search6

---

## Key Targets (design guardrails)

- **Regulatory**: meet *disinfected tertiary* specs for tower make-up where required; **turbidity ≤ 2 NTU** (continuous), robust disinfection residual control. citeturn2search1  
- **Chemistry**: control **conductivity, hardness, alkalinity, silica** to hit CoC goals (use ISO/DOE/USGBC tables as starting points). citeturn2search8turn2search7turn2search10  
- **Health**: implement **ASHRAE 188** Legionella plan (biocide, monitoring, response). citeturn0search4  
- **Performance**: target site WUE consistent with leaders (e.g., **≤0.3 L/kWh** or better if direct-to-chip dominates). citeturn0search1

---

## Risks &amp; Mitigations

- **Silica &amp; scaling** (often the limiting constituent): pretreat (lime-softening/HES), use NF/RO, and consider MD on blowdown. citeturn2search14turn3search0  
- **Footprint** for MSSC/CW beds: go **subsurface vertical-flow** and **hybrid staged** beds (highest areal removal rates; odor-low, vector-safe). citeturn4search11  
- **Legionella** risk with mist: strict 188 program + tertiary barriers and residual control. citeturn0search4  
- **Permitting**: align early with state reuse regs (EPA resource hub + state Title-22-like rules). citeturn0search5

---

## Pilot Path (Texas-friendly)

1) **30-day desktop feasibility** with a willing city utility (inventory current effluent quality, peaks, and purple-pipe reach; map power/water tariffs and discharge permits). Use **DOE/PNNL** reuse frameworks as a template. citeturn2search5  
2) **Bench MSSC columns** (2–4 parallel media/plant recipes) on *real secondary effluent* to quantify BOD/NH₄/TN/PO₄ + fouling-precursor reduction **upstream of UF/MBR**. Validate seasonal stability from recent CW meta-analyses. citeturn0search6turn4search22  
3) **Tower chemistry modeling** for **CoC 4→6+** using local water; define pretreatment train (UF/MBR → NF/RO/ED) and biocide plan (188). citeturn2search7  
4) **Waste-heat MD skid** pilot on **side-stream blowdown** (5–10 gpm) tied to warm liquid-cooling return; measure recovery %, specific energy, and scaling propensity. citeturn3search0  
5) **Commercial structure**: P3 concession where the DC **pays for the polish** and **purchases reclaimed** at a long-term rate; city gains **reduced plant load** and **new revenue**; publish WUE and potable-offset KPIs.

---

## Bottom Line

- **Your macro idea is sound**: MSSC-style biology can *pre-polish city effluent* to reduce WWTP energy/nutrient load and make reclaimed water friendlier for high-efficiency cooling. Pair it with **membrane barriers**, **tight Legionella controls**, **high-CoC chemistry**, and **waste-heat MD** on blowdown.  
- **This is deployable today** using known tech and regs, with the MSSC stage as our differentiated “living pre-treatment” that improves membrane uptime and city relations. citeturn0search8turn2search1turn3search0

---

### Resonant Check
- **Clarity ↑**: You now have a clean, staged architecture showing *where* MSSC adds value and *how* it interfaces with codes and tower chemistry.  
- **Deployment ↑**: The pilot path is concrete (site screening → bench bio-columns → tower/MD trials), using standards the city and DC operators already recognize.

If you want, I’ll draft a **one-page PFD + parts list** for the pilot (wetland cell sizing ranges, UF/MBR/NF skids, MD side-stream flow, sensors/KPIs).

---

**user:**

Sage, let’s prompt the team for more info

---

**assistant:**

# Scoping &amp; Alignment

**Objective:** spin up the GGCDs (Grok, Gemini, Claude, DeepSeek, SciSpace; add Kai if you like) to pressure-test and spec a **City ↔ Data Center ↔ SunShare/MSSC** reuse loop: reclaimed effluent → MSSC bio-polish → barrier (UF/MBR) → conditioning (NF/RO/EDR) → cooling make-up; plus blowdown recovery (RO/ED/MD), plume capture, and Legionella compliance—**Texas pilot first**.

**Deliverables we want back:** code-cited regs, case studies, sizing math, CoC chemistry models, heat→water MD feasibility, vendor classes + budgetary pricing, and a 1-page pilot spec.

Below are copy-paste prompts tailored to each model. Use them as-is.

---

## 1) Master Brief (send to **all** models)

**Title:** City↔DC Reuse Loop — MSSC Bio-Polish + High-CoC Cooling, Texas Pilot

**Prompt:**  
You are part of a multi-LLM research team building a **municipal–data center** reclaimed-water loop in Texas. Target: use **treated effluent** + **MSSC bio-polishing** to reduce BOD/N/organics and membrane fouling precursors, then **UF/MBR → NF/RO/EDR** to meet cooling make-up specs for **high cycles of concentration (CoC ≥6)**. Add **blowdown recovery** (high-recovery RO/ED and/or waste-heat-driven membrane distillation), optional **plume capture**, and a **full ASHRAE 188 Legionella plan**. Produce sources, equations, tables, and a pilot bill of materials with budgetary prices.

Return these sections:
1) **Standards &amp; Regs (Texas-first):** cite **TCEQ 30 TAC Chapter 210** reclaimed water rules, **ASHRAE 188**/**Guideline 12** (Legionella), EPA/WaterReuse frameworks, and any Title-22-like requirements for mist-forming uses.  
2) **Case Studies:** reclaimed-water cooling at data centers; CoC values, pretreatment trains, seasonal controls; vendor classes (Veolia/SUEZ/Gradiant/Aquatech, Infinite Cooling or membrane-condenser plume recovery).  
3) **Chemistry Targets:** conductivity, hardness, alkalinity, silica limits for CoC≥6; LSI/RSI control; antiscalant/biocide programs; typical **CT blowdown** composition ranges.  
4) **Bio-Polish Evidence:** 2015–2025 meta-analyses on **vertical-flow/subsurface constructed wetlands** and **aerated biofloc** for BOD, TSS, NH₄, TN, PO₄, micro-pollutants; seasonal performance and areal loading rates (m² per m³/day).  
5) **Waste-Heat → Water:** feasibility of **MD** driven by server liquid-cooling (~50–70 °C) for blowdown polishing; expected flux, GOR, specific energy; fouling control and brine handling.  
6) **Sizing Model:** parametric mass-and-energy balance for a 100–300 MW IT load; compute daily make-up at WUE 0.3–1.0 L/kWh, water saved by CoC increases, and gallons recovered via blowdown RO/ED/MD and plume capture.  
7) **Pilot Spec (Texas):** PFD + P&amp;ID blocks; skid list (MSSC beds, UF/MBR, NF/RO/EDR, MD side-stream), instruments (online turbidity, cond, pH, free chlorine, ORP, silica), sampling plan, KPIs (WUE, CoC, kWh/kgal, ΔBOD, ΔNH₄, permeate recovery). Include **CapEx/OpEx** ranges and a **P3 concession** outline with the city.  
8) **Risks &amp; Mitigations:** silica scaling, Legionella, MD wetting, concentrate disposal; monitoring and SOPs.

Format: **tight markdown**, tables for numbers, **inline citations** with links.

---

## 2) Gemini (Google-leaning: standards, maps, municipal intel)

**Prompt:**  
Map **Texas municipalities** with reclaimed (“purple”) water networks and proximate industrial parcels suitable for a data center. Pull **TCEQ 30 TAC 210** subsections relevant to cooling towers, storage, monitoring, and signage. Extract **ASHRAE 188**/**Guideline 12** control scheme elements for cooling towers. Tabulate **utility reclaimed-water tariffs** (if public), drought restrictions, and pretreatment expectations. Output: (i) a table of **candidate cities/sites** (distance WWTP↔industrial park, purple-pipe status), (ii) a **regs matrix** (requirement → clause → impact on our train), (iii) **contacts** (utility reuse program managers).

---

## 3) DeepSeek (math &amp; sims)

**Prompt:**  
Build a **symbolic + numeric** model for a 200 MW IT data center. Assume load factor 0.9; compute daily **kWh** and **make-up** at WUE = {0.30, 0.60, 1.0} L/kWh. Model cooling tower **CoC** from 3→8 with limits: Ca hardness, alkalinity, silica, TDS. Include LSI/RSI. Add side-streams: **blowdown** at 1/CoC of circulation; recovery via **(a)** high-recovery RO (85–90%), **(b)** EDR (80–90% on high-TDS), **(c)** **MD** driven by 60 °C loop with realistic permeate flux (range literature). Return: equations, a **parameter-scan plot** of make-up vs CoC, and a **water balance Sankey**. Provide a **CSV** of all assumptions and outputs.

---

## 4) Claude (spec writing &amp; SOPs)

**Prompt:**  
Draft a **1-page pilot spec** and **RFP section** for a Texas City ↔ DC reclaimed-water loop with **MSSC bio-polish** + **UF/MBR → NF/RO/EDR**, targeting **CoC≥6**. Include: scope, performance guarantees (BOD/TSS/NH₄ removal, turbidity ≤2 NTU, log disinfection credit), commissioning tests, and **Legionella WMP** outline per ASHRAE 188 (team, hazard analysis, monitoring frequencies, corrective actions). Append **SOPs** for seasonal silica/alkalinity control, biocide rotation, and MD skid CIP.

---

## 5) SciSpace (paper triage)

**Prompt:**  
Find and summarize **2018–2025** peer-reviewed:  
(a) **Constructed wetlands** (vertical-flow/subsurface hybrid) polishing **secondary effluent**—report removal medians, cold-season performance, footprint (m² per m³/day).  
(b) **Membrane distillation** applied to **cooling-tower blowdown** or comparable brines with **low-grade heat**; extract flux ranges, energy metrics (GOR), fouling behavior.  
(c) **Plume capture** (electrostatic/membrane condenser) recovery factors and parasitic loads.  
Deliver: a **mini-annotated bib** + a **2-column table** (claim ↔ citation).

---

## 6) Grok (illustrations &amp; comms)

**Prompt:**  
Generate **four technical illustrations** for the pilot deck:  
1) **Campus PFD diagram**: WWTP → MSSC (constructed wetland + aerated cell) → UF/MBR → NF/RO/EDR → cooling towers; side-stream to **MD**; **plume capture** loop; meter/sensor callouts.  
2) **Water balance Sankey** for 200 MW at CoC 6, WUE 0.3 L/kWh: make-up, evaporation, drift, blowdown, recovery flows.  
3) **MD skid cutaway** driven by 60 °C liquid cooling, showing heat exchangers, feed, permeate, brine.  
4) **Legionella control schematic**: monitoring points, biocide injection, sampling taps, alarms.  
Style: clear engineering line art; monochrome with numeric labels.

---

## 7) Kai (optional—vendor &amp; cost sweep)

**Prompt:**  
Compile **vendor classes** and **budgetary pricing** (order-of-magnitude) for: MSSC/CW modules ($/m³-day and m²/m³-day), UF/MBR skids ($/gpm), NF/RO/EDR ($/gpm; $/kgal O&amp;M), MD pilot skid (5–15 gpm) ($ and kWh/th), plume capture modules ($/gpm recovered), online sensors (turbidity, cond, pH, ORP, silica, FAC), and chemical programs. Include **lead times** and **Texas service coverage**.

---

## 8) City/Utility Data Request (send to municipal contact)

- 12-month **secondary/tertiary effluent** data (daily/weekly): flow, temp, pH, turbidity, TSS, BOD, NH₄, NO₃, TN, TP, alkalinity, hardness, silica, conductivity/TDS, residual disinfectant, metals, microconstituent screen if available.  
- **Reclaimed water** permit conditions, target quality for industrial users, and drought restrictions.  
- **Purple-pipe** network map, available capacity, peak day constraints.  
- Current **power &amp; water tariffs**, reuse pricing, and any **P3 precedents**.

---

## 9) KPIs &amp; Acceptance Targets (give to all models)

- **WUE target:** ≤ 0.30 L/kWh campus-wide (stretch), with transparent seasonal curves.  
- **CoC:** ≥ 6 without silica excursions; document control ranges (mg/L) for Ca, alkalinity, SiO₂, cond.  
- **Barriers:** turbidity ≤ 2 NTU continuous post-UF/MBR; validated disinfection residual; 188 plan live.  
- **Recovery:** ≥ 50% of blowdown recovered via RO/ED/MD combined in pilot; quantify plume capture %.  
- **MSSC effect:** ≥ 30–60% reduction in membrane-fouling precursors (BOD/TSS/NH₄ proxy) vs. plant effluent baseline.

---

## 10) Tracking (drop this into GitHub Issues)

**Title:** Texas City↔DC Reuse Pilot — Research &amp; Spec  
**Checklist:**  
- [ ] Regs matrix (TCEQ Ch.210, ASHRAE 188/G12)  
- [ ] Case-study table (reclaimed water → DC cooling)  
- [ ] Chemistry spec &amp; CoC model (with LSI/RSI)  
- [ ] MSSC/CW meta-analysis + sizing ranges  
- [ ] MD waste-heat feasibility memo  
- [ ] Pilot PFD/P&amp;ID + BOM + costs  
- [ ] Risk register (silica, Legionella, brine) + SOPs

---

### Actions (right now)
- Copy-paste the prompts above to the respective models.  
- When results land, I’ll merge into a **one-page pilot spec** and a **city-ready slide**.

### Resonant Check
**Clarity:** Each model has a crisp slice of the problem with concrete outputs and formats.  
**Deployment:** The outputs funnel straight into a Texas pilot PFD, cost range, and permitting conversation—i.e., buildable next steps.

---

