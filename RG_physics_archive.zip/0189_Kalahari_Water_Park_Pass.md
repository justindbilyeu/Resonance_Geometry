# Kalahari Water Park Pass

- Conversation ID: 6841a0db-359c-800c-8f97-93b69e814462
- Created: 2025-06-05T13:51:23.565899

---

**user:**

Can you look up the Kalahari Water Park in Round Rock, Texas? I want to know how much a day pass to the water park would be.

---

**assistant:**

Day passes to the Kalahari Waterpark in Round Rock, Texas, are available for guests not staying at the resort. These passes grant access to both the indoor and outdoor waterparks. However, specific pricing details are not provided on the official website, as prices may vary by day and availability. To ensure admission, it&#x27;s recommended to purchase passes online in advance. citeturn0search0

**Key Information:**

- **Children Under 3:** Free admission.
- **Children Under 14:** Must be accompanied by an adult.
- **Towels:** Not provided for day pass guests; bring your own or purchase on-site.
- **Valet Parking:** Available for $25, with an additional $15 for charging services.
- **Military Discount:** Available for all-day waterpark passes with valid military ID at check-in. citeturn0search0

For the most accurate and up-to-date pricing, please visit the official Kalahari Resorts website or contact their guest services directly.

---

**user:**

I’m thinking about offering day passes to my customers…as a referral reward, and also as a thank you. On the day we install their new roof, we want to offer a way for them to get out of the house..especially during the summer. Kids under 14 are free and it looks like it’s about $120 per adult…what do you think?

---

**assistant:**

Offering Kalahari Waterpark day passes as a referral reward or thank-you gift is a thoughtful and strategic idea, especially during the hot Texas summers. It provides your customers with a fun escape while their new roof is being installed.

**Pricing Details:**

- **Children under 3**: Free admission.
- **Children under 14**: Must be accompanied by an adult.
- **Day Passes**: Prices vary by day and availability. It&#x27;s recommended to purchase passes online in advance to guarantee admission. citeturn0search0

**Additional Considerations:**

- **Towels**: Not provided for day pass guests; bring your own or purchase on-site.
- **Valet Parking**: Available for $25, with an additional $15 for charging services.
- **Military Discount**: Available for all-day waterpark passes with valid military ID at check-in. citeturn0search0

**Recommendations:**

- **Advance Purchase**: Since day passes have limited availability and prices vary, purchasing them online ahead of time ensures your customers can plan their visit without issues. citeturn0search0

- **Gift Cards**: Consider providing Kalahari gift cards. This allows your customers the flexibility to choose their visit date and time, accommodating their schedules.

- **Group Discounts**: Reach out to Kalahari Resorts directly to inquire about potential group rates or corporate discounts, especially if you plan to purchase passes in bulk.

- **Alternative Options**: Explore other local attractions or entertainment venues that might offer group discounts or packages suitable for families.

By offering such a generous and enjoyable reward, you&#x27;re likely to enhance customer satisfaction and foster positive word-of-mouth for your roofing business.

---

**user:**

Can you craft a pitch to show this idea to my business partner? Let’s say, it will cost $200 per customer …how do we present this? Does it make sense..also consider the average profit from a normal roof replacement is around $3000 …

---

**assistant:**

Here’s a strategic, numbers-backed pitch you can present to your business partner for offering **Kalahari Waterpark day passes** (valued at ~$200 total per household) as a **customer thank-you + referral booster**:

---

### **Pitch: “The Kalahari Roof Day” – Strategic Thank You + Referral Program**

**Overview:**

Let’s turn one of our biggest customer pain points—being stuck at home during roof installs—into a premium brand experience. By offering a **Kalahari Waterpark Day Pass Package (valued at $200)** on the day of their roof installation, we give families a stress-free escape, elevate our brand above the competition, and spark word-of-mouth that drives referrals.

---

### **Why It Works**

**1. It solves a real pain.**  
Roof installs are loud, messy, and disruptive. Sending families to a waterpark during install turns a negative into a huge positive.

**2. It creates brand loyalty.**  
This isn’t a generic gift card—it’s a full experience. Families will remember us as the company that *gave them a day off and a story to tell.*

**3. It drives referrals naturally.**  
Parents post pics. Kids brag at school. Neighbors ask, “Who did your roof?”  
We become **the memorable roofer**. The generous roofer. The “they took care of us” roofer.

**4. It fits the margins.**

| Metric                     | Value                   |
|---------------------------|-------------------------|
| Avg. Profit Per Roof      | $3,000                  |
| Cost of Kalahari Package  | $200 (avg for 2 adults) |
| Net Profit After Gift     | $2,800                  |
| ROI from 1 Referral       | +$3,000 (new job)       |

If **1 in 15 customers** refers someone because of this gesture, it **pays for itself**.

---

### **Implementation Plan**

- **Buy passes or gift cards in bulk** from Kalahari (explore group/corporate discounts).
- **Offer to families on install day**, packaged as:  
  _“A thank-you getaway while we handle the roof.”_
- **Branded follow-up**: Custom card, check-in text, referral request a week later.

---

### **Positioning Statement (Customer-Facing):**

&gt; “We know roof installs can be disruptive—so we’re sending your family to the waterpark for the day, on us. It’s our way of saying thanks while we handle everything back home.”

---

### **Conclusion:**

For **$200 per job**, we solve a headache, build brand trust, and create referral-worthy experiences. It’s not just a thank-you—it’s a marketing engine that **pays for itself in customer love and repeat business**.

---

Want me to turn this into a one-pager or slide deck?

---

**user:**

How do we approach Kalahari water park with this idea? Would they welcome it, and is it marketable?  We will, as a company, have 300-400 customers annually…

---

**assistant:**

Here’s how to approach **Kalahari Waterpark Round Rock** with a win-win partnership pitch—and yes, it’s very **marketable and potentially welcome**, especially if you’re bringing consistent, volume-based business.

---

## 🎯 **Why This Makes Sense for Kalahari**

- **300–400 guaranteed new guests annually**, many during weekdays or slower seasons.
- High likelihood that **customers will spend more** (food, lockers, souvenirs, extra tickets).
- You’re **not asking for free passes**—you’re offering bulk purchases and co-branding opportunities.
- They get to **associate their brand with premium customer service and community goodwill**.

---

## ✅ **What to Offer Kalahari in the Proposal**

### 1. **Bulk Commitment**  
Offer to **pre-purchase 100–200 passes upfront**, with an option to scale up based on usage.

&gt; “We plan to give our customers 300–400 day passes annually as a premium thank-you gift. We’d like to buy in bulk and explore discounted pricing or a corporate gift card package.”

---

### 2. **Co-Marketing Opportunity**  
Position it as a **“Kalahari Roof Day” experience** — they get free branding on your website, printed materials, social media posts, and customer-facing emails.

&gt; “We’ll feature Kalahari as our official wellness partner—encouraging families to relax while we protect their home.”

---

### 3. **Weekday Traffic Boost**  
Let them know these visits will **align with weekdays**—which are typically less crowded, offering better guest flow and more incremental revenue.

---

### 4. **Referral Data &amp; Metrics**  
Propose tracking engagement and return visits with QR codes, guest follow-ups, or gift card redemptions (if they’re open to data-sharing).

---

## 📞 How to Reach Out

- **Find the right contact**: Call Kalahari Round Rock and ask for the **Marketing Director or Corporate Partnerships Manager**.
- **Subject line for intro email**:  
  &gt; *“Proposal: Kalahari + Local Roofing Company Partnership to Reward 300+ Families in 2025”*
- **Open with this script:**

&gt; Hi [Name],  
&gt;  
&gt; My name is Justin, and I run a local roofing company that installs 300–400 new roofs annually across Central Texas. On install day, families are often displaced—and we’ve decided to turn that inconvenience into a treat by sending them to Kalahari for the day.  
&gt;  
&gt; We’d love to work with you to create a branded experience that brings families your way, creates local goodwill, and offers ongoing exposure in our customer communications. We’re happy to pre-purchase passes or gift cards in bulk and would love to explore discount options or a formal partnership.  
&gt;  
&gt; Can we schedule a quick call to explore this?  
&gt;  
&gt; Thanks,  
&gt; Justin Bilyeu  
&gt; [Your Company Name]  
&gt; [Phone + Email]  

---

## 🧠 Final Thought

**Yes, it’s marketable.** This is exactly the kind of creative, community-forward promotion that brands like Kalahari love—especially when it drives weekday traffic and creates repeat business.

Want me to draft a formal proposal or outreach email to send to their marketing team?

---

**user:**

Let’s look at the psychology of this venture…and who the decision maker for Kalahari is…

---

**assistant:**

Approaching Kalahari Resorts in Round Rock, Texas, with your proposal to offer day passes as customer rewards is both strategic and potentially beneficial for both parties. Here&#x27;s how to navigate this opportunity:

---

## 🧠 Understanding the Psychological Appeal

**For Your Customers:**

- **Alleviating Stress:** Roof installations can be disruptive. Offering a day at Kalahari provides families a relaxing escape during this time.
- **Creating Memorable Experiences:** Transforming a home improvement project into a mini-vacation fosters positive associations with your brand.
- **Enhancing Brand Perception:** Such thoughtful gestures can elevate your company&#x27;s image, leading to increased customer loyalty and referrals.

**For Kalahari Resorts:**

- **Increased Foot Traffic:** Introducing 300–400 new guests annually can boost attendance, especially during off-peak times.
- **Ancillary Revenue:** Guests are likely to spend on food, beverages, and other amenities during their visit.
- **Community Engagement:** Partnering with local businesses aligns with Kalahari&#x27;s commitment to community involvement. citeturn0search8

---

## 🧑‍💼 Identifying the Right Decision-Maker

To propose this partnership, consider reaching out to:

- **Brad Lyles – Regional Sales Director:** Oversees group and convention sales in Texas. citeturn0search7
- **Ryan Urias – National Sales Director:** Specializes in business partnerships within Texas associations. citeturn0search3

You can contact Kalahari Resorts &amp; Conventions in Round Rock directly at 512-651-1000 or through their [contact form](https://www.kalahariresorts.com/texas/more-info/contact-us/).

---

## 📬 Crafting Your Proposal

When reaching out, consider the following points:

- **Volume Commitment:** Express your intent to purchase 300–400 day passes annually.
- **Mutual Benefits:** Highlight how this partnership can drive new customers to Kalahari while enhancing your customer experience.
- **Marketing Collaboration:** Propose co-branded materials or promotions to maximize exposure for both businesses.

---

## ✅ Final Thoughts

This initiative not only offers a unique value proposition to your customers but also fosters community collaboration. By aligning your customer appreciation efforts with Kalahari&#x27;s offerings, you create a win-win scenario that can enhance brand loyalty and drive mutual growth.

Would you like assistance in drafting a formal proposal or introductory email to Kalahari Resorts?

---

**user:**

Let’s draft a proposal…of this idea to pitch to my roofing team. Let’s break this idea down and get the rest of the team behind it

---

**assistant:**

Here’s a clear, motivating proposal you can present to your roofing team to introduce and rally support around **“The Kalahari Roof Day”** customer appreciation program.

---

# 🛠️ Proposal to Roofing Team:  
### **The Kalahari Roof Day – A Bold Move in Customer Experience &amp; Referrals**

---

## 🎯 **What’s the Idea?**

Every time we install a roof—especially during hot summer months—we’ll send our customer and their family to **Kalahari Waterpark in Round Rock** for the day.

It’s our gift to them for trusting us, and a way to make roof day feel like **a reason to celebrate**, not just tolerate.

We call it:  
### **“The Kalahari Roof Day”**  
_&quot;While we work hard on your home, go make a splash on us.&quot;_

---

## 💡 **Why This Works**

### ✅ 1. Turns a Pain Point into a Pleasure
Roof installs are noisy, messy, and disruptive. Offering customers a **fun escape** on install day helps remove friction and stress from the process.

### ✅ 2. Creates Lasting Brand Impressions
This isn’t just another “free gift.” It’s an **experience families remember and talk about.** The kind of thing that separates us from other roofing companies.

### ✅ 3. Fuels Word-of-Mouth and Referrals
Customers will tell neighbors, post on social media, and **generate organic buzz.**  
&gt; “My roofer sent us to Kalahari for the day. Can you believe that?”

### ✅ 4. Fits Financially

| Metric                     | Amount                  |
|---------------------------|-------------------------|
| Avg. Profit Per Roof      | $3,000                  |
| Cost of Kalahari Passes   | ~$200 per family        |
| Net After Gift            | $2,800                  |
| Value of 1 Referral       | $3,000+                 |

If just **1 in 15 customers refers us** because of this gesture, the program more than pays for itself.

---

## 🧠 The Deeper Psychology

- People don’t refer based on price—they refer based on **how you made them feel**.
- Gifting a premium, thoughtful experience like this creates **emotional loyalty**, not just satisfaction.
- In a noisy, storm-hit market full of roofers, this gives us a **story** that spreads.

---

## 🧩 The Plan

1. **We purchase day passes or gift cards in bulk** from Kalahari. (We’re exploring discounted rates or a partnership.)
2. **Each customer with a summer install** receives a waterpark package on install day.  
   - Includes a branded “Roof Day Kit” with tickets, sunscreen, snacks, and a thank-you card.
3. **We follow up** after install with a short referral text and photo request:  
   _“If you had a great Roof Day, share a pic and refer a friend—there’s more splash to go around.”_

---

## 📢 Talking Points for Sales &amp; Install Teams

When booking the job:  
&gt; “Install day can be a little noisy—we actually send your family to Kalahari Waterpark while we take care of everything.”

When handing off the gift:  
&gt; “Here’s your Kalahari pass—it’s our way of saying thanks. Go relax and enjoy a day out while we protect your home.”

---

## 🔧 What We Need from the Team

- **Sales**: Introduce this during your pitch—it sets us apart instantly.
- **Installers**: Make it feel premium and personal when handing off the gift.
- **Office Team**: Track participation and feedback; help scale the system.
- **All of us**: Get behind the idea. Talk it up. Believe in the story. This is who we are—a roofer that actually gives a damn.

---

## 🌊 Final Thought

We’re not in the business of just installing shingles—we’re in the business of **trust, experience, and loyalty**. This program brings all three together.

Let’s be the company people remember.  
Let’s build roofs and memories.

**—Team Proposal Prepared by Justin Bilyeu**  
[Your role/title]  
Texas Choice Roofing

---

Would you like this turned into a branded PDF or slideshow for team meetings? I can format it into a shareable pitch deck.

---

**user:**

Yes, a branded PDF. Here is our logo and QR code:

---

**assistant:**

The logo and QR code have been successfully uploaded and verified. I’ll now create a branded PDF proposal titled **“The Kalahari Roof Day: Customer Experience &amp; Referral Program”** with your logo and QR code included.

It will include:
- Executive summary
- Why this program works
- Financial breakdown
- Team implementation plan
- Customer-facing language
- Visual branding

Please confirm:
- Company name to include on the proposal  
- Any tagline or slogan you&#x27;d like added  
- Email/phone/website (if you want contact info on the footer)

Once confirmed, I’ll generate the finished PDF for you.

---

**assistant:**

Your branded proposal PDF is ready for download:

👉 [Click here to download Kalahari_Roof_Day_Proposal.pdf](sandbox:/mnt/data/Kalahari_Roof_Day_Proposal.pdf)

Let me know if you&#x27;d like a slide version or printed handout layout next.

---

**user:**

Can you expand on it? Make it 2 full pages

---

**assistant:**

Your expanded 2-page branded proposal is ready:

👉 [Download Kalahari_Roof_Day_Proposal_Expanded.pdf](sandbox:/mnt/data/Kalahari_Roof_Day_Proposal_Expanded.pdf)

Let me know if you&#x27;d like a slide deck version, print layout, or a branded folder insert next.

---

**user:**

Ok what if a customer doesn’t want the Kalahari day pass?

---

**assistant:**

Great question—this shows you&#x27;re thinking ahead about flexibility and customer experience. Not every homeowner will want (or be able) to use a Kalahari Waterpark pass, so having **alternative options ready** not only avoids awkwardness, it also preserves the *“premium thank-you”* impact you&#x27;re aiming for.

---

## 🎯 Goal: Maintain the Value, Respect the Customer’s Choice

If a customer declines the Kalahari pass, your response should still feel **generous and thoughtful**, not like they’re forfeiting a gift.

---

## ✅ Suggested Alternatives (Equal ~$200 Value)

### 1. **Visa or Prepaid Gift Card**
- Universal, flexible, and always appreciated.
- Pitch: _“If the waterpark’s not a fit, we’re happy to offer a prepaid gift card instead so your family can enjoy a night out—or anything else you’d like.”_

### 2. **Local Restaurant or Experience Gift Cards**
- Example: A $100 gift card to Salt Lick BBQ + $100 to Alamo Drafthouse.
- Position it as a *customized night out*.

### 3. **Charitable Donation in Their Name**
- Let them choose from vetted local charities or disaster recovery orgs.
- Adds emotional value: _“We’d be proud to donate on your behalf as part of our community commitment.”_

### 4. **Home Upgrade Add-On (Gift-in-Kind)**
- Offer an upgrade instead—premium vent caps, upgraded underlayment, or gutter cleaning.
- Pitch: _“We can put the $200 toward an upgrade or maintenance service—totally your call.”_

---

## 🧠 Bonus Psychology: The Power of Choice

When you offer customers a choice between equally generous options, **they feel respected and in control**—which strengthens brand perception even more.

---

## 🔄 How to Implement It

- During your pre-install call or appointment, mention the Kalahari pass:
  &gt; “Most of our customers love the chance to get away during install day—but if a waterpark isn’t your thing, we have a few other options as well.”

- Let them choose ahead of time from a short list.

---

## 💬 Optional Wording for the Team

&gt; “We like to say thank you in a big way. Some families enjoy a day at Kalahari while we install their roof. Others prefer a gift card or home upgrade instead. We’ve got options—whatever makes the most sense for you.”

---

Would you like me to generate a customer-facing “Reward Options Menu” one-pager you can give them or include in your proposal kit?

---

**user:**

Yes let’s look at the menu

---

**assistant:**

Here is your finalized one-page PDF:

👉 [Download Customer_Reward_Options_Menu.pdf](sandbox:/mnt/data/Customer_Reward_Options_Menu.pdf)

This is ready to hand to customers or include in their welcome packet. Want a matching version for digital email delivery too?

---

