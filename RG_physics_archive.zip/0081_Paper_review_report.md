# Paper review report

- Conversation ID: 68a84536-16ec-8325-af91-c168dd4b0c5e
- Created: 2025-08-22T10:23:51.797318

---

**user:**

Read this paper and report back:

https://www.biorxiv.org/content/10.1101/2025.05.24.655914v2

---

**assistant:**

# Context &amp; Objective  
You asked me to read: **“Advanced neural activity mapping in brain organoids via field potential imaging with ultra‑high‑density CMOS microelectrodes.”** (Yokoi, Matsuda, Ishibashi, Suzuki; Tohoku Institute of Technology). I reviewed the public abstract and metadata (bioRxiv v2; also mirrored on ResearchGate) and cross‑checked the system announcement that references this exact DOI/version. citeturn4view0turn1search12turn1search15

# Assumptions  
- v2 does not materially change the core claims from v1 (electrode count, endpoints, exemplar perturbations); the abstract reflects the stable scope. citeturn4view0turn1search12  
- Full PDF access from bioRxiv was flaky via my browser; I relied on the full abstract (ResearchGate mirror) plus the bioRxiv archive listing and vendor note that cites the same DOI/version. citeturn4view0turn1search15turn1search12

# Reasoned Path (What it says, in plain terms)  
**What they built**  
- A **UHD‑CMOS MEA** platform: **236,880 electrodes** (~10.5 µm pitch) across **~32.45 mm²**; simultaneous readout from **&gt;46,000 electrodes** in contact with organoids for **field‑potential imaging (FPI)** at near single‑cell spatial resolution. citeturn4view0

**What they measured**  
- **Single‑cell spiking** and **network connectivity** in cortical and midbrain organoids and in **midbrain–striatal assembloids**. citeturn4view0  
- Introduced two network endpoints: **propagation velocity** and **propagation area** computed from spatiotemporal field‑potential maps. citeturn4view0  
- **Frequency‑domain** patterns including **gamma‑band** features that differed by region within organoids. citeturn4view0

**Perturbations &amp; readouts**  
- **Midbrain organoids + L‑DOPA**: mixed excitatory/inhibitory single‑cell responses; **dose‑dependent rise in excitatory fraction** → interpreted as enhanced connectivity. citeturn4view0  
- **Cortical organoids + picrotoxin (GABA\(_A\) antagonist)**: **increased propagation velocity**. **+ MK‑801 (NMDA antagonist)**: **broad reduction in propagation area** with local increases. citeturn4view0  
- **Assembloids + 4‑aminopyridine**: strengthened **inter‑organoid** connectivity. citeturn4view0

**Why it matters (their frame)**  
- UHD‑CMOS FPI provides **large‑scale, single‑cell‑resolved** electrophysiology for **drug screening** &amp; **disease modeling**; dovetails with “**organoid intelligence**” ambitions. citeturn4view0  
- A June 2025 joint note (Sony/SCREEN/VitroVo) references this exact bioRxiv **v2 DOI**, signaling an ecosystem around this sensor for trial deployments. citeturn1search12

# Risks &amp; Unknowns (what I’d probe before trusting)  
1) **Ground truthing**: Abstract doesn’t report patch‑clamp or calcium co‑validation for single‑cell assignment—key to confirm spike origin and depth spread in 3D tissue. citeturn4view0  
2) **Replicates/statistics**: Sample sizes, batch variability, and per‑organoid heterogeneity aren’t specified in the abstract. citeturn4view0  
3) **3D vs 2D sensing**: FPI is surface‑coupled; how they deconvolve **depth** (z) contributions and volume conduction is not detailed here. citeturn4view0  
4) **Artifact robustness**: Motion, electrolyte drift, and stimulation artifacts—processing pipelines not described in the abstract. citeturn4view0  
5) **Generalizability**: L‑DOPA/picrotoxin/MK‑801/4‑AP are standard probes; it’s unclear how stable the **propagation metrics** are across donors/lines and over maturation time. citeturn4view0

# Actions (practical next steps)  
1) **Acquire the system or secure a trial**: The Sony/SCREEN/VitroVo trial offer references this exact platform—contact for access, pricing, and data pipeline details. citeturn1search12  
2) **Replicate key endpoints** on our side:  
   - Implement open pipelines for **propagation velocity/area** and **graph connectivity**; benchmark on public UHD‑MEA datasets if available. citeturn4view0  
3) **Add ground truth**: Design side‑by‑side **patch‑clamp** and **calcium imaging** on a subset to validate spike/source localization and frequency features (esp. gamma). citeturn4view0  
4) **Perturbation matrix**: Extend beyond their four compounds to **coherence‑modulating stimuli** we care about (e.g., 40 Hz entrainment paradigms) and quantify shifts in propagation metrics. (Concept aligned with their frequency analysis scope.) citeturn4view0  
5) **Assembloid connectivity**: Reproduce **midbrain–striatal** coupling tests and add directed stimulation to map effective connectivity (causal graphs). citeturn4view0

# Model Prompts (to push this further, now)  
- *“Given UHD‑MEA FPI voltage movies (sampling rate X), compute per‑epoch propagation velocity and area using threshold‑free wavefront tracking; output stability across maturation days and drug conditions.”* citeturn4view0  
- *“Design a validation experiment that pairs UHD‑MEA FPI with cell‑attached patch in cortical organoids to estimate the transfer function from single‑cell firing to surface potentials.”* citeturn4view0  
- *“For midbrain–striatal assembloids, infer directed connectivity under 4‑AP using Granger/TE vs. perturbational mapping; compare consistency with structural fusion geometry.”* citeturn4view0

# Citations/Calcs  
- Paper metadata &amp; abstract (authors, sensor specs, endpoints, perturbations, claims). citeturn4view0  
- Vendor/system note confirming **v2** and ecosystem availability; links the exact DOI/version. citeturn1search12  
- bioRxiv archive index showing posting date for the DOI family. citeturn1search15

---

If you want, I can draft a one‑page **Methods‑at‑a‑glance** and an **experiment checklist** tailored to our lab setup (e.g., entrainment protocols, co‑recordings, data QC).

---

