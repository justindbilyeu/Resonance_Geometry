# Find article in photo

- Conversation ID: 68c2e385-0ea0-8326-9884-f65bae562521
- Created: 2025-09-11T14:58:30.592130

---

**user:**

Can you find the article in this photo?

---

**assistant:**

I found it. The article is:

---

**Title:** *Humpback Whales Blow Poloidal Vortex Bubble Rings*  
**Authors:** Fred Sharpe; Jodi Frediani; Josephine Hubbard; Doug Perrine; Simon Hilbourne; Joy S. Reidenberg; Laurance R. Doyle; Brenda McCowan citeturn0search2turn0search5turn0search0turn0search4  
**Journal:** *Marine Mammal Science* citeturn0search0turn0search4turn0search5  
**Date:** Published May 15, 2025 citeturn0search0turn0search4  
**DOI:** 10.1111/mms.70026 citeturn0search0turn0search5

---

If you want, I can send you a copy or link to the PDF.

---

