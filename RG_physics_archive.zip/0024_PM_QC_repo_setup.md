# PM QC repo setup

- Conversation ID: 68d7cdd9-4ee8-8333-8dba-d5d8a039e037
- Created: 2025-09-27T11:45:19.383107

---

**user:**

Hey Sage! I want to build up this GitHub repo to be a tracker and resource for my job as project manager and quality control for Texas Choice Roofing I’m gonna be able to use you and the Kodex to automate some of my daily stuff like reading my email updating my calendar tracking job tracking time and just kind of test and see what we can do with an LLM that Kodex tool and a kit hub repo to make my day-to-day as a quality control specialist easier is this something you can help with

---

**assistant:**

# Create a starter pack for the PM-QC-TCR repo and zip it for download.
import os, json, textwrap, zipfile, pathlib, datetime

base = &quot;/mnt/data/pm-qc-tcr-starter&quot;
paths = [
    &quot;.github/workflows&quot;,
    &quot;.github/ISSUE_TEMPLATE&quot;,
    &quot;docs/checklists&quot;,
    &quot;docs/process&quot;,
    &quot;docs/templates&quot;,
    &quot;ops&quot;,
    &quot;scripts&quot;,
]
for p in paths:
    os.makedirs(os.path.join(base, p), exist_ok=True)

today = datetime.date.today().isoformat()

files = {}

files[&quot;README.md&quot;] = f&quot;&quot;&quot;# PM · QC · Texas Choice Roofing

A lightweight, automation-friendly hub for **Project Management** and **Quality Control** at Texas Choice Roofing (TCR).  
This repo is designed to work well with ChatGPT (Sage) and the **Kodex** environment to standardize checklists, open issues from templates, and generate daily digests via GitHub Actions.

## Quick Start
1. **Add these files** to your repo (copy from the zip or commit directly).
2. In GitHub → **Settings → Actions → General**, set: *Allow GitHub Actions to create and approve pull requests.*
3. (Optional) In **Settings → Secrets and variables → Actions**, add org- or repo-level secrets you plan to use later (e.g., `GMAIL_APP_PASSWORD`, `GCAL_WEBHOOK_URL`). Workflows included here will run without secrets; integrations are modular.
4. Use the **Issue templates** to log work:
   - `Job QC Audit`
   - `Punchlist`
   - `Daily Log`
   - `Vendor/Material Inspection`

## Automation Overview
- **Daily Digest**: opens a daily “QC Dashboard — {today}” issue at 7:30 AM America/Chicago with rollups (open punchlists, audits due, jobs by status).
- **Label Sync**: ensures a stable, color-coded label set (QC, Punchlist, Safety, Urgent, Scheduling, Materials, Warranty, Customer, Vendor).
- **Auto-Checklist**: when you create an issue from a form, the workflow posts the matching checklist into the body and keeps it in sync on edits.

## Folder Map
```
.github/
  ISSUE_TEMPLATE/         # GitHub Issue forms for consistent logging
  workflows/              # Actions that build daily digest, sync labels, post checklists
docs/
  checklists/             # Source checklists used by forms &amp; bots
  process/                # SOPs and “how-we-work” docs
  templates/              # Reusable text snippets and comment blocks
ops/
  kodex/                  # Prompts and runbooks for Kodex
scripts/                  # Utility scripts (optional)
```
## Kodex
See `ops/kodex/CODEX.md` for the canonical prompt and the task menu. Use it in the Kodex environment to open/triage issues, run checklists, and prepare digests.

---

© {datetime.date.today().year} Texas Choice Roofing — Internal tooling. Apache-2.0 license.
&quot;&quot;&quot;

files[&quot;LICENSE&quot;] = &quot;&quot;&quot;Apache License
Version 2.0, January 2004
http://www.apache.org/licenses/

TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

Copyright 2025 Texas Choice Roofing

Licensed under the Apache License, Version 2.0 (the &quot;License&quot;);
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an &quot;AS IS&quot; BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
&quot;&quot;&quot;

# Workflows
files[&quot;.github/workflows/daily-digest.yml&quot;] = textwrap.dedent(f&quot;&quot;&quot;\
    name: Daily QC Digest
    on:
      schedule:
        - cron: &quot;30 12 * * *&quot;  # 07:30 America/Chicago (UTC-5/6 adjusted automatically by GitHub to UTC)
      workflow_dispatch: {}
    jobs:
      digest:
        runs-on: ubuntu-latest
        permissions:
          issues: write
          contents: read
        steps:
          - uses: actions/checkout@v4
          - name: Build digest body
            id: body
            run: |
              echo &quot;## QC Dashboard — {today}&quot; &gt; body.md
              echo &quot;&quot; &gt;&gt; body.md
              echo &quot;### Open Punchlists&quot; &gt;&gt; body.md
              echo &quot;&quot; &gt;&gt; body.md
              echo &quot;$(gh issue list --label &#x27;Punchlist&#x27; --state open --limit 50 --json number,title,state,labels --template &#x27;{{range .}}{{.number}} · {{.title}}\\n{{end}}&#x27; || true)&quot; &gt;&gt; body.md
              echo &quot;&quot; &gt;&gt; body.md
              echo &quot;### Audits Due (label: QC)&quot; &gt;&gt; body.md
              echo &quot;&quot; &gt;&gt; body.md
              echo &quot;$(gh issue list --label &#x27;QC&#x27; --state open --limit 50 --json number,title,state,labels --template &#x27;{{range .}}{{.number}} · {{.title}}\\n{{end}}&#x27; || true)&quot; &gt;&gt; body.md
              echo &quot;&quot; &gt;&gt; body.md
              echo &quot;### Urgent&quot; &gt;&gt; body.md
              echo &quot;&quot; &gt;&gt; body.md
              echo &quot;$(gh issue list --label &#x27;Urgent&#x27; --state open --limit 50 --json number,title,state,labels --template &#x27;{{range .}}{{.number}} · {{.title}}\\n{{end}}&#x27; || true)&quot; &gt;&gt; body.md
              echo &quot;BODY&lt;&lt;EOF&quot; &gt;&gt; $GITHUB_OUTPUT
              sed -n &#x27;1,200p&#x27; body.md &gt;&gt; $GITHUB_OUTPUT
              echo &quot;EOF&quot; &gt;&gt; $GITHUB_OUTPUT
            env:
              GH_TOKEN: ${{{{ github.token }}}}
          - name: Open or update today&#x27;s digest
            env:
              GH_TOKEN: ${{{{ github.token }}}}
            run: |
              set -e
              TITLE=&quot;QC Dashboard — {today}&quot;
              # Try find existing
              NUM=$(gh issue list --search &quot;in:title {today} QC Dashboard&quot; --json number --jq &quot;.[0].number&quot; || true)
              if [ -z &quot;$NUM&quot; ] || [ &quot;$NUM&quot; = &quot;null&quot; ]; then
                gh issue create --title &quot;$TITLE&quot; --body &quot;${{{{ steps.body.outputs.BODY }}}}&quot; --label &quot;QC,Dashboard&quot;
              else
                gh issue comment &quot;$NUM&quot; --body &quot;🔄 Auto-update at $(date -u +%H:%M) UTC&quot;
                gh issue edit &quot;$NUM&quot; --body &quot;${{{{ steps.body.outputs.BODY }}}}&quot;
              fi
    &quot;&quot;&quot;)

files[&quot;.github/workflows/label-sync.yml&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    name: Sync Labels
    on:
      push:
        paths:
          - .github/labels.json
      workflow_dispatch: {}
    jobs:
      sync:
        runs-on: ubuntu-latest
        permissions:
          issues: write
          contents: read
        steps:
          - uses: actions/checkout@v4
          - uses: crazy-max/ghaction-github-labeler@v5
            with:
              github-token: ${{ secrets.GITHUB_TOKEN }}
              yaml-file: .github/labels.json
              skip-delete: false
    &quot;&quot;&quot;)

files[&quot;.github/labels.json&quot;] = json.dumps([
    {&quot;name&quot;: &quot;QC&quot;, &quot;color&quot;: &quot;0e8a16&quot;, &quot;description&quot;: &quot;Quality Control / Audit&quot;},
    {&quot;name&quot;: &quot;Punchlist&quot;, &quot;color&quot;: &quot;c5def5&quot;, &quot;description&quot;: &quot;Outstanding fixes&quot;},
    {&quot;name&quot;: &quot;Safety&quot;, &quot;color&quot;: &quot;d93f0b&quot;, &quot;description&quot;: &quot;Safety concerns / reports&quot;},
    {&quot;name&quot;: &quot;Urgent&quot;, &quot;color&quot;: &quot;b60205&quot;, &quot;description&quot;: &quot;High priority&quot;},
    {&quot;name&quot;: &quot;Scheduling&quot;, &quot;color&quot;: &quot;5319e7&quot;, &quot;description&quot;: &quot;Calendar / timing&quot;},
    {&quot;name&quot;: &quot;Materials&quot;, &quot;color&quot;: &quot;1d76db&quot;, &quot;description&quot;: &quot;Vendors, materials, delivery&quot;},
    {&quot;name&quot;: &quot;Warranty&quot;, &quot;color&quot;: &quot;f9d0c4&quot;, &quot;description&quot;: &quot;Warranty matters&quot;},
    {&quot;name&quot;: &quot;Customer&quot;, &quot;color&quot;: &quot;fbca04&quot;, &quot;description&quot;: &quot;Customer communication&quot;},
    {&quot;name&quot;: &quot;Vendor&quot;, &quot;color&quot;: &quot;e99695&quot;, &quot;description&quot;: &quot;Vendor coordination&quot;},
    {&quot;name&quot;: &quot;Dashboard&quot;, &quot;color&quot;: &quot;ededed&quot;, &quot;description&quot;: &quot;Bot-created status issues&quot;}
], indent=2)

files[&quot;.github/workflows/post-checklist.yml&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    name: Post Checklist on Issue
    on:
      issues:
        types: [opened, edited]
    jobs:
      apply:
        runs-on: ubuntu-latest
        permissions:
          issues: write
          contents: read
        steps:
          - uses: actions/checkout@v4
          - name: Determine checklist
            id: pick
            run: |
              TITLE=&quot;${{ github.event.issue.title }}&quot;
              LABELS=&quot;$(jq -r &#x27;[ .issue.labels[].name ] | join(\&quot;,\&quot;)&#x27; &lt; $GITHUB_EVENT_PATH)&quot;
              FILE=&quot;&quot;
              if echo &quot;$LABELS&quot; | grep -qi &quot;Punchlist&quot;; then FILE=&quot;docs/checklists/punchlist.md&quot;; fi
              if echo &quot;$LABELS&quot; | grep -qi &quot;QC&quot;; then FILE=&quot;docs/checklists/job-qc-audit.md&quot;; fi
              if echo &quot;$LABELS&quot; | grep -qi &quot;Safety&quot;; then FILE=&quot;docs/checklists/safety-spotcheck.md&quot;; fi
              echo &quot;file=$FILE&quot; &gt;&gt; $GITHUB_OUTPUT
          - name: Update issue body
            if: steps.pick.outputs.file != &#x27;&#x27;
            env:
              GH_TOKEN: ${{ github.token }}
            run: |
              BODY=&quot;$(cat ${{ steps.pick.outputs.file }})&quot;
              gh issue edit ${{ github.event.issue.number }} --body &quot;$BODY&quot;
    &quot;&quot;&quot;)

# Issue templates (forms)
files[&quot;.github/ISSUE_TEMPLATE/job_qc_audit.yml&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    name: Job QC Audit
    description: Structured audit for a roof job (pre/during/post).
    title: &quot;[QC] &lt;CustomerLastName&gt; — &lt;Street Address&gt;&quot;
    labels: [&quot;QC&quot;]
    body:
      - type: input
        id: job_id
        attributes:
          label: Job ID / Claim #
          placeholder: e.g., TCR-24-0912 or 1234567
        validations:
          required: true
      - type: input
        id: address
        attributes:
          label: Address
          placeholder: 123 Main St, Austin, TX
        validations:
          required: true
      - type: dropdown
        id: phase
        attributes:
          label: Project Phase
          options:
            - Pre-Install
            - In-Progress
            - Post-Install
            - Warranty/Service
        validations:
          required: true
      - type: checkboxes
        id: photo_sets
        attributes:
          label: Photo Sets Attached
          options:
            - label: Front/Back/Left/Right elevations
            - label: Roof planes overview
            - label: Flashings &amp; penetrations
            - label: Valleys &amp; step flashing
            - label: Ridge/hip/edge details
            - label: Underlayment &amp; decking
            - label: Materials delivery &amp; storage
            - label: Final cleanup &amp; magnet roll
      - type: textarea
        id: notes
        attributes:
          label: Notes / Observations
          placeholder: Brief bullets; attach photos separately.
    &quot;&quot;&quot; )

files[&quot;.github/ISSUE_TEMPLATE/punchlist.yml&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    name: Punchlist
    description: Track fixes outstanding on a job.
    title: &quot;[PL] &lt;CustomerLastName&gt; — &lt;Street Address&gt;&quot;
    labels: [&quot;Punchlist&quot;]
    body:
      - type: input
        id: job_id
        attributes:
          label: Job ID / Claim #
        validations:
          required: true
      - type: textarea
        id: items
        attributes:
          label: Items
          description: One per line. Use short bullets.
          placeholder: |
            - Replace missing ridge cap on N-facing hip
            - Seal pipe boot @ kitchen vent
            - Paint exposed fasteners on drip edge
      - type: dropdown
        id: status
        attributes:
          label: Status
          options:
            - New
            - Scheduled
            - In Progress
            - Blocked
            - Done
    &quot;&quot;&quot; )

files[&quot;.github/ISSUE_TEMPLATE/daily_log.yml&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    name: Daily Log
    description: Personal daily PM/QC notes
    title: &quot;Daily Log — {{date}}&quot;
    labels: [&quot;Dashboard&quot;]
    body:
      - type: textarea
        id: plan
        attributes:
          label: Plan for today
          placeholder: Top 3 and any hard appointments.
      - type: textarea
        id: done
        attributes:
          label: What I did
          placeholder: Wins, blockers, context.
      - type: textarea
        id: followups
        attributes:
          label: Follow-ups
          placeholder: People to ping, docs to send, etc.
    &quot;&quot;&quot;)

files[&quot;.github/ISSUE_TEMPLATE/vendor_inspection.yml&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    name: Vendor/Material Inspection
    description: Record vendor deliveries and material checks
    title: &quot;[Vendor] &lt;Supplier&gt; — &lt;PO or Ticket&gt;&quot;
    labels: [&quot;Vendor&quot;,&quot;Materials&quot;]
    body:
      - type: input
        id: supplier
        attributes:
          label: Supplier
          placeholder: e.g., ABC Supply
        validations:
          required: true
      - type: textarea
        id: materials
        attributes:
          label: Materials received
          placeholder: |
            - Shingle: 3-tab IR, driftwood, 75 bundles
            - Underlayment: synthetic, 10 rolls
            - Drip edge: black, 250 ft
      - type: checkboxes
        id: checks
        attributes:
          label: Checks
          options:
            - label: Counts match PO
            - label: Pallets wrapped/covered
            - label: Stored off ground
            - label: No visible damage
            - label: Color/lot matched
    &quot;&quot;&quot;)

# Checklists
files[&quot;docs/checklists/job-qc-audit.md&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    # Job QC Audit — Checklist
    
    - [ ] **Permits &amp; HOA** posted/approved
    - [ ] **Decking** sound; replace rot/soft spots; nails flush
    - [ ] **Underlayment** overlapped, nailed per spec; valleys reinforced
    - [ ] **Flashing**: step, counter, apron, chimney cricket as needed
    - [ ] **Penetrations**: boots sized/sealed; satellite re-mounted/marked
    - [ ] **Edges**: drip edge continuous; starter course aligned
    - [ ] **Shingles/Panels** aligned; fastener pattern per manufacturer
    - [ ] **Ridge/Hip** caps correct; ventilation clear
    - [ ] **Site**: tarps, magnet sweep, nails/debris removed
    - [ ] **Photos**: elevations, planes, details, serials, materials
    - [ ] **Customer** walk-through + signoff
    &quot;&quot;&quot;)

files[&quot;docs/checklists/punchlist.md&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    # Punchlist — Checklist
    
    Add items below as task list:
    - [ ] Item 1
    - [ ] Item 2
    - [ ] Item 3
    &quot;&quot;&quot;)

files[&quot;docs/checklists/safety-spotcheck.md&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    # Safety Spot-Check
    
    - [ ] Harnesses tied-off (100%)
    - [ ] Ladders 3&#x27; above roof, secured
    - [ ] Toe-boards/guarding as required
    - [ ] Weather within safe limits
    - [ ] House perimeter protected; signage
    - [ ] First-aid and extinguisher on site
    &quot;&quot;&quot;)

# Process docs
files[&quot;docs/process/triage.md&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    # Triage — How We Flow
    - Use **Job QC Audit** for each job and phase.
    - Use **Punchlist** for fixes; link to the job audit via `Blocks:` / `Relates to:`.
    - Label wisely: `QC`, `Punchlist`, `Safety`, `Scheduling`, `Materials`, `Vendor`, `Warranty`, `Customer`.
    - The **Daily QC Digest** GitHub Action opens a dashboard issue every morning.
    &quot;&quot;&quot;)

files[&quot;docs/process/privacy.md&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    # Privacy &amp; Data Boundaries
    - Do not paste PII beyond what is necessary (use job ID, not full claimant SSN/etc.).
    - Store photos in a private bucket if needed; link from issues instead of committing large images.
    - Secrets for email/calendar integrations must go in **Settings → Secrets and variables → Actions**.
    &quot;&quot;&quot;)

# Templates
files[&quot;docs/templates/comment-prompt.txt&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    When commenting on issues:
    - Keep bullets tight (1–2 lines)
    - Reference photos or docs with links
    - Add/adjust labels to trigger automations where useful
    &quot;&quot;&quot;)

# Kodex prompt
files[&quot;ops/kodex/CODEX.md&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    # Kodex Ops Prompt — PM/QC @ Texas Choice Roofing
    
    ## Prime Directives
    - Keep GitHub as the **single source of truth** for tasks, QC, punchlists.
    - Use issue templates and labels; avoid free-form issues unless necessary.
    - Prefer edits/comments over new issues when updating the same job.
    
    ## Task Menu
    1) **Open Job QC Audit**
       - Use the form `Job QC Audit`
       - Title: `[QC] LastName — Street`
       - Add labels: `QC` (+ `Safety` if relevant)
    2) **Open Punchlist**
       - Use `Punchlist` form; link it to the related QC issue in the body.
       - Label: `Punchlist`
    3) **Daily Log**
       - Use `Daily Log` form for your personal notes.
    4) **Morning Digest**
       - If no digest today, create issue titled `QC Dashboard — &lt;YYYY-MM-DD&gt;` and paste rollups
         from recent open `QC` and `Punchlist` issues.
    
    ## Style
    - Short bullets; start with verbs.
    - Add photos as links; group them by area.
    - Keep address/ID consistent across artifacts.
    
    ## Safety
    - Escalate anything labeled `Safety` + `Urgent` by @-mentioning the PM on duty.
    &quot;&quot;&quot;)

# Scripts (placeholder utility)
files[&quot;scripts/README.md&quot;] = &quot;Utility scripts can live here (optional).&quot;

# Write files
for rel, content in files.items():
    full = os.path.join(base, rel)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
        f.write(content)

# Create zip
zip_path = &quot;/mnt/data/pm-qc-tcr-starter.zip&quot;
with zipfile.ZipFile(zip_path, &quot;w&quot;, zipfile.ZIP_DEFLATED) as z:
    for root, dirs, fs in os.walk(base):
        for name in fs:
            p = os.path.join(root, name)
            z.write(p, arcname=os.path.relpath(p, base))

zip_path

---

**assistant:**

# Re-run generation with safer string handling (no Python f-strings inside GitHub expressions).

import os, json, textwrap, zipfile, datetime

base = &quot;/mnt/data/pm-qc-tcr-starter&quot;
if os.path.exists(base):
    # clean
    import shutil
    shutil.rmtree(base)
os.makedirs(base, exist_ok=True)

paths = [
    &quot;.github/workflows&quot;,
    &quot;.github/ISSUE_TEMPLATE&quot;,
    &quot;docs/checklists&quot;,
    &quot;docs/process&quot;,
    &quot;docs/templates&quot;,
    &quot;ops/kodex&quot;,
    &quot;scripts&quot;,
]
for p in paths:
    os.makedirs(os.path.join(base, p), exist_ok=True)

today = datetime.date.today().isoformat()

files = {}

files[&quot;README.md&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    # PM · QC · Texas Choice Roofing

    A lightweight, automation-friendly hub for **Project Management** and **Quality Control** at Texas Choice Roofing (TCR).  
    This repo is designed to work well with ChatGPT (Sage) and the **Kodex** environment to standardize checklists, open issues from templates, and generate daily digests via GitHub Actions.

    ## Quick Start
    1. **Add these files** to your repo (copy from the zip or commit directly).
    2. In GitHub → **Settings → Actions → General**, set: *Allow GitHub Actions to create and approve pull requests.*
    3. (Optional) In **Settings → Secrets and variables → Actions**, add org- or repo-level secrets you plan to use later (e.g., `GMAIL_APP_PASSWORD`, `GCAL_WEBHOOK_URL`). Workflows included here will run without secrets; integrations are modular.
    4. Use the **Issue templates** to log work:
       - `Job QC Audit`
       - `Punchlist`
       - `Daily Log`
       - `Vendor/Material Inspection`

    ## Automation Overview
    - **Daily Digest**: opens a daily “QC Dashboard — {{TODAY}}” issue at 7:30 AM America/Chicago with rollups (open punchlists, audits due, jobs by status).
    - **Label Sync**: ensures a stable, color-coded label set (QC, Punchlist, Safety, Urgent, Scheduling, Materials, Warranty, Customer, Vendor).
    - **Auto-Checklist**: when you create an issue from a form, the workflow posts the matching checklist into the body and keeps it in sync on edits.

    ## Folder Map
    ```
    .github/
      ISSUE_TEMPLATE/         # GitHub Issue forms for consistent logging
      workflows/              # Actions that build daily digest, sync labels, post checklists
    docs/
      checklists/             # Source checklists used by forms &amp; bots
      process/                # SOPs and “how-we-work” docs
      templates/              # Reusable text snippets and comment blocks
    ops/
      kodex/                  # Prompts and runbooks for Kodex
    scripts/                  # Utility scripts (optional)
    ```
    ## Kodex
    See `ops/kodex/CODEX.md` for the canonical prompt and the task menu. Use it in the Kodex environment to open/triage issues, run checklists, and prepare digests.

    ---

    © 2025 Texas Choice Roofing — Internal tooling. Apache-2.0 license.
    &quot;&quot;&quot;.replace(&quot;{{TODAY}}&quot;, today)
)

files[&quot;LICENSE&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    Apache License
    Version 2.0, January 2004
    http://www.apache.org/licenses/

    TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

    Copyright 2025 Texas Choice Roofing

    Licensed under the Apache License, Version 2.0 (the &quot;License&quot;);
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an &quot;AS IS&quot; BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
    &quot;&quot;&quot;)

# daily-digest workflow with placeholders for GitHub expressions
daily_digest = textwrap.dedent(&quot;&quot;&quot;\
    name: Daily QC Digest
    on:
      schedule:
        - cron: &quot;30 12 * * *&quot;  # 07:30 America/Chicago
      workflow_dispatch: {}
    jobs:
      digest:
        runs-on: ubuntu-latest
        permissions:
          issues: write
          contents: read
        steps:
          - uses: actions/checkout@v4
          - name: Build digest body
            id: body
            run: |
              echo &quot;## QC Dashboard — {{TODAY}}&quot; &gt; body.md
              echo &quot;&quot; &gt;&gt; body.md
              echo &quot;### Open Punchlists&quot; &gt;&gt; body.md
              echo &quot;&quot; &gt;&gt; body.md
              echo &quot;$(gh issue list --label &#x27;Punchlist&#x27; --state open --limit 50 --json number,title,state,labels --template &#x27;{{range .}}{{.number}} · {{.title}}\\n{{end}}&#x27; || true)&quot; &gt;&gt; body.md
              echo &quot;&quot; &gt;&gt; body.md
              echo &quot;### Audits Due (label: QC)&quot; &gt;&gt; body.md
              echo &quot;&quot; &gt;&gt; body.md
              echo &quot;$(gh issue list --label &#x27;QC&#x27; --state open --limit 50 --json number,title,state,labels --template &#x27;{{range .}}{{.number}} · {{.title}}\\n{{end}}&#x27; || true)&quot; &gt;&gt; body.md
              echo &quot;&quot; &gt;&gt; body.md
              echo &quot;### Urgent&quot; &gt;&gt; body.md
              echo &quot;&quot; &gt;&gt; body.md
              echo &quot;$(gh issue list --label &#x27;Urgent&#x27; --state open --limit 50 --json number,title,state,labels --template &#x27;{{range .}}{{.number}} · {{.title}}\\n{{end}}&#x27; || true)&quot; &gt;&gt; body.md
              echo &quot;BODY&lt;&lt;EOF&quot; &gt;&gt; $GITHUB_OUTPUT
              sed -n &#x27;1,200p&#x27; body.md &gt;&gt; $GITHUB_OUTPUT
              echo &quot;EOF&quot; &gt;&gt; $GITHUB_OUTPUT
            env:
              GH_TOKEN: ${{GITHUB_TOKEN}}
          - name: Open or update today&#x27;s digest
            env:
              GH_TOKEN: ${{GITHUB_TOKEN}}
            run: |
              set -e
              TITLE=&quot;QC Dashboard — {{TODAY}}&quot;
              NUM=$(gh issue list --search &quot;in:title {{TODAY}} QC Dashboard&quot; --json number --jq &quot;.[0].number&quot; || true)
              if [ -z &quot;$NUM&quot; ] || [ &quot;$NUM&quot; = &quot;null&quot; ]; then
                gh issue create --title &quot;$TITLE&quot; --body &quot;${{ steps.body.outputs.BODY }}&quot; --label &quot;QC,Dashboard&quot;
              else
                gh issue comment &quot;$NUM&quot; --body &quot;🔄 Auto-update at $(date -u +%H:%M) UTC&quot;
                gh issue edit &quot;$NUM&quot; --body &quot;${{ steps.body.outputs.BODY }}&quot;
              fi
    &quot;&quot;&quot;).replace(&quot;{{TODAY}}&quot;, today).replace(&quot;${{GITHUB_TOKEN}}&quot;, &quot;${{ github.token }}&quot;)

files[&quot;.github/workflows/daily-digest.yml&quot;] = daily_digest

files[&quot;.github/workflows/label-sync.yml&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    name: Sync Labels
    on:
      push:
        paths:
          - .github/labels.json
      workflow_dispatch: {}
    jobs:
      sync:
        runs-on: ubuntu-latest
        permissions:
          issues: write
          contents: read
        steps:
          - uses: actions/checkout@v4
          - uses: crazy-max/ghaction-github-labeler@v5
            with:
              github-token: ${{ secrets.GITHUB_TOKEN }}
              yaml-file: .github/labels.json
              skip-delete: false
    &quot;&quot;&quot;)

files[&quot;.github/labels.json&quot;] = json.dumps([
    {&quot;name&quot;: &quot;QC&quot;, &quot;color&quot;: &quot;0e8a16&quot;, &quot;description&quot;: &quot;Quality Control / Audit&quot;},
    {&quot;name&quot;: &quot;Punchlist&quot;, &quot;color&quot;: &quot;c5def5&quot;, &quot;description&quot;: &quot;Outstanding fixes&quot;},
    {&quot;name&quot;: &quot;Safety&quot;, &quot;color&quot;: &quot;d93f0b&quot;, &quot;description&quot;: &quot;Safety concerns / reports&quot;},
    {&quot;name&quot;: &quot;Urgent&quot;, &quot;color&quot;: &quot;b60205&quot;, &quot;description&quot;: &quot;High priority&quot;},
    {&quot;name&quot;: &quot;Scheduling&quot;, &quot;color&quot;: &quot;5319e7&quot;, &quot;description&quot;: &quot;Calendar / timing&quot;},
    {&quot;name&quot;: &quot;Materials&quot;, &quot;color&quot;: &quot;1d76db&quot;, &quot;description&quot;: &quot;Vendors, materials, delivery&quot;},
    {&quot;name&quot;: &quot;Warranty&quot;, &quot;color&quot;: &quot;f9d0c4&quot;, &quot;description&quot;: &quot;Warranty matters&quot;},
    {&quot;name&quot;: &quot;Customer&quot;, &quot;color&quot;: &quot;fbca04&quot;, &quot;description&quot;: &quot;Customer communication&quot;},
    {&quot;name&quot;: &quot;Vendor&quot;, &quot;color&quot;: &quot;e99695&quot;, &quot;description&quot;: &quot;Vendor coordination&quot;},
    {&quot;name&quot;: &quot;Dashboard&quot;, &quot;color&quot;: &quot;ededed&quot;, &quot;description&quot;: &quot;Bot-created status issues&quot;}
], indent=2)

files[&quot;.github/workflows/post-checklist.yml&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    name: Post Checklist on Issue
    on:
      issues:
        types: [opened, edited]
    jobs:
      apply:
        runs-on: ubuntu-latest
        permissions:
          issues: write
          contents: read
        steps:
          - uses: actions/checkout@v4
          - name: Determine checklist
            id: pick
            run: |
              TITLE=&quot;${{ github.event.issue.title }}&quot;
              LABELS=&quot;$(jq -r &#x27;[ .issue.labels[].name ] | join(\&quot;,\&quot;)&#x27; &lt; $GITHUB_EVENT_PATH)&quot;
              FILE=&quot;&quot;
              if echo &quot;$LABELS&quot; | grep -qi &quot;Punchlist&quot;; then FILE=&quot;docs/checklists/punchlist.md&quot;; fi
              if echo &quot;$LABELS&quot; | grep -qi &quot;QC&quot;; then FILE=&quot;docs/checklists/job-qc-audit.md&quot;; fi
              if echo &quot;$LABELS&quot; | grep -qi &quot;Safety&quot;; then FILE=&quot;docs/checklists/safety-spotcheck.md&quot;; fi
              echo &quot;file=$FILE&quot; &gt;&gt; $GITHUB_OUTPUT
          - name: Update issue body
            if: steps.pick.outputs.file != &#x27;&#x27;
            env:
              GH_TOKEN: ${{ github.token }}
            run: |
              BODY=&quot;$(cat ${{ steps.pick.outputs.file }})&quot;
              gh issue edit ${{ github.event.issue.number }} --body &quot;$BODY&quot;
    &quot;&quot;&quot;)

# ISSUE TEMPLATES
files[&quot;.github/ISSUE_TEMPLATE/job_qc_audit.yml&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    name: Job QC Audit
    description: Structured audit for a roof job (pre/during/post).
    title: &quot;[QC] &lt;CustomerLastName&gt; — &lt;Street Address&gt;&quot;
    labels: [&quot;QC&quot;]
    body:
      - type: input
        id: job_id
        attributes:
          label: Job ID / Claim #
          placeholder: e.g., TCR-24-0912 or 1234567
        validations:
          required: true
      - type: input
        id: address
        attributes:
          label: Address
          placeholder: 123 Main St, Austin, TX
        validations:
          required: true
      - type: dropdown
        id: phase
        attributes:
          label: Project Phase
          options:
            - Pre-Install
            - In-Progress
            - Post-Install
            - Warranty/Service
        validations:
          required: true
      - type: checkboxes
        id: photo_sets
        attributes:
          label: Photo Sets Attached
          options:
            - label: Front/Back/Left/Right elevations
            - label: Roof planes overview
            - label: Flashings &amp; penetrations
            - label: Valleys &amp; step flashing
            - label: Ridge/hip/edge details
            - label: Underlayment &amp; decking
            - label: Materials delivery &amp; storage
            - label: Final cleanup &amp; magnet roll
      - type: textarea
        id: notes
        attributes:
          label: Notes / Observations
          placeholder: Brief bullets; attach photos separately.
    &quot;&quot;&quot;)

files[&quot;.github/ISSUE_TEMPLATE/punchlist.yml&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    name: Punchlist
    description: Track fixes outstanding on a job.
    title: &quot;[PL] &lt;CustomerLastName&gt; — &lt;Street Address&gt;&quot;
    labels: [&quot;Punchlist&quot;]
    body:
      - type: input
        id: job_id
        attributes:
          label: Job ID / Claim #
        validations:
          required: true
      - type: textarea
        id: items
        attributes:
          label: Items
          description: One per line. Use short bullets.
          placeholder: |
            - Replace missing ridge cap on N-facing hip
            - Seal pipe boot @ kitchen vent
            - Paint exposed fasteners on drip edge
      - type: dropdown
        id: status
        attributes:
          label: Status
          options:
            - New
            - Scheduled
            - In Progress
            - Blocked
            - Done
    &quot;&quot;&quot;)

files[&quot;.github/ISSUE_TEMPLATE/daily_log.yml&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    name: Daily Log
    description: Personal daily PM/QC notes
    title: &quot;Daily Log — {{date}}&quot;
    labels: [&quot;Dashboard&quot;]
    body:
      - type: textarea
        id: plan
        attributes:
          label: Plan for today
          placeholder: Top 3 and any hard appointments.
      - type: textarea
        id: done
        attributes:
          label: What I did
          placeholder: Wins, blockers, context.
      - type: textarea
        id: followups
        attributes:
          label: Follow-ups
          placeholder: People to ping, docs to send, etc.
    &quot;&quot;&quot;)

files[&quot;.github/ISSUE_TEMPLATE/vendor_inspection.yml&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    name: Vendor/Material Inspection
    description: Record vendor deliveries and material checks
    title: &quot;[Vendor] &lt;Supplier&gt; — &lt;PO or Ticket&gt;&quot;
    labels: [&quot;Vendor&quot;,&quot;Materials&quot;]
    body:
      - type: input
        id: supplier
        attributes:
          label: Supplier
          placeholder: e.g., ABC Supply
        validations:
          required: true
      - type: textarea
        id: materials
        attributes:
          label: Materials received
          placeholder: |
            - Shingle: 3-tab IR, driftwood, 75 bundles
            - Underlayment: synthetic, 10 rolls
            - Drip edge: black, 250 ft
      - type: checkboxes
        id: checks
        attributes:
          label: Checks
          options:
            - label: Counts match PO
            - label: Pallets wrapped/covered
            - label: Stored off ground
            - label: No visible damage
            - label: Color/lot matched
    &quot;&quot;&quot;)

# Checklists
files[&quot;docs/checklists/job-qc-audit.md&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    # Job QC Audit — Checklist

    - [ ] **Permits &amp; HOA** posted/approved
    - [ ] **Decking** sound; replace rot/soft spots; nails flush
    - [ ] **Underlayment** overlapped, nailed per spec; valleys reinforced
    - [ ] **Flashing**: step, counter, apron, chimney cricket as needed
    - [ ] **Penetrations**: boots sized/sealed; satellite re-mounted/marked
    - [ ] **Edges**: drip edge continuous; starter course aligned
    - [ ] **Shingles/Panels** aligned; fastener pattern per manufacturer
    - [ ] **Ridge/Hip** caps correct; ventilation clear
    - [ ] **Site**: tarps, magnet sweep, nails/debris removed
    - [ ] **Photos**: elevations, planes, details, serials, materials
    - [ ] **Customer** walk-through + signoff
    &quot;&quot;&quot;)

files[&quot;docs/checklists/punchlist.md&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    # Punchlist — Checklist

    Add items below as task list:
    - [ ] Item 1
    - [ ] Item 2
    - [ ] Item 3
    &quot;&quot;&quot;)

files[&quot;docs/checklists/safety-spotcheck.md&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    # Safety Spot-Check

    - [ ] Harnesses tied-off (100%)
    - [ ] Ladders 3&#x27; above roof, secured
    - [ ] Toe-boards/guarding as required
    - [ ] Weather within safe limits
    - [ ] House perimeter protected; signage
    - [ ] First-aid and extinguisher on site
    &quot;&quot;&quot;)

# Process docs
files[&quot;docs/process/triage.md&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    # Triage — How We Flow
    - Use **Job QC Audit** for each job and phase.
    - Use **Punchlist** for fixes; link to the job audit via `Blocks:` / `Relates to:`.
    - Label wisely: `QC`, `Punchlist`, `Safety`, `Scheduling`, `Materials`, `Vendor`, `Warranty`, `Customer`.
    - The **Daily QC Digest** GitHub Action opens a dashboard issue every morning.
    &quot;&quot;&quot;)

files[&quot;docs/process/privacy.md&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    # Privacy &amp; Data Boundaries
    - Do not paste PII beyond what is necessary (use job ID, not full claimant SSN/etc.).
    - Store photos in a private bucket if needed; link from issues instead of committing large images.
    - Secrets for email/calendar integrations must go in **Settings → Secrets and variables → Actions**.
    &quot;&quot;&quot;)

# Templates
files[&quot;docs/templates/comment-prompt.txt&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    When commenting on issues:
    - Keep bullets tight (1–2 lines)
    - Reference photos or docs with links
    - Add/adjust labels to trigger automations where useful
    &quot;&quot;&quot;)

# Kodex prompt
files[&quot;ops/kodex/CODEX.md&quot;] = textwrap.dedent(&quot;&quot;&quot;\
    # Kodex Ops Prompt — PM/QC @ Texas Choice Roofing

    ## Prime Directives
    - Keep GitHub as the **single source of truth** for tasks, QC, punchlists.
    - Use issue templates and labels; avoid free-form issues unless necessary.
    - Prefer edits/comments over new issues when updating the same job.

    ## Task Menu
    1) **Open Job QC Audit**
       - Use the form `Job QC Audit`
       - Title: `[QC] LastName — Street`
       - Add labels: `QC` (+ `Safety` if relevant)
    2) **Open Punchlist**
       - Use `Punchlist` form; link it to the related QC issue in the body.
       - Label: `Punchlist`
    3) **Daily Log**
       - Use `Daily Log` form for your personal notes.
    4) **Morning Digest**
       - If no digest today, create issue titled `QC Dashboard — &lt;YYYY-MM-DD&gt;` and paste rollups
         from recent open `QC` and `Punchlist` issues.

    ## Style
    - Short bullets; start with verbs.
    - Add photos as links; group them by area.
    - Keep address/ID consistent across artifacts.

    ## Safety
    - Escalate anything labeled `Safety` + `Urgent` by @-mentioning the PM on duty.
    &quot;&quot;&quot;)

files[&quot;scripts/README.md&quot;] = &quot;Utility scripts can live here (optional).&quot;

# Write files
for rel, content in files.items():
    full = os.path.join(base, rel)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
        f.write(content)

# Zip it
zip_path = &quot;/mnt/data/pm-qc-tcr-starter.zip&quot;
with zipfile.ZipFile(zip_path, &quot;w&quot;, zipfile.ZIP_DEFLATED) as z:
    for root, dirs, fs in os.walk(base):
        for name in fs:
            p = os.path.join(root, name)
            z.write(p, arcname=os.path.relpath(p, base))

zip_path

---

**assistant:**

Absolutely. Let’s turn your repo into a living PM/QC command center that works with you + Kodex.

I’ve packaged a ready-to-commit starter kit with:
- Issue **forms** for Job QC audits, Punchlists, Daily Log, Vendor/Material inspections
- **Checklists** that auto-populate on issues
- A **Daily QC Digest** GitHub Action (opens a morning dashboard issue at 7:30 AM CT)
- **Label sync** (keeps a consistent label set for QC/Punchlist/Safety/etc.)
- A concise **Kodex ops prompt** you can paste into the Kodex environment

[Download the starter pack (zip)](sandbox:/mnt/data/pm-qc-tcr-starter.zip)

### How to use (quick)
1) Unzip → copy everything into `PM-QC-TCR` and commit.
2) In GitHub: **Settings → Actions → General** → allow Actions to create/approve PRs.  
3) (Optional) Later, add secrets for email/calendar integrations under **Settings → Secrets and variables → Actions**.
4) Use **Issues → New issue** and pick a form (Job QC Audit, Punchlist, Daily Log, Vendor/Material).  
   - Labels you pick will trigger the **Auto-Checklist** workflow to post the right checklist.
5) Each morning you’ll get a `QC Dashboard — YYYY-MM-DD` issue with open punchlists, audits, and urgent items rolled up.

### What’s inside
- `.github/ISSUE_TEMPLATE/…` — Job QC Audit, Punchlist, Daily Log, Vendor inspection (forms)
- `.github/workflows/…`
  - `daily-digest.yml` — opens/updates your morning dashboard
  - `label-sync.yml` — loads color-coded labels from `.github/labels.json`
  - `post-checklist.yml` — injects the right checklist into new/edited issues
- `docs/checklists/` — QC, Punchlist, Safety spot-check lists
- `docs/process/` — triage flow + privacy guardrails
- `ops/kodex/CODEX.md` — the Kodex prompt + task menu (open audits, punchlists, daily logs, morning digest)

### Next small wins we can add
- **Email triage → Issues:** Gmail label → GitHub Issue via a lightweight relay (uses one secret).
- **Calendar nudges:** “Audits due today” comment on the dashboard via cron.
- **Photo handling:** simple pattern to link Google Drive/Dropbox photo sets per job without bloating the repo.

If you want, I’ll tailor the checklists for TCR’s exact install standards (underlayment, flashing, ventilation, cleanup, warranty photos). Just say “tune the QC list” and I’ll ship the updated forms + docs.

---

**user:**

Hold for now. Here is the repo:

https://github.com/justindbilyeu/PM-QC-TCR

---

**assistant:**

Got it—holding. I took a peek at the repo and it’s basically a clean slate with a README, so we’re in a perfect spot to layer in the PM/QC tooling when you’re ready. citeturn0view0

Whenever you give the word, I’ll drop in:
- issue forms (QC audit, punchlist, daily log, vendor/material)
- auto-checklists + label sync
- a 7:30 AM CT daily dashboard action
- a Kodex ops prompt

If you want to prep now, you can just upload this pack into the repo root and commit:
[Download the starter pack](sandbox:/mnt/data/pm-qc-tcr-starter.zip)

Totally fine to pause integrations (email/calendar/time tracking) until you’re ready. Just say “go” and I’ll wire it in.

---

**user:**

Let’s ask CODEX to do these tasks

---

**assistant:**

Perfect—here’s a copy-paste prompt you can drop straight into your CODEX environment to scaffold the repo and open a PR. It’s phased, self-checking, and includes file contents inline so CODEX doesn’t need to fetch anything external.

---

# CODEX RUNBOOK — PM/QC Foundation for `PM-QC-TCR`

## Goal
Create a minimal but complete PM/QC automation scaffold:
- Issue **forms** (QC Audit, Punchlist, Daily Log, Vendor/Material)
- **Checklists** that auto-post on new issues
- **Daily QC Dashboard** action (07:30 America/Chicago)
- **Label Sync** (consistent labels)
- **Kodex ops prompt**

Target branch: `setup/pm-qc-foundation` → open PR.

## Constraints
- Use only repo write primitives (create branch, add files, commit, open PR).
- No secrets required.
- Keep YAML valid; verify with basic `::group::` log checks (CI will run later).

---

## PHASE 1 — Create branch &amp; folders
1) Create a new branch: `setup/pm-qc-foundation`.
2) Ensure folders exist:
```
.github/workflows
.github/ISSUE_TEMPLATE
docs/checklists
docs/process
docs/templates
ops/kodex
scripts
```

---

## PHASE 2 — Add label set + label sync

**File:** `.github/labels.json`
```json
[
  {&quot;name&quot;:&quot;QC&quot;,&quot;color&quot;:&quot;0e8a16&quot;,&quot;description&quot;:&quot;Quality Control / Audit&quot;},
  {&quot;name&quot;:&quot;Punchlist&quot;,&quot;color&quot;:&quot;c5def5&quot;,&quot;description&quot;:&quot;Outstanding fixes&quot;},
  {&quot;name&quot;:&quot;Safety&quot;,&quot;color&quot;:&quot;d93f0b&quot;,&quot;description&quot;:&quot;Safety concerns / reports&quot;},
  {&quot;name&quot;:&quot;Urgent&quot;,&quot;color&quot;:&quot;b60205&quot;,&quot;description&quot;:&quot;High priority&quot;},
  {&quot;name&quot;:&quot;Scheduling&quot;,&quot;color&quot;:&quot;5319e7&quot;,&quot;description&quot;:&quot;Calendar / timing&quot;},
  {&quot;name&quot;:&quot;Materials&quot;,&quot;color&quot;:&quot;1d76db&quot;,&quot;description&quot;:&quot;Vendors, materials, delivery&quot;},
  {&quot;name&quot;:&quot;Warranty&quot;,&quot;color&quot;:&quot;f9d0c4&quot;,&quot;description&quot;:&quot;Warranty matters&quot;},
  {&quot;name&quot;:&quot;Customer&quot;,&quot;color&quot;:&quot;fbca04&quot;,&quot;description&quot;:&quot;Customer communication&quot;},
  {&quot;name&quot;:&quot;Vendor&quot;,&quot;color&quot;:&quot;e99695&quot;,&quot;description&quot;:&quot;Vendor coordination&quot;},
  {&quot;name&quot;:&quot;Dashboard&quot;,&quot;color&quot;:&quot;ededed&quot;,&quot;description&quot;:&quot;Bot-created status issues&quot;}
]
```

**Workflow:** `.github/workflows/label-sync.yml`
```yaml
name: Sync Labels
on:
  push:
    paths:
      - .github/labels.json
  workflow_dispatch: {}
jobs:
  sync:
    runs-on: ubuntu-latest
    permissions:
      issues: write
      contents: read
    steps:
      - uses: actions/checkout@v4
      - uses: crazy-max/ghaction-github-labeler@v5
        with:
          github-token: ${{ secrets.GITHUB_TOKEN }}
          yaml-file: .github/labels.json
          skip-delete: false
```

**Commit message:** `chore(labels): add standard PM/QC label set and sync workflow`

---

## PHASE 3 — Issue forms (4)

**File:** `.github/ISSUE_TEMPLATE/job_qc_audit.yml`
```yaml
name: Job QC Audit
description: Structured audit for a roof job (pre/during/post).
title: &quot;[QC] &lt;CustomerLastName&gt; — &lt;Street Address&gt;&quot;
labels: [&quot;QC&quot;]
body:
  - type: input
    id: job_id
    attributes:
      label: Job ID / Claim #
      placeholder: e.g., TCR-24-0912 or 1234567
    validations:
      required: true
  - type: input
    id: address
    attributes:
      label: Address
      placeholder: 123 Main St, Austin, TX
    validations:
      required: true
  - type: dropdown
    id: phase
    attributes:
      label: Project Phase
      options:
        - Pre-Install
        - In-Progress
        - Post-Install
        - Warranty/Service
    validations:
      required: true
  - type: checkboxes
    id: photo_sets
    attributes:
      label: Photo Sets Attached
      options:
        - label: Front/Back/Left/Right elevations
        - label: Roof planes overview
        - label: Flashings &amp; penetrations
        - label: Valleys &amp; step flashing
        - label: Ridge/hip/edge details
        - label: Underlayment &amp; decking
        - label: Materials delivery &amp; storage
        - label: Final cleanup &amp; magnet roll
  - type: textarea
    id: notes
    attributes:
      label: Notes / Observations
      placeholder: Brief bullets; attach photos separately.
```

**File:** `.github/ISSUE_TEMPLATE/punchlist.yml`
```yaml
name: Punchlist
description: Track fixes outstanding on a job.
title: &quot;[PL] &lt;CustomerLastName&gt; — &lt;Street Address&gt;&quot;
labels: [&quot;Punchlist&quot;]
body:
  - type: input
    id: job_id
    attributes:
      label: Job ID / Claim #
    validations:
      required: true
  - type: textarea
    id: items
    attributes:
      label: Items
      description: One per line. Use short bullets.
      placeholder: |
        - Replace missing ridge cap on N-facing hip
        - Seal pipe boot @ kitchen vent
        - Paint exposed fasteners on drip edge
  - type: dropdown
    id: status
    attributes:
      label: Status
      options:
        - New
        - Scheduled
        - In Progress
        - Blocked
        - Done
```

**File:** `.github/ISSUE_TEMPLATE/daily_log.yml`
```yaml
name: Daily Log
description: Personal daily PM/QC notes
title: &quot;Daily Log — {{date}}&quot;
labels: [&quot;Dashboard&quot;]
body:
  - type: textarea
    id: plan
    attributes:
      label: Plan for today
      placeholder: Top 3 and any hard appointments.
  - type: textarea
    id: done
    attributes:
      label: What I did
      placeholder: Wins, blockers, context.
  - type: textarea
    id: followups
    attributes:
      label: Follow-ups
      placeholder: People to ping, docs to send, etc.
```

**File:** `.github/ISSUE_TEMPLATE/vendor_inspection.yml`
```yaml
name: Vendor/Material Inspection
description: Record vendor deliveries and material checks
title: &quot;[Vendor] &lt;Supplier&gt; — &lt;PO or Ticket&gt;&quot;
labels: [&quot;Vendor&quot;,&quot;Materials&quot;]
body:
  - type: input
    id: supplier
    attributes:
      label: Supplier
      placeholder: e.g., ABC Supply
    validations:
      required: true
  - type: textarea
    id: materials
    attributes:
      label: Materials received
      placeholder: |
        - Shingle: 3-tab IR, driftwood, 75 bundles
        - Underlayment: synthetic, 10 rolls
        - Drip edge: black, 250 ft
  - type: checkboxes
    id: checks
    attributes:
      label: Checks
      options:
        - label: Counts match PO
        - label: Pallets wrapped/covered
        - label: Stored off ground
        - label: No visible damage
        - label: Color/lot matched
```

**Commit message:** `feat(issues): add QC audit, punchlist, daily log, and vendor/material forms`

---

## PHASE 4 — Auto-checklist workflow + checklists

**Workflow:** `.github/workflows/post-checklist.yml`
```yaml
name: Post Checklist on Issue
on:
  issues:
    types: [opened, edited]
jobs:
  apply:
    runs-on: ubuntu-latest
    permissions:
      issues: write
      contents: read
    steps:
      - uses: actions/checkout@v4
      - name: Determine checklist
        id: pick
        run: |
          LABELS=&quot;$(jq -r &#x27;[ .issue.labels[].name ] | join(\&quot;,\&quot;)&#x27; &lt; $GITHUB_EVENT_PATH)&quot;
          FILE=&quot;&quot;
          if echo &quot;$LABELS&quot; | grep -qi &quot;Punchlist&quot;; then FILE=&quot;docs/checklists/punchlist.md&quot;; fi
          if echo &quot;$LABELS&quot; | grep -qi &quot;QC&quot;; then FILE=&quot;docs/checklists/job-qc-audit.md&quot;; fi
          if echo &quot;$LABELS&quot; | grep -qi &quot;Safety&quot;; then FILE=&quot;docs/checklists/safety-spotcheck.md&quot;; fi
          echo &quot;file=$FILE&quot; &gt;&gt; $GITHUB_OUTPUT
      - name: Update issue body
        if: steps.pick.outputs.file != &#x27;&#x27;
        env:
          GH_TOKEN: ${{ github.token }}
        run: |
          BODY=&quot;$(cat ${{ steps.pick.outputs.file }})&quot;
          gh issue edit ${{ github.event.issue.number }} --body &quot;$BODY&quot;
```

**File:** `docs/checklists/job-qc-audit.md`
```md
# Job QC Audit — Checklist

- [ ] **Permits &amp; HOA** posted/approved
- [ ] **Decking** sound; replace rot/soft spots; nails flush
- [ ] **Underlayment** overlapped, nailed per spec; valleys reinforced
- [ ] **Flashing**: step, counter, apron, chimney cricket as needed
- [ ] **Penetrations**: boots sized/sealed; satellite re-mounted/marked
- [ ] **Edges**: drip edge continuous; starter course aligned
- [ ] **Shingles/Panels** aligned; fastener pattern per manufacturer
- [ ] **Ridge/Hip** caps correct; ventilation clear
- [ ] **Site**: tarps, magnet sweep, nails/debris removed
- [ ] **Photos**: elevations, planes, details, serials, materials
- [ ] **Customer** walk-through + signoff
```

**File:** `docs/checklists/punchlist.md`
```md
# Punchlist — Checklist

Add items below as task list:
- [ ] Item 1
- [ ] Item 2
- [ ] Item 3
```

**File:** `docs/checklists/safety-spotcheck.md`
```md
# Safety Spot-Check

- [ ] Harnesses tied-off (100%)
- [ ] Ladders 3&#x27; above roof, secured
- [ ] Toe-boards/guarding as required
- [ ] Weather within safe limits
- [ ] House perimeter protected; signage
- [ ] First-aid and extinguisher on site
```

**Commit message:** `feat(checklists): auto-apply QC/punchlist/safety checklists via workflow`

---

## PHASE 5 — Daily QC Dashboard action

**Workflow:** `.github/workflows/daily-digest.yml`  
*(Runs 07:30 America/Chicago; GitHub uses UTC cron — 12:30 UTC during CDT)*
```yaml
name: Daily QC Digest
on:
  schedule:
    - cron: &quot;30 12 * * *&quot;  # 07:30 America/Chicago
  workflow_dispatch: {}
jobs:
  digest:
    runs-on: ubuntu-latest
    permissions:
      issues: write
      contents: read
    steps:
      - uses: actions/checkout@v4
      - name: Build digest body
        id: body
        run: |
          TODAY=&quot;$(date -u +%F)&quot;
          echo &quot;## QC Dashboard — $TODAY&quot; &gt; body.md
          echo &quot;&quot; &gt;&gt; body.md
          echo &quot;### Open Punchlists&quot; &gt;&gt; body.md
          echo &quot;&quot; &gt;&gt; body.md
          gh issue list --label &#x27;Punchlist&#x27; --state open --limit 50 --json number,title,state,labels --template &#x27;{{range .}}{{.number}} · {{.title}}{{&quot;\\n&quot;}}{{end}}&#x27; &gt;&gt; body.md || true
          echo &quot;&quot; &gt;&gt; body.md
          echo &quot;### Audits Due (label: QC)&quot; &gt;&gt; body.md
          echo &quot;&quot; &gt;&gt; body.md
          gh issue list --label &#x27;QC&#x27; --state open --limit 50 --json number,title,state,labels --template &#x27;{{range .}}{{.number}} · {{.title}}{{&quot;\\n&quot;}}{{end}}&#x27; &gt;&gt; body.md || true
          echo &quot;&quot; &gt;&gt; body.md
          echo &quot;### Urgent&quot; &gt;&gt; body.md
          echo &quot;&quot; &gt;&gt; body.md
          gh issue list --label &#x27;Urgent&#x27; --state open --limit 50 --json number,title,state,labels --template &#x27;{{range .}}{{.number}} · {{.title}}{{&quot;\\n&quot;}}{{end}}&#x27; &gt;&gt; body.md || true
          echo &quot;BODY&lt;&lt;EOF&quot; &gt;&gt; $GITHUB_OUTPUT
          sed -n &#x27;1,200p&#x27; body.md &gt;&gt; $GITHUB_OUTPUT
          echo &quot;EOF&quot; &gt;&gt; $GITHUB_OUTPUT
        env:
          GH_TOKEN: ${{ github.token }}
      - name: Open or update today&#x27;s digest
        env:
          GH_TOKEN: ${{ github.token }}
        run: |
          TITLE=&quot;QC Dashboard — $(date -u +%F)&quot;
          NUM=$(gh issue list --search &quot;in:title $(date -u +%F) QC Dashboard&quot; --json number --jq &quot;.[0].number&quot; || true)
          if [ -z &quot;$NUM&quot; ] || [ &quot;$NUM&quot; = &quot;null&quot; ]; then
            gh issue create --title &quot;$TITLE&quot; --body &quot;${{ steps.body.outputs.BODY }}&quot; --label &quot;QC,Dashboard&quot;
          else
            gh issue comment &quot;$NUM&quot; --body &quot;🔄 Auto-update at $(date -u +%H:%M) UTC&quot;
            gh issue edit &quot;$NUM&quot; --body &quot;${{ steps.body.outputs.BODY }}&quot;
          fi
```

**Commit message:** `feat(dashboard): add 07:30 CT daily QC digest`

---

## PHASE 6 — Kodex ops prompt

**File:** `ops/kodex/CODEX.md`
```md
# Kodex Ops Prompt — PM/QC @ Texas Choice Roofing

## Prime Directives
- Keep GitHub the **single source of truth** for tasks, QC, punchlists.
- Use issue templates and labels; avoid free-form issues when possible.
- Prefer edits/comments over new issues when updating the same job.

## Task Menu
1) **Open Job QC Audit** — use the `Job QC Audit` form; label `QC`.
2) **Open Punchlist** — use `Punchlist` form; link to the related QC issue.
3) **Daily Log** — use `Daily Log` form for personal notes.
4) **Morning Digest** — ensure a `QC Dashboard — &lt;YYYY-MM-DD&gt;` exists.

## Style
- Short bullets; start with verbs.
- Link photos; group by area.
- Keep address/ID consistent across artifacts.

## Safety
- Escalate anything labeled `Safety` + `Urgent` by @-mentioning the PM on duty.
```

**Commit message:** `docs(kodex): add ops prompt for daily use`

---

## PHASE 7 — README touch-up (optional, if not present)

If a README exists, append a short “How to use” section pointing to issue forms and the Kodex doc. If not, create a minimal one:

**File:** `README.md` (create only if missing)
```md
# PM · QC · Texas Choice Roofing

This repo hosts PM/QC workflows, issue forms, and daily automations.
- Open **Issues → New issue** and choose a form (QC Audit, Punchlist, Daily Log, Vendor).
- The **Daily QC Digest** opens an issue each morning at ~07:30 CT.
- Labels are kept in sync via `.github/labels.json`.

See `ops/kodex/CODEX.md` for the Kodex task menu.
```

**Commit message:** `docs: baseline README for PM/QC usage`

---

## PHASE 8 — Open Pull Request
- Title: `feat: PM/QC foundation (forms, labels, dashboard, checklists)`
- Body: Briefly list what’s included and how to test (open a Punchlist issue to see auto-checklist; run “Sync Labels” and “Daily QC Digest” via **Actions → Run workflow** to smoke test).

---

## SUCCESS CRITERIA (self-check)
- [ ] `Issues → New issue` shows 4 forms.
- [ ] `Labels` includes the 10 labels from `.github/labels.json`.
- [ ] “Sync Labels” workflow is present and runnable.
- [ ] Opening a QC or Punchlist issue auto-replaces the body with the right checklist.
- [ ] “Daily QC Digest” workflow exists and manually runs without error.

---

If any step fails, print the failing file path and the exact YAML/JSON line that needs correction, apply a fix, recommit, and continue.

---

**user:**

CODEX said:

I’m operating in read-only QA-review mode for this session, so I’m unable to create branches, edit files, commit, or open pull requests. If you can switch to a mode that allows repository changes, I can help walk through the implementation steps or review them once applied.


Explain how I fix that issue

---

**assistant:**

Yep—this is a permissions/mode issue. CODEX can run in a **read-only QA mode** (review only) or a **write-enabled mode** (can branch/commit/PR). Here’s how to switch it to write and make sure GitHub is authorized correctly:

### 1) Verify you’re using CODEX (not just the GitHub connector)
The regular GitHub connector in ChatGPT is **read-only**. Pushing code/PRs requires **Codex**. In ChatGPT, open the **Codex** sidebar/session for this repo (or the environment link you shared earlier). citeturn0search4turn0search1

### 2) Connect GitHub with write access (first-time or re-auth)
In Codex settings:
- **Connect to GitHub** (OAuth flow).  
- When GitHub asks what to grant, choose **the specific repo** (or “All repos”) and ensure **write** is allowed so Codex can create branches/PRs. If you previously connected with read-only scope, re-authorize and upgrade scopes. citeturn0search16turn0search3

### 3) Attach the right repo &amp; switch mode
In the Codex environment:
- Select the repository **justindbilyeu/PM-QC-TCR**.
- Make sure the task mode is **Build/Write** (not QA/Review). Codex runs tasks in an isolated sandbox tied to the repo; in QA mode it won’t write. citeturn0search3

### 4) Check GitHub repo settings that can block writes
In **PM-QC-TCR → Settings**:
- **Branch protection**: if `main` is protected, that’s fine—Codex should open a **feature branch + PR**. But ensure “Allow GitHub Apps and GitHub Actions to push to matching branches” (or equivalent) isn’t blocking app writes.
- **Third-party access**: if your org enforces app approvals, an owner may need to approve the **OpenAI/Codex** GitHub App for this repo.  
(General guidance from GitHub/Actions docs on write permissions &amp; PR creation.) citeturn0search17

### 5) Retry the runbook
Once write is enabled, re-run the prompt you gave Codex (the phased runbook). In write mode it should:
- create `setup/pm-qc-foundation`
- add files
- commit
- open a PR

### 6) If you’re still stuck
- Ask Codex explicitly: “**Switch to write mode and open a PR**” (some environments expose a toggle).  
- As a fallback, have Codex generate a **patch (git diff)** or **zip** that you can upload via the GitHub web UI; then open the PR yourself. Codex supports producing changes even when it can’t push. citeturn0search1

Want me to sanity-check your Codex environment screen and tell you exactly which toggle to flip? If you paste a screenshot (with the left/right sidebars visible), I’ll point to the exact control.

---

**user:**

Got it. CODEX is working

---

**assistant:**

Great — that means Codex now has write access and can actually branch, commit, and open PRs in your `PM-QC-TCR` repo. 🎉  

**What changed?**  
Before, Codex was running in **QA-only mode** (safe review sandbox). That’s why it told you it couldn’t create files or PRs. You fixed it by switching into a **write-enabled mode** and confirming the GitHub connection with proper **write permissions** on the repo.

**From here:**  
- Re-run the phased runbook I gave you. Codex should now:  
  1. Create a branch (`setup/pm-qc-foundation`)  
  2. Add labels, workflows, issue forms, and checklists  
  3. Commit with structured messages  
  4. Open a PR into `main`  

**Tip:**  
If you ever hit this again, the checklist is:  
1. Make sure you’re in **Codex** (not just GitHub connector).  
2. Confirm the repo is attached in the Codex environment.  
3. Ensure Codex is set to **Build/Write mode**, not **QA/Review**.  
4. Double-check GitHub authorization has **write** scope.  

Want me to slim the runbook down into a **“minimum viable commit” version** (just labels + one issue form + one workflow) so you can do a smoke test first, instead of pushing everything in one go?

---

**user:**

Ok. Codex got that done. Here is the repo so far. 

https://github.com/justindbilyeu/PM-QC-TCR

I want to talk about what we can do moving forward. 
We use google for email , justinb@txchoiceroofing.com
Is it possible to have you pull information from my email?

---

**assistant:**

Yes — but there’s an important distinction here:

### 1. What I can do for you directly
Right now, I can’t reach into your Google account on my own. For privacy/safety, I don’t have passive access to your Gmail. To work with your email, one of two things needs to happen:
- **You connect Gmail as a source** here in ChatGPT. Once connected, I can search, read, and summarize emails for you on demand (e.g., “Show me the last 5 emails from XYZ supplier”).
- **You forward/export** specific emails you want me to process (like copy/paste or upload `.eml`/`.mbox` files). Then I can parse and act on them.

### 2. What we can automate with your repo
Once Gmail is connected:
- **Email → GitHub Issues:** A label in Gmail (“Punchlist,” “Audit,” etc.) could trigger an issue in the repo with the right form + checklist.
- **Daily QC Digest:** The morning digest could include a “New unread emails from vendor/customers” section.
- **Follow-up tracking:** I can auto-tag emails that need replies and push them into GitHub as “Customer” issues.
- **Attachments:** Photo files or PDFs in emails could be linked into issues rather than stored in the repo.

### 3. What’s possible long-term
- **Two-way sync:** Not just pulling in emails, but also having GitHub activity trigger templated replies (e.g., “Audit scheduled” email goes out when you close a scheduling issue).  
- **Calendar integration:** Meeting invites, inspection appointments, or roof installs can flow into the repo or dashboard issues.

---

👉 The next step is: do you want to **connect Gmail to this workspace** so I can search/summarize directly, or should we first build a GitHub Action that polls Gmail with an API key and posts into your repo?  

Would you like me to walk you through setting up the Gmail connector here, or sketch the GitHub Action flow that bridges Gmail → Issues?

---

**user:**

Yes. Let’s connect Gmail to this workspace so you can search/summarize directly

---

**assistant:**

Perfect. Here’s how to connect Gmail into this workspace so I can start pulling and summarizing emails for you:  

---

### 🔑 How to connect Gmail
1. In ChatGPT, open the **“Settings”** menu (bottom-left on desktop, or top-right on mobile).  
2. Go to **Connected Apps / Data Controls → Manage connected apps**.  
3. Look for **Gmail** in the list of connectors.  
4. Click **Connect**, then log in with your Google account (`justinb@txchoiceroofing.com`).  
5. Approve the permissions — you’ll usually see “read emails, metadata, subject, sender” (I don’t get the ability to send/delete).  

---

### ✅ Once connected
- You’ll be able to ask things like:
  - “Show me my last 5 emails from ABC Supply.”
  - “Summarize today’s unread emails labeled ‘Customer’.”
  - “Pull any emails mentioning ‘insurance claim’ this week.”
- I can then integrate these into your GitHub workflows (e.g., **auto-create a Punchlist issue** when an email comes in with “warranty” in the subject).

---

⚠️ **Note:** Until you complete the connector step, I won’t be able to touch Gmail at all — I’ll just see the same public info you see.  

Do you want me to also prep the **GitHub workflow** that will take tagged Gmail messages and push them into issues, so as soon as Gmail is connected we can test it?

---

**user:**

Ok my personal gmail is connected , justindbilyeu@gmail.com. Am I able to connect another email account?

---

**assistant:**

Yes — you can connect **more than one Gmail account** here. Each connected account becomes its own searchable source.  

Here’s what that means for you:  

- Right now, you’ve got **`justindbilyeu@gmail.com`** connected.  
- You can also connect **`justinb@txchoiceroofing.com`** (your work Google Workspace account).  
- Once both are connected, I can search/summarize across either one — you just tell me *which inbox* you want me to pull from. For example:  
  - “Show me the last 5 emails in my **work** Gmail from ABC Supply.”  
  - “Summarize unread emails this week from my **personal** Gmail.”  

---

### How to add another Gmail account
1. Go back to **Settings → Connected apps / Manage connected apps**.  
2. Select **Gmail → Connect another account**.  
3. Sign in with your work account (`justinb@txchoiceroofing.com`).  
4. Approve the same read-only permissions.  

---

👉 Do you want me to set up the GitHub action so that **only your work Gmail (`@txchoiceroofing.com`)** feeds into the PM-QC-TCR repo, while keeping your personal Gmail separate for private use?

---

**user:**

Yes

---

**assistant:**

Awesome — we’ll keep your **personal Gmail private** and wire **only your work Gmail (`justinb@txchoiceroofing.com`) → GitHub issues**.

Here’s a **minimum-viable bridge** you can drop into `PM-QC-TCR`. It runs every 10 minutes (and on manual dispatch), scans your **work inbox** for unread messages matching simple rules, and opens/updates issues with the right labels.

---

# Files to add

## 1) `.github/workflows/work-gmail-to-issues.yml`
```yaml
name: Work Gmail → Issues

on:
  workflow_dispatch: {}
  schedule:
    - cron: &quot;*/10 * * * *&quot;  # every 10 minutes

jobs:
  pull:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      issues: write
    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: &quot;3.11&quot;

      - name: Install deps
        run: |
          python -m pip install --upgrade pip
          pip install google-api-python-client google-auth google-auth-oauthlib google-auth-httplib2 python-dateutil

      - name: Run importer
        env:
          GMAIL_CLIENT_ID: ${{ secrets.WORK_GMAIL_CLIENT_ID }}
          GMAIL_CLIENT_SECRET: ${{ secrets.WORK_GMAIL_CLIENT_SECRET }}
          GMAIL_REFRESH_TOKEN: ${{ secrets.WORK_GMAIL_REFRESH_TOKEN }}
          GMAIL_ADDRESS: &quot;justinb@txchoiceroofing.com&quot;
          GMAIL_QUERY: &#x27;is:unread -in:chats -category:promotions newer_than:7d&#x27;
          LABEL_DEFAULTS: &#x27;Customer&#x27;
          MAP_SUBJECT_TO_LABELS: &gt;
            QC:audit,qc;
            Punchlist:punchlist,pl;
            Vendor:abc supply,invoice,delivery,po;
            Warranty:warranty,claim
        run: |
          python scripts/gmail_to_issues.py
```

## 2) `scripts/gmail_to_issues.py`
```python
import os, re, base64, json, hashlib, subprocess
from datetime import datetime, timezone
from dateutil import parser as dtp

from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

def env(name, default=None, required=False):
    v = os.getenv(name, default)
    if required and not v:
        raise SystemExit(f&quot;Missing env: {name}&quot;)
    return v

CLIENT_ID = env(&quot;GMAIL_CLIENT_ID&quot;, required=True)
CLIENT_SECRET = env(&quot;GMAIL_CLIENT_SECRET&quot;, required=True)
REFRESH_TOKEN = env(&quot;GMAIL_REFRESH_TOKEN&quot;, required=True)
EMAIL = env(&quot;GMAIL_ADDRESS&quot;, required=True)
QUERY = env(&quot;GMAIL_QUERY&quot;, &quot;is:unread newer_than:7d&quot;)
LABEL_DEFAULTS = [l.strip() for l in env(&quot;LABEL_DEFAULTS&quot;, &quot;&quot;).split(&quot;,&quot;) if l.strip()]
MAP_SUBJECT_TO_LABELS = env(&quot;MAP_SUBJECT_TO_LABELS&quot;, &quot;&quot;)

# Build subject→labels mapping
subject_map = {}
for chunk in [c.strip() for c in MAP_SUBJECT_TO_LABELS.split(&quot;;&quot;) if c.strip()]:
    if &quot;:&quot; in chunk:
        label, kws = chunk.split(&quot;:&quot;, 1)
        kws_list = [k.strip() for k in kws.split(&quot;,&quot;) if k.strip()]
        subject_map[label.strip()] = kws_list

# OAuth creds via refresh token
creds = Credentials(
    None,
    refresh_token=REFRESH_TOKEN,
    token_uri=&quot;https://oauth2.googleapis.com/token&quot;,
    client_id=CLIENT_ID,
    client_secret=CLIENT_SECRET,
    scopes=[&quot;https://www.googleapis.com/auth/gmail.readonly&quot;],
)

service = build(&quot;gmail&quot;, &quot;v1&quot;, credentials=creds)
users = service.users()

def list_messages(q, max_results=10):
    resp = users.messages().list(userId=&quot;me&quot;, q=q, maxResults=max_results).execute()
    return resp.get(&quot;messages&quot;, [])

def get_msg(mid):
    return users.messages().get(userId=&quot;me&quot;, id=mid, format=&quot;full&quot;).execute()

def header(hs, name):
    for h in hs:
        if h.get(&quot;name&quot;,&quot;&quot;).lower() == name.lower():
            return h.get(&quot;value&quot;,&quot;&quot;)
    return &quot;&quot;

def decode_body(payload):
    if &quot;data&quot; in payload.get(&quot;body&quot;, {}):
        return base64.urlsafe_b64decode(payload[&quot;body&quot;][&quot;data&quot;]).decode(errors=&quot;ignore&quot;)
    for part in (payload.get(&quot;parts&quot;) or []):
        if part.get(&quot;mimeType&quot;,&quot;&quot;).startswith(&quot;text/plain&quot;):
            if &quot;data&quot; in part[&quot;body&quot;]:
                return base64.urlsafe_b64decode(part[&quot;body&quot;][&quot;data&quot;]).decode(errors=&quot;ignore&quot;)
    return &quot;&quot;

def gh(*args, input_text=None):
    cmd = [&quot;gh&quot;] + list(args)
    res = subprocess.run(cmd, input=input_text.encode() if input_text else None, capture_output=True)
    if res.returncode != 0:
        raise RuntimeError(f&quot;gh {&#x27; &#x27;.join(args)} failed: {res.stderr.decode()}&quot;)
    return res.stdout.decode()

def label_from_subject(subject):
    s = subject.lower()
    matched = []
    for lbl, kws in subject_map.items():
        if any(kw in s for kw in kws):
            matched.append(lbl)
    if not matched:
        matched = LABEL_DEFAULTS.copy()
    return &quot;,&quot;.join(matched) if matched else None

def make_issue_title(subject, date_str):
    dt = None
    try:
        dt = dtp.parse(date_str).astimezone(timezone.utc)
    except Exception:
        dt = datetime.now(timezone.utc)
    dtstamp = dt.strftime(&quot;%Y-%m-%d %H:%M UTC&quot;)
    subj = subject.strip()[:120]
    return f&quot;[Email] {subj} — {dtstamp}&quot;

def issue_exists(fingerprint):
    # Search by fingerprint in title or body
    q = f&#x27;--search &quot;{fingerprint}&quot;&#x27;
    out = gh(&quot;issue&quot;, &quot;list&quot;, &quot;--state&quot;, &quot;open&quot;, &quot;--json&quot;, &quot;number,title&quot;, q)
    data = json.loads(out)
    return data[0][&quot;number&quot;] if data else None

def main():
    msgs = list_messages(QUERY, max_results=15)
    if not msgs:
        print(&quot;No messages matching query.&quot;)
        return

    for m in msgs:
        msg = get_msg(m[&quot;id&quot;])
        hdrs = msg[&quot;payload&quot;].get(&quot;headers&quot;, [])
        subject = header(hdrs, &quot;Subject&quot;) or &quot;(no subject)&quot;
        from_ = header(hdrs, &quot;From&quot;)
        date_ = header(hdrs, &quot;Date&quot;)
        thread_id = msg.get(&quot;threadId&quot;, &quot;&quot;)
        snippet = msg.get(&quot;snippet&quot;,&quot;&quot;)
        body = decode_body(msg[&quot;payload&quot;])

        # fingerprint ties duplicates to one issue
        fp_src = f&quot;{EMAIL}|{thread_id}|{subject}&quot;
        fingerprint = hashlib.sha1(fp_src.encode()).hexdigest()[:12]

        number = issue_exists(fingerprint)
        labels = label_from_subject(subject)

        issue_body = f&quot;&quot;&quot;**From:** {from_}
**To:** {EMAIL}
**Date:** {date_}

**Subject:** {subject}

---

**Snippet:**  
{snippet}

---

**Body (trimmed):**
```
{(body[:3000] + &#x27;…&#x27;) if len(body) &gt; 3000 else body}
```

_Fingerprint: {fingerprint}_
&quot;&quot;&quot;
        if number:
            gh(&quot;issue&quot;, &quot;comment&quot;, str(number), &quot;--body&quot;, f&quot;🔄 Update from Gmail poll @ {datetime.utcnow().isoformat()}Z&quot;)
        else:
            title = make_issue_title(subject, date_)
            args = [&quot;issue&quot;, &quot;create&quot;, &quot;--title&quot;, title, &quot;--body-file&quot;, &quot;-&quot;]
            if labels:
                args += [&quot;--label&quot;, labels]
            gh(*args, input_text=issue_body)

if __name__ == &quot;__main__&quot;:
    main()
```

---

## Setup (one-time)

1) **Create a Google OAuth Client** (for your **work** Google Workspace account):
- App type: **Desktop** (easiest for getting a refresh token)
- Get **Client ID** and **Client Secret**

2) **Generate a Refresh Token** (one-time):
- Use Google’s OAuth flow (e.g., OAuth Playground) with the scope:  
  `https://www.googleapis.com/auth/gmail.readonly`
- Exchange the code for tokens → copy the **refresh token**.

3) In the GitHub repo, add **Actions secrets** (Settings → Secrets and variables → Actions):
- `WORK_GMAIL_CLIENT_ID`
- `WORK_GMAIL_CLIENT_SECRET`
- `WORK_GMAIL_REFRESH_TOKEN`

*(No secrets from your personal Gmail are used. This flow is **work-only**.)*

4) Optional: adjust the search query or label rules in the workflow env:
- `GMAIL_QUERY` (default: unread, last 7 days)
- `MAP_SUBJECT_TO_LABELS` (keyword buckets → labels)
- `LABEL_DEFAULTS` (applied when no keyword matches)

---

## How it respects your split (work vs personal)
- The workflow **only** uses the **work** OAuth credentials + work address.
- Your **personal Gmail connector** in ChatGPT stays available for *ad-hoc asks* (e.g., “summarize my personal inbox today”), but it **does not** feed the repo.

---

If you want, I can also add:
- **De-dup on message-ID** and update the same issue when new messages arrive in the same thread.
- **Auto-close** the issue when the email gets labeled “done” or read (needs write-scope &amp; an extra label).
- A **vendor whitelist** (e.g., if `From: @abcsupply.com` → add `Vendor` + `Materials` labels automatically).

Say the word and I’ll package these as a PR-ready patch.

---

**user:**

Hold for now. Check my email

---

**assistant:**

Here are your 10 most recent emails from your connected Gmail. Want me to flag anything for action or turn any into GitHub issues?

**Job Notification: Mary Ellen Borgelt**  
From: [Justin Bilyeu](reply@mail.acculynx.com)  
Word. I appreciate that View the Message Customer contact information: Borgelt, Mary Ellen Job: NA 3608 Windsor Austin , TX 78703 meborgelt@aol.com - Primary &amp;#40;512&amp;#41; 560-4674 - Primary acculynx-message-…  
[Open in Gmail](https://mail.google.com/mail/#all/19986fdaa7bb1d63)

---

**Job Notification: Mary Ellen Borgelt**  
From: [Terra Friesen](reply@mail.acculynx.com)  
We maaaay need to get an engineer out for an assessment on this house. It&#x27;s not the same weight obviously as like, concrete but it is roughly double the weight of shingles....something to think…  
[Open in Gmail](https://mail.google.com/mail/#all/19986f855cf14d84)

---

**Estimate Complete Stage Beyond 2 Days - 5 Star Vacation Homes at 4400 Aqua Verde, Austin, Texas 78746, Austin, TX 78746 US**  
From: [Cody Kleeves](reply@mail.acculynx.com)  
Automated Message: This lead has been in the &#x27;Estimate Complete&#x27; stage for 2 days. Do one of the following: Send the estimate to client and change status to PROSPECT Already sent the estimate?…  
[Open in Gmail](https://mail.google.com/mail/#all/199850c725f898af)

---

**Texas Choice Roofing: Roofing Shingle Order - 10407 Tildon Ave**  
From: [Cody Kleeves](reply@mail.acculynx.com)  
A labor ticket has been shared with you! Open the attached PDF to view the full labor ticket. Labor Ticket Roofing Shingle Order - 10407 Tildon Ave Catherine Ott Griffith 10407 Tildon Avenue, Austin,…  
[Open in Gmail](https://mail.google.com/mail/#all/199840eb4a549d18)

---

**Invitation: Catherine Ott Install @ Tue Sep 30, 2025 (Justin Bilyeu)**  
From: [Chanel Kleeves](chanel@txchoiceroofing.com)  
Catherine Ott Install 30sq, 6/12 pitch 30sq, 6/12 pitch When Tuesday Sep 30, 2025 Location 10407 Tildon Ave, Austin, TX 78754, USA View map Guests Chanel Kleeves - organizer Andrea Mercury Justin…  
[Open in Gmail](https://mail.google.com/mail/#all/19984063c68b6309)

---

**Texas Choice Roofing: Roofing Shingle Order - 4410 Quicksilver Blvd**  
From: [Cody Kleeves](reply@mail.acculynx.com)  
A labor ticket has been shared with you! Open the attached PDF to view the full labor ticket. Labor Ticket Roofing Shingle Order - 4410 Quicksilver Blvd Curtis Bradford 4410 Quicksilver Blvd, Austin,…  
[Open in Gmail](https://mail.google.com/mail/#all/199822c82e12a46f)

---

**Texas Choice Roofing - You Have a Presentation Available to Review**  
From: [Justin Bilyeu](reply@mail.acculynx.com)  
Texas Choice Roofing Austin , TX You have a new presentation available to view. Skylight Lens Review Contact us: Reply to this email with any questions or reach out directly to your company…  
[Open in Gmail](https://mail.google.com/mail/#all/199808aa080456f2)

---

**Your Password Has Been Updated**  
From: [&quot;360training.com Support&quot;](support@360training.com)  
Dear Justin Bilyeu, Your password has been updated. Site Login: https://lms.360training.com/lms/login.do?brand=AdvanceOnline If you have any questions or if you did not change your password please…  
[Open in Gmail](https://mail.google.com/mail/#all/1997d40d05499974)

---

**Texas Choice Roofing: Roofing Shingle Order - 1607 Lloydminister Way**  
From: [Cody Kleeves](reply@mail.acculynx.com)  
A labor ticket has been shared with you! Open the attached PDF to view the full labor ticket. Labor Ticket Roofing Shingle Order - 1607 Lloydminister Way Edgar Colòn 1607 Lloydminister Way, Cedar Park,…  
[Open in Gmail](https://mail.google.com/mail/#all/1997caa5e305765f)

---

**Invitation: Edgar Colon Install @ Thu Sep 25, 2025 (Justin Bilyeu)**  
From: [Chanel Kleeves](chanel@txchoiceroofing.com)  
Edgar Colon Install You have been invited by Chanel Kleeves to attend an event named Edgar Colon Install on Thursday Sep 25, 2025. When Thursday Sep 25, 2025 Location 1607 Lloydminister Way, Cedar Park…  
[Open in Gmail](https://mail.google.com/mail/#all/19979eb12adca9e8)

---

Say the word and I can:
- turn the **Borgelt** thread into a **QC Audit** issue (and link the AccuLynx job)  
- convert the **Catherine Ott** and **Edgar Colon** invites into **Scheduling** issues  
- add the **Quicksilver Blvd** and **Lloydminister Way** shingle orders as **Vendor/Materials** issues (with attachments noted)

---

