# Build wiki pages

- Conversation ID: 68a2111d-ca00-8323-8972-12b56d61f1e5
- Created: 2025-08-17T17:28:00.698798

---

**user:**

Let’s build the wiki 

https://github.com/justindbilyeu/SCSRRS-TCR/wiki

---

**assistant:**

Perfect—let’s stand the wiki up fast with page-ready Markdown you can paste straight into GitHub. I’m giving you a clean starter set (10 core pages + a shared nav snippet). Create pages in this order; paste each block into a **new wiki page with the matching title**.

---

### 0) Shared Mini-Nav (paste at the top of every page)
```
&gt; [[Home]] · [[Calculator Guide]] · [[Sales Playbook]] · [[Inspection &amp; Scope Capture]] · [[Detach &amp; Reset (Solar)]] · [[Materials &amp; Spec Matrix]] · [[Installation SOP]] · [[Safety &amp; QA]] · [[Insurance &amp; Compliance]] · [[Troubleshooting the Calculator]] · [[Changelog]]
```

---

### 1) Home
```
# SCSRRS-TCR Wiki

&gt; Solar-Connected Storm-Resistant Roofing System — Texas Choice Roofing  
&gt; Observe Precisely. Question Relentlessly. Build with Truth. No Waste.

[[Calculator Guide]] · [[Sales Playbook]] · [[Inspection &amp; Scope Capture]] · [[Detach &amp; Reset (Solar)]] · [[Materials &amp; Spec Matrix]] · [[Installation SOP]] · [[Safety &amp; QA]] · [[Insurance &amp; Compliance]] · [[Troubleshooting the Calculator]] · [[Changelog]]

## What this is
A field-tested playbook + technical reference for selling, scoping, pricing, and installing storm-resilient roofs — with or without solar detach &amp; reset (D&amp;R). Built for phone-first reps and site crews.

## Who this is for
- **Sales**: fast scoping, clear pricing, honest positioning
- **Ops**: consistent installs, safety, QA, and documentation
- **Owners**: margin control, risk reduction, predictable delivery

## Quick Start
1. Read [[Sales Playbook]] for messaging &amp; flow.
2. Use [[Inspection &amp; Scope Capture]] in the field (photos + notes).
3. Run numbers in the [[Calculator Guide]] (on phone).
4. If solar present, follow [[Detach &amp; Reset (Solar)]].
5. Hand off to [[Installation SOP]] with [[Materials &amp; Spec Matrix]] references.
6. Close out with QA in [[Safety &amp; QA]] and document per [[Insurance &amp; Compliance]].

## Core Principles
- **Truth over spin**: No overpromises. Every claim must map to scope or spec.
- **Phone-first**: Capture once, reuse everywhere.
- **Safety is schedule**: Unsafe sites hemorrhage time and money.
- **Documentation wins**: Good notes/photos de-risk claims, change orders, and callbacks.

## Versioning
- Current baseline: **v0.1 (initial)** — see [[Changelog]] for updates.

```

---

### 2) Calculator Guide
```
# Calculator Guide

[[Home]] · [[Sales Playbook]] · [[Inspection &amp; Scope Capture]] · [[Troubleshooting the Calculator]]

## Purpose
A simple, transparent estimator for roof replacement / repair and solar D&amp;R. Designed for **phone use**, **copy-paste** from Roofr reports, and quick “Good/Better/Best” optioning.

## Workflow
1. **Inputs**: copy key measurements (SQ, facets, pitch, eaves, rakes, valleys) from Roofr → paste into the calculator fields.
2. **Options**: select material class (e.g., Class 4 shingle vs. stone-coated steel), underlayment strategy, accessories, D&amp;R if present.
3. **Outputs**: review labor, material, overhead, and margin; present Good/Better/Best.
4. **Documentation**: screenshot customer-facing summary; export or note the Scope ID.

## Inputs (definitions)
- **Roof Area (SQ)**: total squares (1 SQ = 100 ft²).
- **Pitch Class**: Low (≤4/12), Standard (5–7/12), Steep (≥8/12).
- **Edges (LF)**: eaves, rakes; **Valleys (LF)**; **Hips/Ridges (LF)**.
- **Penetrations (count)**: pipes, vents, chimneys, skylights.
- **Tear-off layers (count)**: 1–2 typical.
- **Deck repair allowance (ft²)**: contingency (set conservative default).
- **Solar D&amp;R**: module count, inverter type, racking type, conduit runs, setbacks.

## Outputs
- **Line-item scope** (labor, materials, accessories, waste).
- **Overhead + Profit** derived from policy (see Pricing Policy).
- **Customer view**: Good / Better / Best with notes.

## Updating Rates (owner/operator)
- **Material costs**: update the calculator config (e.g., `config.json` or constants in `script.js`) for shingles, underlayment, flashings, nails, vents.
- **Labor baselines**: update tear-off $/SQ by pitch class; install $/SQ; line rates for valleys, chimneys, etc.
- **Waste factors**: set by pitch + cut complexity; default 10–15%, adjust per plan.
- **D&amp;R**: per-module remove/reinstall + commissioning checks; crane/lift day as needed.

### Example Config Snippet
```json
{
  &quot;labor&quot;: {
    &quot;tearoff&quot;: { &quot;low&quot;: 45, &quot;std&quot;: 55, &quot;steep&quot;: 75 },
    &quot;install&quot;: { &quot;low&quot;: 65, &quot;std&quot;: 80, &quot;steep&quot;: 110 }
  },
  &quot;materials&quot;: {
    &quot;class4_shingle_per_sq&quot;: 210,
    &quot;synthetic_underlayment_per_sq&quot;: 28,
    &quot;ice_water_per_lf&quot;: 2.0,
    &quot;ridge_vent_per_lf&quot;: 7.5
  },
  &quot;dnr&quot;: {
    &quot;module_remove_reinstall&quot;: 85,
    &quot;string_inverter_commission&quot;: 250,
    &quot;microinverter_commission_per_module&quot;: 6
  },
  &quot;overhead_pct&quot;: 0.10,
  &quot;target_profit_pct&quot;: 0.15
}
```

## Presentation (customer)
- Always **tie price deltas to spec deltas** (e.g., Class 4 impact, ventilation, underlayment).
- Show **schedule and disruption** expectations in writing.
- Document exclusions and assumptions (e.g., **hidden decking damage** beyond allowance).

## Guardrails
- Don’t change **rates** in the field. If needed, note a discount line with reason.
- Keep **contingency** lines explicit (decking, rot, code upgrades).
- If insurance is involved, speak only to **scope and code**—not claim outcomes.

```

---

### 3) Sales Playbook
```
# Sales Playbook

[[Home]] · [[Calculator Guide]] · [[Inspection &amp; Scope Capture]]

## Positioning (why us)
- **Storm-resilient by design**: materials + details that actually reduce future loss.
- **Transparent scope &amp; price**: field photos + line-items; no mystery math.
- **Solar-aware**: clean D&amp;R process, safe handling, and proper recommissioning.

## 90-Second Field Flow
1. **Open**: “I’m Justin with Texas Choice Roofing. We specialize in storm-resilient roofs. Quick question: any leaks, granule loss, or insurance questions since the hail/wind?”
2. **Permission**: “If you have 2 minutes, I can photo-document the roofline now and show you what I’m seeing before we talk numbers.”
3. **Evidence**: capture per [[Inspection &amp; Scope Capture]]. Show 3–5 **clear** photos linked to simple explanations.
4. **Options**: “Here’s Good/Better/Best — same house, different lifespan and risk. Which path fits your situation?”
5. **Next step**: schedule attic/roof walk or finalize scope; set install window.

## Message Pillars
- **Clarity** beats charisma.
- **Evidence** beats adjectives.
- **Schedule** beats slogans.

## Common Objections (short answers)
- *“Can you beat their price?”* → “If the scope and specs match, possibly. Let’s align scope first, then I’ll see if we can sharpen.”
- *“Why Class 4?”* → “Better impact resistance and granule retention; fewer callbacks; some carriers credit it.”
- *“Do I need ridge vent?”* → “Your attic photos suggest under-ventilation. Ridge + intakes keep deck temps down, extend shingle life.”

## Close Without Pressure
- Offer **written summary** with photos and scope.
- Provide **install window** options.
- Ask for the **green light to order** once scope is aligned.

```

---

### 4) Inspection &amp; Scope Capture
```
# Inspection &amp; Scope Capture

[[Home]] · [[Sales Playbook]] · [[Calculator Guide]]

## Safety First (non-negotiable)
- Ladder angle 4:1, tie-off where possible, footing verified.
- No roof access in high winds/wet surfaces. Use optics/drone if needed.
- Wear fall protection when required by pitch/exposure.

## Photo Standard (minimum set)
1. **Front elevation** (curb appeal, gutters, downspouts)
2. **Eaves &amp; rakes (close)** — drip edge, rot, detachments
3. **Valleys** — metal type/condition, debris, water path
4. **Hips/Ridges** — ridge cap condition, ventilation type
5. **Penetrations** — pipes, boots, vents, skylights, chimneys (3 sides + flashing)
6. **Attic** — intake vents, baffles, daylight, decking condition, moisture signs
7. **Solar (if present)** — array overview, inverter type, disconnects, labels

## Damage Taxonomy (use consistent language)
- **Shingle**: granule loss, bruising, creases, edge tears, blisters.
- **Metals**: dents, corrosion, failed sealant, loose fasteners.
- **Decking**: delamination, rot, prior patches.
- **Flashings**: improper laps, failed counter-flashing, exposed nails.
- **Ventilation**: inadequate intake/exhaust; blocked soffits.

## Notes to Capture
- Pitch class; layers; deck thickness if visible; ventilation counts.
- Code triggers (valley metal, ice/water in valleys, drip edge, starter).
- Access constraints (lifts, HOA rules, parking).

## Field Checklist (copyable)
- [ ] Ladder safety verified
- [ ] Minimum photo set captured
- [ ] Measurements copied (Roofr → Calculator)
- [ ] Attic inspection (if permission)
- [ ] Solar equipment documented (if present)
- [ ] Homeowner walkthrough done
- [ ] Scope summary written

```

---

### 5) Detach &amp; Reset (Solar)
```
# Detach &amp; Reset (Solar)

[[Home]] · [[Inspection &amp; Scope Capture]] · [[Calculator Guide]] · [[Safety &amp; QA]]

&gt; Goal: remove, store, and reinstall PV safely—no energized surprises, no broken glass, no lost production post-install.

## Pre-Check
- Identify **inverter topology**: string vs. microinverter/DC optimizer.
- Locate and label **AC/DC disconnects**, breakers, combiner(s).
- Photograph nameplates, wiring paths, and roof penetrations.

## Lockout/Tagout (LOTO)
- De-energize per manufacturer sequence (utility/disconnect/inverter).
- Verify absence of voltage; use proper PPE.
- Tag all points with date, job, tech initials.

## Removal
- Soft-edge staging for modules; glass-up only.
- Disconnect module leads; cap/secure connectors.
- Remove clamps/bolts per racking spec; map module positions (grid diagram).
- Lift and store modules in padded racks; weather-safe.

## Roof Work Interface
- Plug/cover penetrations; protect conductor runs.
- Coordinate new underlayment/flashings to manufacturer specs (roof + racking).
- Confirm final penetration count and locations align with structural members.

## Reinstall &amp; Commission
- Reinstall racking to torque spec; verify bonding path.
- Reinstall modules; route conductors; strain-relief at transitions.
- Re-energize in sequence; confirm inverter status, production, and monitoring.
- Document with photos + commissioning sheet.

## Scope Lines (typical)
- Remove/reinstall modules (each)
- Remove/reinstall racking (rail feet, attachments)
- Re-terminate conductors, labels, and touch-safe caps
- Commissioning and monitoring verification
- Lift/crane (if required)

```

---

### 6) Materials &amp; Spec Matrix
```
# Materials &amp; Spec Matrix

[[Home]] · [[Installation SOP]] · [[Calculator Guide]]

&gt; Choose specs to match risk, code, and budget. Tie every upgrade to a concrete benefit.

## Shingles (baseline examples)
| Spec Item | Good (Architectural) | Better (Class 4) | Best (Stone-Coated Steel) |
|---|---|---|---|
| Impact | Standard | Enhanced (Class 4) | Excellent |
| Weight | ~200–230 lb/SQ | ~220–260 lb/SQ | ~150–175 lb/SQ |
| Lifespan (typical) | 20–30 yrs | 25–35 yrs | 40+ yrs |
| Cost (relative) | $ | $$ | $$$ |

## Underlayment
- **Synthetic** baseline; **Ice &amp; Water** in valleys/critical edges as required by code or design.
- For stone-coated steel: confirm **manufacturer-approved underlayment**.

## Flashings &amp; Metals
- Drip edge at eaves/rakes; valley metal gauge consistent with code and manufacturer.
- Step &amp; counter-flashing at walls; new apron at chimneys.

## Ventilation
- Ridge vent with **balanced intake** (soffits). Calculate net free area (NFA) to meet or exceed code.

## Fasteners
- Corrosion-resistant nails; length to achieve required deck penetration.
- Follow manufacturer **nailing pattern** and **quantity per shingle**.

&gt; Final selections must be reflected in the calculator scope and customer summary.

```

---

### 7) Installation SOP
```
# Installation SOP

[[Home]] · [[Materials &amp; Spec Matrix]] · [[Safety &amp; QA]]

## Staging &amp; Protection
- Property protection (plants, AC, windows); magnet sweep perimeter.
- Dumpster/lift placement; weather monitoring.

## Tear-Off
- Sectional removal; immediate deck clean.
- Deck inspection; mark repairs; photograph before/after.

## Dry-In
- Synthetic underlayment; valley treatment (ice/water or metal per plan).
- Drip edge install; starter strip aligned.

## Shingle/Panel Install
- Follow nailing spec; straight courses; minimal shiners.
- Flashings integrated correctly (step, counter, apron).
- Ridge vent and caps; verify intake vents unobstructed.

## Solar Interface (if any)
- Coordinate with [[Detach &amp; Reset (Solar)]] team on penetrations and flashings.

## Cleanup &amp; Closeout
- Full magnet sweep; gutters flushed if needed.
- Warranty packet + photo set delivered.

```

---

### 8) Safety &amp; QA
```
# Safety &amp; QA

[[Home]] · [[Installation SOP]] · [[Inspection &amp; Scope Capture]]

## Safety
- Ladder: correct angle, tie-off; three points of contact.
- Fall protection per pitch/exposure; anchor points verified.
- Weather stops work when surfaces are wet or winds exceed safe limits.

## QA Checkpoints
- Decking repairs documented with measurements and photos.
- Underlayment laps and valleys correct and sealed.
- Flashing details (step/counter/apron) installed and sealed properly.
- Ventilation balanced (intake vs exhaust) and ridge vent continuous.
- Fastener count/pattern verified.

## Sign-offs
- **Crew lead**: scope completed, photos uploaded.
- **QA**: checklist passed, punch items resolved.
- **Homeowner**: walkthrough completed, care/warranty explained.

```

---

### 9) Insurance &amp; Compliance (neutral, homeowner-safe)
```
# Insurance &amp; Compliance (Neutral Language)

[[Home]] · [[Inspection &amp; Scope Capture]]

&gt; We are not giving legal advice. Our role is to document conditions, propose code-compliant scopes, and complete approved work safely and to spec.

## How We Communicate
- Provide **clear photos and plain-language scope** (line items tied to evidence).
- Reference **applicable codes/manufacturer requirements** where relevant.
- Avoid predicting claim outcomes; focus on **what the house needs**.

## Documentation Package
- Photo set (before/during/after)
- Scope with quantities (LF, SQ, count)
- Code/manufacturer references used in the scope
- Change orders with reasons (discovery, code, safety)

## Homeowner Protections
- Transparent pricing tied to work performed
- Written schedule windows and site protection plan
- Warranty packet with materials list and install date

```

---

### 10) Troubleshooting the Calculator
```
# Troubleshooting the Calculator

[[Home]] · [[Calculator Guide]]

## Common Issues

### 1) “Input text is invisible (white on white)”
**Cause**: CSS sets `color: #fff` on inputs or inherited from a container.

**Fix**: In the stylesheet, ensure inputs have explicit text color and background.
```css
input, select, textarea {
  color: #111 !important;
  background: #fff !important;
}
::placeholder { color: #777 !important; opacity: 1; }
```
If on iOS Safari, also add:
```css
input, select, textarea { -webkit-text-fill-color: #111; }
```

### 2) Mobile zoom jumps on focus
Add viewport meta and input font-size ≥16px.
```html
&lt;meta name=&quot;viewport&quot; content=&quot;width=device-width, initial-scale=1, viewport-fit=cover&quot;&gt;
```
```css
input, select { font-size: 16px; }
```

### 3) Copy/paste from Roofr adds spaces/commas
Sanitize inputs in JS:
```js
const toNumber = v =&gt; Number(String(v).replace(/[^0-9.]/g,&#x27;&#x27;) || 0);
```

### 4) Rounding looks “off”
Round **display**, not internal math:
```js
const round2 = n =&gt; Math.round(n * 100) / 100;
```

### 5) Printing/screenshotting summary
Create a print-safe block:
```css
@media print {
  .no-print { display:none; }
  .summary { font-size:12pt; }
}
```

## If Something Breaks
- Hard refresh (clear cache).
- Test on another mobile browser.
- Validate inputs aren’t blank/NaN.

```

---

### 11) Changelog
```
# Changelog

[[Home]]

## v0.1 — Initial (Aug 2025)
- Created core wiki structure (10 pages).
- Added Calculator inputs/outputs and config pattern.
- Added D&amp;R SOP, Safety/QA, and Troubleshooting.

```

---

## What’s next (optional)
- Want me to add **HOA Outreach Letters (5-minute read each)** and a **Warranty Matrix** page next? I can draft both as page-ready Markdown in the same style.

---

**user:**

Give me the Sales Playbook page

---

**assistant:**

```
# Sales Playbook

&gt; [[Home]] · [[Calculator Guide]] · [[Inspection &amp; Scope Capture]] · [[Detach &amp; Reset (Solar)]] · [[Materials &amp; Spec Matrix]] · [[Installation SOP]] · [[Safety &amp; QA]] · [[Insurance &amp; Compliance]] · [[Troubleshooting the Calculator]] · [[Changelog]]

## Purpose
A field-ready sales flow you can run from your phone: document → align scope → price transparently → earn the “yes” without pressure. Built for storm recovery and solar-aware jobs.

---

## Positioning (Why Us)
- **Storm-resilient by design** — specs tied to fewer future problems: impact-rated materials, correct ventilation, clean flashing details.
- **Transparent scope &amp; math** — photos + line items + calculator outputs; no mystery pricing.
- **Solar-aware** — safe PV detach &amp; reset (D&amp;R), proper roof-to-racking interfaces, clean recommissioning.

---

## 90-Second Field Flow (Talk Track)
1) **Open**  
“Hi, I’m Justin with Texas Choice Roofing. We specialize in storm-resilient roofs. Any leaks, granule loss, or insurance questions since the hail/wind?”

2) **Permission to Inspect (from ground)**  
“If you’ve got 2 minutes, I’ll photo-document the roofline and key details now so we’re looking at evidence, not guesses.”

3) **Evidence**  
Show 3–5 clear photos tied to plain language: edges, valleys, penetrations, attic (if allowed). Use the taxonomy in [[Inspection &amp; Scope Capture]].

4) **Options (Good / Better / Best)**  
“Same house, different risk profiles.” Tie each option to spec changes (Class 4, ventilation, flashing upgrades, stone-coated steel).

5) **Next Step**  
“Let’s align the scope in writing, pick an install window, and I’ll lock in material availability.”

---

## Discovery Script (Copy/Paste)
- “Any active leaks or interior staining?”  
- “Age of current roof? Any prior repairs or second layers?”  
- “Attic temps or utility spikes in summer? (Ventilation clues.)”  
- “HOA rules on color/materials? Parking or noise restrictions?”  
- “Solar present? What inverter type—string, micro, or optimizers? Monitoring working?”  
- “Any must-haves or firm budget limits I should respect?”

---

## Evidence Standard (What to Show)
- **Edges &amp; Metals:** drip edge present/condition, valley metal type, improper laps.
- **Shingles:** bruising/creases/granule loss with scale reference.  
- **Penetrations:** boots, chimneys, skylights (3 sides + flashing).  
- **Attic:** intake/exhaust balance, decking condition, daylight, moisture signs.  
- **Solar (if any):** array overview, disconnects, nameplates, wire management.  
Keep the photo set minimal but decisive. Label each photo in plain English.

---

## Framing Options: Good / Better / Best
- **Good (Architectural)** — code-compliant install, synthetic underlayment, corrected flashings, balanced ventilation.  
- **Better (Class 4)** — impact-rated shingles, ridge vent + verified intake, upgraded valley/edge metals, ice/water where appropriate.  
- **Best (Stone-Coated Steel)** — lightweight panels, long service life, superior wind/debris resilience, manufacturer-approved underlayment and metals.

&gt; Always tie price delta → spec delta. No vague promises.

---

## Insurance-Safe Language (Neutral &amp; Helpful)
- “We’re documenting conditions and proposing a code-compliant scope. We don’t speak to claim outcomes.”  
- “Here’s our evidence and line-item quantities. If your carrier requests info, this packet keeps it clear.”  
- “Any changes we discover are documented and approved before work.”

See: [[Insurance &amp; Compliance]].

---

## Solar D&amp;R Talk Track (If PV is Present)
- “We de-energize and tag out, map module positions, protect conductors and penetrations, reinstall to torque spec, and verify monitoring/production on recommission.”  
- “Your roof details will be flashed to both roofing and racking manufacturer specs.”  
- “You’ll get a commissioning sheet at closeout.”

See: [[Detach &amp; Reset (Solar)]].

---

## HOA-Friendly Version
- “We have HOA-compliant color/material options and clean jobsite practices (parking, hours, magnet sweeps). I can send the board a one-pager with scope and photos.”

---

## Objections → Short Answers
- **“Can you beat their price?”**  
“If the scope and specs match, possibly. Let’s align the scope first so it’s apples-to-apples; then I’ll see if we can sharpen.”
- **“Why Class 4?”**  
“Better impact resistance and granule retention; fewer callbacks over storms. Some carriers credit it.”
- **“Do I need ridge vent?”**  
“Your attic photos suggest low intake/exhaust. Balanced ventilation lowers deck temps and extends shingle life.”
- **“I’m getting several bids.”**  
“Good plan. Here’s our photo-tied scope and math. If another bid shows the same scope cheaper, send it over—I’ll review and respond in writing.”
- **“We’ll wait until next season.”**  
“Totally your call. Two risks to note: unseen decking damage can grow, and material/labor availability changes. I can hold today’s scope for X days.”

---

## Price Alignment (Protect Margin, Stay Honest)
- Never change baseline **rates** in the field. Apply a single, explicit discount line if needed (reason documented).  
- Keep contingencies separate: **deck repair**, **code upgrades**, **discovery**.  
- Summarize Good/Better/Best with two sentences each; attach the calculator snapshot.  
See: [[Calculator Guide]].

---

## Next Step &amp; Close (No Pressure)
- “Which option aligns with how long you want this roof to

---

**user:**

Let’s try one page at a time

---

**assistant:**

Got it—here’s a single, complete page you can paste into the wiki.

```
# Sales Playbook

&gt; [[Home]] · [[Calculator Guide]] · [[Inspection &amp; Scope Capture]] · [[Detach &amp; Reset (Solar)]] · [[Materials &amp; Spec Matrix]] · [[Installation SOP]] · [[Safety &amp; QA]] · [[Insurance &amp; Compliance]] · [[Troubleshooting the Calculator]] · [[Changelog]]

## Purpose
A phone-first sales flow: document → align scope → price transparently → earn the “yes” without pressure. Built for storm recovery and solar-aware jobs.

---

## Positioning (Why Us)
- **Storm-resilient by design** — specs that actually reduce future loss (impact materials, ventilation, flashing details).
- **Transparent scope &amp; math** — photos + line items + calculator outputs; no mystery pricing.
- **Solar-aware** — clean PV detach &amp; reset (D&amp;R), proper roof-to-racking interfaces, solid recommissioning.

---

## 90-Second Field Flow (Talk Track)
1) **Open**  
“Hi, I’m Justin with Texas Choice Roofing. We specialize in storm-resilient roofs. Any leaks, granule loss, or insurance questions since the hail/wind?”

2) **Permission to Inspect (from ground)**  
“If you’ve got 2 minutes, I’ll photo-document the roofline and key details now so we’re looking at evidence, not guesses.”

3) **Evidence**  
Show 3–5 clear photos tied to plain language: edges, valleys, penetrations, attic (if allowed). Use [[Inspection &amp; Scope Capture]].

4) **Options (Good / Better / Best)**  
“Same house, different risk profiles.” Tie each option to spec changes (Class 4, ventilation, flashing upgrades, stone-coated steel).

5) **Next Step**  
“Let’s align the scope in writing, pick an install window, and I’ll lock in material availability.”

---

## Discovery Script (Copy/Paste)
- “Any active leaks or interior staining?”  
- “Age of current roof? Any prior repairs or second layers?”  
- “Attic temps or utility spikes in summer? (Ventilation clues.)”  
- “HOA rules on color/materials? Parking or noise restrictions?”  
- “Solar present? What inverter type—string, micro, or optimizers? Monitoring working?”  
- “Any must-haves or firm budget limits I should respect?”

---

## Evidence Standard (What to Show)
- **Edges &amp; metals** — drip edge presence/condition, valley metal type, improper laps.  
- **Shingles** — bruising/creases/granule loss with scale reference.  
- **Penetrations** — boots, chimneys, skylights (3 sides + flashing).  
- **Attic** — intake/exhaust balance, decking condition, daylight, moisture signs.  
- **Solar (if any)** — array overview, disconnects, nameplates, wire management.  
Keep the photo set minimal but decisive. Label each photo in plain English.

---

## Framing Options: Good / Better / Best
- **Good (Architectural)** — code-compliant install, synthetic underlayment, corrected flashings, balanced ventilation.  
- **Better (Class 4)** — impact-rated shingles, ridge vent + verified intake, upgraded valley/edge metals, ice/water where appropriate.  
- **Best (Stone-Coated Steel)** — lightweight panels, long service life, superior wind/debris resilience, manufacturer-approved underlayment and metals.

&gt; Always tie price delta → spec delta. No vague promises.

---

## Insurance-Safe Language (Neutral &amp; Helpful)
- “We’re documenting conditions and proposing a code-compliant scope. We don’t speak to claim outcomes.”  
- “Here’s our evidence and line-item quantities. If your carrier requests info, this packet keeps it clear.”  
- “Any changes we discover are documented and approved before work.”  
See: [[Insurance &amp; Compliance]].

---

## Solar D&amp;R Talk Track (If PV is Present)
- “We de-energize and tag out, map module positions, protect conductors and penetrations, reinstall to torque spec, and verify monitoring/production on recommission.”  
- “Your roof details will be flashed to both roofing and racking manufacturer specs.”  
- “You’ll get a commissioning sheet at closeout.”  
See: [[Detach &amp; Reset (Solar)]].

---

## HOA-Friendly Version
- “We have HOA-compliant color/material options and clean jobsite practices (parking, hours, magnet sweeps). I can send the board a one-pager with scope and photos.”

---

## Objections → Short Answers
- **“Can you beat their price?”**  
“If the scope and specs match, possibly. Let’s align the scope first so it’s apples-to-apples; then I’ll see if we can sharpen.”
- **“Why Class 4?”**  
“Better impact resistance and granule retention; fewer callbacks over storms. Some carriers credit it.”
- **“Do I need ridge vent?”**  
“Your attic photos suggest low intake/exhaust. Balanced ventilation lowers deck temps and extends shingle life.”
- **“I’m getting several bids.”**  
“Good plan. Here’s our photo-tied scope and math. If another bid shows the same scope cheaper, send it over—I’ll review and respond in writing.”
- **“We’ll wait until next season.”**  
“Totally your call. Two risks to note: unseen decking damage can grow, and material/labor availability changes. I can hold today’s scope for X days.”

---

## Price Alignment (Protect Margin, Stay Honest)
- Don’t change baseline **rates** in the field. If needed, use one explicit **discount** line with reason.  
- Keep **contingencies** separate: deck repair, code upgrades, discovery.  
- Summarize Good/Better/Best with two sentences each; attach the calculator snapshot.  
See: [[Calculator Guide]].

---

## Next Step &amp; Close (No Pressure)
- “Which option best fits how long you plan to keep the home and how much risk you want to carry?”  
- “If we align on this scope today, I’ll reserve materials and give you an install window.”  
- “I’ll text you the photo set + written scope so you can review with anyone else.”

**Checklist**
- [ ] Scope aligned in writing  
- [ ] Install window offered (two options)  
- [ ] Calculator summary attached  
- [ ] Photo set shared (link or PDF)  
- [ ] Contingencies listed clearly

---

## Follow-Up Templates (Copy/Paste)

**Text (same-day):**  
“Hi &lt;Name&gt;, Justin here. I just sent your photo set + written scope (Good/Better/Best). Which option feels right based on lifespan and budget? If you’d like, I can hold materials for the &lt;Date Range&gt; window.”

**Email (next-day):**  
_Subject: Your Roof Scope + Options_  
“Hi &lt;Name&gt;,  
Attached are your photos and scope. Quick summary:  
• Good — code-compliant architectural shingle, corrected flashings, balanced ventilation.  
• Better — Class 4 impact shingle, upgraded metals, ridge + intake balance.  
• Best — Stone-coated steel, longest life, superior wind/debris resilience.  
Reply with your preferred option and I’ll confirm schedule.”

---

## Attachments to Share
- Calculator snapshot (Good/Better/Best) → [[Calculator Guide]]  
- Photo set (labeled) → [[Inspection &amp; Scope Capture]]  
- Material specs selected → [[Materials &amp; Spec Matrix]]  
- Install steps + QA → [[Installation SOP]] · [[Safety &amp; QA]]
```

If you want the next page, say the word and tell me which one to prioritize.

---

**user:**

Next page

---

**assistant:**

```
# Inspection &amp; Scope Capture

&gt; [[Home]] · [[Sales Playbook]] · [[Calculator Guide]] · [[Detach &amp; Reset (Solar)]] · [[Materials &amp; Spec Matrix]] · [[Installation SOP]] · [[Safety &amp; QA]] · [[Insurance &amp; Compliance]] · [[Troubleshooting the Calculator]] · [[Changelog]]

## Purpose
Capture decisive evidence and quantities **once**, cleanly, from the ground/attic/roof—so pricing, scope, and installation line up with zero surprises.

---

## Safety First (non-negotiable)
- Ladder angle 4:1, footing checked, top tied when feasible.  
- No roof access on wet surfaces or unsafe winds; use optics/drone.  
- Fall protection per pitch/exposure. PPE for attic (mask, light, boards).

See: [[Safety &amp; QA]].

---

## Minimum Photo Set (10 shots)
1. **Front elevation** (house, gutters, downspouts, driveway protection points)  
2. **Rear elevation**  
3. **Eave close-up** (drip edge presence/condition, fascia rot)  
4. **Rake close-up** (metal, returns, paint condition)  
5. **Valley** (metal type, lap direction, debris/water path)  
6. **Hips &amp; ridge** (cap condition, vent type, continuity)  
7. **Penetration A** (pipe boot—3 sides + base)  
8. **Penetration B** (chimney/skylight—step + counter flashing)  
9. **Attic** (intake baffles, daylight, deck condition, moisture signs)  
10. **Context risk** (trees overhanging, satellite/solar, access constraints)

&gt; Label each photo in plain English: `“Eave – no drip edge, fascia rot 18””`.

---

## Damage Taxonomy (use consistent terms)
- **Shingle:** granule loss, bruise, crease, edge tear, blister.  
- **Metals:** dents, corrosion, open lap, exposed fasteners.  
- **Deck:** delamination, rot, prior patch, deflection.  
- **Flashing:** missing counter, short step laps, face-nailed apron.  
- **Ventilation:** inadequate intake/exhaust, blocked soffits, non-continuous ridge.  
- **Gutters:** pitch reversal, ponding, seam splits, loose hangers.  
- **Solar (if present):** cracked glass, loose wiring, compromised penetrations.

&gt; Avoid “cosmetic”/“functional” judgments on site. Describe **what is**; let scope map to codes/specs. See: [[Insurance &amp; Compliance]].

---

## Quantities to Capture (map to calculator)
- **Roof area (SQ)** — copy from Roofr or sketch; note layers (1/2).  
- **Pitch class** — Low (≤4/12), Standard (5–7/12), Steep (≥8/12).  
- **Linear feet** — eaves, rakes, hips, ridges, valleys.  
- **Counts** — pipe boots, box/turtle vents, O’Hagins, chimneys, skylights.  
- **Specials** — sidewall/headwall lengths, dead valleys, cricket needed?  
- **Deck allow.** — ft² contingency (note suspected soft spots).  
- **Gutters (if in scope)** — LF by side; downspout count; outlets; screens.  
- **Solar D&amp;R** — module count, racking type, roof/rail attachment count, home runs, inverter type (string/micro/optimizer), monitoring present.

Paste these into: [[Calculator Guide]].

---

## Ground → Attic → Roof Workflow
**Ground (2–5 min)**  
- Walk perimeter; capture elevations and edge/valley close-ups.  
- Note access issues (parking, staging, HOA constraints).  
- Mark hazards (glass, AC units, landscaping).

**Attic (if permitted, 3–7 min)**  
- Intake baffles present? Soffits blocked?  
- Decking (ply/OSB thickness if visible), dark stains, fastener pops.  
- Ducts exhausting to attic? (flag for venting)  
- Photo: ridge light, intake area, any moisture signs.

**Roof (as safe/needed, 5–12 min)**  
- Verify valley treatments, step/counter flashing overlaps, starter presence.  
- Lift shingle at sample eave to confirm **drip edge** and underlayment.  
- Confirm ridge vent continuity; count/size intakes.  
- If unsafe: use zoom optics/drone—do **not** compromise safety.

---

## Photo Labeling &amp; File Hygiene
- **Convention:** `JOB#_address_YYYY-MM-DD_[view]_[note].jpg`  
- **Examples:**  
  - `2318_123Oak_2025-08-17_valley_openlap_8in.jpg`  
  - `2318_123Oak_2025-08-17_attic_intake_blocked_south.jpg`  
- Keep blur to a minimum; retake instead of stacking junk photos.

---

## Scope Notes (plain-language examples)
- “North valley: open lap against water path; replace w/ W-valley or ice/water + metal per spec.”  
- “Two layers confirmed at west eave; include 2-layer tear-off rate.”  
- “Attic shows low intake; add 42 lf ridge vent **and** match NFA with soffit vents.”  
- “Chimney lacks counter-flashing; include grind-in counter per spec.”  
- “Gutters pond at rear left; re-pitch 48 lf and reset 2 downspouts.”

---

## Solar D&amp;R Capture (if present)
- Array overview; **module count x rows**; rail type; standoff pattern.  
- Nameplates: inverter(s), combiners, disconnects, rapid shutdown labeling.  
- Conductor routing and penetrations; photo each roof penetration.  
- Monitoring status screenshot (if accessible).  
- Note crane/lift needs, walkway protection, and staging area.

See: [[Detach &amp; Reset (Solar)]].

---

## Field Checklist (copy/paste)
- [ ] Safety verified (ladder, weather, PPE)  
- [ ] 10-shot minimum photo set captured &amp; labeled  
- [ ] Roofr/measurements copied to calculator  
- [ ] Attic inspection (if allowed) documented  
- [ ] Ventilation counts (ridge + intake) recorded  
- [ ] Flashing details verified (step/counter, apron, side/headwall)  
- [ ] Solar equipment documented (if any)  
- [ ] Plain-language scope notes written  
- [ ] Access/HOA constraints noted

---

## Insurance-Neutral Communication (safe phrasing)
- “Here’s what we observed and how the scope addresses it to code/manufacturer specs.”  
- “Quantities and photos are included for clarity. Let me know if you need anything else.”  
- “Any discovered changes will be documented and approved before work.”

See: [[Insurance &amp; Compliance]].

---

## Hand-Off
- Upload labeled photos + checklist to job folder.  
- Paste quantities into [[Calculator Guide]].  
- Send homeowner the **photo summary** + short scope bullets (Good/Better/Best preview).  
- Flag any safety/code blockers before scheduling: [[Installation SOP]].

```

---

**user:**

Next

---

**assistant:**

```
# Detach &amp; Reset (Solar)

&gt; [[Home]] · [[Inspection &amp; Scope Capture]] · [[Calculator Guide]] · [[Materials &amp; Spec Matrix]] · [[Installation SOP]] · [[Safety &amp; QA]] · [[Insurance &amp; Compliance]] · [[Troubleshooting the Calculator]] · [[Changelog]]

## Purpose
Safely **remove, store, and reinstall** rooftop PV to enable roof work without damaging equipment or creating energized hazards. Finish with a documented **commissioning** proving the system is restored.

---

## Scope Triggers (When D&amp;R Applies)
- Any roof replacement or major flashing/underlayment work beneath a PV array.  
- Any rack-foot or penetration rework.  
- Any module removal for localized deck repair or valley/flash detail changes.

---

## Roles &amp; Requirements
- Crew lead trained on PV **lockout/tagout (LOTO)**, racking hardware, and connector handling.  
- Electrical test equipment on site (multimeter rated CAT III/1000V), PPE, tags.  
- Manufacturer install manuals available for **racking and inverter**.

---

## Identify the System (before touching anything)
Record in photos/notes:
- **Inverter topology**: String inverter (DC strings), Microinverters (AC at module), DC optimizers (hybrid).  
- **Nameplates**: inverter(s), rapid shutdown device(s), combiner(s).  
- **Disconnect points**: AC disconnect, DC/array disconnect(s), breakers.  
- **Racking**: brand/model, rail type, standoff/foot pattern, bonding method.  
- **Monitoring**: gateway/logger present and online?

Map these in [[Inspection &amp; Scope Capture]] and copy quantities to [[Calculator Guide]].

---

## Safety &amp; LOTO (non-negotiable)
1. **Communicate**: Inform homeowner that PV will be offline during roof work.  
2. **Shut down** in manufacturer order (typical):  
   - Utility AC off → Inverter AC off → DC/array off (string/optimizer systems).  
   - For microinverters: AC branch circuit off and labeled.  
3. **Verify absence of voltage** at inverter/combiner terminals (PPE).  
4. **Tag &amp; lock** all points (“DO NOT ENERGIZE – D&amp;R in progress,” date, initials).  
5. **Cap and secure** any exposed connectors to keep dry and debris-free.

&gt; Treat modules in sunlight as live DC sources. Do not mate/demate under load.

---

## Tools &amp; Materials (minimum)
- Impact driver + torque wrench (per racking spec)  
- Socket set, T-handles, hex bits; spare T-bolts/clips/bonding washers  
- MC-type connector caps/plugs; cable ties; strain-relief clips  
- Edge guards, moving blankets, padded module racks  
- Labels/tags; painter’s tape; grid map template for module layout  
- Multimeter (CAT III/1000V), PPE (gloves, eyewear), lockout kit

---

## Removal Workflow
1. **Photo the array** (wide, corners, wire paths, penetrations, labels).  
2. **Create a grid map** (rows × columns). Number each module position.  
3. **Disconnect**:  
   - **String/optimizer**: open DC disconnects, then unplug module pair leads at safe shadow if possible; cap connectors.  
   - **Microinverters**: de-energize AC branch; unplug trunk connectors; cap.  
4. **Hardware**: loosen clamps in sequence; maintain bonding path awareness.  
5. **Lift modules** glass-up, move to **padded racks**.  
6. **Racking**: remove rails/feet only as needed. Photograph each penetration and **count all penetrations**.

---

## Storage &amp; Protection
- Store modules **vertical** on padded A-frames; strap lightly; keep dry.  
- Bag/box small hardware labeled by roof plane/array section.  
- Protect conductors at roof exits; **no sharp bends**; cover stubs.

---

## Roof Work Interface
- Plug/cover all old penetrations until re-flashed.  
- Coordinate underlayment laps, metal flashings, and **new standoff locations** with framing.  
- Use manufacturer-approved flashing kits; maintain min. embedment and torque specs.

&gt; Any **layout changes** (rail spans, attachment spacing, setback to ridges/edges) must be documented and meet racking and electrical clearances. Do not increase wind/snow spans beyond spec.

---

## Reinstall Workflow
1. **Layout** rails per spec; confirm level, spans, and bonding hardware present.  
2. **Standoffs/feet**: set to framing; install flashing; torque to spec.  
3. **Rails &amp; bonding**: install splice/bonding jumpers; verify continuity path.  
4. **Wire management**: secure home runs; drip loops; UV-rated ties/clips; away from valleys/gutters.  
5. **Modules**: place per grid map; install mid/end clamps to torque; bond per spec.  
6. **Reconnect**:  
   - **String/optimizer**: make series connections; check polarity; dress leads.  
   - **Microinverters**: connect trunk; cap unused ports; verify ground path.  
7. **Labeling**: replace any missing/damaged labels (disconnects, rapid shutdown).

---

## Commissioning &amp; QA (document everything)
- **Visual**: all clamps engaged, end clamps present, no pinched wires, all penetrations flashed and sealed.  
- **Mechanical**: spot-check torque on sample clamps and feet (record values).  
- **Electrical**:  
  - **String systems**: With DC still isolated, measure **Voc** at string ends (in safe shade) and compare to expected nameplate (record).  
  - **Energize** in reverse of shutdown; verify inverter start-up, string voltages/currents within range.  
  - **Micros**: restore AC, confirm each serial reports in monitoring.  
- **Rapid Shutdown**: test per label (initiate; verify shutdown indicator/voltage drop at inverter).  
- **Monitoring**: log back online; time/date correct; firmware updates complete.

**Commissioning Sheet (attach to job):**
- Job #, date, crew, weather  
- Array layout (rows × columns), module count  
- Racking brand/model, foot count, penetration count  
- Inverter type/serial(s)  
- LOTO times (off/on)  
- Measured Voc per string (if applicable)  
- Rapid shutdown test result  
- Photos: before, mid (flashing), after, nameplates, monitoring screen

---

## Calculator Mapping (quantities to enter)
- **Modules – remove/reinstall (ea.)**  
- **Rails/feet – remove/reinstall (LF / ea.)** (if required)  
- **Penetrations flashed (ea.)**  
- **Conductor re-termination / labeling (lump)**  
- **Commissioning &amp; monitoring (lump)**  
- **Lift/crane day(s)** (if walkway or staging requires)  
- **Troubleshooting allowance** (optional contingency)

See rates in [[Calculator Guide]].

---

## Customer Communication (plain and safe)
- “Your system will be safely powered down during roof work. We’ll document each step and provide a commissioning report when power is restored.”  
- “If any components are found damaged/worn, we’ll document and present options before proceeding.”  
- “Monitoring will be restored; you’ll see production resume the same day as commissioning.”

See: [[Insurance &amp; Compliance]] for neutral phrasing.

---

## Common Failure Modes (prevent them)
- **Uncapped connectors** taking on moisture/debris → always cap immediately.  
- **Lost bonding path** at splices or end clamps → verify continuity hardware and torque.  
- **Pinched/unsupported conductors** at rail ends → add clips/edge guards.  
- **Missing end clamps** after re-layout → count clamps before/after.  
- **Skipped monitoring restore** → include in closeout checklist.

---

## Field Checklist (copy/paste)
- [ ] System identified (photos of nameplates, racking, disconnects)  
- [ ] LOTO applied, voltages verified absent, tags placed  
- [ ] Grid map created; modules labeled by position  
- [ ] Connectors capped; conductors protected  
- [ ] Penetrations counted and flashed per spec  
- [ ] Rails/feet torqued; bonding verified  
- [ ] Modules reinstalled; clamps torqued; wire management secured  
- [ ] Commissioning: Voc (if strings), inverter online, RSD test passed  
- [ ] Monitoring restored; screenshots saved  
- [ ] Commissioning sheet completed with photo set

```

Would you like **Materials &amp; Spec Matrix** next, or jump to **Installation SOP**?

---

**user:**

Install SOP

---

**assistant:**

```
# Installation SOP

&gt; [[Home]] · [[Materials &amp; Spec Matrix]] · [[Detach &amp; Reset (Solar)]] · [[Inspection &amp; Scope Capture]] · [[Safety &amp; QA]] · [[Calculator Guide]] · [[Insurance &amp; Compliance]] · [[Troubleshooting the Calculator]] · [[Changelog]]

## Purpose
Deliver **consistent, code-compliant, storm-resilient installs** with predictable schedule, zero avoidable leaks, and clean closeout. Safety is built into the sequence, not tacked on.

---

## Pre-Job (T-24–72 hrs)
- **Scope lock**: final plan set + Good/Better/Best choice + allowances (deck, code upgrades).  
- **Material check**: colors, ridge/hip, starter, metals, vents, sealants, fasteners, underlayment, ice/water (if specified), **stone-coated steel kit** (if applicable).  
- **PV coordination** (if present): schedule D&amp;R window, monitoring access, racking flash kits.  
- **Staging**: dumpster/lift spot, cover path, neighbor notice, HOA constraints, power access, restroom.  
- **Weather gates**: halt if &gt;50% precip during dry-in window or sustained winds &gt;25 mph on steep/complex roofs. See [[Safety &amp; QA]].

---

## Day-Of Roles
- **Crew Lead**: safety brief, sequence control, QA sign-offs.  
- **Deck Lead**: tear-off, deck repair, underlayment integrity.  
- **Flash Lead**: valleys, edges, walls, penetrations.  
- **PV Lead** (if applicable): follows [[Detach &amp; Reset (Solar)]].  
- **Ground Lead**: protection, material flow, magnets, neighbor care.

---

## Property Protection &amp; Setup (0:00–0:30)
- Cones/tarps, window/AC guards, ladder footing, ridge hooks if used.  
- Downspout extensions; plywood over fragile surfaces; magnet sweep baseline.  
- “Before” photos (front/rear, landscaping, driveway).  
- Weather check &amp; go/no-go. See [[Safety &amp; QA]].

---

## Tear-Off (0:30–2:30)
- **Sectional removal** (start high→downhill). Keep deck dry.  
- Pull nails; scrape flat. **Two-layer** rates if present (confirm).  
- **Deck inspection**: mark soft/rotted areas; photo evidence.  
- **Deck repair protocol**: replace to match thickness (7/16&quot; OSB or 1/2&quot; ply typical), 1/8&quot; panel gap, ring-shank nails to framing, H-clips per code where required. Document ft² used vs allowance.

---

## Dry-In (2:30–4:30)
&gt; Goal: fully watertight before main install.
- **Drip edge**:  
  - *Typical practice*: eaves metal **below** synthetic; rakes **above** synthetic. Verify local code/manufacturer—follow their order if different.  
- **Underlayment (synthetic)**: shingle-style laps; side laps ≥4&quot;, end laps ≥6&quot;, install parallel to eaves.  
  - Fastening: cap nails per mfr (e.g., 12&quot; o.c. field, 6&quot; o.c. edges; increase on steep/wind).  
- **Ice &amp; Water** (when specified): valleys, eaves set-back, around penetrations, dead valleys.  
- **Valleys** (choose one per scope):  
  - **Open metal**: W-valley 24 ga min, hemmed edges; min 4–6&quot; exposure.  
  - **Closed-cut**: ice &amp; water full length; cut after shingle install; no nails within 6&quot; of centerline.  
  - *(Avoid woven in hail/wind regions.)*  
- **Walls/Transitions**: install kick-out at first step; prep for step + counter-flashing.

---

## Shingle / Panel Install (4:30–finish)
### Asphalt Shingles
- **Starter** at eaves and rakes; factory edge out.  
- **Nailing**: flush, not over/under-driven; length to penetrate ≥3/4&quot; into deck or fully through deck.  
  - **Wind zone**: 6 nails/shingle (no exceptions).  
- **Courses**: straight lines; stagger per mfr; avoid “short tabs”.  
- **Hips/Ridges**: continuous ridge vent (if specified) + cap shingles.

### Stone-Coated Steel (SCS)
- **Underlayment**: per mfr (often high-temp synthetic; some require double-layer).  
- **Starter/eave closures**: continuous; insect/ember closures as specified.  
- **Panels**: install per wind zone; fasteners to deck/framing at pattern &amp; torque spec; lap direction per mfr; walk on **lower rib** or battens only.  
- **Valleys**: use SCS valley pans; side-hemmed; close foam where required.  
- **Hips/Ridges**: matching caps with closures; verify ventilation components are compatible.

---

## Flashings &amp; Penetrations (throughout)
- **Step flashing**: 2&quot; min wall leg; one piece per shingle course; **no continuous L**.  
- **Counter-flashing**: reglet grind-in or existing counter re-set to code.  
- **Headwall/sidewall**: apron + step; kick-out always at eave start.  
- **Chimneys**: saddle/cricket when width ≥30&quot;; new counter-flashing.  
- **Skylights**: follow kit; no caulk-only fixes.  
- **Sealants**: use sparingly and only as accessory to proper metal/underlayment overlaps.

---

## Ventilation (spec + quick calc)
Target balanced intake/exhaust per code/mfr. Typical rules of thumb:  
- **1:150** NFA (no balanced system) or **1:300** with balanced, vapor-retarding ceiling.  
- **NFA total (sq in)** = Attic floor area (ft²) × 144 ÷ 150 (or ÷ 300).  
- Split ~50/50 intake vs exhaust; size ridge vent by its **NFA per LF**.

*Example*: 2,000 ft² attic, 1:300 → 2,000×144/300 = **960 sq in** total → **480 in² intake**, **480 in² exhaust**.  
If ridge vent NFA = 18 in²/LF → 480/18 ≈ **27 LF** ridge vent required (and match intake).  
Record counts/lengths in closeout photos.

---

## PV Interface (if present)
- Coordinate penetrations with rafters; install flashed standoffs before shingle cap/ridge.  
- Keep conductor paths out of valleys/gutter lines; drip loops; UV-rated clips.  
- Handoff to [[Detach &amp; Reset (Solar)]] for recommissioning and tests.

---

## Weather &amp; Work Stops
- Stop if adhesive-set underlayments won’t bond (cold/wet deck); stage temporary dry-in and reschedule.  
- Halt on lightning, wet steep slopes, or high winds per [[Safety &amp; QA]].  
- Never leave an **unsealed valley/wall** overnight—temporary membrane + metal is mandatory.

---

## Cleanup &amp; Closeout
- Full magnet sweep (perimeter + lawn + beds) ×2; gutters flushed if dirty.  
- Remove tarps/protection; touch-up paint on exposed metal cuts as specified.  
- “After” photos: front/rear elevations, valleys, walls, penetrations, ridge/hip, attic (if applicable), PV reinstalled.  
- Site left cleaner than arrival.

---

## QA Sign-Offs (Crew Lead)
See full list in [[Safety &amp; QA]]. Minimum checkpoints:  
- [ ] Deck repairs documented (ft² vs allowance) with photos  
- [ ] Underlayment laps &amp; fasteners per spec; valleys fully sealed  
- [ ] Drip edge order correct (eave under/ rake over, unless local spec differs)  
- [ ] Step + counter-flashing correct; kick-outs installed  
- [ ] Ridge vent length matches NFA calc; intake unobstructed  
- [ ] Fastener counts/pattern per mfr (6-nail in wind zones)  
- [ ] SCS closures (if used) installed at eaves/ridges/valleys  
- [ ] Penetrations sealed/flashed (no exposed fasteners in water path)  
- [ ] PV re-commissioned with monitoring restored (if applicable)  
- [ ] Magnet sweep passed; gutters clear

---

## Closeout Package (to homeowner + file)
- **Photo set** (before / during / after)  
- **Scope as-built** (quantities + any approved change orders)  
- **Ventilation calc** (inputs &amp; final LF/counts)  
- **PV commissioning sheet** (if applicable)  
- **Warranty packet**: manufacturer + workmanship; color &amp; product lot (if available)  
- **Care notes**: first rain check, debris management, how to reach us

---

## Field Checklists (copy/paste)
**Start-of-Day**
- [ ] Safety brief done; weather OK  
- [ ] Property protection up; dumpster/lift placed  
- [ ] Materials verified; colors match  
- [ ] PV LOTO plan reviewed (if any)

**Mid-Day (post dry-in)**
- [ ] All planes watertight (valleys/walls sealed)  
- [ ] Underlayment laps + cap nails verified  
- [ ] Drip edge installed per plan

**End-of-Day**
- [ ] No open water paths; temporary seal where needed  
- [ ] Tools/materials secured; magnets + sweep done  
- [ ] Daily photos uploaded; note blockers for tomorrow

---

## Tools &amp; Consumables (minimum)
- Ladders, harnesses, anchors, ridge hooks (as needed)  
- Tear-off tools, brooms/scrapers, shears/snips, brake (if metal bends on site)  
- Coil/hand nailers (calibrated), torque driver (for SCS/PV)  
- Cap nailer or hammer tacker (per underlayment spec)  
- Sealants (mfr-approved), primers, tapes; closures (SCS)  
- Magnets (on wheels + hand), tarps, plywood, cones

---

## Common Failure Modes (preventive notes)
- **Incorrect drip-edge order** → follow sequence noted; photo proof.  
- **Missing kick-outs** → mandatory at first step.  
- **Nail in valley** → keep 6&quot; clear each side (closed-cut).  
- **Under/over-driven nails** → adjust pressure; spot-check rows.  
- **SCS gaps at closures** → verify foam fit; seal per mfr.  
- **PV wires in water path** → reroute, clip, and drip loop.

---
```

---

**user:**

Next

---

**assistant:**

```
# Materials &amp; Spec Matrix

&gt; [[Home]] · [[Installation SOP]] · [[Calculator Guide]] · [[Inspection &amp; Scope Capture]] · [[Detach &amp; Reset (Solar)]] · [[Safety &amp; QA]] · [[Insurance &amp; Compliance]] · [[Troubleshooting the Calculator]] · [[Changelog]]

## Purpose
Pick components that map **directly** to performance claims and line items. Every upgrade must have a concrete benefit we can explain, install, and warranty.

---

## Roof System Options (Good / Better / Best)

| Layer / Feature | **Good** (Architectural) | **Better** (Class 4 Impact) | **Best** (Stone-Coated Steel) |
|---|---|---|---|
| Field material | Architectural asphalt shingle | Class 4 asphalt shingle | Stone-coated steel panel |
| Underlayment | Synthetic (single layer) | Synthetic + ice/water at valleys/critical zones | High-temp synthetic (per mfr) |
| Valleys | Closed-cut or open metal (per scope) | Open W-valley metal (24 ga) or closed-cut w/ I&amp;W | SCS valley pans w/ side hems |
| Edges | New drip edge (eaves/rakes) | New drip edge + heavier gauge option | SCS eave/rake closures |
| Flashing | New step + counter (walls); apron at headwalls | Same + premium metals/sealants | SCS-compatible flashings &amp; closures |
| Ventilation | Ridge vent + matched intake | Ridge vent + verified NFA match | SCS ridge components + matched intake |
| Fasteners | Ring-shank nails (per mfr) | Same (6-nail wind pattern) | Mfr-approved screws/nails to torque |
| Warranty | Mfr + workmanship | Mfr + workmanship (impact spec) | Mfr system warranty + workmanship |

&gt; Tie any price delta to the **specific** spec change (impact rating, valley metal gauge, underlayment class, ventilation hardware).

---

## Underlayment (select by climate &amp; system)
- **Synthetic (baseline)** — primary water-shed; cap-nailed to spec; side laps ≥4&quot;, end laps ≥6&quot;.
- **Ice &amp; Water (self-adhered)** — valleys, dead valleys, penetrations, vulnerable eaves (when specified).
- **High-Temp Synthetic** — mandatory under metal/SCS or hot exposures per manufacturer.

**Calculator mapping:** `synthetic_per_sq`, `ice_water_per_lf`, `hitemp_upgrade_per_sq`.

---

## Valleys
- **Open W-Valley (24 ga min, hemmed edges)** — predictable water path, debris tolerant.
- **Closed-Cut** — clean look; requires full-length I&amp;W and strict no-nail zone (≥6&quot; from centerline).
- **SCS Valley Pans** — per panel manufacturer; side hems + closure foams as specified.

**Calc:** `valley_lf_open_metal` vs `valley_lf_closed_cut`.

---

## Edges &amp; Metals
- **Drip Edge** at eaves and rakes; color to match fascia/metal package.
- **Starter** at eaves **and rakes** (asphalt); SCS starter/closures per mfr.
- **Kick-Out Flashing** at every sidewall eave start (non-negotiable).

**Calc:** `drip_edge_lf`, `starter_sq`, `kickout_count`.

---

## Walls, Chimneys, Skylights
- **Step Flashing** — one piece per shingle course; 2&quot; min wall leg.
- **Counter-Flashing** — grind-in/reglet or new counter where needed.
- **Chimney Cricket** — required if chimney width ≥30&quot;.
- **Skylights** — manufacturer kit or curb; no caulk-only “repairs”.

**Calc:** `step_flashing_lf`, `counter_flashing_lf`, `chimney_count`, `skylight_count`.

---

## Ventilation (match NFA)
- Target balanced intake/exhaust; typical **1:300** with balanced system.
- Size ridge vent by **NFA per LF** and match with soffit/intake NFA.
- Use baffles to open blocked soffits; document counts/lengths.

**Calc:** `ridge_vent_lf`, `intake_vents_count_or_lf`, `baffles_count`.

---

## Fasteners
- **Asphalt** — nails long enough to penetrate ≥3/4&quot; into deck or through deck; 6-nail pattern in wind zones.
- **SCS** — specified screws/nails at pattern; verify torque; walk on lower ribs/battens only.

**Calc:** included in labor/material rates; no separate line unless specified.

---

## Decking (repair allowance)
- Replace damaged panels to match thickness (7/16&quot; OSB or 1/2&quot; ply typical).
- Leave ~1/8&quot; panel gap; ring-shank nails to framing; H-clips where code requires.

**Calc:** `deck_repair_sqft_allowance` with unit rate `deck_repair_per_sqft`.

---

## PV Interface (if present)
- **Standoffs/feet** flashed with manufacturer kits; attachments to framing.
- Conductor routing off water paths; UV-rated clips; drip loops.
- Coordinate with [[Detach &amp; Reset (Solar)]] for LOTO and commissioning.

**Calc:** `pv_penetrations_flushed_each`, `pv_commissioning_lump`, `pv_remove_reinstall_module_each`.

---

## Gutters (optional scope)
- Re-pitch where ponding; replace damaged sections; match outlets/downspouts.
- Screens/guards only if homeowner requests; disclose maintenance trade-offs.

**Calc:** `gutter_replace_lf`, `gutter_repitch_lf`, `downspout_count`, `guard_lf`.

---

## Code &amp; Manufacturer Triggers (include when present)
- Drip edge at all eaves/rakes.
- Ice &amp; Water in valleys/dead valleys (per plan/spec).
- Step + counter at walls; kick-out flashing.
- Balanced ventilation to NFA requirement.
- Cricket at ≥30&quot; chimney width.
- SCS requires high-temp underlayment and approved closures.

---

## Selection Block (copy/paste template)
**Home:** &lt;Address&gt;  
**Option Chosen:** ☐ Good ☐ Better ☑ Best (SCS)  
**Field Material:** Stone-coated steel, color &lt;Color&gt;  
**Underlayment:** High-temp synthetic (brand/model)  
**Valleys:** SCS valley pans w/ side hems  
**Edges:** SCS eave/rake closures; color-matched metals  
**Walls/Chimneys:** New step + grind-in counter; kick-outs added  
**Ventilation:** Ridge vent &lt;LF&gt; matched to intake &lt;LF/count&gt;; NFA calc attached  
**Decking Allowance:** &lt;sq ft&gt;  
**PV Interface:** ☐ N/A ☑ D&amp;R with standoff re-flash; commissioning sheet  
**Gutters:** ☐ N/A ☐ Re-pitch &lt;LF&gt; ☐ Replace &lt;LF&gt;

Map these to the calculator: [[Calculator Guide]].

---

## Communication Notes (customer-safe)
- “Here’s exactly what changes between Good, Better, Best—and why it matters (impact rating, valley metal, underlayment heat rating, ventilation balance).”
- “Every selection appears as a line item in your scope and photo set so you can see what you’re paying for.”

---
```

---

**user:**

Next

---

**assistant:**

```
# Safety &amp; QA

&gt; [[Home]] · [[Installation SOP]] · [[Inspection &amp; Scope Capture]] · [[Materials &amp; Spec Matrix]] · [[Detach &amp; Reset (Solar)]] · [[Calculator Guide]] · [[Insurance &amp; Compliance]] · [[Troubleshooting the Calculator]] · [[Changelog]]

## Purpose
Prevent injuries and leaks. Build **once** with proof. This page sets **stop-work gates**, daily safety practices, and **objective QA checks** tied to photos and logs.

---

## Stop-Work Gates (call it early)
- **Weather:** rain on deck/underlayment; lightning within 10 miles; sustained winds &gt;25 mph on steep/complex roofs; gusts &gt;35 mph.  
- **Access:** unstable ladder footing; roof too hot/cold for adhesives to bond; nightfall without dry-in.  
- **Structure:** spongy deck beyond allowance; unknown electrical near penetrations; unsafe chimney/skylight conditions.  
- **PV:** live conductors you cannot de-energize/verify; damaged rapid-shutdown.

&gt; If any gate is hit: make safe, temporary dry-in if required, document, and reschedule.

---

## Ladder &amp; Fall Protection (minimums)
- **Ladder**: 4:1 angle; extend ≥3 rungs (≥36 in) above landing; tie-off at top; non-slip feet; gate the base.  
- **Fall arrest**: required on steep slopes and where exposure warrants (lead judgment). Anchor to structure; inspect harness/lanyard/rope grab; keep slack minimal.  
- **Ridge hooks**: padded; verify ridge condition before load.  
- **Walking**: no wet surfaces; no debris paths; maintain 3 points of contact.

---

## Heat, PPE, and Site Hygiene
- **Heat plan** (TX reality): shade + water on site; 15–20 min cool break per hour in extreme heat; buddy checks for heat stress.  
- **PPE**: hard hat where overhead work; cut-resistant gloves; eye protection; respirator for dusty attic/tear-off; knee protection.  
- **Neighbors/Property**: cones/tarps, AC and window guards, magnet sweeps (start, mid, end).

---

## Electrical &amp; PV Safety (if solar present)
- **LOTO**: follow [[Detach &amp; Reset (Solar)]]. De-energize in order; verify **absence of voltage** with CAT III meter; tag and cap connectors.  
- Treat **modules in sun as live**. Do not mate/demate under load.  
- Protect and label conductor stubs; no exposed wires at day’s end.

---

## Daily Safety Brief (2–3 min, crew lead)
- Today’s scope &amp; **hazards** (weather, pitch, attic, PV, neighbors).  
- **Roles**: who is lead on deck, flashings, ground, PV.  
- **Stops**: when we halt and how we dry-in.  
- **Emergency**: address + nearest hospital; who calls; who meets EMS.

**Emergency card (fill at start):**  
- Site: __________________  City: ____________  
- Nearest ER: __________________  Phone: ____________  
- First aid kit location: __________________  
- Supervisor contact: __________________

---

## Job Hazard Analysis (JHA) – template
| Task | Hazard | Control | Owner | Verified |
|---|---|---|---|---|
| Ladder setup | Fall, slip | 4:1, tie-off, gate base | ____ | ☐ |
| Tear-off | Falls, nails | Harness on steep, debris control | ____ | ☐ |
| Dry-in | Wind uplift | Cap nails per spec, stage small rolls | ____ | ☐ |
| Valleys/Flash | Cuts, leaks | Gloves, hemmed metal, no-nail zone | ____ | ☐ |
| PV D&amp;R | Shock | LOTO, meter verify, caps on MC | ____ | ☐ |

---

## QA — What “Done Right” Looks Like
**Decking**  
- Rot/soft spots removed; new panels match thickness; 1/8&quot; gap; ring-shank nails to framing.  
- **Photos**: before, marked repair, after.

**Underlayment &amp; Metals**  
- Side laps ≥4&quot;, end laps ≥6&quot;; cap-nailed per manufacturer (tight rows at edges).  
- Eave drip under synthetic; rake drip over synthetic (unless local/manufacturer requires otherwise).  
- **Valleys**: W-valley hemmed with 4–6&quot; exposure **or** closed-cut with full I&amp;W and 6&quot; no-nail each side.  
- **Photos**: laps, valley centerline, drip sequence.

**Flashings**  
- Step flashing one-per-course; 2&quot; wall leg; **kick-out** at first step.  
- Counter-flashing seated (reglet or reset), no face-nails.  
- Chimney cricket ≥30&quot; width.  
- **Photos**: first step + kick-out, mid-wall, counter detail.

**Fasteners (asphalt)**  
- 6 nails/shingle in wind zones; heads flush; penetrations ≥3/4&quot; into or through deck.  
- **Photos**: sample row showing nail placement.

**Ventilation**  
- Ridge vent installed continuous (if specified); intakes opened/unblocked; NFA balanced (see calc in [[Installation SOP]]).  
- **Photos**: ridge vent length; soffit/intake views.

**Stone-Coated Steel (if used)**  
- High-temp underlayment; closures at eaves/ridges/valleys fitted; fasteners at pattern and torque spec.  
- **Photos**: closure fit, panel laps, fastener samples.

**PV Interface**  
- Standoffs flashed with manufacturer kits; rails bonded; wire management secure; no conductors in water paths.  
- **Photos**: every penetration flashed, bonding jumpers, conductor dress.

---

## QA Checklists (copy/paste)

**Mid-Job (post dry-in)**
- [ ] Deck repairs complete &amp; photographed  
- [ ] Synthetic laps correct; cap nails per spec  
- [ ] Eave/rake drip sequence verified  
- [ ] Valleys fully detailed (no exposed nails in water path)  
- [ ] Temporary dry-in ready if weather shifts

**Pre-Close (before cleanup)**
- [ ] Flashings (step + counter + kick-out) correct  
- [ ] Ridge vent length matches NFA; intakes clear  
- [ ] Penetrations sealed/flashed; no exposed fasteners in water path  
- [ ] SCS closures (if applicable) seated tight  
- [ ] PV rails/feet torqued; bonding confirmed; connectors properly dressed

**Final (after cleanup)**
- [ ] Magnet sweep (perimeter + lawn + beds) complete (×2)  
- [ ] Gutters checked/cleared if debris present  
- [ ] Photo set: front/rear, valleys, walls, penetrations, ridge/hip, attic (if inspected), PV monitoring online  
- [ ] Homeowner walkthrough complete; care notes given

---

## Torque &amp; Test Logs (attach to job file)
**PV / Mechanical sample log**  
- Rail splice torque: ____ N·m  (samples: ______)  
- Foot/standoff torque: ____ N·m  (samples: ______)  
- Mid/end clamp torque: ____ N·m  (samples: ______)

**Electrical (if strings)**  
- Voc by string (shade if safe): S1 ____ V, S2 ____ V, … (within expected)  
- Rapid-shutdown test: ☐ Pass ☐ Fail (action: __________)

---

## Photo Proof – Minimum Required Set
- Before/after elevations (front + rear)  
- Deck repair (before/after)  
- Underlayment laps + drip sequence  
- Each valley detail  
- Step + counter + kick-out  
- Ridge vent + intake evidence  
- PV penetrations flashed + wire management (if any)  
- Final curb appeal + ground cleanup

---

## Communication (insurance-neutral, homeowner-safe)
- “We document what’s present and how our scope meets code/manufacturer specs.”  
- “Any discovered changes are photographed, written up, and approved before work resumes.”  
- “Here’s your closeout packet: photos, as-built quantities, ventilation calc, (PV) commissioning.”

See [[Insurance &amp; Compliance]].

---

## Common Failure Modes → Preventatives
- **Under/over-driven nails** → adjust pressure; spot-check rows hourly.  
- **Missing kick-out** → mandatory; photo first step.  
- **Nails in valley** → mark 6&quot; no-nail lines; verify before shingling.  
- **Unbalanced ventilation** → calculate NFA; add intake or shorten ridge.  
- **PV bonding gap** → verify jumpers at splices; record torque.  
- **Debris left** → three magnet sweeps; walk neighbors’ side yards.

---

## Closeout Package (contents)
- Photo set (before/during/after)  
- As-built scope (LF/SQ/counts + approved changes)  
- Ventilation calc &amp; ridge/intake quantities  
- PV commissioning sheet (if applicable)  
- Warranty packet (materials + workmanship)  
- Care guide (first rain check, debris, contacts)

---
```

---

**user:**

Next

---

**assistant:**

```
# Insurance &amp; Compliance (Neutral Language)

&gt; [[Home]] · [[Sales Playbook]] · [[Inspection &amp; Scope Capture]] · [[Calculator Guide]] · [[Materials &amp; Spec Matrix]] · [[Installation SOP]] · [[Detach &amp; Reset (Solar)]] · [[Safety &amp; QA]] · [[Troubleshooting the Calculator]] · [[Changelog]]

## Purpose
Protect the homeowner and the company by communicating **exactly what is**: observations, quantities, codes/manufacturer requirements, and the scope we will perform. No legal advice. No claim outcome predictions.

---

## Our Role (plain and safe)
- We **document** site conditions with photos and measurements.
- We **propose** a code-compliant, manufacturer-compliant scope.
- We **perform** approved work and provide a complete closeout packet.
- We **do not** adjust claims, interpret policy coverage, or promise outcomes.

&gt; If insurance is involved, we can provide documentation **at the homeowner’s request**.

---

## Communication Guardrails (Do / Don’t)
**Do say**
- “Photos show ___; our scope addresses this with ___ per manufacturer/code.”
- “Quantities are listed so anyone can verify the math.”
- “Any changes we discover will be written up for approval before work.”

**Don’t say**
- “This is covered / this will be approved.”
- “Cosmetic only.” (Instead, **describe** what you see and the effect on function, if known.)
- “We’ll handle your claim.” (We can share documentation; the homeowner handles their claim or uses a licensed public adjuster/attorney if they choose.)

---

## Documentation Package (what we produce)
- **Photo set**: before / during / after (labeled).
- **Scope**: line items with **LF / SQ / count** quantities.
- **Codes / Manufacturer notes** used to justify details (e.g., drip edge, kick-out, step &amp; counter, ridge/soffit NFA balance, valley treatment).
- **Change orders** with reason: discovery, code trigger, safety.
- **Closeout**: as-built quantities, ventilation calc, warranties, PV commissioning (if applicable).

Store digitally in the job folder. Share selectively with the homeowner.

---

## Code &amp; Manufacturer Triggers (typical)
- **Drip edge** at eaves and rakes.
- **Valleys**: no nails within 6&quot; of centerline (closed-cut) or use **hemmed W-valley metal**.
- **Step + counter-flashing** at walls; **kick-out** at the first step.
- **Ventilation**: balance intake/exhaust to required NFA; continuous ridge (if specified).
- **Chimney cricket** when width ≥ 30&quot;.
- **High-temp underlayment** under metal/stone-coated steel per manufacturer.

&gt; Cite the relevant page from the product manual or common code text when you include these in scope. Keep excerpts brief; link or attach the page image.

---

## Change Order Protocol (protects everyone)
1) **Stop &amp; document** (photos + 1-line description).  
2) **Write the delta**: quantity, labor/material, reason (discovery/code/safety).  
3) **Homeowner approval** (text/email signature is fine).  
4) **Resume** and file change order in job folder.

---

## Permits, Inspections, HOA
- Pull permits when required; post onsite; schedule inspections on time.
- Respect HOA color/material rules; submit a **one-page scope + photos** when requested.
- Keep jobsite hours, parking, and protection in writing.

**HOA one-pager includes**
- Material/color, ridge/vent plan, edges/metals, valley style.
- Start/finish window and daily cleanup plan.
- Contact for questions.

---

## Licensing, Insurance, Warranties
- Provide COI on request (GL/Workers’ Comp where applicable).
- Clarify **workmanship warranty** term and **manufacturer warranty** registration steps.
- Record material brand/model/lot (if available) in closeout packet.

---

## Privacy &amp; Data Handling
- Only share photos/documents **with the homeowner** or parties they designate.
- No social media posting without written permission.
- Redact PII on any public examples.

---

## Safe Phrases (copy/paste)
- “Our photos show ___ at the ___ side. The proposed scope corrects this by ___ per the manufacturer detail attached.”
- “Here are the quantities (LF/SQ/count) that correspond to each line. If you need additional documentation, we can provide it.”
- “We don’t determine coverage; if your carrier requests info, this packet keeps everything clear.”

---

## Sample: Carrier-Safe Summary Email
_Subject: Documentation for &lt;Address&gt; Roof Scope_  
“Hello &lt;Adjuster/Homeowner&gt;,  
Attached are labeled photos (before/during/after) and the line-item scope with quantities. The following details reflect manufacturer/code guidance included in the packet: drip edge at eaves/rakes; step+counter flashing with kick-out at sidewalls; valley treatment (no-nail zone/hemmed W-valley); balanced ventilation (ridge+intake NFA).  
We’re available to answer **scope** questions or provide additional photos. We don’t comment on coverage decisions.”

---

## Crew Brief (insurance-neutral reminders)
- Describe conditions; avoid policy language.  
- Tie each detail to **manufacturer/code** or clear functional purpose.  
- Log change orders before resuming work.

---

## Closeout Compliance Checklist
- [ ] Permits closed, inspection passed (if required)  
- [ ] As-built scope + photo set uploaded  
- [ ] Ventilation calc documented  
- [ ] Warranties (workmanship + manufacturer) issued/registered  
- [ ] PV commissioning sheet (if applicable) completed  
- [ ] Homeowner received digital packet

---
```

---

**user:**

Next

---

**assistant:**

```
# Calculator Guide

&gt; [[Home]] · [[Sales Playbook]] · [[Inspection &amp; Scope Capture]] · [[Detach &amp; Reset (Solar)]] · [[Materials &amp; Spec Matrix]] · [[Installation SOP]] · [[Safety &amp; QA]] · [[Insurance &amp; Compliance]] · [[Troubleshooting the Calculator]] · [[Changelog]]

## Purpose
Phone-first estimator for roof replacement/repair and solar D&amp;R. Copy key quantities from Roofr or your field notes → select specs → present Good/Better/Best with honest math.

---

## Quick Start (field flow)
1) Copy measurements from Roofr (or your sketch).  
2) Paste into inputs (SQ, LF, counts).  
3) Choose spec: Good / Better / Best (see [[Materials &amp; Spec Matrix]]).  
4) If PV present, complete the D&amp;R block (module count, inverter type, penetrations).  
5) Review totals; screenshot the **Customer Summary**; save Scope ID.

---

## Inputs (what each field means)
**Area &amp; Geometry**
- **Roof Area (SQ)** – total squares (1 SQ = 100 ft²).  
- **Pitch Class** – Low (≤4/12), Standard (5–7/12), Steep (≥8/12).  
- **Waste %** – default 10–15% (autofills by pitch; override only if plan is simple/complex).  
- **Linear Feet (LF)** – eaves, rakes, hips, ridges, valleys.  
- **Counts** – pipe boots, box/turtle vents, O’Hagin, chimneys, skylights.

**Layers &amp; Deck**
- **Tear-off Layers** – 1 or 2 typical; adds labor &amp; dumpster.  
- **Deck Repair Allowance (ft²)** – contingency; used only when approved.  
- **Deck Type** – OSB/Ply (so crew matches thickness &amp; nailing).

**Ventilation**
- **Ridge Vent (LF)** and **Intake (LF or count)** – size to balance NFA (see quick calc in [[Installation SOP]]).

**Metals &amp; Flashings**
- **Drip Edge (LF)**, **Valley Style &amp; LF**, **Step/Counter (LF)**, **Kick-outs (qty)**, **Aprons/Headwalls (LF)**.

**PV Detach &amp; Reset (if present)**
- **Module Count**, **Inverter Type** (string/micro/optimizer), **Racking Brand** (note if unknown),  
- **Penetrations to flash (ea.)**, **Branch circuits/home runs (ea.)**, **Lift/Crane (days)**, **Monitoring restore (Y/N)**.

**Adders (optional)**
- **Gutters** (replace or re-pitch LF), **Screens**, **Skylight kit(s)**, **Chimney cricket (Y/N)**, **Access/Lift day(s)**.

---

## Output (how totals are built)
- **Labor** = Σ(line qty × rate) × **pitch multiplier** × **layers multiplier**.  
- **Materials** = Σ(line qty × unit cost) (includes waste where applicable).  
- **Overhead** = (Labor + Materials) × `overhead_pct`.  
- **Target Profit** = (Labor + Materials + Overhead) × `target_profit_pct`.  
- **Price** = Labor + Materials + Overhead + Target Profit.  
- **Taxes/Fees (if used)** are applied per config (e.g., sales tax on materials only).

&gt; Owner-only toggle: show/hide cost breakdown on customer view.

---

## Good / Better / Best (default mapping)
- **Good (Architectural)** → synthetic underlayment, closed-cut or open valley per scope, drip edge, balanced vent.  
- **Better (Class 4)** → impact shingle, open W-valley metal (24 ga) or closed-cut with full I&amp;W, ridge + verified intake, premium flashings.  
- **Best (Stone-Coated Steel)** → SCS panels, high-temp underlayment, SCS valley pans/closures, SCS-compatible flashings.

**Customer framing:** “Same house, different risk profile and lifespan. Price deltas map **only** to spec deltas.”

---

## Field → Calculator Mapping (cheat table)
| Field note | Paste into |
|---|---|
| Roofr “Total Area (sq ft)” | Roof Area (SQ) = ft² ÷ 100 |
| Eaves LF on plan | Eaves (LF) |
| Rakes LF on plan | Rakes (LF) |
| Hips/Ridges LF | Hips (LF), Ridges (LF) |
| Valley LF &amp; style | Valleys (LF) + select style |
| # Pipe boots / Skylights / Chimneys | Penetrations (counts) |
| Attic intake/ridge | Ridge Vent (LF); Intake (LF or count) |
| PV module count / inverter type | PV D&amp;R block |

---

## Guardrails (do these, don’t do those)
- **Do** keep waste defaults and pitch/layer multipliers locked; adjust only with reason noted.  
- **Do** separate **contingencies** (deck, code upgrades) from base price.  
- **Do not** tweak unit rates mid-appointment; if discounting, add a single explicit **discount line** with reason.  
- **Do** round **display** to 2 decimals; keep internal math unrounded.

---

## Update Rates (owner/operator)
**Material costs** (per SQ/LF/count), **labor baselines** (tear-off/install by pitch), **PV D&amp;R** line items, and **O/H &amp; Profit** live in the config.

**Suggested config keys**
```json
{
  &quot;labor&quot;: {
    &quot;tearoff_per_sq&quot;: { &quot;low&quot;: 45, &quot;std&quot;: 55, &quot;steep&quot;: 75, &quot;two_layer_multiplier&quot;: 1.35 },
    &quot;install_per_sq&quot;: { &quot;low&quot;: 65, &quot;std&quot;: 80, &quot;steep&quot;: 110 }
  },
  &quot;pitch_multiplier&quot;: { &quot;low&quot;: 1.00, &quot;std&quot;: 1.10, &quot;steep&quot;: 1.30 },
  &quot;materials&quot;: {
    &quot;arch_shingle_per_sq&quot;: 165,
    &quot;class4_shingle_per_sq&quot;: 210,
    &quot;scs_panel_per_sq&quot;: 420,
    &quot;synthetic_underlayment_per_sq&quot;: 28,
    &quot;hitemp_underlayment_per_sq&quot;: 55,
    &quot;drip_edge_per_lf&quot;: 2.4,
    &quot;w_valley_24ga_per_lf&quot;: 8.5,
    &quot;ice_water_per_lf&quot;: 2.0,
    &quot;ridge_vent_per_lf&quot;: 7.5,
    &quot;step_flashing_per_lf&quot;: 4.2,
    &quot;counter_flashing_per_lf&quot;: 7.9,
    &quot;kickout_each&quot;: 42
  },
  &quot;pv_dnr&quot;: {
    &quot;module_remove_reinstall_each&quot;: 85,
    &quot;rack_foot_reinstall_each&quot;: 12,
    &quot;penetration_flash_each&quot;: 22,
    &quot;string_commission_lump&quot;: 250,
    &quot;micro_commission_per_module&quot;: 6,
    &quot;monitoring_restore_lump&quot;: 95,
    &quot;lift_day&quot;: 650
  },
  &quot;overhead_pct&quot;: 0.10,
  &quot;target_profit_pct&quot;: 0.15,
  &quot;tax&quot;: { &quot;apply_sales_tax_on_materials&quot;: true, &quot;rate&quot;: 0.0825 }
}
```

**Where to edit:** constants in `script.js` (or `config.json` if externalized). Commit changes with a dated note in [[Changelog]].

---

## Data Hygiene (the boring stuff that prevents pain)
- **Sanitize inputs**: strip commas/spaces (`toNumber()`); treat blank as 0.  
- **Lock types**: SQ/LF numeric only; counts as integers.  
- **Prevent NaN**: default any failed parse to 0; highlight required fields if empty.  
- **Currency**: format display as `$#,###.##`; keep raw numbers inside.  
- **Mobile UX**: min input font-size **16px** to stop iOS zoom; sticky labels; large tap targets.  
- **Print/Share**: a `@media print` style that hides controls and prints the summary block.

&gt; If you see white text in inputs on iOS, see [[Troubleshooting the Calculator]].

---

## Example (sanity check)
**Assumptions**  
- 30 SQ, Standard pitch, 300 LF eaves+rakes, 40 LF valleys (open W), 60 LF ridge, 6 pipe boots, deck allowance 32 ft², waste 12%.  
- Good = Architectural; Better = Class 4; Best = SCS.  
- No PV.

**Back-of-envelope**  
- Install labor (std): 30 × $80 = $2,400  
- Tear-off (std): 30 × $55 = $1,650  
- Materials (Good): shingles 30 × $165 = $4,950; synthetic 30 × $28 = $840; drip 300 × $2.4 = $720; valley 40 × $8.5 = $340; ridge vent 60 × $7.5 = $450; boots 6 × (mat+labor est. $35) ≈ $210 → Materials ≈ $7,510  
- Subtotal (L+M) ≈ $11,560 → Overhead 10% ≈ $1,156 → Target profit 15% ≈ $1,913  
- **Price (Good)** ≈ **$14,629** (+ tax if applicable).  
Use this to spot check your calculator result within a few percent.

---

## Customer Summary (what they should see)
- A short spec block for the chosen option (bullets, not jargon).  
- Line items with quantities (LF/SQ/count), subtotal, overhead/profit already inside.  
- Clear **contingencies** (deck, code upgrades) listed separately.  
- Install window options and site protection notes.

---

## Change Orders (in the calculator)
- Use an **Add/Remove** line with quantity, unit rate, and a short reason (“discovery/code/safety”).  
- Change orders must be approved (text/email OK) before resuming work.  
- Tag them so they appear in the Customer Summary with date/time.

---

## Validation Checklist
- [ ] All numeric fields parse (no NaN)  
- [ ] Waste applied to panel/shingle quantities (not metals)  
- [ ] Pitch &amp; layer multipliers applied to **labor only**  
- [ ] O/H and profit use correct base(s)  
- [ ] PV block hidden when N/A, required when PV = Yes  
- [ ] Print summary is clean on mobile

---

## Common Pitfalls (and fixes)
- **Invisible input text on iOS** → set `-webkit-text-fill-color: #111;` and normal `color/background` on inputs. See [[Troubleshooting the Calculator]].  
- **Weird rounding** → round **display** only; keep math in full precision.  
- **Copy/paste junk** → sanitize to digits/periods on input.  
- **Apples-to-oranges quotes** → export the line-item summary so scope is comparable.

---

## Owner Notes
- When rates change, bump the version in [[Changelog]] and commit with a one-line reason (e.g., “asphalt up 6%, Aug ’25”).  
- Consider locking a **promo/discount** field with a cap (e.g., ≤5%) to protect margin while giving reps flexibility.

---
```

---

**user:**

Give me troubleshooting the calculator

---

**assistant:**

```
# Troubleshooting the Calculator

&gt; [[Home]] · [[Calculator Guide]] · [[Sales Playbook]] · [[Inspection &amp; Scope Capture]] · [[Materials &amp; Spec Matrix]] · [[Installation SOP]] · [[Detach &amp; Reset (Solar)]] · [[Safety &amp; QA]] · [[Insurance &amp; Compliance]] · [[Changelog]]

## Purpose
Field-ready fixes for common calculator glitches—especially on iOS Safari. Copy the snippets, paste, and re-test.

---

## Quick Diagnostic Checklist
- [ ] Inputs visible (typed text + placeholder)
- [ ] Numbers parse (no NaN), commas handled
- [ ] Totals change as you type (events firing)
- [ ] Mobile focus doesn’t zoom page
- [ ] Print/Screenshot summary looks clean
- [ ] No “stuck” old CSS/JS (cache-busted)

---

## 1) “Input text is invisible (white on white)”
**Cause:** Inherited white text color or autofill styling on iOS.

**Fix (CSS):**
```css
/* Force readable text + background */
input, select, textarea {
  color: #111 !important;
  background: #fff !important;
  -webkit-text-fill-color: #111; /* iOS Safari */
}

/* Placeholders */
::placeholder { color: #777 !important; opacity: 1; }

/* iOS autofill yellow override */
input:-webkit-autofill {
  -webkit-text-fill-color: #111 !important;
  box-shadow: 0 0 0px 1000px #fff inset !important;
  -webkit-box-shadow: 0 0 0px 1000px #fff inset !important;
}

/* If dark mode flips colors */
:root { color-scheme: light; } /* opt out of UA dark mode on form fields */
```

---

## 2) Mobile zoom jumps on focus (iOS)
**Cause:** iOS auto-zooms inputs with font-size &lt; 16px.

**Fix:**
```html
&lt;meta name=&quot;viewport&quot; content=&quot;width=device-width, initial-scale=1, viewport-fit=cover&quot;&gt;
```
```css
input, select { font-size: 16px; }
```

---

## 3) Numbers won’t parse / NaN (commas, units, spaces)
**Cause:** Copy/paste from Roofr or notes includes commas, units, or spaces.

**Fix (JS sanitizer):**
```js
const toNumber = v =&gt; Number(String(v).replace(/[^0-9.]/g, &#x27;&#x27;)) || 0;
// For LF/SQ integers:
const toInt = v =&gt; parseInt(String(v).replace(/[^0-9]/g, &#x27;&#x27;), 10) || 0;

// Attach to every numeric input
document.querySelectorAll(&#x27;[data-num]&#x27;).forEach(el =&gt; {
  el.addEventListener(&#x27;input&#x27;, e =&gt; { e.target.value = e.target.value.replace(/[^0-9.,]/g,&#x27;&#x27;); });
  el.addEventListener(&#x27;change&#x27;, e =&gt; { e.target.value = toNumber(e.target.value); recompute(); });
});
```
&gt; If your locale uses commas as decimals, normalize before `Number()`.

---

## 4) Totals not updating as you type
**Cause:** Using `change` events only; missing `input` listeners; or calculating before DOM loads.

**Fix (JS):**
```js
window.addEventListener(&#x27;DOMContentLoaded&#x27;, () =&gt; {
  const recalc = () =&gt; recompute(); // your compute function
  document.querySelectorAll(&#x27;input,select,textarea&#x27;).forEach(el =&gt; {
    el.addEventListener(&#x27;input&#x27;, recalc);
    el.addEventListener(&#x27;change&#x27;, recalc);
  });
  recalc();
});
```

---

## 5) “Rounding looks off”
**Rule:** Round **display only**, not internal math.

**Fix (JS):**
```js
const round2 = n =&gt; Math.round((n + Number.EPSILON) * 100) / 100;
const fmt$ = n =&gt; `$${round2(n).toLocaleString()}`;
// Keep raw sums unrounded; only round when rendering.
```

---

## 6) Waste applied to the wrong things
**Symptom:** Metals (LF) look too high; valleys multiplied by waste.

**Fix (logic):** Apply waste to **field materials (SQ)**, not to LF items.
```js
const materialSQ = roofSQ * (1 + wastePct);
const metalsLF   = baseMetalsLF; // no waste multiplier
```

---

## 7) PV block not showing / not required when it should be
**Cause:** Visibility tied to a stale checkbox or wrong initial state.

**Fix (JS):**
```js
const pvToggle = document.getElementById(&#x27;hasPV&#x27;);
const pvBlock  = document.getElementById(&#x27;pvBlock&#x27;);
const syncPV = () =&gt; pvBlock.style.display = pvToggle.checked ? &#x27;block&#x27; : &#x27;none&#x27;;
pvToggle.addEventListener(&#x27;change&#x27;, syncPV);
window.addEventListener(&#x27;DOMContentLoaded&#x27;, syncPV);
```

---

## 8) Print / PDF looks messy
**Goal:** Clean customer summary without controls.

**Fix (CSS):**
```css
@media print {
  .no-print, header, nav, footer, form, .controls { display: none !important; }
  .summary { display: block !important; font-size: 12pt; }
  body { margin: 0.5in; }
}
```

---

## 9) iOS keyboard covers inputs on the bottom
**Fix (JS + CSS):**
```js
const lastField = document.querySelector(&#x27;#lastField&#x27;);
lastField &amp;&amp; lastField.addEventListener(&#x27;focus&#x27;, e =&gt; {
  setTimeout(() =&gt; e.target.scrollIntoView({block: &#x27;center&#x27;, behavior: &#x27;smooth&#x27;}), 250);
});
```
```css
/* Give space for the on-screen keyboard */
@supports (padding-bottom: env(safe-area-inset-bottom)) {
  body { padding-bottom: env(safe-area-inset-bottom); }
}
```

---

## 10) “Changes aren’t taking effect” (cache)
**Cause:** Browser caching old `script.js` / `styles.css`.

**Fix:** Add a version query string and bump it when you deploy.
```html
&lt;link rel=&quot;stylesheet&quot; href=&quot;styles.css?v=2025-08-17a&quot;&gt;
&lt;script src=&quot;script.js?v=2025-08-17a&quot; defer&gt;&lt;/script&gt;
```
Also do a **hard refresh** on mobile (close tab, reopen) or clear site data.

---

## 11) Buttons submit the page / reload form
**Cause:** Missing `type=&quot;button&quot;` defaults to submit.

**Fix (HTML):**
```html
&lt;button type=&quot;button&quot; id=&quot;recalcBtn&quot;&gt;Recalculate&lt;/button&gt;
```
or disable form submission:
```html
&lt;form onsubmit=&quot;return false;&quot;&gt;
```

---

## 12) Keep values after refresh (optional, field-friendly)
**Add persistence** so reps don’t retype data after accidental reloads.

```js
const form = document.getElementById(&#x27;calcForm&#x27;);
const KEY  = &#x27;scsrrs_calc_v1&#x27;;

function save() {
  const data = Object.fromEntries(new FormData(form).entries());
  localStorage.setItem(KEY, JSON.stringify(data));
}

function load() {
  const data = JSON.parse(localStorage.getItem(KEY) || &#x27;{}&#x27;);
  Object.entries(data).forEach(([k,v]) =&gt; {
    const el = form.elements[k]; if (!el) return;
    el.value = v; el.dispatchEvent(new Event(&#x27;change&#x27;, {bubbles:true}));
  });
}

window.addEventListener(&#x27;DOMContentLoaded&#x27;, () =&gt; {
  load();
  form.addEventListener(&#x27;input&#x27;, save);
  form.addEventListener(&#x27;change&#x27;, save);
});
```

---

## 13) Sanity checks for UX
- Inputs **left-aligned**, labels visible, placeholders clear.
- Tap targets ≥ 40px height.
- Error states obvious (e.g., red outline + hint text).
- Disable irrelevant blocks (e.g., PV) unless toggled on.

---

## 14) Dev Console Quick Tests
- `Number(&#x27;1,234&#x27;)` → `NaN` (you need a sanitizer)
- `getComputedStyle(input).color` → should be `rgb(17, 17, 17)`
- `document.querySelectorAll(&#x27;input&#x27;).length` → verify selectors
- Network tab → confirm latest `script.js?v=...` is served (Status 200, not from disk cache)

---

## 15) When to escalate
- Layout broken on a single device model → grab **device + iOS version** and a screenshot.
- Persistent NaN → log the offending field name and raw value.
- Rounding drift &gt; 1% → check for double rounding or wrong base for O/H &amp; Profit.

---

## Version Note
Any code/style change should bump [[Changelog]] with date + one-line reason:
- `2025-08-17 — Fix iOS input visibility and autofill styling.`

---
```

---

**user:**

Let’s add a footer with a link to the calculator site and our Google page (https://maps.app.goo.gl/WXW9ards8rbvAsVWA?g_st=ipc)

---

**assistant:**

Great call. Easiest way to add a footer to **every** wiki page is to create a page titled **`_Footer`** in the wiki—GitHub will auto-append it site-wide.

Paste this into a new wiki page named `_Footer`:

```
---

&lt;small&gt;
&lt;b&gt;Quick Links:&lt;/b&gt;
&lt;a href=&quot;https://justindbilyeu.github.io/SCSRRS-TCR/calculator/&quot; target=&quot;_blank&quot;&gt;Open the SCSRRS Calculator&lt;/a&gt;
·
&lt;a href=&quot;https://maps.app.goo.gl/WXW9ards8rbvAsVWA?g_st=ipc&quot; target=&quot;_blank&quot;&gt;Texas Choice Roofing — Google Page&lt;/a&gt;
&lt;/small&gt;
```

If you prefer per-page control instead of a global footer, paste that same block at the bottom of any individual page.

---

**user:**

great work!

---

**assistant:**

🙏 appreciate it. Want me to draft the **Home** page next, or the **Changelog**?

---

**user:**

Hey Sage! 
Here is the wiki, and the calculator… are you ready to work on a final product?

---

**user:**

Hey Sage! 
Here is the wiki, and the calculator… are you ready to work on a final product?

https://github.com/justindbilyeu/SCSRRS-TCR/wiki

https://justindbilyeu.github.io/SCSRRS-TCR/

---

**assistant:**

Absolutely—reviewed both links. You’re in striking distance. Here’s a tight finalization package: (a) 3 paste-ready wiki pages to round out the system, and (b) a small calculator polish patch (SEO, share link, footer). I verified what’s live so we’re building on reality. citeturn1view0turn2view0

# Context &amp; objective
Make the SCSRRS wiki + calculator field-ready and owner-safe: clear pages for reps, clean incentives guidance, and a calculator that’s easy to share/print.

# Actions (paste-ready)

## 1) Wiki page: “Start Here”
Create a new wiki page titled **Start Here** and paste:

```
# Start Here

&gt; [[Home]] · [[Sales Playbook]] · [[Inspection &amp; Scope Capture]] · [[Calculator Guide]] · [[Installation SOP]] · [[Safety &amp; QA]]

## What to do in the field (5 steps)
1) Run the [[Sales Playbook]] talk track.
2) Capture the 10-shot photo set in [[Inspection &amp; Scope Capture]].
3) Open the live calculator → https://justindbilyeu.github.io/SCSRRS-TCR/calculator/
4) Present Good / Better / Best (tie price deltas to spec deltas).
5) Book an install window; send the photo summary + scope.

## What we install (short version)
- **Good**: architectural shingles + correct flashings + balanced ventilation  
- **Better**: Class 4 impact shingles + open W-valleys or I&amp;W + matched intake/exhaust  
- **Best**: stone-coated steel + high-temp underlayment + SCS closures/valleys  

## Insurance-neutral stance
We document conditions and propose a code/manufacturer-compliant scope. We do not predict claim outcomes. See [[Insurance &amp; Compliance]].

## Links you can text
- Calculator: https://justindbilyeu.github.io/SCSRRS-TCR/calculator/  
- Google page (reviews/directions): https://maps.app.goo.gl/WXW9ards8rbvAsVWA?g_st=ipc

---
```

## 2) Wiki page: “Incentives &amp; Rebates (Austin + Federal + TX)”
Create **Incentives &amp; Rebates** and paste:

```
# Incentives &amp; Rebates (Austin + Federal + Texas)

&gt; We are not giving legal or tax advice. Confirm eligibility with the program and your tax professional.

## Austin Energy (City of Austin)
- **Residential Solar Rebate:** **$2,500** after completing the AE solar education course and installing a qualifying system.  
- **Value-of-Solar (VoS) Bill Credit:** AE credits production at the current VoS rate (¢/kWh). This shows up as bill credits, not net metering.

## Federal — Residential Clean Energy Credit (IRC §25D)
- **30% credit** on qualified residential clean energy property placed in service **2022–2032** (steps down to 26% in 2033, 22% in 2034).  
- Applies to **solar PV** (and qualified batteries).  
- **Roof replacement is generally not a 25D expense** unless the roofing product is itself a qualified solar electric property (e.g., solar shingles). Keep roof costs separate from PV on invoices.

## Texas — Property Tax
- **100% exemption** of the **appraised value added** by a solar or wind-powered energy device on the property (file once; local appraisal district may require receipts).

## Class 4 Impact-Resistant (IR) Roofing — Insurance Notes
- Many TX carriers offer premium credits for **UL 2218 Class 4** roofing. Discounts and proof requirements vary by carrier and ZIP.  
- Expect to provide a **UL 2218 / Class 4** proof and, if requested, the **TDI PC068** impact-resistant roof form signed by the installer. See [[Insurance &amp; Compliance]].

## How to present this to homeowners (safe language)
- “Austin Energy currently offers a $2,500 solar rebate and a Value-of-Solar bill credit. We’ll provide links; please confirm details with AE.”  
- “The federal Residential Clean Energy Credit is 30% for solar through 2032. Roofing itself isn’t covered unless it’s a solar roofing product.”  
- “Texas exempts the value added by the solar system from property taxes; file once with your appraisal district.”

## Links (hand to the homeowner)
- Austin Energy Residential Solar: austinenergy.com → Green Power → Solar Solutions (Residential)  
- IRS: ‘Residential Clean Energy Credit’ and Form 5695 instructions  
- Texas Property Tax: “Exemption Application for Solar or Wind-Powered Energy Device” (Form 50-123)

---
```

**Sources for this page:** Austin Energy shows a **$2,500** residential solar rebate and the current **Value-of-Solar** credit; both are on AE’s site. citeturn5search4turn5search12turn5search8  
IRS confirms the Residential Clean Energy Credit is **30% from 2022–2032**, stepping down afterward; see IRS overview and §25D. citeturn5search6turn5search2turn5search10turn5search14  
Texas property-tax solar exemption is codified at **Tax Code §11.27** and the **Form 50-123** filing is published by the Comptroller. citeturn5search5turn5search17  
For IR roofing, TDI references UL 2218 requirements and provides the **PC068** form commonly requested by insurers. citeturn5search3turn5search7

## 3) Wiki page: “Changelog”
Open **Changelog** and paste (append if it exists):

```
# Changelog

## v0.2 — Field-Ready Pass (Sep 2025)
- Added **Start Here** and **Incentives &amp; Rebates** pages.
- Linked AE rebate / VoS + IRS §25D + TX §11.27 guidance in plain language.
- Calculator: added share-link + print stylesheet + LocalBusiness schema (see repo README patch).
- Global footer: calculator + Google page links.

## v0.1 — Initial (Aug 2025)
- Core wiki pages and calculator published.
```

---

## 4) Calculator polish patch (drop-in)

### a) Add `&lt;head&gt;` metadata (SEO/OG)
In `docs/calculator/index.html` `&lt;head&gt;`:

```html
&lt;title&gt;SCSRRS ROI Calculator — Texas Choice Roofing&lt;/title&gt;
&lt;meta name=&quot;description&quot; content=&quot;Compare asphalt vs. Class-4 metal with carrier discounts, incentives and deductible avoidance. Private, client-side only.&quot;&gt;
&lt;meta property=&quot;og:title&quot; content=&quot;SCSRRS ROI Calculator&quot;&gt;
&lt;meta property=&quot;og:description&quot; content=&quot;Asphalt vs. Class-4 metal: savings, payback, and NPV with insurer credits and incentives.&quot;&gt;
&lt;meta property=&quot;og:type&quot; content=&quot;website&quot;&gt;
&lt;meta property=&quot;og:url&quot; content=&quot;https://justindbilyeu.github.io/SCSRRS-TCR/calculator/&quot;&gt;
&lt;meta name=&quot;viewport&quot; content=&quot;width=device-width, initial-scale=1, viewport-fit=cover&quot;&gt;
&lt;link rel=&quot;icon&quot; href=&quot;data:image/svg+xml,&lt;svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22&gt;&lt;text y=%22.9em%22 font-size=%2290%22&gt;🏠&lt;/text&gt;&lt;/svg&gt;&quot;&gt;
```

### b) JSON-LD for LocalBusiness (links your Google page)
Also in `&lt;head&gt;`:

```html
&lt;script type=&quot;application/ld+json&quot;&gt;
{
  &quot;@context&quot;: &quot;https://schema.org&quot;,
  &quot;@type&quot;: &quot;RoofingContractor&quot;,
  &quot;name&quot;: &quot;Texas Choice Roofing&quot;,
  &quot;url&quot;: &quot;https://justindbilyeu.github.io/SCSRRS-TCR/&quot;,
  &quot;sameAs&quot;: [&quot;https://maps.app.goo.gl/WXW9ards8rbvAsVWA?g_st=ipc&quot;],
  &quot;telephone&quot;: &quot;512-945-9720&quot;
}
&lt;/script&gt;
```

### c) Shareable link + load-from-URL
In your calculator JS (or a `&lt;script&gt;` tag):

```js
function readFields() {
  return Array.from(document.querySelectorAll(&#x27;input,select&#x27;))
    .filter(el =&gt; el.id)
    .reduce((a,el)=&gt; (a[el.id]=el.value, a), {});
}
function writeFields(map) {
  Object.entries(map).forEach(([id,v])=&gt;{
    const el=document.getElementById(id); if(!el) return;
    el.value=v; el.dispatchEvent(new Event(&#x27;change&#x27;,{bubbles:true}));
  });
}
function copyShareURL() {
  const p = new URLSearchParams(readFields()).toString();
  const url = `${location.origin}${location.pathname}?${p}`;
  navigator.clipboard.writeText(url);
  alert(&#x27;Shareable link copied!&#x27;);
}
// On load: hydrate from URL
window.addEventListener(&#x27;DOMContentLoaded&#x27;, ()=&gt;{
  const q = Object.fromEntries(new URLSearchParams(location.search).entries());
  if (Object.keys(q).length) writeFields(q);
});
```

Hook the “Copy shareable link” button to `copyShareURL()`.

### d) Print-friendly summary
Add a **Save as PDF** button that calls `window.print()`, and in your CSS:

```css
@media print {
  body { margin: 0.5in; }
  header, nav, form .controls, .no-print { display:none !important; }
  .summary, #results { display:block !important; font-size:12pt; }
}
```

### e) Footer with Google page (calculator)
In the calculator footer, add:

```html
&lt;footer&gt;
  © 2025 Texas Choice Roofing · 
  &lt;a href=&quot;https://justindbilyeu.github.io/SCSRRS-TCR/calculator/&quot;&gt;Calculator&lt;/a&gt; ·
  &lt;a href=&quot;https://maps.app.goo.gl/WXW9ards8rbvAsVWA?g_st=ipc&quot; target=&quot;_blank&quot; rel=&quot;noopener&quot;&gt;Google Page&lt;/a&gt; ·
  &lt;a href=&quot;https://github.com/justindbilyeu/SCSRRS-TCR&quot;&gt;GitHub&lt;/a&gt;
&lt;/footer&gt;
```

# What I checked (quick audit)
- The site root **redirects to the live calculator**, which renders inputs/results with “Copy shareable link” and “Save as PDF” calls to action visible in the markup. citeturn1view0  
- The wiki **Home** exists with your mini-nav and the **global footer links** to the calculator and Google page already appear. citeturn2view0

# Risks &amp; unknowns (callouts)
- Incentives are programmatic and can change; keep the **Incentives** page short with official links (done above) and avoid quoting $ beyond AE’s current rebate headline. citeturn5search4
- IRS roof expense eligibility under §25D is narrow—keep roof and PV invoicing **separate** (we do).

If you’re good with this, paste the three pages, make the small calculator edits, and we’ll tag **v0.2** in the Changelog. Want me to also add a global **_Sidebar** for the wiki so the mini-nav is automatic on every page?

---

**user:**

Yes

---

**assistant:**

Awesome. GitHub wikis use a special page named **`_Sidebar`**. Create it and paste the block below—GitHub will auto-show it on every page.

```
# SCSRRS · TCR

**Quick Links**
- 🔢 **[Open Calculator](https://justindbilyeu.github.io/SCSRRS-TCR/calculator/)**  
- 📍 **[Texas Choice Roofing — Google Page](https://maps.app.goo.gl/WXW9ards8rbvAsVWA?g_st=ipc)**

---

**Start Here**
- 🏠 [[Home]]
- 🚀 [[Start Here]]
- 🧾 [[Changelog]]

**Field Ops**
- 🗣️ [[Sales Playbook]]
- 📸 [[Inspection &amp; Scope Capture]]
- 🛠️ [[Installation SOP]]
- ⚡ [[Detach &amp; Reset (Solar)]]
- 🦺 [[Safety &amp; QA]]

**Pricing &amp; Materials**
- 💻 [[Calculator Guide]]
- 🧱 [[Materials &amp; Spec Matrix]]
- 🧩 [[Troubleshooting the Calculator]]

**Owner-Safe**
- 🧭 [[Insurance &amp; Compliance (Neutral Language)]]
- 💸 [[Incentives &amp; Rebates (Austin + Federal + Texas)]]

---

&lt;small&gt;
&lt;b&gt;SCSRRS — Solar-Connected Storm-Resistant Roofing System&lt;/b&gt;&lt;br&gt;
Observe Precisely. Question Relentlessly. Build with Truth. No Waste.
&lt;/small&gt;
```

**Notes**
- This will appear on every wiki page automatically.  
- You can keep your mini-nav at the top of pages, or remove it now that the sidebar exists—your call.  
- If you later rename any page, just update the link text in `_Sidebar`.

---

