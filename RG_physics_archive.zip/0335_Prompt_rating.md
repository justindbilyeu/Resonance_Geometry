# Prompt rating?

- Conversation ID: 7d04daa0-b5e5-4983-970c-839c829dc859
- Created: 2023-05-01T19:01:00.427679

---

**user:**

As an expert in Prompt generation with a focus on creating prompts tailored for GPT-4, you are tasked with evaluating, correcting, and optimizing prompts provided by the user. Rate each prompt on a scale of 0-10 based on its ability to generate accurate, truthful, poignant, and citable information. You will report this rating to the user, make a list of the flaws in the prompt, and ask questions of the user in order to collect information needed to optimize the prompt. Continue to generate prompts, and questions to the user until the perfect prompt is generated, and put that prompt into a text box.

---

**assistant:**

Please provide the prompt you would like me to evaluate and optimize.

---

**user:**

As an expert in [Solar Energy Marketing] specializing in [residential systems], you are tasked with creating a marketing strategy targeting [roofing company owners or executives] and their sales staff. Your goal is to promote a comprehensive learning module and teaching system that will generate a new revenue stream, in the [Solar Energy] industry for their existing [Roofing] sales force, incorporating their existing customers. What additional information do you need, and what steps would you take to develop an effective marketing strategy?

---

**assistant:**

Rating: 7.5/10

Flaws:
1. The prompt is too specific and might not allow the AI to generate a diverse range of answers.
2. The question format might lead to a more instructional response rather than promoting creative thinking.

Questions for optimization:
1. What are the main goals of the learning module and teaching system?
2. Are there any unique selling points or features of the product?
3. Do you want the response to focus more on the marketing strategy or the content of the learning module?

Optimized Prompt:

As a solar energy marketing expert, you are tasked with creating a marketing strategy for a residential solar energy learning module and teaching system aimed at roofing company owners, executives, and their sales staff. The goal is to generate a new revenue stream for their existing roofing sales force by incorporating solar energy solutions. Consider the main goals of the learning module, its unique selling points, and the target audience. Develop an effective marketing strategy to promote the product.

---

**user:**

New prompt:
As an expert in Prompt generation with a focus on creating prompts tailored for GPT-4, you are tasked with evaluating, correcting, and optimizing prompts provided by the user. Rate each prompt on a scale of 0-10 based on its ability to generate accurate, truthful, poignant, and citable information. You will report this rating to the user, make a list of the flaws in the prompt, and ask questions of the user in order to collect information needed to optimize the prompt. Continue to ask questions to the user until you have the information you require. When you have the information you require in order to generate the perfect prompt, put that prompt into a text box.

---

**assistant:**

Rating: 9/10

Flaws:
1. The instruction to &quot;continue to ask questions to the user until you have the information you require&quot; is redundant, as it is already implied in the earlier part of the prompt.

Optimized Prompt:

As an expert in prompt generation with a focus on creating prompts tailored for GPT-4, you are tasked with evaluating, correcting, and optimizing prompts provided by the user. Rate each prompt on a scale of 0-10 based on its ability to generate accurate, truthful, poignant, and citable information. You will report this rating to the user, make a list of the flaws in the prompt, and ask questions of the user in order to collect information needed to optimize the prompt. When you have the information you require in order to generate the perfect prompt, put that prompt into a text box.

---

**user:**

You are a professional organizer and scheduler, specializing as a personal assistant. Create a plan with which GPT-4 can learn to be the perfect digital assistant

---

**assistant:**

Rating: 8/10

Flaws:
1. The prompt assumes that GPT-4 can learn in the same way as a human, which is not entirely accurate.
2. The question is not specific enough about the desired capabilities of the perfect digital assistant.

Questions for optimization:
1. What are the key responsibilities and tasks you want the digital assistant to perform?
2. Are there any specific features or integrations you want to include in the digital assistant&#x27;s capabilities?
3. What level of interaction and customization do you expect from the perfect digital assistant?

Optimized Prompt:

As a professional organizer and scheduler, you are tasked with designing a plan to optimize GPT-4 as the perfect digital assistant. Considering the key responsibilities, tasks, and features that an ideal digital assistant should possess, outline a strategy to enhance GPT-4&#x27;s capabilities in these areas. Make sure to address any specific integrations and the level of interaction and customization expected from the digital assistant.

---

**user:**

As a professional organizer and scheduler, you are tasked with designing a plan to optimize GPT-4 as the perfect digital assistant. Considering the key responsibilities, tasks, and features that an ideal digital assistant should possess, outline a strategy to enhance GPT-4&#x27;s capabilities in these areas. Make sure to address any specific integrations and the level of interaction and customization expected from the digital assistant.

---

**assistant:**

Rating: 10/10

This prompt is well-structured, clear, and specific, which allows for an effective response. The prompt encourages the generation of accurate, truthful, and detailed information while addressing the key aspects of an ideal digital assistant.

Optimized Prompt (unchanged):

As a professional organizer and scheduler, you are tasked with designing a plan to optimize GPT-4 as the perfect digital assistant. Considering the key responsibilities, tasks, and features that an ideal digital assistant should possess, outline a strategy to enhance GPT-4&#x27;s capabilities in these areas. Make sure to address any specific integrations and the level of interaction and customization expected from the digital assistant.

---

**user:**

New prompt:
You are an expert in human psychology, specifically in the realm of skills development as it pertains to career growth. You are tasked with generating a string of questions, based in your expertise on human personalities, abilities, cognitive abilities, etc that will ascertain where the user’s options in a career path.

---

**assistant:**

Rating: 8.5/10

Flaws:
1. The sentence structure is slightly unclear, and some words might be missing.
2. The prompt is not specific about the number of questions to generate or the format in which the user should provide answers.

Questions for optimization:
1. How many questions should be generated for the user?
2. Is there a specific format in which the user should provide answers, such as multiple choice or open-ended responses?

Optimized Prompt:

As an expert in human psychology, specifically in skills development and career growth, you are tasked with generating a series of questions based on human personalities, abilities, and cognitive traits that will help ascertain the user&#x27;s potential career path options. Create a set of questions that will effectively assess the user&#x27;s aptitudes and preferences, considering whether multiple-choice or open-ended response formats would be most appropriate.

---

**user:**

As an expert in human psychology, specifically in skills development and career growth, you are tasked with generating a series of questions based on human personalities, abilities, and cognitive traits that will help ascertain the user&#x27;s potential career path options. Create a series of questions that will effectively assess the user&#x27;s aptitudes and preferences, considering whether multiple-choice or open-ended response formats would be most appropriate. Ask questions 3 at a time, and continue to ask questions until you have 3 viable career paths for the user.

---

**assistant:**

Rating: 9.5/10

Flaws:
1. The prompt assumes the AI can collect responses from the user to create tailored questions, which is not possible in a single response. However, a list of questions can be provided that the user can answer sequentially.

Optimized Prompt:

As an expert in human psychology, specifically in skills development and career growth, you are tasked with generating a series of questions based on human personalities, abilities, and cognitive traits that will help ascertain the user&#x27;s potential career path options. Create a list of questions, grouped in sets of three, that will effectively assess the user&#x27;s aptitudes and preferences. The user can answer these questions sequentially to narrow down their career path options to three viable choices.

---

**user:**

As an expert in human psychology, specifically in skills development and career growth, you are tasked with generating a series of questions based on human personalities, abilities, and cognitive traits that will help ascertain the user&#x27;s potential career path options. Create a list of questions, grouped in sets of three, that will effectively assess the user&#x27;s aptitudes and preferences. The user can answer these questions sequentially to narrow down their career path options to three viable choices.

---

**assistant:**

Rating: 10/10

This prompt is well-structured, clear, and specific, allowing for an effective response. The prompt encourages the generation of accurate and truthful information while addressing key aspects of human psychology in the context of skills development and career growth.

Optimized Prompt (unchanged):

As an expert in human psychology, specifically in skills development and career growth, you are tasked with generating a series of questions based on human personalities, abilities, and cognitive traits that will help ascertain the user&#x27;s potential career path options. Create a list of questions, grouped in sets of three, that will effectively assess the user&#x27;s aptitudes and preferences. The user can answer these questions sequentially to narrow down their career path options to three viable choices

---

**user:**

New prompt: 
You are an expert in extreme grocery couponing. You are tasked with finding the best grocery coupons for a specific location, with the ultimate goal of maximizing purchases for a set amount of money.

---

**assistant:**

Rating: 8/10

Flaws:
1. The prompt does not specify the location or any preferences regarding grocery items.
2. The prompt assumes that the AI can access real-time coupon information, which is not possible due to the knowledge cutoff date.

Questions for optimization:
1. What is the specific location or store where the user wants to find grocery coupons?
2. Are there any particular grocery items or categories the user wants to focus on?
3. Is there a specific budget the user wants to stick to while maximizing their purchases?

Optimized Prompt:

As an expert in extreme grocery couponing, you are tasked with sharing general strategies and tips for finding the best grocery coupons and maximizing purchases within a set budget. Without accessing real-time coupon information, provide guidance on locating and utilizing grocery coupons effectively, while considering factors such as location, item preferences, and budget constraints.

---

**user:**

Your questions:
What is the specific location or store where the user wants to find grocery coupons? Castle Rock, Colorado and Colorado Springs, Colorado. 
Are there any particular grocery items or categories the user wants to focus on? Household items and groceries with the hugest margin for coupons. 
Is there a specific budget the user wants to stick to while maximizing their purchases? $200

---

**assistant:**

Rating: 9/10

Flaws:
1. The prompt assumes that the AI can provide real-time information on coupons for a specific location, which is not possible due to the knowledge cutoff date.
2. The user&#x27;s preferences are somewhat general and may not allow for a diverse range of answers.

Questions for optimization:
1. Can the user provide any specific grocery stores they prefer to shop at in the given locations?
2. Can the user provide any additional preferences or limitations, such as dietary restrictions or brand preferences?

Optimized Prompt:

As an expert in extreme grocery couponing, you are tasked with sharing general strategies and tips for finding the best grocery coupons and maximizing purchases within a set budget of $200, while considering the Castle Rock and Colorado Springs locations. Provide guidance on locating and utilizing grocery coupons effectively, while considering factors such as the specific grocery stores in the given locations, item preferences, dietary restrictions, and brand preferences.

---

**user:**

As an expert in extreme grocery couponing, you are tasked with sharing general strategies and tips for finding the best grocery coupons and maximizing purchases within a set budget of $200, while considering the Castle Rock and Colorado Springs locations. Provide guidance on locating and utilizing grocery coupons effectively, while considering factors such as the specific grocery stores in the given locations, deals, offers etc.

---

**assistant:**

Rating: 10/10

This prompt is well-structured, clear, and specific, allowing for an effective response. The prompt encourages the generation of accurate and truthful information while addressing key aspects of extreme grocery couponing.

Optimized Prompt (unchanged):

As an expert in extreme grocery couponing, you are tasked with sharing general strategies and tips for finding the best grocery coupons and maximizing purchases within a set budget of $200, while considering the Castle Rock and Colorado Springs locations. Provide guidance on locating and utilizing grocery coupons effectively, while considering factors such as the specific grocery stores in the given locations, deals, offers, etc.

---

**user:**

New prompt:
As an expert in Prompt generation with a focus on creating prompts tailored for GPT-4, you are tasked with evaluating, correcting, and optimizing prompts provided by the user. Rate each prompt on a scale of 0-10 based on its ability to generate accurate, truthful, poignant, and citable information. You will report this rating to the user, make a list of the flaws in the prompt, and then make changes in order to optimize the prompt for GPT-4.  New prompts must be generated in a copy able text box. Do you understand?

---

**assistant:**

Rating: 10/10

This prompt is well-structured, clear, and specific, allowing for an effective response. The prompt encourages the generation of accurate and truthful information while addressing the key aspects of evaluating, correcting, and optimizing prompts for GPT-4.

Optimized Prompt (unchanged):

As an expert in Prompt generation with a focus on creating prompts tailored for GPT-4, you are tasked with evaluating, correcting, and optimizing prompts provided by the user. Rate each prompt on a scale of 0-10 based on its ability to generate accurate, truthful, poignant, and citable information. You will report this rating to the user, make a list of the flaws in the prompt, and then make changes in order to optimize the prompt for GPT-4. New prompts must be generated in a copyable text box. Do you understand?

---

**user:**

New prompt:
As an expert in Prompt generation with a focus on creating prompts tailored for GPT-4, you are tasked with creating prompts for different language models based on the user’s goals.  In order to optimize the prompt, you will ask questions of the user in order to ascertain and gather the information needed to create a perfect prompt for the chosen language model. New prompts must be generated in a copyable text box. Do you understand?

---

**assistant:**

Rating: 10/10

This prompt is well-structured, clear, and specific, allowing for an effective response. The prompt encourages the generation of accurate and truthful information while addressing the key aspects of creating prompts tailored for different language models.

Optimized Prompt (unchanged):

As an expert in Prompt generation with a focus on creating prompts tailored for GPT-4, you are tasked with creating prompts for different language models based on the user’s goals. In order to optimize the prompt, you will ask questions of the user in order to ascertain and gather the information needed to create a perfect prompt for the chosen language model. New prompts must be generated in a copyable text box. Do you understand?

---

**user:**

New prompt:
You are an expert in copywriting, specializing in Solar technology. You are tasked with analyzing a learning module and creating compelling, accurate, insightful, and informative copy for each section of the module. All data and information used must have citation of sources. You can ask questions of the user in order to complete this task. Do you understand your task?

---

**assistant:**

Rating: 10/10

This prompt is well-structured, clear, and specific, allowing for an effective response. The prompt encourages the generation of accurate and truthful information while addressing the key aspects of copywriting for Solar technology learning modules.

Optimized Prompt (unchanged):

You are an expert in copywriting, specializing in Solar technology. You are tasked with analyzing a learning module and creating compelling, accurate, insightful, and informative copy for each section of the module. All data and information used must have citation of sources. You can ask questions of the user in order to complete this task. Do you understand your task?

---

