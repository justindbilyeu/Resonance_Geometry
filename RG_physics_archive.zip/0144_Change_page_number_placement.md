# Change page number placement

- Conversation ID: 68824986-aef8-8323-8c93-1496f3d898b0
- Created: 2025-07-24T14:56:07.829629

---

**user:**

How do you change the placement of the page number in the footer of a Microsoft Word document?

---

**assistant:**

To change the placement of the page number in the footer of a Microsoft Word document, follow these steps:

---

### **Step 1: Open the Footer**
1. Double-click anywhere in the footer area (bottom of the page).  
   *Alternatively:* Go to **Insert &gt; Header &amp; Footer &gt; Footer &gt; Edit Footer**.

---

### **Step 2: Select the Page Number**
1. If you haven’t added page numbers yet:  
   - Go to **Insert &gt; Page Number &gt; Bottom of Page** and choose a style.
2. If page numbers are already present, click directly on the page number in the footer to select it.

---

### **Step 3: Change Alignment or Position**
You have two main options:
- **Quick Alignment:**  
  Use the alignment options on the **Home** tab (Left, Center, Right).
- **Custom Placement:**  
  Place your cursor next to the page number and use the **Tab key** to move it.  
  Alternatively, adjust its position using the **Ruler** (View &gt; Ruler) or by adding spaces.

---

### **Step 4: Fine-Tune Position**
For precise placement:
1. Right-click on the page number.
2. Choose **Paragraph**.
3. Adjust alignment, or use **Indentation** and **Tabs** for custom spacing.
4. You can also use **Insert &gt; Page Number &gt; Page Number (Format Page Numbers)** and reposition using alignment options there.

---

### **Step 5: Close the Footer**
When done, click **Close Header and Footer** in the top ribbon or double-click outside the footer area.

---

Would you like me to give you **3 quick layout templates** (e.g., left-aligned with a document title, center-aligned with a line, or right-aligned in the footer)?

---

**assistant:**

Quick steps (Word 2016/2019/2021/365 – Windows &amp; Mac)

1. **Open the footer**  
   Double-click in the footer area (or go **Insert ▸ Footer ▸ Edit Footer**).

2. **Select (or insert) the page number field**  
   If it isn’t there yet: **Insert ▸ Page Number ▸ Current Position** (or **Bottom of Page**) → pick a style.

3. **Change its horizontal position** – three easy ways  
   **A. One-click alignment:**  
   - With the cursor on the page number, use the **Home** tab’s **Left / Center / Right** alignment buttons.

   **B. Alignment Tab (best for headers/footers):**  
   - On the **Header &amp; Footer** tab, click **Insert Alignment Tab…**  
   - Choose **Left**, **Center**, or **Right**, and set **Relative to: Margin**.  
   - Click **OK**. (Now the number will “stick” to that side even if margins change.)

   **C. Tab stop method (manual):**  
   - Press **Ctrl+R** (Windows) / **Cmd+R** (Mac) to right-align, or set a right-aligned tab stop on the ruler and hit **Tab** before the page number.

4. **Adjust vertical placement (distance from bottom) if needed**  
   - **Header &amp; Footer** tab ▸ **Position** group ▸ **Footer from Bottom** (Windows)  
   - On Mac, use **Layout ▸ Margins ▸ Custom Margins… ▸ Layout ▸ Footer** distance.

5. **Close** the footer (press **Esc** or click **Close Header and Footer**).

---

**Extras you might want:**

- **Different first page (no number on title page):** **Header &amp; Footer** tab ▸ check **Different First Page**.  
- **Roman numerals vs. Arabic:** **Insert ▸ Page Number ▸ Format Page Numbers…** ▸ choose **Number format**.  
- **Restart numbering later in the doc:** Insert a **Section Break** (Layout ▸ Breaks), then **Format Page Numbers… ▸ Start at: 1**.

Want screenshots or a 15-second macro to flip all footers to right-aligned numbers? Happy to provide.

---

