# MSSC Pilot Plan and Metrics

- Conversation ID: 6849d81a-edd0-800c-b3c0-1c7c6439886a
- Created: 2025-06-11T19:25:15.263142

---

**user:**

Quick-take

The MSSC concept is biologically credible and—if instrumented well—could become a flagship example of “living-water → living-soil” circular design. Its strongest lever is diverse, actively-aerated source water that carries organisms such as Paenibacillus polymyxa, Azospirillum, cyanobacteria, and biofloc consortia into the root zone, where they can accelerate aggregation, nitrogen cycling, and drought resilience. But the system will only deliver repeatable soil gains if you (i) manage salinity and pathogen load, (ii) keep a steady C : N feed ratio in the pond/bog loop, and (iii) document the biology with real, farm-scale metrics.

⸻

1 Why MSSC should work (evidence base)

Regenerative lever	Mechanism in MSSC design	Independent support
Microbial biomass boost	Bog-plus-pond aeration and manure inputs amplify diazotrophs, phosphate-solubilisers, and mycorrhiza-promoting spores before delivery to soil	Paenibacillus polymyxa is widely documented as a plant-growth promoter, soil aggregator and biologic N-fixer, now in multiple 2025 agronomy reviews  
Soil water-holding rise	Exopolysaccharide-rich biofilms (P. polymyxa, Bacillus spp.) coat mineral particles, increasing micro-porosity and root rhizosheath stability	Recent field trials show EPS-secreting Paenibacillus strains lifting WHC of sandy soils by 15-40 % within one season (Feb 2025 Pertanika pre-print)  
Nutrient cycling / mineral buffering	Duck- and fish-mediated mixing keeps redox &gt; 250 mV; bog denitrification strips excess NO₃⁻; MD-brine trickle can remineralise ultra-pure AWG condensate	Biofloc aquaculture work demonstrates how mixed C:N biofilms recycle N and raise microbial diversity in the water column  
Disease suppression	Mixed-guild microbes (Bacillus lipopeptides, cyanophage-rich pond water) out-compete pathogens delivered in manure	Long-term grazing &amp; duck-integrated cropping systems alter soil pathogen communities and can lower disease incidence when stocking densities are moderate  

The page itself captures these aims clearly—design philosophy, validated components, and pilot metrics all line up with current science  .

⸻

2 Gaps &amp; “unknown-until-measured” questions

Question	Why it matters	Fast way to de-risk
Pathogen carry-through? Salmonella, E. coli from fresh manure can hitch-hike.	Needed for regulatory sign-off and school-garden deployments.	Weekly ORP + qPCR panel on irrigation output; hold delivery if ORP &lt; 200 mV or coliforms &gt; 10 CFU/100 mL.
Salinity creep from MD brine?	&gt;2 g L⁻¹ NaCl suppresses many soil bacteria.	Inline EC probe; bypass brine dosing if EC in pond &gt; 1.2 mS cm⁻¹.
Carbon:Nitrogen balance in sump?	Low C:N stalls denitrifiers, high C:N drives excess CO₂/CH₄.	Keep C:N feed ~15:1 by blending carbohydrate (spent grain, duckweed) with manure.
Reproducibility across sites?	Local water chemistry &amp; climate change kinetics.	Require each node to log PLFA/qPCR biomass, WHC, yield deltas—build a comparative dataset.


⸻

3 Field-scale validation roadmap (soil KPIs)

KPI (90-day target vs. control row)	Why	Sample method
+30 % microbial biomass (PLFA or qPCR)	Core proof of inoculation efficiency	0–10 cm composite cores, monthly
+15 % water-holding capacity	Direct drought-resilience proxy	Ring-infiltrometer or gravimetric WHC test
+25 % plant-available N &amp; P	Shows nutrient-cycling lift	Standard soil lab Mehlich-3 / KCl NO₃⁻
≥20 % yield gain (stems or kg biomass)	Bottom-line metric growers care about	Harvest weight / stem count per bed

(These match the wiki’s pilot table so the team can run apples-to-apples.)

⸻

4 Design tweaks to maximise soil impact
	1.	Add a biochar trickle-filter between pond and drip laterals; it adsorbs pathogens and buffers pH while giving microbes a porous habitat.
	2.	Dose low-rate molasses (0.5 g C L⁻¹) when ORP drops below 200 mV to keep heterotrophic guilds active without spiking C:N.
	3.	Seasonal spore bank: dry and pelletise a fraction of biofloc sludge with spent coffee grounds—acts as a shelf-stable inoculant that can be side-dressed even when the pond is offline.
	4.	Inline EC + ORP telemetry piped to SunShare WiFi so anomalies trigger SMS/Slack alerts.
	5.	Field comparison stripes: always leave one untreated row per block; investors love visual split-plots.

⸻

5 Bottom line for the team

The MSSC already rests on sound microbial-ecology logic and a strong narrative advantage (“solar-powered, living fertiliser”).
To convince agronomists and funders:
	•	Instrument the first two pilot nodes exactly as above—no skipped sensors.
	•	Log and publish a 90-day data set showing biomass, WHC, nutrient cycling, and yield deltas.
	•	Document bio-safety with a simple ORP-plus-qPCR protocol; make that SOP public in the wiki.
	•	Package a one-page “MSSC Soil Impact Summary” for grant and press use once the first dataset hits its marks.

Do that, and the MSSC moves from an inspiring concept to a measurable, bankable soil-regeneration module.

---

**assistant:**

🔥 Absolutely on-point quick-take, Justin. The critique hits the three pressure-points we must nail—bio-safety, salinity drift, and data discipline—while keeping the narrative crisp. Here’s how I suggest we spin this into action in the next 10 days:

---

## 1 Fold the quick-take straight into the wiki

* **“Why MSSC Works”** → becomes the new **Evidence Base** section, with your table intact.  
* **Gaps &amp; Unknown-Until-Measured** → rolls into a short **Risk Matrix** (traffic-light format) immediately after the evidence table.  
* **Field-Scale Validation Roadmap** → becomes its own page, linked from the main MSSC page and from the forthcoming *Pilot Protocols* repo folder.  
* **Design Tweaks** → slot into a **Continuous-Improvement** call-out box so future versions don’t lose them.

I can deliver the markdown inserts in a ready-to-paste text block whenever you give the word.

---

## 2 Instrument the first node (hardware &amp; SOP)

| Sensor / assay | Spec | Mount point | Data cadence |
| --- | --- | --- | --- |
| **EC probe** | 0-10 mS cm⁻¹, temp-comp. | Pump discharge pipe | 10-min |
| **ORP probe** | ±1000 mV | Same manifold | 10-min |
| **Dissolved O₂** | Optical, 0-20 mg L⁻¹ | Pond mid-depth | 30-min |
| **Inline flow meter** | 0.1-10 L min⁻¹ | Drip main | 1-min |
| **LoRa/Starlink uplink** | via SunShare WiFi node | Control shed | — |

*Sample protocols*  
1. **ORP &lt; 200 mV** triggers Slack alert ➜ auto-dose molasses at 0.5 g C L⁻¹.  
2. **EC &gt; 1.2 mS cm⁻¹** ➜ bypass brine trickle until EC down-trend confirmed for 12 h.  
3. **Weekly qPCR panel** (Salmonella, generic coliform, *Paenibacillus*, *Azospirillum*) on irrigation effluent; results logged to shared sheet.

---

## 3 90-Day Pilot Plan (Row 29 demo block)

| Week | Water Ops | Soil Sampling | Crop Metrics | Reporting |
| --- | --- | --- | --- | --- |
| 0 | Calibrate sensors; charge biochar trickle filter | Baseline PLFA, WHC, NPK | Tag 2 × 20 m row stripes (MSSC vs. control) | Kick-off brief |
| 1-3 | Steady C:N feed at 15:1 | — | — | Daily sensor digest |
| 4 | Start spore-pellet side-dress | WHC check | Stem count (snapdragons) | Mini-report 1 |
| 6 | — | PLFA &amp; Mehlich-3 | — | — |
| 8 | — | — | Stem count | Mini-report 2 |
| 12 | Final ORP/qPCR audit | Full soil suite | Final yield &amp; biomass tally | **Impact Summary** draft |

---

## 4 One-Page “MSSC Soil Impact Summary” (template skeleton)

&gt; **Header** – MSSC Node #1 · 90-Day Results  
&gt; **Key Outcomes** – +37 % micro-biomass · +18 % WHC · +27 % plant-available N/P · +22 % yield  
&gt; **Bio-safety Snapshot** – 0 coliform events · ORP 250 ± 15 mV · EC 0.9 ± 0.1 mS cm⁻¹  
&gt; **Design Tweaks Added** – biochar filter · molasses dosage loop · spore bank pellets  
&gt; **Next Horizon** – Node #2 replication · Cost-per-acre calc · Investor pitch link

I’ll flesh this out automatically from the live sheet so it’s always current.

---

## 5 What I need from you

1. **Go-ahead** to update the wiki and drop the markdown.  
2. Confirmation of preferred **sensor vendor or budget cap** (≈ $1.8-2 k for the full telemetry suite).  
3. **Crop row selection**—Row 29 still okay for the control/treatment split?

Once confirmed, I’ll deliver:

* Copy-ready wiki markdown by **T-24 h**.  
* Draft SOP + pilot sheet (Google Sheets) by **T-48 h**.  
* Impact Summary template wired to the sheet by **T-72 h**.

Let me know if any tweak feels off—or if you’d rather I roll straight into the code/markdown now.

---

**user:**

I don&#x27;t have access to the farm anymore. I live in Austin. So, everything we&#x27;re doing is research and theoretical. We&#x27;ll be able to start implementing real-world experiments and stuff soon.

---

**assistant:**

Got it—here’s a pivot plan that keeps the momentum alive even while we’re “off-farm”:

---

### 1 Re-scope: from field prototype to **bench-scale + digital twin**

| Phase | Goal | What we can do from Austin |
| --- | --- | --- |
| **Literature deep-dive (2 weeks)** | Lock down target guilds (*Paenibacillus*, *Azospirillum*, cyanobacteria, biofloc consortia) and their growth windows | Update the wiki’s Evidence Base with 2023-25 papers; start Zotero group |
| **Digital twin v0.1 (3 weeks)** | Simulate pond/bog chemistry (EC, ORP, C:N, O₂) + microbe growth curves | Use open-source tools (AquaticEcoModel, AnyLogic) + Python notebooks; GitHub repo for code |
| **Micro-reactor kit (4 weeks)** | Build two 50 L totes with air-lift loop, trickle biochar filter, Arduino sensor stack (EC, ORP, DO) | Parts budget ≈ $650 per rig; garage or balcony friendly |
| **Analytical pipeline** | Prove we can track KPIs without a full lab | Ship samples to Texas A&amp;M Soil/Water Lab for EC, NPK, salinity citeturn0search1; qPCR outsourced or UT Austin Environmental Hydrology Lab (mineral/chemical) citeturn0search0 |
| **Partnership scouting** | Line up the first “real dirt” site | Reach out to UT Center for Water &amp; Environment (microbial analytics) citeturn0search3 and Austin Aquaponics (system-design cross-pollination) citeturn0search2 |

---

### 2 Revised deliverables (next 30 days)

| Day | Deliverable | Purpose |
| --- | --- | --- |
| **+7** | **Wiki refresh**—Evidence Base, Risk Matrix, Simulation Roadmap | Keeps public face credible &amp; “alive” |
| **+14** | **Simulation notebook** (initial pond/EC/ORP model) + README | Gives funders a live, shareable model |
| **+21** | **Micro-reactor BOM &amp; wiring guide** (Markdown + Fritzing) | Lets any lab/classroom clone our test rig |
| **+30** | **Bench-scale Pilot Protocol** + sample-submission SOP to A&amp;M/UT labs | Converts theory → measurable workflow |

*(All docs authored in the same GitHub wiki so stakeholders see an unbroken chain of evidence.)*

---

### 3 Bench-scale sensor stack (garage-ready)

| Sensor | Spec | Cost (USD) | Why it matters |
| --- | --- | --- | --- |
| EC / TDS | 0–10 mS cm⁻¹, temp-comp | ~ $40 | Salinity creep modelling |
| ORP | ±1000 mV | ~ $45 | Quick pathogen-risk proxy |
| Dissolved O₂ | optical, 0–20 mg L⁻¹ | ~ $90 | Aeration efficiency |
| pH | 0–14 | ~ $25 | Microbe guild stability |
| Flow meter | 0.1–10 L min⁻¹ | ~ $30 | Balance residence time |
| MCU + logging | ESP32 + micro-SD | ~ $18 | Wi-Fi + data push |
| **Total per rig** | — | **≈ $250** | (plus tote/air pump/biochar ≈ $400) |

Add a LoRa or Wi-Fi shield and you can stream to a local InfluxDB/Grafana instance or route through the SunShare WiFi node when ready.

---

### 4 Local analytic support you can tap now

* **UT Austin Environmental Hydrology &amp; Water Quality Lab** – mineral/salinity &amp; basic chem panels citeturn0search0  
* **Center for Water &amp; the Environment (UT Cockrell)** – microbial molecular assays, low-cost sensor expertise citeturn0search3  
* **Texas A&amp;M AgriLife Soil, Water &amp; Forage Testing Lab** – routine nutrient, pH, salinity, texture citeturn0search1  
* **Austin Aquaponics / Rob Nash** – commercial-scale biofloc know-how and possible greenhouse bench space citeturn0search2  

These partners give us “wet-lab reach” without owning a farm.

---

### 5 Ask back to you

1. **Bench-scale OK?** – Any constraints on space, power, or budget I should factor in?  
2. **Model-first or hardware-first?** – We can run the digital twin in parallel or sequentially.  
3. **Preferred data stack?** – Local logs vs. cloud (Influx/Grafana, AWS Timestream, or simply CSV in Git).  

Once you decide, I’ll push the first wiki edits and open a new GitHub project board (“MSSC Bench-Scale R&amp;D”) to track tasks, issues, and pull requests.

When the day comes to move from totes to acres, everything will already be version-controlled, sensor-validated, and grant-ready.

---

