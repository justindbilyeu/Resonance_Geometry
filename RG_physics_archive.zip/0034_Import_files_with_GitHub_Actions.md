# Import files with GitHub Actions

- Conversation ID: 68d166e2-1eb4-8326-9ff1-5e0a91c1ee04
- Created: 2025-09-22T15:10:27.116355

---

**user:**

I&#x27;ve started a new GitHub repository, and I&#x27;m wondering how I can import files from other repositories into the new repository. And is that something that I can set up as an action in the new repository?

---

**assistant:**

You’ve got a few good options, depending on whether you want a one-time import or an automatic sync whenever the source repos change.

## Quick one-time import
If you just need to copy files once:

```bash
# In your new repo
git remote add other https://github.com/OWNER/SOURCE_REPO.git
git fetch other

# Option A: copy entire repo snapshot into a subfolder
git checkout other/main -- .        # copies files into your working tree
# (or if you want a subfolder)
mkdir vendor &amp;&amp; git checkout other/main -- . &amp;&amp; git add -A &amp;&amp; git mv * vendor/ 2&gt;/dev/null || true

# Commit
git add -A
git commit -m &quot;Import files from OWNER/SOURCE_REPO&quot;
git push
```

If you only want a subdirectory from the source repo, use sparse checkout:
```bash
git sparse-checkout init --cone
git sparse-checkout set path/in/source
git checkout other/main
# copy files you need, commit, push
```

---

## Keep files synced automatically (GitHub Actions)
Yes—you can set this up as a workflow in your new repo. The workflow will periodically (or on demand) check out the source repo, copy selected files, and commit changes if anything changed.

### Option A: Simple sync using `actions/checkout`
This is great for pulling a few files or a folder.

**.github/workflows/sync-from-external.yml**
```yaml
name: Sync files from external repo

on:
  workflow_dispatch:
    inputs:
      ref:
        description: &quot;Source branch or tag to sync from&quot;
        required: false
        default: &quot;main&quot;
  schedule:
    - cron: &quot;17 3 * * *&quot;  # daily at 03:17 UTC

permissions:
  contents: write  # needed to push commits

jobs:
  sync:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout destination repo (this repo)
        uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Checkout source repo
        uses: actions/checkout@v4
        with:
          repository: OWNER/SOURCE_REPO
          ref: ${{ github.event.inputs.ref || &#x27;main&#x27; }}
          path: source
          # For private source repos, create a PAT with &#x27;repo&#x27; scope and add as secret: SOURCE_REPO_TOKEN
          token: ${{ secrets.SOURCE_REPO_TOKEN || github.token }}

      # (Optional) sparse checkout only a subfolder of the source repo
      # - name: Sparse-checkout subset
      #   run: |
      #     cd source
      #     git sparse-checkout init --cone
      #     git sparse-checkout set path/in/source

      - name: Copy files
        run: |
          # customize which files/folders to sync
          mkdir -p imported
          rsync -av --delete \
            source/path/you/want/ \
            imported/

      - name: Commit changes (if any)
        run: |
          set -e
          if [ -n &quot;$(git status --porcelain)&quot; ]; then
            git config user.name &quot;github-actions[bot]&quot;
            git config user.email &quot;41898282+github-actions[bot]@users.noreply.github.com&quot;
            git add -A
            git commit -m &quot;Sync: update imported files from OWNER/SOURCE_REPO@${{ github.event.inputs.ref || &#x27;main&#x27; }}&quot;
            git push
          else
            echo &quot;No changes to commit.&quot;
          fi
```

**Notes:**
- If the source repo is **private**, create a Personal Access Token (classic) with `repo` scope, store it as `SOURCE_REPO_TOKEN` in the **destination** repo’s secrets, and the workflow will use it to read the source repo.
- `GITHUB_TOKEN` (the default `github.token`) is enough to push back to the current repo.

### Option B: Use a dedicated sync action
If you’re syncing the *same set of files across multiple repos*, something like `repo-file-sync-action` (third-party) is handy. It lets you define a mapping of source → target paths. The above “plain rsync” approach is more transparent and requires no external actions.

---

## Alternatives (choose based on how you want updates to flow)

### 1) Git submodules
- **What it is:** Your repo references another repo at a specific commit.
- **Pros:** Lightweight; you can “point” at upstream updates by bumping the submodule ref in a commit.
- **Cons:** Consumers must remember to init/update submodules; files aren’t directly in your tree unless you vendor them during build.

**Commands:**
```bash
git submodule add https://github.com/OWNER/SOURCE_REPO.git vendor/source
git commit -m &quot;Add submodule&quot;
# To update later:
cd vendor/source &amp;&amp; git fetch &amp;&amp; git checkout main &amp;&amp; git pull &amp;&amp; cd -
git add vendor/source
git commit -m &quot;Bump submodule&quot;
```

### 2) Git subtree (vendor with ability to pull updates)
- **What it is:** Bring in another repo’s contents under a subdirectory; no submodule management for users.
- **Pros:** Files live in your tree; you can pull updates later.
- **Cons:** History can get bigger; merging can be a bit noisier.

**Commands:**
```bash
git remote add source https://github.com/OWNER/SOURCE_REPO.git
git subtree add --prefix=vendor/source source main --squash
# To update:
git fetch source
git subtree pull --prefix=vendor/source source main --squash
```

### 3) Build-time fetch
Fetch files during your build/test workflow without committing them (useful for templates or generated artifacts). Similar to the Action above, but you skip committing the files.

---

## Good practices &amp; gotchas
- **Licensing:** Ensure the source repo’s license permits copying; preserve license headers if required.
- **Pinning:** For reproducibility, pin to a specific commit SHA (e.g., `ref: 1234abcd…`) or tag in your workflow; update intentionally.
- **Security:** Use least-privilege tokens. For private sources, use a PAT with `repo:read`. Don’t check secrets into the repo.
- **Conflict strategy:** If you edit imported files locally, they’ll conflict with upstream. Prefer editing upstream and letting the sync pull changes down—or keep a clear “local overrides” layer.
- **Monorepo subfolders:** Use sparse checkout to pull just the subdirectory you need to reduce time and noise.

---

If you tell me:
- the source repo(s),
- which files or folders you need,
- whether the sources are public or private,

I can tailor the workflow YAML (including sparse-checkout and path mappings) exactly to your setup.

---

**user:**

I just want to pull files from the other repositories one time just like a mass download

---

**assistant:**

Got it — for a one-time, “mass download” from other GitHub repos, the simplest route is to script it locally (no Action needed). Below are copy-pasteable scripts that clone shallow snapshots, copy the files into your new repo, and leave out the source history.

---

# Option 1: Bash (macOS/Linux/WSL)

**What it does**
- Shallow-clones each repo at a branch/tag/commit
- Copies files into `imports/&lt;owner-repo&gt;/`
- Deletes the temporary clones
- Works with public repos out of the box; works with private if you set `GH_TOKEN`

```bash
#!/usr/bin/env bash
set -euo pipefail

# Optional: for private repos, set a token with &#x27;repo&#x27; scope:
# export GH_TOKEN=ghp_xxxxx

DEST=&quot;imports&quot;
mkdir -p &quot;$DEST&quot;

# List the repos you want to pull.
# Format: &quot;OWNER/REPO@REF&quot; (REF can be branch, tag, or commit; defaults to &#x27;main&#x27; if omitted)
REPOS=(
  &quot;owner1/repo1@main&quot;
  &quot;owner2/repo2@v1.2.3&quot;
  &quot;owner3/repo3@abcdef1234567890&quot;  # specific commit
  # &quot;owner4/repo4&quot;                  # defaults to @main
)

for item in &quot;${REPOS[@]}&quot;; do
  repo=&quot;${item%@*}&quot;
  ref=&quot;${item#*@}&quot;
  if [[ &quot;$repo&quot; == &quot;$ref&quot; ]]; then ref=&quot;main&quot;; fi

  safe=&quot;${repo//\//-}&quot;
  tmp=&quot;tmp-$safe&quot;
  url=&quot;https://github.com/$repo.git&quot;

  echo &quot;==&gt; Fetching $repo@$ref&quot;

  if [[ -n &quot;${GH_TOKEN:-}&quot; ]]; then
    # Auth header avoids putting the token in the URL or shell history
    git -c http.extraheader=&quot;Authorization: Bearer $GH_TOKEN&quot; \
      clone --depth 1 --branch &quot;$ref&quot; &quot;$url&quot; &quot;$tmp&quot;
  else
    git clone --depth 1 --branch &quot;$ref&quot; &quot;$url&quot; &quot;$tmp&quot;
  fi

  # If you only want certain paths, list them here; otherwise copy everything.
  ONLY_PATHS=()  # e.g. (&quot;src&quot; &quot;README.md&quot;)

  mkdir -p &quot;$DEST/$safe&quot;
  if (( ${#ONLY_PATHS[@]} )); then
    rsync -a --delete $(printf &quot;%q &quot; &quot;${ONLY_PATHS[@]/#/$tmp/}&quot;) &quot;$DEST/$safe&quot;/
  else
    rm -rf &quot;$tmp/.git&quot;
    rsync -a --delete &quot;$tmp&quot;/ &quot;$DEST/$safe&quot;/
  fi

  rm -rf &quot;$tmp&quot;
done

echo
echo &quot;Done. Imported content is in &#x27;$DEST/&#x27;. Now commit it to your new repo:&quot;
echo &quot;  git add $DEST &amp;&amp; git commit -m &#x27;One-time import from external repos&#x27; &amp;&amp; git push&quot;
```

### Notes / tweaks
- **Private repos**: `export GH_TOKEN=&lt;token-with-repo-scope&gt;` before running.
- **Only certain folders/files**: set `ONLY_PATHS=(&quot;path/in/repo&quot; &quot;another/file.txt&quot;)` inside the loop for each repo.
- **LFS files**: if any source uses Git LFS, run `git lfs install` once and add `git -C &quot;$tmp&quot; lfs pull` before copying.

---

# Option 2: PowerShell (Windows)

```powershell
# Optional: for private repos, set $env:GH_TOKEN with a PAT that has &#x27;repo&#x27; scope
# $env:GH_TOKEN = &quot;ghp_xxxxx&quot;

$dest = &quot;imports&quot;
New-Item -ItemType Directory -Force -Path $dest | Out-Null

# Define repos: @{ repo=&quot;OWNER/REPO&quot;; ref=&quot;main&quot;; paths=@() }
$repos = @(
  @{ repo = &quot;owner1/repo1&quot;; ref = &quot;main&quot;;      paths = @() }            # copy all
  @{ repo = &quot;owner2/repo2&quot;; ref = &quot;v1.2.3&quot;;    paths = @(&quot;src&quot;,&quot;README.md&quot;) }  # only some paths
  @{ repo = &quot;owner3/repo3&quot;; ref = &quot;abcdef1234567890&quot;; paths = @() }     # specific commit
)

foreach ($r in $repos) {
  $safe = $r.repo -replace &quot;/&quot;, &quot;-&quot;
  $tmp = &quot;tmp-$safe&quot;
  $url = &quot;https://github.com/$($r.repo).git&quot;

  Write-Host &quot;==&gt; Fetching $($r.repo)@$($r.ref)&quot;

  if ($env:GH_TOKEN) {
    git -c &quot;http.extraheader=Authorization: Bearer $($env:GH_TOKEN)&quot; clone --depth 1 --branch $r.ref $url $tmp
  } else {
    git clone --depth 1 --branch $r.ref $url $tmp
  }

  New-Item -ItemType Directory -Force -Path &quot;$dest\$safe&quot; | Out-Null

  if ($r.paths.Count -gt 0) {
    foreach ($p in $r.paths) {
      Copy-Item -Path (Join-Path $tmp $p) -Destination &quot;$dest\$safe&quot; -Recurse -Force
    }
  } else {
    Remove-Item &quot;$tmp\.git&quot; -Recurse -Force -ErrorAction SilentlyContinue
    Copy-Item -Path &quot;$tmp\*&quot; -Destination &quot;$dest\$safe&quot; -Recurse -Force
  }

  Remove-Item $tmp -Recurse -Force
}

Write-Host &quot;`nDone. Imported content is in &#x27;$dest\&#x27;. Commit it to your new repo:&quot;
Write-Host &quot;  git add $dest; git commit -m &#x27;One-time import from external repos&#x27;; git push&quot;
```

---

## Extra: one-time import of a subfolder from giant monorepos
If you only need a subdirectory and want to avoid cloning everything:

```bash
# One repo at a time
git clone --depth 1 --filter=blob:none --sparse https://github.com/OWNER/REPO.git tmp
git -C tmp sparse-checkout set path/you/need another/path
rsync -a tmp/ imports/OWNER-REPO/
rm -rf tmp
```

---

## After the import
From the root of your new repository:

```bash
git add imports
git commit -m &quot;One-time import from external repositories&quot;
git push
```

---

If you want, paste a quick list of the repos/branches/tags you’re pulling and (optionally) the subpaths you care about, and I’ll pre-fill the script for you.

---

**user:**

Ok the new repository is:

https://github.com/justindbilyeu/eMSSC-squared

We want to download pertinent files from the following repositories:

https://github.com/justindbilyeu/SunShare-TriSource

https://github.com/justindbilyeu/SunShare-Connect-Initiative-

https://github.com/justindbilyeu/eMSSC2

---

**user:**

Ok the new repository is:

https://github.com/justindbilyeu/eMSSC-squared

We want to download pertinent files from the following repositories:

https://github.com/justindbilyeu/SunShare-TriSource

https://github.com/justindbilyeu/SunShare-Connect-Initiative-

https://github.com/justindbilyeu/eMSSC2


We are doing this work remote..do not have access to a desktop computer

---

**assistant:**

Perfect—since you’re fully remote and just want a **one-time mass download** into your new repo, do it entirely on GitHub with a single, on-demand workflow. No desktop needed.

## What this will do
- Clone each source repo (shallow) on a runner
- Copy the files into your new repo under `imports/&lt;owner-repo&gt;/`
- Commit &amp; push the imported files back to `justindbilyeu/eMSSC-squared`
- You can delete/disable the workflow afterward

---

## 1) Add this workflow to `eMSSC-squared`
In the GitHub web UI for your repo:

**Actions → New workflow → set up a workflow yourself** (or add a new file) named  
`.github/workflows/one-time-import.yml`, and paste:

```yaml
name: One-time import from external repositories

on:
  workflow_dispatch: {}  # run manually from the Actions tab

permissions:
  contents: write  # needed to push back to this repo

jobs:
  import:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout destination repo (this repo)
        uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: One-time import
        env:
          # If any source repos are PRIVATE, create a PAT with &#x27;repo&#x27; scope,
          # add it as a secret in this repo named SOURCE_REPO_TOKEN,
          # and it will be used automatically. Public repos work without it.
          GH_READ_TOKEN: ${{ secrets.SOURCE_REPO_TOKEN }}
        shell: bash
        run: |
          set -euo pipefail

          REPOS=(
            &quot;justindbilyeu/SunShare-TriSource&quot;
            &quot;justindbilyeu/SunShare-Connect-Initiative-&quot;
            &quot;justindbilyeu/eMSSC2&quot;
          )

          mkdir -p imports

          for repo in &quot;${REPOS[@]}&quot;; do
            safe=&quot;${repo//\//-}&quot;                  # e.g., justindbilyeu-SunShare-TriSource
            tmp=&quot;$RUNNER_TEMP/tmp-$safe&quot;
            url=&quot;https://github.com/$repo.git&quot;

            echo &quot;==&gt; Cloning $repo (default branch, shallow)&quot;
            if [[ -n &quot;${GH_READ_TOKEN:-}&quot; ]]; then
              git -c http.extraheader=&quot;Authorization: Bearer $GH_READ_TOKEN&quot; clone --depth 1 &quot;$url&quot; &quot;$tmp&quot;
            else
              git clone --depth 1 &quot;$url&quot; &quot;$tmp&quot;
            fi

            # If repo uses Git LFS, fetch large files (safe to run even if not using LFS)
            if command -v git-lfs &gt;/dev/null 2&gt;&amp;1; then
              git lfs install --local || true
              git -C &quot;$tmp&quot; lfs pull || true
            fi

            dest=&quot;imports/$safe&quot;
            echo &quot;==&gt; Copying files to $dest/&quot;
            rm -rf &quot;$dest&quot;
            mkdir -p &quot;$dest&quot;
            rm -rf &quot;$tmp/.git&quot;

            # Copy including dotfiles
            shopt -s dotglob
            cp -a &quot;$tmp&quot;/* &quot;$dest&quot;/ || true
            shopt -u dotglob

            rm -rf &quot;$tmp&quot;
          done

      - name: Commit &amp; push (if any changes)
        shell: bash
        run: |
          set -e
          if [ -n &quot;$(git status --porcelain)&quot; ]; then
            git config user.name &quot;github-actions[bot]&quot;
            git config user.email &quot;41898282+github-actions[bot]@users.noreply.github.com&quot;
            git add -A
            git commit -m &quot;One-time import: SunShare-TriSource, SunShare-Connect-Initiative-, eMSSC2&quot;
            git push
            echo &quot;Changes committed and pushed.&quot;
          else
            echo &quot;No changes to commit.&quot;
          fi

      - name: Summary
        run: |
          {
            echo &quot;## Imported repositories&quot;
            echo &quot;- justindbilyeu/SunShare-TriSource → \`imports/justindbilyeu-SunShare-TriSource/\`&quot;
            echo &quot;- justindbilyeu/SunShare-Connect-Initiative- → \`imports/justindbilyeu-SunShare-Connect-Initiative-/\`&quot;
            echo &quot;- justindbilyeu/eMSSC2 → \`imports/justindbilyeu-eMSSC2/\`&quot;
            echo
            echo &quot;_You can delete or disable this workflow after the import._&quot;
          } &gt;&gt; &quot;$GITHUB_STEP_SUMMARY&quot;
```

### If any source repo is **private**
1. Create a Personal Access Token (classic) with **repo** scope.
2. In `eMSSC-squared` → **Settings → Secrets and variables → Actions → New repository secret**  
   Name: `SOURCE_REPO_TOKEN`, Value: your token.

Public repos require no token.

---

## 2) Run it
Go to **Actions → One-time import from external repositories → Run workflow → Run**.  
After it finishes, the files will be in:
- `imports/justindbilyeu-SunShare-TriSource/`
- `imports/justindbilyeu-SunShare-Connect-Initiative-/`
- `imports/justindbilyeu-eMSSC2/`

---

## Optional: only import certain folders/files
If you don’t want EVERYTHING, you can filter per repo inside the script. Replace the copy section with e.g.:

```bash
# Example: only pull specific paths per repo
case &quot;$repo&quot; in
  &quot;justindbilyeu/SunShare-TriSource&quot;)
    INCLUDE=( &quot;src&quot; &quot;README.md&quot; )
    ;;
  &quot;justindbilyeu/SunShare-Connect-Initiative-&quot;)
    INCLUDE=( &quot;docs&quot; &quot;config/*.json&quot; )
    ;;
  &quot;justindbilyeu/eMSSC2&quot;)
    INCLUDE=( &quot;*&quot; )  # everything
    ;;
esac

rm -rf &quot;$dest&quot; &amp;&amp; mkdir -p &quot;$dest&quot;
for p in &quot;${INCLUDE[@]}&quot;; do
  shopt -s dotglob extglob nullglob
  cp -a &quot;$tmp&quot;/$p &quot;$dest&quot;/ 2&gt;/dev/null || true
  shopt -u dotglob extglob nullglob
done
```

---

If you want me to pre-fill that INCLUDE list with specific paths, say the folders/files you consider “pertinent” for each repo and I’ll drop in a ready-to-paste version.

---

**user:**

Let&#x27;s try this. Give me a workflow that just pulls all of the docs from one repository. And then we&#x27;ll go on to the next.

---

**assistant:**

Great—here’s a single **on-demand** workflow that copies the `docs/` folder from **one** GitHub repo into your new repo (no desktop needed). You choose which repo when you run it.

Add this file to `eMSSC-squared` as `.github/workflows/import-docs.yml`:

```yaml
name: One-time import docs from another repo

on:
  workflow_dispatch:
    inputs:
      source_repo:
        description: &quot;owner/repo to import from (e.g., justindbilyeu/SunShare-TriSource)&quot;
        required: true
        default: &quot;justindbilyeu/SunShare-TriSource&quot;
      ref:
        description: &quot;Branch, tag, or commit (leave blank for default branch)&quot;
        required: false
        default: &quot;&quot;
      source_docs_path:
        description: &quot;Path to docs folder in source repo&quot;
        required: false
        default: &quot;docs&quot;
      dest_subdir:
        description: &quot;Destination folder in this repo&quot;
        required: false
        default: &quot;imports/docs&quot;

permissions:
  contents: write

jobs:
  import-docs:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout destination repo (this repo)
        uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Clone source repo
        env:
          GH_READ_TOKEN: ${{ secrets.SOURCE_REPO_TOKEN }}  # Only needed if the source repo is private
          SRC_REPO: ${{ inputs.source_repo }}
          REF: ${{ inputs.ref }}
          SRC_PATH: ${{ inputs.source_docs_path }}
          DEST_ROOT: ${{ inputs.dest_subdir }}
        shell: bash
        run: |
          set -euo pipefail

          SAFE=&quot;${SRC_REPO//\//-}&quot;
          TMP=&quot;$RUNNER_TEMP/src-$SAFE&quot;
          URL=&quot;https://github.com/$SRC_REPO.git&quot;

          echo &quot;==&gt; Cloning $SRC_REPO ${REF:+@ $REF}&quot;
          if [[ -n &quot;${GH_READ_TOKEN:-}&quot; ]]; then
            if [[ -n &quot;$REF&quot; ]]; then
              git -c http.extraheader=&quot;Authorization: Bearer $GH_READ_TOKEN&quot; clone --depth 1 --branch &quot;$REF&quot; &quot;$URL&quot; &quot;$TMP&quot; || {
                echo &quot;::warning title=Clone by branch failed::Falling back to fetching specific ref/commit&quot;
                git -c http.extraheader=&quot;Authorization: Bearer $GH_READ_TOKEN&quot; clone --depth 1 &quot;$URL&quot; &quot;$TMP&quot;
                git -C &quot;$TMP&quot; fetch --depth 1 origin &quot;$REF&quot;:&quot;tmpref&quot;
                git -C &quot;$TMP&quot; checkout --detach &quot;tmpref&quot;
              }
            else
              git -c http.extraheader=&quot;Authorization: Bearer $GH_READ_TOKEN&quot; clone --depth 1 &quot;$URL&quot; &quot;$TMP&quot;
            fi
          else
            if [[ -n &quot;$REF&quot; ]]; then
              git clone --depth 1 --branch &quot;$REF&quot; &quot;$URL&quot; &quot;$TMP&quot; || {
                echo &quot;::warning title=Clone by branch failed::Falling back to fetching specific ref/commit&quot;
                git clone --depth 1 &quot;$URL&quot; &quot;$TMP&quot;
                git -C &quot;$TMP&quot; fetch --depth 1 origin &quot;$REF&quot;:&quot;tmpref&quot;
                git -C &quot;$TMP&quot; checkout --detach &quot;tmpref&quot;
              }
            else
              git clone --depth 1 &quot;$URL&quot; &quot;$TMP&quot;
            fi
          fi

          SRC_ABS=&quot;$TMP/$SRC_PATH&quot;
          if [[ ! -d &quot;$SRC_ABS&quot; ]]; then
            echo &quot;::error title=Docs path not found::$SRC_PATH not found in $SRC_REPO&quot;
            echo &quot;Repo root contents:&quot;; ls -la &quot;$TMP&quot; || true
            exit 1
          fi

          DEST=&quot;$DEST_ROOT/$SAFE&quot;
          echo &quot;==&gt; Copying $SRC_PATH to $DEST/&quot;
          rm -rf &quot;$DEST&quot;
          mkdir -p &quot;$DEST&quot;
          shopt -s dotglob
          cp -a &quot;$SRC_ABS&quot;/. &quot;$DEST&quot;/
          shopt -u dotglob

      - name: Commit &amp; push (if changed)
        env:
          SRC_REPO: ${{ inputs.source_repo }}
          REF: ${{ inputs.ref }}
          SRC_PATH: ${{ inputs.source_docs_path }}
          DEST_ROOT: ${{ inputs.dest_subdir }}
        shell: bash
        run: |
          set -e
          if [ -n &quot;$(git status --porcelain)&quot; ]; then
            git config user.name &quot;github-actions[bot]&quot;
            git config user.email &quot;41898282+github-actions[bot]@users.noreply.github.com&quot;
            git add -A
            git commit -m &quot;One-time import of docs from ${SRC_REPO}${REF:+@$REF} (path: ${SRC_PATH})&quot;
            git push
            echo &quot;Committed changes.&quot;
          else
            echo &quot;No changes detected.&quot;
          fi

      - name: Summary
        run: |
          echo &quot;## Imported docs&quot; &gt;&gt; &quot;$GITHUB_STEP_SUMMARY&quot;
          echo &quot;- Source: \`${{ inputs.source_repo }}\` (ref: \`${{ inputs.ref || &#x27;default branch&#x27; }}\`, path: \`${{ inputs.source_docs_path }}\`)&quot; &gt;&gt; &quot;$GITHUB_STEP_SUMMARY&quot;
          echo &quot;- Destination: \`${{ inputs.dest_subdir }}/${{ replace(inputs.source_repo, &#x27;/&#x27;, &#x27;-&#x27;) }}/\`&quot; &gt;&gt; &quot;$GITHUB_STEP_SUMMARY&quot;
```

### How to run
1. In `eMSSC-squared` → **Actions**, select **One-time import docs from another repo**.
2. Click **Run workflow** and set:
   - **source_repo**: e.g. `justindbilyeu/SunShare-TriSource` (then do the next repos later)
   - (optional) **ref**: a branch/tag/commit; leave blank to use default branch
   - **source_docs_path**: keep `docs` (change if the docs live elsewhere)
3. Run it. The files will appear at:
```
imports/docs/&lt;owner-repo&gt;/   # e.g., imports/docs/justindbilyeu-SunShare-TriSource/
```

&gt; If the source repo is **private**, create a PAT with `repo` scope and add it as a secret named `SOURCE_REPO_TOKEN` in `eMSSC-squared` (Settings → Secrets and variables → Actions). Public repos don’t need a token.

When you’re happy, we’ll repeat for the next repository (or change the `source_repo` input and rerun).

---

**user:**

I’ve linked CODEX with the new repository. Can you prompt them to do this task for us?

---

**assistant:**

I can’t talk to CODEX directly, but here’s a ready-to-paste prompt you can give it. It will add a workflow to **eMSSC-squared** that imports the `docs/` folder from one repo (starting with `justindbilyeu/SunShare-TriSource`), runs it, and opens a PR with the results.

---

## 📋 Prompt for CODEX (copy/paste)

**Task:** One-time import of the `docs/` folder from `justindbilyeu/SunShare-TriSource` into `justindbilyeu/eMSSC-squared` using a GitHub Actions workflow, then open a PR.

**Steps:**
1. Create a new branch in `justindbilyeu/eMSSC-squared` named `chore/import-docs-sunshare-trisource`.
2. Add the file `.github/workflows/import-docs.yml` with the exact content below.
3. Commit with message: `chore: add workflow to import docs from SunShare-TriSource`.
4. Push the branch to GitHub.
5. Trigger the workflow on that branch with inputs:
   - `source_repo`: `justindbilyeu/SunShare-TriSource`
   - `ref`: *(leave blank to use default branch)*
   - `source_docs_path`: `docs`
   - `dest_subdir`: `imports/docs`
6. After the workflow run completes successfully and pushes the imported files, open a pull request from `chore/import-docs-sunshare-trisource` → `main` with title:
   - **Title:** `Import docs from SunShare-TriSource`
   - **Body:** `Imports the docs folder into imports/docs/justindbilyeu-SunShare-TriSource/ via one-time workflow.`

&gt; If the source repo is private, ensure the destination repo has a secret named `SOURCE_REPO_TOKEN` with a PAT that has `repo` scope; the workflow will use it automatically. Public repos don’t need a token.

**Workflow file content (`.github/workflows/import-docs.yml`):**
```yaml
name: One-time import docs from another repo

on:
  workflow_dispatch:
    inputs:
      source_repo:
        description: &quot;owner/repo to import from (e.g., justindbilyeu/SunShare-TriSource)&quot;
        required: true
        default: &quot;justindbilyeu/SunShare-TriSource&quot;
      ref:
        description: &quot;Branch, tag, or commit (leave blank for default branch)&quot;
        required: false
        default: &quot;&quot;
      source_docs_path:
        description: &quot;Path to docs folder in source repo&quot;
        required: false
        default: &quot;docs&quot;
      dest_subdir:
        description: &quot;Destination folder in this repo&quot;
        required: false
        default: &quot;imports/docs&quot;

permissions:
  contents: write

jobs:
  import-docs:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout destination repo (this repo)
        uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Clone source repo
        env:
          GH_READ_TOKEN: ${{ secrets.SOURCE_REPO_TOKEN }}  # Only needed if source is private
          SRC_REPO: ${{ inputs.source_repo }}
          REF: ${{ inputs.ref }}
          SRC_PATH: ${{ inputs.source_docs_path }}
          DEST_ROOT: ${{ inputs.dest_subdir }}
        shell: bash
        run: |
          set -euo pipefail

          SAFE=&quot;${SRC_REPO//\//-}&quot;
          TMP=&quot;$RUNNER_TEMP/src-$SAFE&quot;
          URL=&quot;https://github.com/$SRC_REPO.git&quot;

          echo &quot;==&gt; Cloning $SRC_REPO ${REF:+@ $REF}&quot;
          if [[ -n &quot;${GH_READ_TOKEN:-}&quot; ]]; then
            if [[ -n &quot;$REF&quot; ]]; then
              git -c http.extraheader=&quot;Authorization: Bearer $GH_READ_TOKEN&quot; clone --depth 1 --branch &quot;$REF&quot; &quot;$URL&quot; &quot;$TMP&quot; || {
                echo &quot;::warning title=Clone by branch failed::Falling back to fetching specific ref/commit&quot;
                git -c http.extraheader=&quot;Authorization: Bearer $GH_READ_TOKEN&quot; clone --depth 1 &quot;$URL&quot; &quot;$TMP&quot;
                git -C &quot;$TMP&quot; fetch --depth 1 origin &quot;$REF&quot;:&quot;tmpref&quot;
                git -C &quot;$TMP&quot; checkout --detach &quot;tmpref&quot;
              }
            else
              git -c http.extraheader=&quot;Authorization: Bearer $GH_READ_TOKEN&quot; clone --depth 1 &quot;$URL&quot; &quot;$TMP&quot;
            fi
          else
            if [[ -n &quot;$REF&quot; ]]; then
              git clone --depth 1 --branch &quot;$REF&quot; &quot;$URL&quot; &quot;$TMP&quot; || {
                echo &quot;::warning title=Clone by branch failed::Falling back to fetching specific ref/commit&quot;
                git clone --depth 1 &quot;$URL&quot; &quot;$TMP&quot;
                git -C &quot;$TMP&quot; fetch --depth 1 origin &quot;$REF&quot;:&quot;tmpref&quot;
                git -C &quot;$TMP&quot; checkout --detach &quot;tmpref&quot;
              }
            else
              git clone --depth 1 &quot;$URL&quot; &quot;$TMP&quot;
            fi
          fi

          SRC_ABS=&quot;$TMP/$SRC_PATH&quot;
          if [[ ! -d &quot;$SRC_ABS&quot; ]]; then
            echo &quot;::error title=Docs path not found::$SRC_PATH not found in $SRC_REPO&quot;
            echo &quot;Repo root contents:&quot;; ls -la &quot;$TMP&quot; || true
            exit 1
          fi

          DEST=&quot;$DEST_ROOT/$SAFE&quot;
          echo &quot;==&gt; Copying $SRC_PATH to $DEST/&quot;
          rm -rf &quot;$DEST&quot;
          mkdir -p &quot;$DEST&quot;
          shopt -s dotglob
          cp -a &quot;$SRC_ABS&quot;/. &quot;$DEST&quot;/
          shopt -u dotglob

      - name: Commit &amp; push (if changed)
        env:
          SRC_REPO: ${{ inputs.source_repo }}
          REF: ${{ inputs.ref }}
          SRC_PATH: ${{ inputs.source_docs_path }}
          DEST_ROOT: ${{ inputs.dest_subdir }}
        shell: bash
        run: |
          set -e
          if [ -n &quot;$(git status --porcelain)&quot; ]; then
            git config user.name &quot;github-actions[bot]&quot;
            git config user.email &quot;41898282+github-actions[bot]@users.noreply.github.com&quot;
            git add -A
            git commit -m &quot;One-time import of docs from ${SRC_REPO}${REF:+@$REF} (path: ${SRC_PATH})&quot;
            git push
            echo &quot;Committed changes.&quot;
          else
            echo &quot;No changes detected.&quot;
          fi

      - name: Summary
        run: |
          echo &quot;## Imported docs&quot; &gt;&gt; &quot;$GITHUB_STEP_SUMMARY&quot;
          echo &quot;- Source: \`${{ inputs.source_repo }}\` (ref: \`${{ inputs.ref || &#x27;default branch&#x27; }}\`, path: \`${{ inputs.source_docs_path }}\`)&quot; &gt;&gt; &quot;$GITHUB_STEP_SUMMARY&quot;
          echo &quot;- Destination: \`${{ inputs.dest_subdir }}/${{ replace(inputs.source_repo, &#x27;/&#x27;, &#x27;-&#x27;) }}/\`&quot; &gt;&gt; &quot;$GITHUB_STEP_SUMMARY&quot;
```

**After this repo is merged:** To import docs from the next repository, re-run the same workflow with `source_repo` set to the next repo (e.g., `justindbilyeu/SunShare-Connect-Initiative-` or `justindbilyeu/eMSSC2`).

---

