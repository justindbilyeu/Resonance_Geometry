# GitHub repository access

- Conversation ID: 68ff5462-57b4-832f-b8a1-ed63b30a76a7
- Created: 2025-10-27T11:16:19.057210

---

**user:**

Are you able to look at all of the repositories I have here on GitHub? 

https://github.com/justindbilyeu?tab=repositories

---

**assistant:**

Yep — I can view and review all the **public** repos on your GitHub profile. I’m seeing **23 public repositories** right now, including:

- **Resonance_Geometry** (updated Oct 27, 2025) citeturn0view0  
- **eMSSC-squared** (updated Oct 27, 2025) citeturn0view0  
- **2ndStory-Services** (updated Oct 6, 2025) citeturn0view0  

If any repos are **private**, I can’t access them unless you share access or paste specific files/links here. Want me to review or summarize any of these now?

---

**user:**

All are public, you have permission to access all of them. Review them, and report back.

---

**assistant:**

Thanks! To tailor the review to what matters most to you, could you clarify what you&#x27;re looking for?

1. Are you interested in a high-level summary of each repository (purpose, technologies, status)?
2. Do you want an assessment of code quality, documentation, or project completeness?
3. Should I identify standout projects or ones worth polishing/showcasing?

Let me know your goals, and I’ll get started accordingly.

---

**user:**

#1 and #3

---

**assistant:**

Great — I’ll review all public repositories in your GitHub profile and provide:

1. A high-level summary of each repository, including its purpose, technologies used, and current development status.
2. A highlight of standout projects based on originality, completeness, or polish, and note any with potential for improvement or showcasing.

I’ll start now and follow up with a full report shortly.

---

**assistant:**

{
  &quot;task_violates_safety_guidelines&quot;: false,
  &quot;user_def_doesnt_want_research&quot;: false,
  &quot;response&quot;: &quot;Great — I’ll review all public repositories in your GitHub profile and provide:\n\n1. A high-level summary of each repository, including its purpose, technologies used, and current development status.\n2. A highlight of standout projects based on originality, completeness, or polish, and note any with potential for improvement or showcasing.\n\nI’ll start now and follow up with a full report shortly.&quot;,
  &quot;title&quot;: &quot;Summary and Highlights of Public GitHub Repositories&quot;,
  &quot;prompt&quot;: &quot;Review all public repositories at https://github.com/justindbilyeu?tab=repositories. For each repository:\n\n1. Provide a high-level summary including its purpose, main technologies used, and the current development status (active, archived, incomplete, etc.).\n2. Identify standout repositories based on factors such as originality, completeness, documentation, design, or potential for real-world application. Highlight what makes them strong.\n3. Optionally suggest projects that are worth polishing or further development for showcasing in a portfolio.\n\nFormat the output as a report with clear headers and structure, including a table listing all repos and summary metadata (name, purpose, status, language/framework).&quot;
}

---

**assistant:**

# Review of Justin Bilyeu’s Public GitHub Repositories

Below is an organized review of all 23 public repositories under **justindbilyeu**, including each project’s purpose, primary technologies, and development status. A summary table is followed by detailed observations, standout projects, and suggestions for portfolio focus.

## Repository Overview

| **Repository**                | **Purpose / Description**                                             | **Main Tech / Framework**    | **Status**                 |
|-------------------------------|----------------------------------------------------------------------|-----------------------------|----------------------------|
| **Resonance_Geometry**        | Research framework for phase transitions &amp; dynamical systems (“Resonance Geometry”)【28†L475-L483】. Combines math analysis, simulation, and documentation. | Python (scientific stack), LaTeX docs | **Active** – Frequently updated (Oct 2025), comprehensive code + papers. |
| **eMSSC-squared**             | “Exponential Microbial Systems for Sustainable Communities” – open blueprint integrating microbial water treatment, solar desalination, etc., for off-grid water/soil systems【32†L319-L327】【32†L345-L354】. Extensive technical docs and planning. | Python (simulations), Markdown/Diagrams | **Active** – Well-documented (Apache-2.0 licensed), updated Oct 2025, multi-folder documentation. |
| **2ndStory-Services**         | *TBD* – Placeholder for a services project (possibly related to “Second Story”). No significant content yet. | Python (empty scaffold)      | **Incomplete** – Repo exists with MIT license but no real content【35†L161-L169】. |
| **JustAsking** (`justasking`) | “Idea Resonator” web app – generates model-specific prompts for multiple LLMs (Claude, Grok, Gemini, etc.) and synthesizes answers【37†L265-L273】. Front-end and optional Cloudflare worker for API proxy. | HTML/JS (93%/6%)【37†L398-L404】; Cloudflare Worker (JS) | **Prototype** – Functional static app (GitHub Pages), with features like multi-LLM fan-out and markdown export【37†L301-L305】. Could be polished further. |
| **PM-QC-TCR**                | Project Management &amp; Quality Control for *Texas Choice Roofing* – used as an internal tracker (issues, checklists). Mostly documentation (checklists in `docs/`). | Markdown/docs (no code)      | **Active (Internal)** – Contains issues (29) and checklists for QA, updated Sep 2025【38†L175-L183】【38†L228-L236】. Likely in use internally; minimal code. |
| **SCSRRS-TCR**               | **S**olar-**C**onnected **S**torm-**R**esistant **R**oofing **S**ystem for Texas Choice Roofing – a specialized version of SCSRRS for a roofing company. Includes a live ROI calculator and contact info. | HTML/JS (static site in `docs/` for GitHub Pages) | **Active** – Updated Sep 2025 with a working calculator and wiki. Supersedes “v1” (below) as the current version. |
| **Mega-Prompt**              | *“Choose your own adventure”* prompt demo – likely an interactive prompt/story generator (details sparse due to minimal commits). Possibly a prototype for dynamic storytelling with AI. | HTML/JS (docs folder)        | **Incomplete** – Only 3 commits (Sep 2025). Apache-2.0 licensed, but content not fully fleshed out. |
| **ITPU**                     | **Information-Theoretic Processing Unit** – library to accelerate entropy &amp; mutual information computations, envisioning hardware acceleration in future【49†L31-L39】. Provides Python API (`itpu.sdk`) for MI estimators (histogram, k-NN, etc.). | Python library (with tests), Citable design docs | **Active** – 133+ commits, Apache-2.0, last updated Sep 2025. Has stable API and issues/PRs, indicating ongoing development of the tool【49†L49-L57】【49†L71-L75】. |
| **ResonanceGeometry**        | Earlier *Resonance Geometry* repository (likely precursor to **Resonance_Geometry**). Contains TeX documents (e.g. “Structured_Resonance_Codex_v4.1”) and theoretical work on extended general relativity (EGR). | TeX (technical paper, wiki)  | **Semi-Active** – 51 commits (last Sep 2025). Not archived, but superseded by the “Cleaned up ResGeo” in **Resonance_Geometry**. Serves as historical research notes. |
| **Geometric-Plasticity-**    | Data/Methods capsule for *Resonant Witness Dynamics* research – provides preview figures, CSV data, and a methods summary (but not full code)【25†L283-L292】【25†L322-L330】. Meant to share results while protecting full source. | Python (data analysis), figures/docs | **Partial Release** – 22 commits (Sep 2025). Essentially a “defensive publication” repository with key results and falsifiable criteria【25†L290-L299】【25†L322-L330】. Not a runnable app, but supplemental to Resonance_Geometry work. |
| **SunShare-TriSource**       | Repository for **Tri-Source Water Node™** – a modular, solar-powered water system combining atmospheric water harvesting, microbial treatment, and solar desalination【1†L231-L239】. Contains research paper, technical docs, and deployment framework. | Markdown docs, schematics    | **Active** – 36 commits, updated Sep 2025. Rich documentation (white paper, bibliography) but little code. Part of the larger SunShare Connect initiative【1†L229-L238】【1†L233-L241】. |
| **SunShare-Connect-Initiative** | Umbrella repo for the **SunShare Connect™** program (resilient energy/water/connectivity hubs). Currently minimal – includes a PDF (“MSSC_Exhibit_A_Overlap_Matrix.pdf”) and likely intended to host combined resources. | Docs (PDF)                   | **Barebones** – Only 8 commits (Aug 2025)【52†L228-L232】. Likely a placeholder to integrate multiple SunShare projects (TriSource, etc.). Not yet fleshed out. |
| **SCSRRS-TCRv1**             | Earlier iteration of the SCSRRS for Texas Choice Roofing. Contains an initial version of the ROI calculator (in `docs/calculator`) and README. | HTML/JS (static content)     | **Deprecated** – 64 commits (last Aug 2025)【42†L230-L234】. Replaced by the updated **SCSRRS-TCR**; kept for reference. Not actively maintained. |
| **SCSRRS**                   | **Solar-Connected Storm-Resistant Roofing System** (general project). Open-source roofing solution with Class-4 impact metal roofing + solar-ready design. Includes homeowner guides, ROI Excel calculator, engineering whitepaper, etc.【41†L256-L264】【41†L281-L289】. | JavaScript (37%), TeX (28%), HTML/CSS docs【41†L388-L394】 | **Active** – Comprehensive documentation and assets, updated Aug 2025. Serves as the core knowledge base for SCSSRS (with open-source license: code MIT, docs CC BY-NC)【41†L330-L338】. A strong real-world project with collaboration invites. |
| **RoofBot**                  | Concept note for a **roofing mini skid-steer attachment** (“RoofBot Attachment v0.1”). Aims to automate roof tear-off and material handling using a machine attachment【58†L249-L257】【58†L274-L283】. Essentially a timestamped idea disclosure (for prior art). | Markdown concept doc         | **Archived Concept** – 2 commits (Aug 16, 2025). Contains problem statement and proposed solution for a future prototype【58†L260-L268】【58†L274-L282】. No code; serves as an open idea publication. |
| **Live-Social-Shopping**     | “#LiveSocialRoofShopping” – An open playbook to launch and measure **live video commerce for roofing**. Contains market research, platform guides, content templates, and AI-generated research prompts【61†L242-L251】【61†L253-L262】. Essentially a knowledge repo for a 90-day live-stream commerce strategy. | Markdown wiki, prompts       | **Active (Documentation)** – 2 commits (Aug 2025). Growing wiki and roadmap documented【61†L253-L262】【61†L264-L272】. Unique application of multi-LLM research to marketing. Could be expanded with results of experiments. |
| **stone-coated-steel-gpt**   | Knowledge base for **stone-coated steel roofing** – likely a collection of Q&amp;A or text “chunks” intended to feed a GPT model for training or FAQ support. Possibly used to develop an AI assistant or to enable GPT queries on roofing topics. | Markdown/JSON text chunks    | **Completed Dataset** – 31 commits (Jul 2025) with content in a `chunks/` directory. No application code, but prepared data and GitHub Actions (perhaps to format or update content). Used internally for AI-driven customer service or training. |
| **eMSSC2**                   | *Emergent Model of Situated Symbolic Co-Creation* – An experimental framework for human-AI collaborative learning/creativity【64†L1-L4】. Contains a manifesto and index. Not related to the sustainable “eMSSC”; instead, focuses on education and “situated symbolic” emergence. | Markdown/TeX (docs, manifesto) | **Draft** – 10 commits (June 2025). Early-stage concept repository (possibly abandoned or merged elsewhere). Shows ambition in AI-driven educational frameworks, but not an active code project. |
| **REAL**                     | Likely acronymic project (possibly **R.E.A.L.** – e.g., “Resonance/Reality” codex). Contains LaTeX documents like *Structured_Resonance_Codex v4.1* and related theoretical write-ups. Tied to the Resonance projects (advanced physics/quantum theory notes). | LaTeX, academic writing      | **Semi-Active** – 65 commits (last June 2025). Primarily a paper/research repo (no software). May represent draft sections of a thesis or publication on resonance and consciousness (given context). |
| **Tech-but-Verify**          | Play on “Trust but verify” – presumably a security or tech verification blog/guide. However, repository only has an initial README (no content visible) and a note “Security.” Likely intended for writing about security best practices or AI/tech validation. | N/A (no code)                | **Empty** – 1 commit (June 7, 2025) with essentially no content【68†L229-L236】. Possibly an idea for a security-focused article series that was not pursued. |
| **HOA-StormReadyAI**         | Homeowners Association *StormReady AI* playbook – presumably guidelines and tools to help HOAs use AI for storm preparedness (e.g., evaluating roof resiliency, insurance, etc.). Created during roofing domain work. | Markdown (planned guide)     | **Empty** – 1 commit (May 27, 2025). Only a placeholder README, no developed content. Idea not executed yet. |
| **Energy-at-Wholesale**      | *TBD* – Likely an idea about energy procurement or energy market strategies. No info besides the name (could have been about buying energy at wholesale rates for communities or projects). | N/A                          | **Empty** – 1 commit (May 14, 2025) with “TBD”【72†L159-L167】【72†L228-L236】. No development; simply a reserved concept. |
| **DoorKnockingMastery**      | Repository intended as a “mastery guide” for door-to-door sales (relevant to roofing sales leads). Possibly to compile training tips, scripts, and conversion tracking methods for door knocking campaigns. | Markdown (guide)             | **Started** – 2 commits (May 12, 2025). Minimal content in README. Likely envisioned as a training playbook, but not developed beyond an outline. |

*(**Note:** Several names above include “TCR” – Texas Choice Roofing – indicating those projects were for a roofing company context, often focusing on sales, marketing, or technical solutions in roofing.)*

## Notable Standout Repositories

Among the above, a few projects stand out for their originality, completeness, documentation quality, or potential impact:

- **Resonance_Geometry** – This is a flagship research repository. It is comprehensive (400+ commits) and well-documented, featuring a full technical paper draft (“Resonant Transition Points Beyond Hopf Bifurcations” with reproducible results)【28†L494-L503】【28†L505-L513】, installation instructions, automated tests, and even a Quarto-based dissertation under development【28†L593-L600】. The combination of rigorous theory, code (with Python simulations and `pytest` tests), and clear README structure makes it a strong example of scientific software. It demonstrates the author’s strength in algorithmic research and ability to maintain a complex project over time. This repository’s documentation is particularly strong – it outlines core questions, findings, and how to reproduce results, which is excellent for readability and verifiability.

- **eMSSC-squared** – This project is impressive in scope and documentation. It acts as an open-source blueprint for sustainable tech integration (water treatment + solar desalination + agriculture). The README is detailed with vision, contribution guidelines, repository map, status updates, and even embedded system diagrams【32†L310-L319】【32†L345-L354】. It stands out for real-world application potential – addressing climate resilience infrastructure – and for originality in combining engineering with open collaboration. While it’s documentation-heavy, the thoroughness (folder structure from foundational tech to pilot implementation) and the call to action for contributors show strong design and planning. This could be showcased to demonstrate project management and domain knowledge in environmental tech.

- **SCSRRS (Solar-Connected Storm-Resistant Roofing System)** – A highly practical project with a mix of engineering and software. It effectively open-sources a **roofing product** concept (impact-resistant, solar-ready roof system) and provides value to multiple stakeholders (homeowners, installers, insurers). The repository includes a live savings calculator (Excel and web), a technical whitepaper in LaTeX, and homeowner-friendly documentation【41†L281-L289】【41†L294-L302】. The professionalism in the README – including licensing for different content types, contribution guidelines, and contact info for press – makes it portfolio-worthy【41†L330-L338】【41†L340-L349】. It demonstrates the author’s ability to document and package an innovative solution in a traditionally non-software field, which is quite original. The design and thoroughness (even offering sealed engineering drawings in the future) indicate strong planning.

- **JustAsking (Idea Resonator)** – In terms of software originality, JustAsking is notable. It’s a lightweight web application that orchestrates multiple Large Language Models in parallel and synthesizes their outputs【37†L265-L273】. This is an innovative “prompt engineering” tool that showcases front-end skills and integration of AI services. The project has a clear use-case (brainstorming an idea via many AI perspectives) and some unique technical choices (e.g., using GitHub Actions or a Cloudflare Worker to keep API keys off the client【37†L323-L331】【37†L347-L355】). Although it’s a prototype, it has a working demo and a well-explained README (features list, quick start, and roadmap)【37†L299-L307】【37†L309-L317】. Its strength lies in demonstrating modern web dev (static SPA + serverless) and practical AI integration – a great portfolio piece if polished (e.g. add a hosted demo, refine UI).

- **ITPU (Information-Theoretic Processing Unit)** – This is a strong technical code project. It provides a clean Python API for complex computations (entropy, mutual information) and hints at low-level optimization or future hardware use【49†L31-L39】. The presence of issues and pull requests suggests collaborative development, and the focus on keeping a stable public API with tests【49†L71-L75】 reflects good software engineering practices. If the goal is to showcase algorithmic coding and performance optimization, ITPU is a great choice. It’s original in concept (few people attempt an “ITPU”), and it has practical utility in data science. Improving documentation (usage examples, installation via pip) and adding benchmarks could further highlight its strengths.

- **Live-Social-Shopping** – Though relatively new, this repository is unique in that it applies AI and open knowledge to a marketing problem (live commerce for roofing). It stands out for creative use of technology: using “GGCDs” (Gemini, Grok, Claude, DeepSeek AI assistants) to research and generate content【61†L255-L263】【61†L270-L273】. The structured approach (market intel, prompts, governance, roadmap) shows the author’s skill in knowledge organization and cutting-edge marketing techniques. It’s not a traditional code project, but it could be compelling in a portfolio for roles involving strategy, growth, or content automation. To strengthen it, one could add outcomes of the 90-day experiment or data from the pilot live shows.

## Recommendations for Portfolio Enhancement

Given the above, a few projects are especially worth polishing and showcasing:

- **JustAsking (Idea Resonator):** This project can shine with a bit more work. To impress, one could deploy it at a public URL and perhaps integrate a few example use-cases. Emphasize its multi-LLM orchestration capability and the neat synthesis feature. It demonstrates full-stack ability (frontend + cloud function) and understanding of prompt engineering – very relevant and eye-catching in the AI boom.

- **Resonance_Geometry or ITPU:** If pursuing roles in data science, quantitative research, or software engineering, these show a mastery of complex problem-solving. For Resonance_Geometry, highlight the novel scientific findings (e.g., discovery of a resonant transition point with all eigenvalues negative, defying Hopf bifurcation【28†L497-L505】) and the rigorous validation (`pytest` tests, reproducible sweeps). For ITPU, focus on performance and how it could accelerate analytical workloads. Cleaning up documentation and perhaps publishing a Python package for ITPU would further demonstrate software engineering maturity.

- **SCSRRS (or its TCR variant):** To showcase product development and domain expertise, SCSRRS is ideal. It’s essentially an engineering project turned open-source. For a portfolio, one might extract a narrative: how you identified a problem (hail damage, etc.), developed a solution (roof system), and used code and data to prove its value (savings calculator, whitepaper). Even if not directly software, it highlights project management, multi-disciplinary skills, and the impact of your work (e.g., “≈$45,000 net 20-year gain for an Austin home” with the system【41†L269-L275】). Including this can set you apart, especially for roles bridging tech and the built environment or for showing initiative and entrepreneurship.

- **eMSSC-squared:** If you want to emphasize climate tech or large-scale project coordination, polishing this repository could be beneficial. It already has a professional tone (vision, partnership briefs, funding targets in the README)【32†L361-L369】【32†L371-L379】. To use it in a portfolio, ensure the README’s key points are clear and maybe add a short executive summary of what was achieved so far (patent filed, pilot identified, etc.). This would underline your ability to tackle global challenges with technology and collaboration.

In summary, Justin Bilyeu’s GitHub shows a **diverse portfolio** ranging from deep physics research to practical roofing technology and AI tools. Strengths include extremely thorough documentation and innovative cross-domain thinking. By highlighting a few key repositories – for instance, a **polished web app (JustAsking)**, a **robust research/code project (Resonance_Geometry or ITPU)**, and a **real-world solution (SCSRRS or eMSSC-squared)** – the portfolio will demonstrate a rare combination of theoretical knowledge, coding skill, and impactful problem-solving. Each of these standout projects, with a bit of additional refinement (e.g. live demos, clearer results, or usage instructions), will greatly impress potential employers or collaborators.

---

**user:**

How about a main repo that explains the journey and links to each repo…like if you’re a physicist go here , a roofer go here…

---

**assistant:**

love that. let’s make a single “hub” repo that routes people by path (physicist, roofer, climate-tech, AI, etc.) and links straight into each project.

below are copy-paste files so you can create it today.

---

# 1) Repo name &amp; layout

**Suggested name:** `Open-Lab` (or `JustinBilyeu-Open-Lab`)

**Files to add:**
```
Open-Lab/
├─ README.md
└─ docs/
   ├─ index.md
   └─ _config.yml
```

---

# 2) `README.md` (paste this)

```markdown
# Justin Bilyeu — Open Lab (Project Hub)

**Welcome.** This is the high-level map of my work. Choose a path below to jump into the repos that fit you best.

## Choose your path

[![Physicists &amp; Theorists](https://img.shields.io/badge/Physicists_%26_Theorists-%E2%86%93-blue)](#physicists--theorists)
[![Climate Tech &amp; Water](https://img.shields.io/badge/Climate_Tech_%26_Water-%E2%86%93-brightgreen)](#climate-tech--water)
[![Roofing &amp; Built Env](https://img.shields.io/badge/Roofing_%26_Built_Env-%E2%86%93-orange)](#roofing--built-environment)
[![AI Tools &amp; Research SW](https://img.shields.io/badge/AI_Tools_%26_Research_SW-%E2%86%93-purple)](#ai-tools--research-software)
[![Business &amp; Ventures](https://img.shields.io/badge/Business_%26_Ventures-%E2%86%93-lightgrey)](#business--ventures)

---

## Featured (start here)
- **Resonance_Geometry** — core research on resonance dynamics and phase behavior.  
  → &lt;https://github.com/justindbilyeu/Resonance_Geometry&gt;
- **SCSRRS** — Solar-Connected Storm-Resistant Roofing System (engineering, ROI, docs).  
  → &lt;https://github.com/justindbilyeu/SCSRRS&gt;
- **eMSSC-squared** — open blueprint for resilient water/soil systems (solar desal + microbial).  
  → &lt;https://github.com/justindbilyeu/eMSSC-squared&gt;
- **JustAsking** — multi-LLM “idea resonator” tool (parallel prompts, synthesis).  
  → &lt;https://github.com/justindbilyeu/justasking&gt;

---

## Physicists &amp; Theorists
- **Resonance_Geometry** → &lt;https://github.com/justindbilyeu/Resonance_Geometry&gt;  
  Mathematical framework, simulations, figures, papers.
- **ResonanceGeometry** → &lt;https://github.com/justindbilyeu/ResonanceGeometry&gt;  
  Earlier/theory notes and TeX (“Structured Resonance Codex”).
- **Geometric-Plasticity** (methods capsule) → &lt;https://github.com/justindbilyeu/Geometric-Plasticity-&gt;  
  Results/figures + methods; defensive publication capsule.
- **REAL** → &lt;https://github.com/justindbilyeu/REAL&gt;  
  LaTeX codex and extended theory notes.

---

## Climate Tech &amp; Water
- **eMSSC-squared** → &lt;https://github.com/justindbilyeu/eMSSC-squared&gt;  
  Systems integration: solar desal, microbial loops, pilots.
- **SunShare-TriSource** → &lt;https://github.com/justindbilyeu/SunShare-TriSource&gt;  
  Tri-Source Water Node™ docs and deployment framing.
- **SunShare-Connect-Initiative** → &lt;https://github.com/justindbilyeu/SunShare-Connect-Initiative&gt;  
  Umbrella for community nodes (energy/water/connectivity).

---

## Roofing &amp; Built Environment
- **SCSRRS** → &lt;https://github.com/justindbilyeu/SCSRRS&gt;  
  Core open project (whitepaper, calculator, homeowner guides).
- **SCSRRS-TCR** → &lt;https://github.com/justindbilyeu/SCSRRS-TCR&gt;  
  Texas Choice Roofing variant; ROI site &amp; wiki.
- **SCSRRS-TCRv1** → &lt;https://github.com/justindbilyeu/SCSRRS-TCRv1&gt;  
  Earlier iteration (kept for reference).
- **PM-QC-TCR** → &lt;https://github.com/justindbilyeu/PM-QC-TCR&gt;  
  Project mgmt &amp; quality control checklists.
- **stone-coated-steel-gpt** → &lt;https://github.com/justindbilyeu/stone-coated-steel-gpt&gt;  
  Knowledge base / “chunks” for AI assistants.
- **RoofBot** → &lt;https://github.com/justindbilyeu/RoofBot&gt;  
  Concept note for a tear-off/handling attachment.
- **Live-Social-Shopping** → &lt;https://github.com/justindbilyeu/Live-Social-Shopping&gt;  
  90-day live-commerce playbook + prompts.
- **DoorKnockingMastery** → &lt;https://github.com/justindbilyeu/DoorKnockingMastery&gt;  
  Sales training/playbook (outline).
- **HOA-StormReadyAI** → &lt;https://github.com/justindbilyeu/HOA-StormReadyAI&gt;  
  HOA readiness guide (placeholder).

---

## AI Tools &amp; Research Software
- **JustAsking** → &lt;https://github.com/justindbilyeu/justasking&gt;  
  Multi-LLM fan-out + synthesis web app (Pages-ready).
- **ITPU** → &lt;https://github.com/justindbilyeu/ITPU&gt;  
  Information-theoretic toolkit (entropy/MI APIs).
- **Mega-Prompt** → &lt;https://github.com/justindbilyeu/Mega-Prompt&gt;  
  Interactive prompt/story prototype.
- **Tech-but-Verify** → &lt;https://github.com/justindbilyeu/Tech-but-Verify&gt;  
  Security/verification blog seed.

---

## Business &amp; Ventures
- **2ndStory-Services** → &lt;https://github.com/justindbilyeu/2ndStory-Services&gt;
- **Energy-at-Wholesale** → &lt;https://github.com/justindbilyeu/Energy-at-Wholesale&gt;
- **eMSSC2** (education/“situated symbolic” concept) → &lt;https://github.com/justindbilyeu/eMSSC2&gt;

---

## Architectural map (quick visual)

```mermaid
mindmap
  root((Open Lab Hub))
    Physicists &amp; Theorists
      Resonance_Geometry
      ResonanceGeometry
      Geometric-Plasticity
      REAL
    Climate Tech &amp; Water
      eMSSC-squared
      SunShare-TriSource
      SunShare-Connect-Initiative
    Roofing &amp; Built Environment
      SCSRRS
      SCSRRS-TCR
      SCSRRS-TCRv1
      PM-QC-TCR
      stone-coated-steel-gpt
      RoofBot
      Live-Social-Shopping
      DoorKnockingMastery
      HOA-StormReadyAI
    AI Tools &amp; Research SW
      justasking
      ITPU
      Mega-Prompt
      Tech-but-Verify
    Business &amp; Ventures
      2ndStory-Services
      Energy-at-Wholesale
      eMSSC2
```

---

## How this hub is used
- **Skim** the paths above and jump in.
- **Clone** the repo you care about from its own README.
- **Issues &amp; Roadmaps** live in their respective repos.
- **Contact**: open an issue here if you’re unsure where to start.

&gt; _“This hub is the map; each repo is the territory.”_
```

---

# 3) `docs/index.md` (GitHub Pages homepage)

```markdown
---
title: Justin Bilyeu — Open Lab
description: Choose your path and dive into the repos.
---

# Justin Bilyeu — Open Lab

Welcome. This site routes you to the right projects, fast.

&lt;div style=&quot;display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;margin:24px 0;&quot;&gt;
  &lt;div style=&quot;border:1px solid #e5e7eb;border-radius:12px;padding:16px;&quot;&gt;
    &lt;h3&gt;🧠 Physicists &amp; Theorists&lt;/h3&gt;
    &lt;p&gt;Resonance dynamics, theory, and methods capsules.&lt;/p&gt;
    &lt;ul&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/Resonance_Geometry&quot;&gt;Resonance_Geometry&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/ResonanceGeometry&quot;&gt;ResonanceGeometry&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/Geometric-Plasticity-&quot;&gt;Geometric-Plasticity&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/REAL&quot;&gt;REAL&lt;/a&gt;&lt;/li&gt;
    &lt;/ul&gt;
  &lt;/div&gt;

  &lt;div style=&quot;border:1px solid #e5e7eb;border-radius:12px;padding:16px;&quot;&gt;
    &lt;h3&gt;🌞 Climate Tech &amp; Water&lt;/h3&gt;
    &lt;p&gt;Solar desal, microbial systems, resilient nodes.&lt;/p&gt;
    &lt;ul&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/eMSSC-squared&quot;&gt;eMSSC-squared&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/SunShare-TriSource&quot;&gt;SunShare-TriSource&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/SunShare-Connect-Initiative&quot;&gt;SunShare-Connect-Initiative&lt;/a&gt;&lt;/li&gt;
    &lt;/ul&gt;
  &lt;/div&gt;

  &lt;div style=&quot;border:1px solid #e5e7eb;border-radius:12px;padding:16px;&quot;&gt;
    &lt;h3&gt;🏠 Roofing &amp; Built Environment&lt;/h3&gt;
    &lt;p&gt;Open roofing system, ROI tools, field ops.&lt;/p&gt;
    &lt;ul&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/SCSRRS&quot;&gt;SCSRRS&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/SCSRRS-TCR&quot;&gt;SCSRRS-TCR&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/PM-QC-TCR&quot;&gt;PM-QC-TCR&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/stone-coated-steel-gpt&quot;&gt;stone-coated-steel-gpt&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/RoofBot&quot;&gt;RoofBot&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/Live-Social-Shopping&quot;&gt;Live-Social-Shopping&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/DoorKnockingMastery&quot;&gt;DoorKnockingMastery&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/HOA-StormReadyAI&quot;&gt;HOA-StormReadyAI&lt;/a&gt;&lt;/li&gt;
    &lt;/ul&gt;
  &lt;/div&gt;

  &lt;div style=&quot;border:1px solid #e5e7eb;border-radius:12px;padding:16px;&quot;&gt;
    &lt;h3&gt;🧰 AI Tools &amp; Research Software&lt;/h3&gt;
    &lt;p&gt;Multi-LLM orchestration and info-theory tools.&lt;/p&gt;
    &lt;ul&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/justasking&quot;&gt;JustAsking&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/ITPU&quot;&gt;ITPU&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/Mega-Prompt&quot;&gt;Mega-Prompt&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/Tech-but-Verify&quot;&gt;Tech-but-Verify&lt;/a&gt;&lt;/li&gt;
    &lt;/ul&gt;
  &lt;/div&gt;

  &lt;div style=&quot;border:1px solid #e5e7eb;border-radius:12px;padding:16px;&quot;&gt;
    &lt;h3&gt;🚀 Business &amp; Ventures&lt;/h3&gt;
    &lt;p&gt;Services, programs, and market experiments.&lt;/p&gt;
    &lt;ul&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/2ndStory-Services&quot;&gt;2ndStory-Services&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/Energy-at-Wholesale&quot;&gt;Energy-at-Wholesale&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/eMSSC2&quot;&gt;eMSSC2&lt;/a&gt;&lt;/li&gt;
    &lt;/ul&gt;
  &lt;/div&gt;
&lt;/div&gt;

---

### About
This site is the **map**; each linked repository is the **territory** with its own README, issues, and roadmaps. If you’re unsure where to begin, open an issue on the repo that feels closest to your interests.

```

---

# 4) `docs/_config.yml` (enable GitHub Pages quickly)

```yaml
title: &quot;Justin Bilyeu — Open Lab&quot;
description: &quot;Choose your path and dive into the repos.&quot;
theme: jekyll-theme-cayman
markdown: kramdown
kramdown:
  input: GFM
```

---

# 5) Turn on Pages

- In the new hub repo, go to **Settings → Pages**  
- **Source:** `Deploy from a branch` → Branch: `main` → Folder: `/docs`  
- Save. Your site will be live at `https://justindbilyeu.github.io/Open-Lab/` (or whatever repo name you choose).

---

want me to also add a tiny **“What’s new”** section that auto-lists latest commits across your repos (via a simple GitHub Actions workflow), or keep it static for now?

---

**user:**

Yes, let’s do that!  Also , I like “Choose your own adventure”…

and let’s add a “books” section for later

---

**assistant:**

Amazing—let’s make your hub feel like a **“Choose Your Own Adventure”** AND keep it fresh with an auto-updated **What’s New**. I’ve included copy-paste files for:

- a “Books” section (placeholder for now)
- a daily **What’s New** page that pulls the latest commits across all your public repos
- updated README + Pages site

If you already started the hub, just drop these files in. If not, create a new repo (e.g., `Open-Lab`) and add the files below.

---

## 1) Updated README (with “Choose Your Own Adventure”, Books, What’s New)

**# path: README.md**
```markdown
# Justin Bilyeu — Open Lab
_Choose Your Own Adventure through my work: physics → climate-tech → roofing → AI._

[![Physicists &amp; Theorists](https://img.shields.io/badge/Physicists_%26_Theorists-%E2%86%93-blue)](#physicists--theorists)
[![Climate Tech &amp; Water](https://img.shields.io/badge/Climate_Tech_%26_Water-%E2%86%93-brightgreen)](#climate-tech--water)
[![Roofing &amp; Built Env](https://img.shields.io/badge/Roofing_%26_Built_Env-%E2%86%93-orange)](#roofing--built-environment)
[![AI Tools &amp; Research SW](https://img.shields.io/badge/AI_Tools_%26_Research_SW-%E2%86%93-purple)](#ai-tools--research-software)
[![Business &amp; Ventures](https://img.shields.io/badge/Business_%26_Ventures-%E2%86%93-lightgrey)](#business--ventures)
[![What’s New](https://img.shields.io/badge/What%E2%80%99s_New-auto--updated-informational)](docs/whats-new.md)
[![Books](https://img.shields.io/badge/Books-reading_list-plum)](docs/books.md)

---

## Featured (start here)
- **Resonance_Geometry** — core research on resonance dynamics and phase behavior.  
  → https://github.com/justindbilyeu/Resonance_Geometry
- **SCSRRS** — Solar-Connected Storm-Resistant Roofing System (engineering, ROI, docs).  
  → https://github.com/justindbilyeu/SCSRRS
- **eMSSC-squared** — open blueprint for resilient water/soil systems (solar desal + microbial).  
  → https://github.com/justindbilyeu/eMSSC-squared
- **JustAsking** — multi-LLM “idea resonator” tool (parallel prompts, synthesis).  
  → https://github.com/justindbilyeu/justasking

---

## Physicists &amp; Theorists
- **Resonance_Geometry** → https://github.com/justindbilyeu/Resonance_Geometry
- **ResonanceGeometry** → https://github.com/justindbilyeu/ResonanceGeometry
- **Geometric-Plasticity-** → https://github.com/justindbilyeu/Geometric-Plasticity-
- **REAL** → https://github.com/justindbilyeu/REAL

## Climate Tech &amp; Water
- **eMSSC-squared** → https://github.com/justindbilyeu/eMSSC-squared
- **SunShare-TriSource** → https://github.com/justindbilyeu/SunShare-TriSource
- **SunShare-Connect-Initiative** → https://github.com/justindbilyeu/SunShare-Connect-Initiative

## Roofing &amp; Built Environment
- **SCSRRS** → https://github.com/justindbilyeu/SCSRRS
- **SCSRRS-TCR** → https://github.com/justindbilyeu/SCSRRS-TCR
- **SCSRRS-TCRv1** → https://github.com/justindbilyeu/SCSRRS-TCRv1
- **PM-QC-TCR** → https://github.com/justindbilyeu/PM-QC-TCR
- **stone-coated-steel-gpt** → https://github.com/justindbilyeu/stone-coated-steel-gpt
- **RoofBot** → https://github.com/justindbilyeu/RoofBot
- **Live-Social-Shopping** → https://github.com/justindbilyeu/Live-Social-Shopping
- **DoorKnockingMastery** → https://github.com/justindbilyeu/DoorKnockingMastery
- **HOA-StormReadyAI** → https://github.com/justindbilyeu/HOA-StormReadyAI

## AI Tools &amp; Research Software
- **JustAsking** → https://github.com/justindbilyeu/justasking
- **ITPU** → https://github.com/justindbilyeu/ITPU
- **Mega-Prompt** → https://github.com/justindbilyeu/Mega-Prompt
- **Tech-but-Verify** → https://github.com/justindbilyeu/Tech-but-Verify

## Business &amp; Ventures
- **2ndStory-Services** → https://github.com/justindbilyeu/2ndStory-Services
- **Energy-at-Wholesale** → https://github.com/justindbilyeu/Energy-at-Wholesale
- **eMSSC2** → https://github.com/justindbilyeu/eMSSC2

---

## What’s New
Auto-updated daily: **[docs/whats-new.md](docs/whats-new.md)**

## Books (coming soon)
Curated reading list &amp; notes: **[docs/books.md](docs/books.md)**

---

## Architectural map

```mermaid
mindmap
  root((Open Lab Hub))
    Physicists &amp; Theorists
      Resonance_Geometry
      ResonanceGeometry
      Geometric-Plasticity-
      REAL
    Climate Tech &amp; Water
      eMSSC-squared
      SunShare-TriSource
      SunShare-Connect-Initiative
    Roofing &amp; Built Environment
      SCSRRS
      SCSRRS-TCR
      SCSRRS-TCRv1
      PM-QC-TCR
      stone-coated-steel-gpt
      RoofBot
      Live-Social-Shopping
      DoorKnockingMastery
      HOA-StormReadyAI
    AI Tools &amp; Research SW
      justasking
      ITPU
      Mega-Prompt
      Tech-but-Verify
    Business &amp; Ventures
      2ndStory-Services
      Energy-at-Wholesale
      eMSSC2
```

&gt; _This hub is the map; each repo is the territory._
```

---

## 2) Pages site (homepage updated + Books page + What’s New page)

**# path: docs/index.md**
```markdown
---
title: Justin Bilyeu — Open Lab
description: Choose your own adventure through my projects.
---

# Choose Your Own Adventure

Welcome. Pick a path to jump straight in:

&lt;div style=&quot;display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;margin:24px 0;&quot;&gt;
  &lt;div style=&quot;border:1px solid #e5e7eb;border-radius:12px;padding:16px;&quot;&gt;
    &lt;h3&gt;🧠 Physicists &amp; Theorists&lt;/h3&gt;
    &lt;ul&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/Resonance_Geometry&quot;&gt;Resonance_Geometry&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/ResonanceGeometry&quot;&gt;ResonanceGeometry&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/Geometric-Plasticity-&quot;&gt;Geometric-Plasticity-&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/REAL&quot;&gt;REAL&lt;/a&gt;&lt;/li&gt;
    &lt;/ul&gt;
  &lt;/div&gt;
  &lt;div style=&quot;border:1px solid #e5e7eb;border-radius:12px;padding:16px;&quot;&gt;
    &lt;h3&gt;🌞 Climate Tech &amp; Water&lt;/h3&gt;
    &lt;ul&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/eMSSC-squared&quot;&gt;eMSSC-squared&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/SunShare-TriSource&quot;&gt;SunShare-TriSource&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/SunShare-Connect-Initiative&quot;&gt;SunShare-Connect-Initiative&lt;/a&gt;&lt;/li&gt;
    &lt;/ul&gt;
  &lt;/div&gt;
  &lt;div style=&quot;border:1px solid #e5e7eb;border-radius:12px;padding:16px;&quot;&gt;
    &lt;h3&gt;🏠 Roofing &amp; Built Environment&lt;/h3&gt;
    &lt;ul&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/SCSRRS&quot;&gt;SCSRRS&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/SCSRRS-TCR&quot;&gt;SCSRRS-TCR&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/PM-QC-TCR&quot;&gt;PM-QC-TCR&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/stone-coated-steel-gpt&quot;&gt;stone-coated-steel-gpt&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/RoofBot&quot;&gt;RoofBot&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/Live-Social-Shopping&quot;&gt;Live-Social-Shopping&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/DoorKnockingMastery&quot;&gt;DoorKnockingMastery&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/HOA-StormReadyAI&quot;&gt;HOA-StormReadyAI&lt;/a&gt;&lt;/li&gt;
    &lt;/ul&gt;
  &lt;/div&gt;
  &lt;div style=&quot;border:1px solid #e5e7eb;border-radius:12px;padding:16px;&quot;&gt;
    &lt;h3&gt;🧰 AI Tools &amp; Research Software&lt;/h3&gt;
    &lt;ul&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/justasking&quot;&gt;JustAsking&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/ITPU&quot;&gt;ITPU&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/Mega-Prompt&quot;&gt;Mega-Prompt&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/Tech-but-Verify&quot;&gt;Tech-but-Verify&lt;/a&gt;&lt;/li&gt;
    &lt;/ul&gt;
  &lt;/div&gt;
  &lt;div style=&quot;border:1px solid #e5e7eb;border-radius:12px;padding:16px;&quot;&gt;
    &lt;h3&gt;🚀 Business &amp; Ventures&lt;/h3&gt;
    &lt;ul&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/2ndStory-Services&quot;&gt;2ndStory-Services&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/Energy-at-Wholesale&quot;&gt;Energy-at-Wholesale&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/eMSSC2&quot;&gt;eMSSC2&lt;/a&gt;&lt;/li&gt;
    &lt;/ul&gt;
  &lt;/div&gt;
&lt;/div&gt;

---

### What’s New
This page auto-updates daily with recent commits across my public repos:  
➡️ &lt;a href=&quot;whats-new.md&quot;&gt;whats-new.md&lt;/a&gt;

### Books
Reading list &amp; notes (placeholder for now):  
➡️ &lt;a href=&quot;books.md&quot;&gt;books.md&lt;/a&gt;
```

**# path: docs/books.md**
```markdown
# Books (Reading List &amp; Notes)

_Coming soon._  
I’ll collect key texts (physics, complex systems, water/climate tech, roofing/build, AI, and entrepreneurship) with short notes and “why it matters” blurbs.

Planned sections:
- Physics &amp; Math of Resonance
- Complex Systems &amp; Information
- Water, Energy &amp; Resilience
- Roofing &amp; The Built Environment
- AI, Collective Intelligence &amp; Design
- Business, Ops &amp; Sales

&gt; Suggest a book? Open an issue in this repo.
```

**# path: docs/whats-new.md**
```markdown
# What’s New (Auto-Updated)

This page lists recent commits across my public GitHub repositories (rolling 14 days).  
_Updated by a GitHub Action in `.github/workflows/whats-new.yml`._

If nothing shows below, there were no updates in the last two weeks.

*(First run will populate this automatically.)*
```

**# path: docs/_config.yml**
```yaml
title: &quot;Justin Bilyeu — Open Lab&quot;
description: &quot;Choose your own adventure through my projects.&quot;
theme: jekyll-theme-cayman
markdown: kramdown
kramdown:
  input: GFM
```

---

## 3) GitHub Action: auto-build “What’s New”

This workflow calls a small Python script that:
- lists all your **public** repos
- fetches commits from the last **14 days**
- writes a grouped summary to `docs/whats-new.md`
- commits only if the file changed

**No secrets needed** (public API). Runs daily and on demand.

**# path: .github/workflows/whats-new.yml**
```yaml
name: Update What&#x27;s New

on:
  workflow_dispatch:
  schedule:
    # Daily at 15:00 UTC (~9:00 AM America/Chicago; adjust if you like)
    - cron: &quot;0 15 * * *&quot;

permissions:
  contents: write

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Check out
        uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: &quot;3.11&quot;

      - name: Install deps
        run: |
          python -m pip install --upgrade pip
          pip install requests python-dateutil

      - name: Generate whats-new.md
        run: |
          python .github/scripts/update_whats_new.py

      - name: Commit changes (if any)
        run: |
          if [[ -n &quot;$(git status --porcelain)&quot; ]]; then
            git config user.name &quot;github-actions[bot]&quot;
            git config user.email &quot;github-actions[bot]@users.noreply.github.com&quot;
            git add docs/whats-new.md
            git commit -m &quot;chore: update whats-new.md&quot;
            git push
          else
            echo &quot;No changes to commit.&quot;
          fi
```

**# path: .github/scripts/update_whats_new.py**
```python
#!/usr/bin/env python3
import os, sys, textwrap, requests, datetime
from dateutil import parser as dtparser
from dateutil.tz import UTC

OWNER = &quot;justindbilyeu&quot;  # change if you fork under another user/org
EXCLUDE_REPOS = {&quot;Open-Lab&quot;, &quot;open-lab&quot;, &quot;JustinBilyeu-Open-Lab&quot;}

NOW = datetime.datetime.now(tz=UTC)
SINCE = NOW - datetime.timedelta(days=14)
SINCE_ISO = SINCE.isoformat()

def gh(url, params=None):
    &quot;&quot;&quot;Minimal GitHub GET helper (public endpoints).&quot;&quot;&quot;
    headers = {
        &quot;Accept&quot;: &quot;application/vnd.github+json&quot;,
        # Use GITHUB_TOKEN if present (helps with rate limits), else unauthenticated
        **({&quot;Authorization&quot;: f&quot;Bearer {os.environ.get(&#x27;GITHUB_TOKEN&#x27;)}&quot;} if os.environ.get(&quot;GITHUB_TOKEN&quot;) else {})
    }
    r = requests.get(url, headers=headers, params=params, timeout=30)
    r.raise_for_status()
    return r.json()

def list_public_repos(owner):
    repos = []
    page = 1
    while True:
        data = gh(f&quot;https://api.github.com/users/{owner}/repos&quot;, params={
            &quot;per_page&quot;: 100, &quot;page&quot;: page, &quot;sort&quot;: &quot;updated&quot;
        })
        if not data:
            break
        repos.extend(data)
        page += 1
    return [r for r in repos if not r.get(&quot;private&quot;)]

def list_recent_commits(owner, repo, since_iso):
    # Skip forks to avoid noise (optional)
    # if repo[&quot;fork&quot;]:
    #     return []
    name = repo[&quot;name&quot;]
    # commits API
    data = gh(f&quot;https://api.github.com/repos/{owner}/{name}/commits&quot;, params={&quot;since&quot;: since_iso, &quot;per_page&quot;: 100})
    commits = []
    for c in data:
        sha = c.get(&quot;sha&quot;)[:7]
        msg = (c.get(&quot;commit&quot;, {}).get(&quot;message&quot;) or &quot;&quot;).strip().splitlines()[0]
        html_url = c.get(&quot;html_url&quot;)
        date_str = c.get(&quot;commit&quot;, {}).get(&quot;author&quot;, {}).get(&quot;date&quot;) or c.get(&quot;commit&quot;, {}).get(&quot;committer&quot;, {}).get(&quot;date&quot;)
        dt = dtparser.parse(date_str).astimezone(UTC) if date_str else None
        commits.append({
            &quot;sha&quot;: sha, &quot;msg&quot;: msg, &quot;url&quot;: html_url, &quot;date&quot;: dt
        })
    # sort newest-first
    commits.sort(key=lambda x: x[&quot;date&quot;] or SINCE, reverse=True)
    return commits

def render_md(updates_by_repo):
    lines = []
    lines.append(&quot;# What’s New (Auto-Updated)\n&quot;)
    lines.append(f&quot;_Window: last 14 days; generated {NOW.strftime(&#x27;%Y-%m-%d %H:%M UTC&#x27;)}._\n&quot;)
    if not any(updates_by_repo.values()):
        lines.append(&quot;&gt; No updates in the last 14 days.\n&quot;)
        return &quot;\n&quot;.join(lines)

    for repo, commits in updates_by_repo.items():
        if not commits:
            continue
        lines.append(f&quot;## {repo}\n&quot;)
        for c in commits[:20]:
            when = c[&quot;date&quot;].strftime(&quot;%Y-%m-%d&quot;) if c[&quot;date&quot;] else &quot;&quot;
            lines.append(f&quot;- {when} · [{c[&#x27;sha&#x27;]}]({c[&#x27;url&#x27;]}) — {c[&#x27;msg&#x27;]}&quot;)
        lines.append(&quot;&quot;)  # blank line
    return &quot;\n&quot;.join(lines)

def main():
    repos = list_public_repos(OWNER)
    updates = {}
    for r in repos:
        name = r[&quot;name&quot;]
        if name in EXCLUDE_REPOS:
            continue
        commits = list_recent_commits(OWNER, r, SINCE_ISO)
        # only include if there are commits in window
        commits = [c for c in commits if c[&quot;date&quot;] and c[&quot;date&quot;] &gt;= SINCE]
        updates[name] = commits

    os.makedirs(&quot;docs&quot;, exist_ok=True)
    out = render_md(updates)
    with open(&quot;docs/whats-new.md&quot;, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
        f.write(out)

if __name__ == &quot;__main__&quot;:
    main()
```

---

## 4) Turn on Pages
Settings → **Pages** → Source: **Deploy from a branch** → Branch: `main`, Folder: `/docs`.

---

## Want extras?
- Add a **“Latest release”** tile pulling tags/releases.
- Include a **“This week I’m working on…”** blurb at the top of `whats-new.md`.
- Make “Books” interactive (short notes + 1-line takeaways per title).

If you want, tell me the exact repo name you choose for the hub and I’ll tailor the EXCLUDE list + links accordingly.

---

**user:**

I want to name the repo “JuiceWorks, an Open-Lab by Justin Bilyeu”

---

**assistant:**

Love the name. Small GitHub nuance: **repo names can’t have spaces or commas**, so use this slug:

- **Repository name:** `JuiceWorks-Open-Lab`  
- **Description (free text):** `JuiceWorks, an Open-Lab by Justin Bilyeu`

Below are drop-in files updated with the new branding, **“Choose Your Own Adventure”** vibe, a **Books** page, and the auto-updated **What’s New** page.

---

## 1) README (hub map)

**# path: `README.md`**
```markdown
# JuiceWorks — Open-Lab by Justin Bilyeu
_Choose Your Own Adventure through my work: physics → climate-tech → roofing → AI._

[![Physicists &amp; Theorists](https://img.shields.io/badge/Physicists_%26_Theorists-%E2%86%93-blue)](#physicists--theorists)
[![Climate Tech &amp; Water](https://img.shields.io/badge/Climate_Tech_%26_Water-%E2%86%93-brightgreen)](#climate-tech--water)
[![Roofing &amp; Built Env](https://img.shields.io/badge/Roofing_%26_Built_Env-%E2%86%93-orange)](#roofing--built-environment)
[![AI Tools &amp; Research SW](https://img.shields.io/badge/AI_Tools_%26_Research_SW-%E2%86%93-purple)](#ai-tools--research-software)
[![Business &amp; Ventures](https://img.shields.io/badge/Business_%26_Ventures-%E2%86%93-lightgrey)](#business--ventures)
[![What’s New](https://img.shields.io/badge/What%E2%80%99s_New-auto--updated-informational)](docs/whats-new.md)
[![Books](https://img.shields.io/badge/Books-reading_list-plum)](docs/books.md)

---

## Featured (start here)
- **Resonance_Geometry** — core research on resonance dynamics and phase behavior.  
  → https://github.com/justindbilyeu/Resonance_Geometry
- **SCSRRS** — Solar-Connected Storm-Resistant Roofing System (engineering, ROI, docs).  
  → https://github.com/justindbilyeu/SCSRRS
- **eMSSC-squared** — open blueprint for resilient water/soil systems (solar desal + microbial).  
  → https://github.com/justindbilyeu/eMSSC-squared
- **JustAsking** — multi-LLM “idea resonator” tool (parallel prompts, synthesis).  
  → https://github.com/justindbilyeu/justasking

---

## Physicists &amp; Theorists
- **Resonance_Geometry** → https://github.com/justindbilyeu/Resonance_Geometry
- **ResonanceGeometry** → https://github.com/justindbilyeu/ResonanceGeometry
- **Geometric-Plasticity-** → https://github.com/justindbilyeu/Geometric-Plasticity-
- **REAL** → https://github.com/justindbilyeu/REAL

## Climate Tech &amp; Water
- **eMSSC-squared** → https://github.com/justindbilyeu/eMSSC-squared
- **SunShare-TriSource** → https://github.com/justindbilyeu/SunShare-TriSource
- **SunShare-Connect-Initiative** → https://github.com/justindbilyeu/SunShare-Connect-Initiative

## Roofing &amp; Built Environment
- **SCSRRS** → https://github.com/justindbilyeu/SCSRRS
- **SCSRRS-TCR** → https://github.com/justindbilyeu/SCSRRS-TCR
- **SCSRRS-TCRv1** → https://github.com/justindbilyeu/SCSRRS-TCRv1
- **PM-QC-TCR** → https://github.com/justindbilyeu/PM-QC-TCR
- **stone-coated-steel-gpt** → https://github.com/justindbilyeu/stone-coated-steel-gpt
- **RoofBot** → https://github.com/justindbilyeu/RoofBot
- **Live-Social-Shopping** → https://github.com/justindbilyeu/Live-Social-Shopping
- **DoorKnockingMastery** → https://github.com/justindbilyeu/DoorKnockingMastery
- **HOA-StormReadyAI** → https://github.com/justindbilyeu/HOA-StormReadyAI

## AI Tools &amp; Research Software
- **JustAsking** → https://github.com/justindbilyeu/justasking
- **ITPU** → https://github.com/justindbilyeu/ITPU
- **Mega-Prompt** → https://github.com/justindbilyeu/Mega-Prompt
- **Tech-but-Verify** → https://github.com/justindbilyeu/Tech-but-Verify

## Business &amp; Ventures
- **2ndStory-Services** → https://github.com/justindbilyeu/2ndStory-Services
- **Energy-at-Wholesale** → https://github.com/justindbilyeu/Energy-at-Wholesale
- **eMSSC2** → https://github.com/justindbilyeu/eMSSC2

---

## What’s New
Auto-updated daily: **[docs/whats-new.md](docs/whats-new.md)**

## Books (coming soon)
Curated reading list &amp; notes: **[docs/books.md](docs/books.md)**

---

## Architectural map

```mermaid
mindmap
  root((JuiceWorks — Open-Lab))
    Physicists &amp; Theorists
      Resonance_Geometry
      ResonanceGeometry
      Geometric-Plasticity-
      REAL
    Climate Tech &amp; Water
      eMSSC-squared
      SunShare-TriSource
      SunShare-Connect-Initiative
    Roofing &amp; Built Environment
      SCSRRS
      SCSRRS-TCR
      SCSRRS-TCRv1
      PM-QC-TCR
      stone-coated-steel-gpt
      RoofBot
      Live-Social-Shopping
      DoorKnockingMastery
      HOA-StormReadyAI
    AI Tools &amp; Research SW
      justasking
      ITPU
      Mega-Prompt
      Tech-but-Verify
    Business &amp; Ventures
      2ndStory-Services
      Energy-at-Wholesale
      eMSSC2
```

&gt; _This hub is the map; each repo is the territory._
```

---

## 2) Pages content (homepage + Books + What’s New)

**# path: `docs/index.md`**
```markdown
---
title: JuiceWorks — Open-Lab by Justin Bilyeu
description: Choose your own adventure through my projects.
---

# Choose Your Own Adventure

Welcome. Pick a path to jump straight in:

&lt;div style=&quot;display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;margin:24px 0;&quot;&gt;
  &lt;div style=&quot;border:1px solid #e5e7eb;border-radius:12px;padding:16px;&quot;&gt;
    &lt;h3&gt;🧠 Physicists &amp; Theorists&lt;/h3&gt;
    &lt;ul&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/Resonance_Geometry&quot;&gt;Resonance_Geometry&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/ResonanceGeometry&quot;&gt;ResonanceGeometry&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/Geometric-Plasticity-&quot;&gt;Geometric-Plasticity-&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/REAL&quot;&gt;REAL&lt;/a&gt;&lt;/li&gt;
    &lt;/ul&gt;
  &lt;/div&gt;
  &lt;div style=&quot;border:1px solid #e5e7eb;border-radius:12px;padding:16px;&quot;&gt;
    &lt;h3&gt;🌞 Climate Tech &amp; Water&lt;/h3&gt;
    &lt;ul&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/eMSSC-squared&quot;&gt;eMSSC-squared&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/SunShare-TriSource&quot;&gt;SunShare-TriSource&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/SunShare-Connect-Initiative&quot;&gt;SunShare-Connect-Initiative&lt;/a&gt;&lt;/li&gt;
    &lt;/ul&gt;
  &lt;/div&gt;
  &lt;div style=&quot;border:1px solid #e5e7eb;border-radius:12px;padding:16px;&quot;&gt;
    &lt;h3&gt;🏠 Roofing &amp; Built Environment&lt;/h3&gt;
    &lt;ul&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/SCSRRS&quot;&gt;SCSRRS&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/SCSRRS-TCR&quot;&gt;SCSRRS-TCR&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/PM-QC-TCR&quot;&gt;PM-QC-TCR&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/stone-coated-steel-gpt&quot;&gt;stone-coated-steel-gpt&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/RoofBot&quot;&gt;RoofBot&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/Live-Social-Shopping&quot;&gt;Live-Social-Shopping&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/DoorKnockingMastery&quot;&gt;DoorKnockingMastery&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/HOA-StormReadyAI&quot;&gt;HOA-StormReadyAI&lt;/a&gt;&lt;/li&gt;
    &lt;/ul&gt;
  &lt;/div&gt;
  &lt;div style=&quot;border:1px solid #e5e7eb;border-radius:12px;padding:16px;&quot;&gt;
    &lt;h3&gt;🧰 AI Tools &amp; Research Software&lt;/h3&gt;
    &lt;ul&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/justasking&quot;&gt;JustAsking&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/ITPU&quot;&gt;ITPU&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/Mega-Prompt&quot;&gt;Mega-Prompt&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/Tech-but-Verify&quot;&gt;Tech-but-Verify&lt;/a&gt;&lt;/li&gt;
    &lt;/ul&gt;
  &lt;/div&gt;
  &lt;div style=&quot;border:1px solid #e5e7eb;border-radius:12px;padding:16px;&quot;&gt;
    &lt;h3&gt;🚀 Business &amp; Ventures&lt;/h3&gt;
    &lt;ul&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/2ndStory-Services&quot;&gt;2ndStory-Services&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/Energy-at-Wholesale&quot;&gt;Energy-at-Wholesale&lt;/a&gt;&lt;/li&gt;
      &lt;li&gt;&lt;a href=&quot;https://github.com/justindbilyeu/eMSSC2&quot;&gt;eMSSC2&lt;/a&gt;&lt;/li&gt;
    &lt;/ul&gt;
  &lt;/div&gt;
&lt;/div&gt;

---

### What’s New
This page auto-updates daily with recent commits across my public repos:  
➡️ &lt;a href=&quot;whats-new.md&quot;&gt;whats-new.md&lt;/a&gt;

### Books
Reading list &amp; notes (placeholder for now):  
➡️ &lt;a href=&quot;books.md&quot;&gt;books.md&lt;/a&gt;
```

**# path: `docs/books.md`**
```markdown
# Books (Reading List &amp; Notes)

_Coming soon._  
I’ll collect key texts (physics, complex systems, water/climate tech, roofing/build, AI, and entrepreneurship) with short notes and “why it matters”.

Planned sections:
- Physics &amp; Math of Resonance
- Complex Systems &amp; Information
- Water, Energy &amp; Resilience
- Roofing &amp; The Built Environment
- AI, Collective Intelligence &amp; Design
- Business, Ops &amp; Sales

&gt; Suggest a book? Open an issue in this repo.
```

**# path: `docs/whats-new.md`**
```markdown
# What’s New (Auto-Updated)

This page lists recent commits across my public GitHub repositories (rolling 14 days).  
_Updated by a GitHub Action in `.github/workflows/whats-new.yml`._

If nothing shows below, there were no updates in the last two weeks.

*(First run will populate this automatically.)*
```

**# path: `docs/_config.yml`**
```yaml
title: &quot;JuiceWorks — Open-Lab by Justin Bilyeu&quot;
description: &quot;Choose your own adventure through my projects.&quot;
theme: jekyll-theme-cayman
markdown: kramdown
kramdown:
  input: GFM
```

---

## 3) GitHub Action for “What’s New” (owner + excludes set)

**# path: `.github/workflows/whats-new.yml`**
```yaml
name: Update What&#x27;s New

on:
  workflow_dispatch:
  schedule:
    # Daily at 15:00 UTC (~10:00 AM America/Chicago while DST is active)
    - cron: &quot;0 15 * * *&quot;

permissions:
  contents: write

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Check out
        uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: &quot;3.11&quot;

      - name: Install deps
        run: |
          python -m pip install --upgrade pip
          pip install requests python-dateutil

      - name: Generate whats-new.md
        run: |
          python .github/scripts/update_whats_new.py

      - name: Commit changes (if any)
        run: |
          if [[ -n &quot;$(git status --porcelain)&quot; ]]; then
            git config user.name &quot;github-actions[bot]&quot;
            git config user.email &quot;github-actions[bot]@users.noreply.github.com&quot;
            git add docs/whats-new.md
            git commit -m &quot;chore: update whats-new.md&quot;
            git push
          else
            echo &quot;No changes to commit.&quot;
          fi
```

**# path: `.github/scripts/update_whats_new.py`**
```python
#!/usr/bin/env python3
import os, requests, datetime
from dateutil import parser as dtparser
from dateutil.tz import UTC

OWNER = &quot;justindbilyeu&quot;
EXCLUDE_REPOS = {&quot;JuiceWorks-Open-Lab&quot;, &quot;juiceworks-open-lab&quot;, &quot;JuiceWorks&quot;}

NOW = datetime.datetime.now(tz=UTC)
SINCE = NOW - datetime.timedelta(days=14)
SINCE_ISO = SINCE.isoformat()

def gh(url, params=None):
    headers = {&quot;Accept&quot;: &quot;application/vnd.github+json&quot;}
    token = os.environ.get(&quot;GITHUB_TOKEN&quot;)
    if token:
        headers[&quot;Authorization&quot;] = f&quot;Bearer {token}&quot;
    r = requests.get(url, headers=headers, params=params, timeout=30)
    r.raise_for_status()
    return r.json()

def list_public_repos(owner):
    repos, page = [], 1
    while True:
        data = gh(f&quot;https://api.github.com/users/{owner}/repos&quot;,
                  params={&quot;per_page&quot;: 100, &quot;page&quot;: page, &quot;sort&quot;: &quot;updated&quot;})
        if not data:
            break
        repos.extend(data)
        page += 1
    return [r for r in repos if not r.get(&quot;private&quot;)]

def list_recent_commits(owner, repo, since_iso):
    name = repo[&quot;name&quot;]
    commits_api = f&quot;https://api.github.com/repos/{owner}/{name}/commits&quot;
    data = gh(commits_api, params={&quot;since&quot;: since_iso, &quot;per_page&quot;: 100})
    commits = []
    for c in data:
        sha = (c.get(&quot;sha&quot;) or &quot;&quot;)[:7]
        msg = (c.get(&quot;commit&quot;, {}).get(&quot;message&quot;) or &quot;&quot;).strip().splitlines()[0]
        url = c.get(&quot;html_url&quot;) or &quot;&quot;
        date_str = (c.get(&quot;commit&quot;, {}).get(&quot;author&quot;, {}) or {}).get(&quot;date&quot;) \
                   or (c.get(&quot;commit&quot;, {}).get(&quot;committer&quot;, {}) or {}).get(&quot;date&quot;)
        dt = dtparser.parse(date_str).astimezone(UTC) if date_str else None
        commits.append({&quot;sha&quot;: sha, &quot;msg&quot;: msg, &quot;url&quot;: url, &quot;date&quot;: dt})
    commits.sort(key=lambda x: x[&quot;date&quot;] or SINCE, reverse=True)
    return [c for c in commits if c[&quot;date&quot;] and c[&quot;date&quot;] &gt;= SINCE]

def render_md(updates_by_repo):
    lines = []
    lines.append(&quot;# What’s New (Auto-Updated)\n&quot;)
    lines.append(f&quot;_Window: last 14 days; generated {NOW.strftime(&#x27;%Y-%m-%d %H:%M UTC&#x27;)}._\n&quot;)
    any_updates = any(updates_by_repo.values())
    if not any_updates:
        lines.append(&quot;&gt; No updates in the last 14 days.\n&quot;)
        return &quot;\n&quot;.join(lines)

    for repo, commits in updates_by_repo.items():
        if not commits:
            continue
        lines.append(f&quot;## {repo}\n&quot;)
        for c in commits[:20]:
            when = c[&quot;date&quot;].strftime(&quot;%Y-%m-%d&quot;) if c[&quot;date&quot;] else &quot;&quot;
            lines.append(f&quot;- {when} · [{c[&#x27;sha&#x27;]}]({c[&#x27;url&#x27;]}) — {c[&#x27;msg&#x27;]}&quot;)
        lines.append(&quot;&quot;)  # blank line
    return &quot;\n&quot;.join(lines)

def main():
    repos = list_public_repos(OWNER)
    updates = {}
    for r in repos:
        name = r[&quot;name&quot;]
        if name in EXCLUDE_REPOS:
            continue
        updates[name] = list_recent_commits(OWNER, r, SINCE_ISO)

    os.makedirs(&quot;docs&quot;, exist_ok=True)
    with open(&quot;docs/whats-new.md&quot;, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
        f.write(render_md(updates))

if __name__ == &quot;__main__&quot;:
    main()
```

---

## 4) Turn on Pages
**Settings → Pages → Source:** “Deploy from a branch” → Branch: `main` → Folder: `/docs`.  
Your site URL will be `https://justindbilyeu.github.io/JuiceWorks-Open-Lab/`.

---

## Nice-to-haves (optional)
- Add repo topics (e.g., `open-lab`, `choose-your-own-adventure`, `resonance-geometry`, `roofing`, `climate-tech`, `ai-tools`) so GitHub surfaces it better.
- Add a **social preview** image (Settings → Social preview) with the JuiceWorks branding.
- When you’re ready, I can draft the **Books** list with starter titles for each lane.

Want me to also add a one-click “Contribute” section (good first issues across your repos) on the homepage next?

---

**user:**

We can use Claude’s code bot to create and push PR’s in the repo. I will create it and bring you the link

---

**assistant:**

Perfect. When you drop the link, I’ll review PRs live—but you don’t have to wait on me to get started. Here’s a **ready-made “Bootstrapping PR”** Claude’s code bot can open on `JuiceWorks-Open-Lab` that sets up: Pages, “Choose Your Own Adventure” hub, **What’s New** auto-updates, a **Books** stub, CI for docs lint + link checking, and contributor plumbing (PR/issue templates, CODEOWNERS, labeler, and a “Contribute” page that auto-pulls good-first-issues across your repos).

You/Claude can copy–paste these files into a branch like `feat/hub-bootstrap` and open a PR titled:
**“feat: bootstrap JuiceWorks hub (Pages, What’s New, Books, CI, templates)”**

---

## 1) Hub pages (README + site)

```markdown
# path: README.md
# JuiceWorks — Open-Lab by Justin Bilyeu
_Choose Your Own Adventure through my work: physics → climate-tech → roofing → AI._

[![Physicists &amp; Theorists](https://img.shields.io/badge/Physicists_%26_Theorists-%E2%86%93-blue)](#physicists--theorists)
[![Climate Tech &amp; Water](https://img.shields.io/badge/Climate_Tech_%26_Water-%E2%86%93-brightgreen)](#climate-tech--water)
[![Roofing &amp; Built Env](https://img.shields.io/badge/Roofing_%26_Built_Env-%E2%86%93-orange)](#roofing--built-environment)
[![AI Tools &amp; Research SW](https://img.shields.io/badge/AI_Tools_%26_Research_SW-%E2%86%93-purple)](#ai-tools--research-software)
[![Business &amp; Ventures](https://img.shields.io/badge/Business_%26_Ventures-%E2%86%93-lightgrey)](#business--ventures)
[![What’s New](https://img.shields.io/badge/What%E2%80%99s_New-auto--updated-informational)](docs/whats-new.md)
[![Books](https://img.shields.io/badge/Books-reading_list-plum)](docs/books.md)
[![Contribute](https://img.shields.io/badge/Contribute-good_first_issues-blueviolet)](docs/contribute.md)

## Featured (start here)
- **Resonance_Geometry** — https://github.com/justindbilyeu/Resonance_Geometry  
- **SCSRRS** — https://github.com/justindbilyeu/SCSRRS  
- **eMSSC-squared** — https://github.com/justindbilyeu/eMSSC-squared  
- **JustAsking** — https://github.com/justindbilyeu/justasking

## Physicists &amp; Theorists
- Resonance_Geometry · ResonanceGeometry · Geometric-Plasticity- · REAL

## Climate Tech &amp; Water
- eMSSC-squared · SunShare-TriSource · SunShare-Connect-Initiative

## Roofing &amp; Built Environment
- SCSRRS · SCSRRS-TCR · SCSRRS-TCRv1 · PM-QC-TCR · stone-coated-steel-gpt · RoofBot · Live-Social-Shopping · DoorKnockingMastery · HOA-StormReadyAI

## AI Tools &amp; Research Software
- justasking · ITPU · Mega-Prompt · Tech-but-Verify

## Business &amp; Ventures
- 2ndStory-Services · Energy-at-Wholesale · eMSSC2

&gt; This hub is the map; each repo is the territory.
```

```markdown
# path: docs/index.md
---
title: JuiceWorks — Open-Lab by Justin Bilyeu
description: Choose your own adventure through my projects.
---

# Choose Your Own Adventure

- 🧠 **Physicists &amp; Theorists** → Resonance_Geometry, ResonanceGeometry, Geometric-Plasticity-, REAL  
- 🌞 **Climate Tech &amp; Water** → eMSSC-squared, SunShare-TriSource, SunShare-Connect-Initiative  
- 🏠 **Roofing &amp; Built Environment** → SCSRRS, SCSRRS-TCR, PM-QC-TCR, stone-coated-steel-gpt, RoofBot, Live-Social-Shopping, DoorKnockingMastery, HOA-StormReadyAI  
- 🧰 **AI Tools &amp; Research SW** → justasking, ITPU, Mega-Prompt, Tech-but-Verify  
- 🚀 **Business &amp; Ventures** → 2ndStory-Services, Energy-at-Wholesale, eMSSC2

---

### What’s New
Auto-updated daily with recent commits: 👉 [whats-new.md](whats-new.md)

### Books
Reading list &amp; notes: 👉 [books.md](books.md)

### Contribute
Fresh “good first issues” across my repos: 👉 [contribute.md](contribute.md)
```

```markdown
# path: docs/books.md
# Books (Reading List &amp; Notes)

_Coming soon._ I’ll collect key texts with short notes and “why it matters.”

Planned shelves:
- Physics &amp; Math of Resonance
- Complex Systems &amp; Information
- Water, Energy &amp; Resilience
- Roofing &amp; The Built Environment
- AI, Collective Intelligence &amp; Design
- Business, Ops &amp; Sales
```

```markdown
# path: docs/whats-new.md
# What’s New (Auto-Updated)

This page lists recent commits across my public GitHub repositories (rolling 14 days).  
_Updated by a GitHub Action in `.github/workflows/whats-new.yml`._

*(First run will populate this automatically.)*
```

```yaml
# path: docs/_config.yml
title: &quot;JuiceWorks — Open-Lab by Justin Bilyeu&quot;
description: &quot;Choose your own adventure through my projects.&quot;
theme: jekyll-theme-cayman
markdown: kramdown
kramdown:
  input: GFM
```

---

## 2) CI &amp; automations (What’s New + Contribute + docs quality)

```yaml
# path: .github/workflows/whats-new.yml
name: Update What&#x27;s New
on:
  workflow_dispatch:
  schedule:
    - cron: &quot;0 15 * * *&quot;  # daily ~10:00 AM America/Chicago
permissions:
  contents: write
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: &quot;3.11&quot; }
      - run: |
          python -m pip install --upgrade pip
          pip install requests python-dateutil
      - run: python .github/scripts/update_whats_new.py
      - run: |
          if [[ -n &quot;$(git status --porcelain)&quot; ]]; then
            git config user.name &quot;github-actions[bot]&quot;
            git config user.email &quot;github-actions[bot]@users.noreply.github.com&quot;
            git add docs/whats-new.md
            git commit -m &quot;chore: update whats-new.md&quot;
            git push
          fi
```

```python
# path: .github/scripts/update_whats_new.py
#!/usr/bin/env python3
import os, requests, datetime
from dateutil import parser as dtparser
from dateutil.tz import UTC

OWNER = &quot;justindbilyeu&quot;
EXCLUDE = {&quot;JuiceWorks-Open-Lab&quot;, &quot;juiceworks-open-lab&quot;, &quot;JuiceWorks&quot;}

NOW = datetime.datetime.now(tz=UTC)
SINCE = NOW - datetime.timedelta(days=14)

def gh(url, params=None):
    h={&quot;Accept&quot;:&quot;application/vnd.github+json&quot;}
    tok=os.environ.get(&quot;GITHUB_TOKEN&quot;)
    if tok: h[&quot;Authorization&quot;]=f&quot;Bearer {tok}&quot;
    r=requests.get(url,headers=h,params=params,timeout=30); r.raise_for_status(); return r.json()

def public_repos(owner):
    out=[]; page=1
    while True:
        data=gh(f&quot;https://api.github.com/users/{owner}/repos&quot;,{&quot;per_page&quot;:100,&quot;page&quot;:page,&quot;sort&quot;:&quot;updated&quot;})
        if not data: break
        out+= [r for r in data if not r.get(&quot;private&quot;)]
        page+=1
    return [r for r in out if r[&quot;name&quot;] not in EXCLUDE]

def recent_commits(repo):
    name=repo[&quot;name&quot;]
    data=gh(f&quot;https://api.github.com/repos/{OWNER}/{name}/commits&quot;,{&quot;since&quot;:SINCE.isoformat(),&quot;per_page&quot;:100})
    commits=[]
    for c in data:
        msg=(c.get(&quot;commit&quot;,{}).get(&quot;message&quot;) or &quot;&quot;).splitlines()[0]
        date_str=c.get(&quot;commit&quot;,{}).get(&quot;author&quot;,{}).get(&quot;date&quot;) or c.get(&quot;commit&quot;,{}).get(&quot;committer&quot;,{}).get(&quot;date&quot;)
        dt=dtparser.parse(date_str).astimezone(UTC) if date_str else None
        commits.append({&quot;sha&quot;:(c.get(&quot;sha&quot;) or &quot;&quot;)[:7],&quot;msg&quot;:msg,&quot;url&quot;:c.get(&quot;html_url&quot;) or &quot;&quot;, &quot;date&quot;:dt})
    commits=[x for x in commits if x[&quot;date&quot;] and x[&quot;date&quot;]&gt;=SINCE]
    commits.sort(key=lambda x:x[&quot;date&quot;], reverse=True)
    return commits

def render(updates):
    lines=[&quot;# What’s New (Auto-Updated)\n&quot;, f&quot;_Window: last 14 days; generated {NOW.strftime(&#x27;%Y-%m-%d %H:%M UTC&#x27;)}._\n&quot;]
    if not any(updates.values()):
        lines.append(&quot;&gt; No updates in the last 14 days.\n&quot;); return &quot;\n&quot;.join(lines)
    for repo, cs in updates.items():
        if not cs: continue
        lines.append(f&quot;## {repo}\n&quot;)
        for c in cs[:20]:
            when=c[&quot;date&quot;].strftime(&quot;%Y-%m-%d&quot;)
            lines.append(f&quot;- {when} · [{c[&#x27;sha&#x27;]}]({c[&#x27;url&#x27;]}) — {c[&#x27;msg&#x27;]}&quot;)
        lines.append(&quot;&quot;)
    return &quot;\n&quot;.join(lines)

def main():
    updates={}
    for r in public_repos(OWNER):
        updates[r[&quot;name&quot;]] = recent_commits(r)
    os.makedirs(&quot;docs&quot;, exist_ok=True)
    with open(&quot;docs/whats-new.md&quot;,&quot;w&quot;,encoding=&quot;utf-8&quot;) as f:
        f.write(render(updates))

if __name__==&quot;__main__&quot;: main()
```

```yaml
# path: .github/workflows/contribute.yml
name: Update Contribute (Good First Issues)
on:
  workflow_dispatch:
  schedule:
    - cron: &quot;15 15 * * *&quot;
permissions:
  contents: write
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: &quot;3.11&quot; }
      - run: |
          python -m pip install --upgrade pip
          pip install requests
      - run: python .github/scripts/update_contribute.py
      - run: |
          if [[ -n &quot;$(git status --porcelain)&quot; ]]; then
            git config user.name &quot;github-actions[bot]&quot;
            git config user.email &quot;github-actions[bot]@users.noreply.github.com&quot;
            git add docs/contribute.md
            git commit -m &quot;chore: refresh contribute.md (good first issues)&quot;
            git push
          fi
```

```python
# path: .github/scripts/update_contribute.py
#!/usr/bin/env python3
import os, requests
OWNER=&quot;justindbilyeu&quot;
LABELS=(&quot;good first issue&quot;,&quot;help wanted&quot;)
EXCLUDE={&quot;JuiceWorks-Open-Lab&quot;,&quot;juiceworks-open-lab&quot;,&quot;JuiceWorks&quot;}

def gh(url, params=None):
    h={&quot;Accept&quot;:&quot;application/vnd.github+json&quot;}
    tok=os.environ.get(&quot;GITHUB_TOKEN&quot;)
    if tok: h[&quot;Authorization&quot;]=f&quot;Bearer {tok}&quot;
    r=requests.get(url,headers=h,params=params,timeout=30); r.raise_for_status(); return r.json()

def repos():
    out=[]; p=1
    while True:
        data=gh(f&quot;https://api.github.com/users/{OWNER}/repos&quot;,{&quot;per_page&quot;:100,&quot;page&quot;:p,&quot;sort&quot;:&quot;updated&quot;})
        if not data: break
        out+= [r for r in data if not r.get(&quot;private&quot;)]
        p+=1
    return [r for r in out if r[&quot;name&quot;] not in EXCLUDE]

def issues(repo):
    name=repo[&quot;name&quot;]; arr=[]
    for lab in LABELS:
        data=gh(f&quot;https://api.github.com/repos/{OWNER}/{name}/issues&quot;,
                {&quot;state&quot;:&quot;open&quot;,&quot;labels&quot;:lab,&quot;per_page&quot;:50})
        for it in data:
            if &quot;pull_request&quot; in it: continue
            arr.append({&quot;repo&quot;:name, &quot;title&quot;:it[&quot;title&quot;], &quot;url&quot;:it[&quot;html_url&quot;]})
    return arr

def main():
    buckets={}
    for r in repos():
        items=issues(r)
        if items: buckets[r[&quot;name&quot;]]=items
    lines=[&quot;# Contribute (Good First Issues)\n&quot;,
           &quot;Issues labeled **good first issue** or **help wanted** across my public repos.\n&quot;]
    if not buckets:
        lines.append(&quot;&gt; No starter issues found. Check back soon.\n&quot;)
    else:
        for repo, items in sorted(buckets.items()):
            lines.append(f&quot;## {repo}\n&quot;)
            for it in items[:10]:
                lines.append(f&quot;- [{it[&#x27;title&#x27;]}]({it[&#x27;url&#x27;]})&quot;)
            lines.append(&quot;&quot;)
    os.makedirs(&quot;docs&quot;, exist_ok=True)
    with open(&quot;docs/contribute.md&quot;,&quot;w&quot;,encoding=&quot;utf-8&quot;) as f:
        f.write(&quot;\n&quot;.join(lines))

if __name__==&quot;__main__&quot;: main()
```

```markdown
# path: docs/contribute.md
# Contribute (Good First Issues)

This page will auto-populate with beginner-friendly issues across my repos.  
*(First run will populate this automatically.)*
```

```yaml
# path: .github/workflows/docs-quality.yml
name: Docs Quality (markdownlint + link check + spell)
on:
  pull_request:
    paths: [&quot;**/*.md&quot;,&quot;docs/**&quot;,&quot;README.md&quot;,&quot;.github/**&quot;]
  push:
    branches: [&quot;main&quot;]
    paths: [&quot;**/*.md&quot;,&quot;docs/**&quot;,&quot;README.md&quot;,&quot;.github/**&quot;]
jobs:
  markdownlint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: markdownlint-cli
        uses: nosborn/github-action-markdown-cli@v3
        with:
          files: .
          config_file: &quot;.github/markdownlint.json&quot;
  linkcheck:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: lychee link checker
        uses: lycheeverse/lychee-action@v1
        with:
          args: --exclude-mail --max-redirects 5 --retry-wait-time 2 --timeout 20 --json lychee.json &quot;**/*.md&quot; &quot;docs/**/*.md&quot;
      - name: Upload lychee report
        uses: actions/upload-artifact@v4
        with: { name: lychee-report, path: lychee.json }
  spellcheck:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: |
          python -m pip install --upgrade pip
          pip install codespell
          codespell -S .git,*.png,*.jpg,*.svg,*.pdf,*.json -L teh,crate,aks -q 3
```

```json
# path: .github/markdownlint.json
{
  &quot;MD013&quot;: false,  // line length
  &quot;MD033&quot;: false,  // inline HTML
  &quot;MD041&quot;: false   // first line heading (allows badges first)
}
```

---

## 3) Collaboration plumbing (PR/issue templates, CODEOWNERS, labels)

```md
# path: .github/PULL_REQUEST_TEMPLATE.md
## Summary
Describe the change. Link related issues.

## Checklist
- [ ] Updates hub content (README/docs) if needed
- [ ] CI passes (docs quality + link check)
- [ ] Screenshots for visual changes (if any)
- [ ] “What’s New”/“Contribute” generators unaffected (or tested)

## Type
- [ ] Feature  [ ] Fix  [ ] Docs  [ ] Chore
```

```yaml
# path: .github/ISSUE_TEMPLATE/bug_report.yml
name: Bug report
description: Something&#x27;s broken in the hub
labels: [&quot;bug&quot;]
body:
  - type: textarea
    id: what
    attributes: { label: What happened?, placeholder: Describe the issue… }
    validations: { required: true }
  - type: input
    id: url
    attributes: { label: Link (if applicable) }
```

```yaml
# path: .github/ISSUE_TEMPLATE/feature_request.yml
name: Feature request
description: Propose an improvement to the hub
labels: [&quot;enhancement&quot;]
body:
  - type: textarea
    id: idea
    attributes: { label: Idea, placeholder: What do you want to add or change? }
    validations: { required: true }
```

```yaml
# path: .github/ISSUE_TEMPLATE/content_update.yml
name: Content update
description: Add/update links, Books entries, or repo routing
labels: [&quot;docs&quot;]
body:
  - type: textarea
    id: content
    attributes: { label: Update details, placeholder: What needs to change? }
    validations: { required: true }
```

```txt
# path: .github/CODEOWNERS
* @justindbilyeu
```

```yml
# path: .github/labeler.yml
docs:
  - changed-files:
      - any-glob-to-any-file: [&quot;**/*.md&quot;,&quot;docs/**&quot;]
ci:
  - changed-files:
      - any-glob-to-any-file: [&quot;.github/**&quot;]
```

```yml
# path: .github/workflows/labeler.yml
name: PR Labeler
on:
  pull_request_target:
    types: [opened,synchronize]
permissions:
  contents: read
  pull-requests: write
jobs:
  label:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/labeler@v5
        with:
          configuration-path: .github/labeler.yml
```

---

## 4) Pages: one manual step
After merging, in **Settings → Pages**: Source → **Deploy from a branch** → Branch `main`, Folder `/docs`.

---

## 5) Checklist for Claude’s Code Bot PR
- Create branch `feat/hub-bootstrap`
- Add all files above
- Open PR with title: **feat: bootstrap JuiceWorks hub (Pages, What’s New, Books, CI, templates)**
- PR body: include a short summary and the Pages step
- After merge: flip Pages setting (one-time)

---

When you share the repo link, I’ll sanity-check the PR diff and the Actions runs. If you want, I can also add a **“Latest Releases”** panel and a **social preview** image next.

---

**user:**

https://github.com/justindbilyeu/JuiceWorks-Open-Lab

---

**user:**

https://github.com/justindbilyeu/JuiceWorks-Open-Lab

---

**assistant:**

Perfect—saw the repo live. It’s brand-new with just a basic README and one commit, so we can drop in the hub scaffolding as a first PR. citeturn0view0

Here’s a ready-to-paste **Bootstrapping PR** for `JuiceWorks-Open-Lab` that sets up:
- “Choose Your Own Adventure” hub (README + Pages site)
- **Books** page (placeholder)
- **What’s New** page that auto-updates daily from all your public repos (GitHub Action + script)

You/Claude can create a branch like `feat/hub-bootstrap` and add these files.

---

## PR title
**feat: bootstrap JuiceWorks hub (Pages, What’s New, Books)**

## PR body (paste)
This PR bootstraps the JuiceWorks hub:
- README with “Choose Your Own Adventure” lanes
- GitHub Pages site under `/docs`
- Books placeholder (`docs/books.md`)
- Auto-generated “What’s New” (`docs/whats-new.md`) + daily Action
**One manual step after merge:** Settings → Pages → Source: *Deploy from a branch* → Branch: `main` → Folder: `/docs`.

---

## Files to add

### 1) README (hub map)

**path: `README.md`**
```markdown
# JuiceWorks — Open-Lab by Justin Bilyeu
_Choose Your Own Adventure through my work: physics → climate-tech → roofing → AI._

[![Physicists &amp; Theorists](https://img.shields.io/badge/Physicists_%26_Theorists-%E2%86%93-blue)](#physicists--theorists)
[![Climate Tech &amp; Water](https://img.shields.io/badge/Climate_Tech_%26_Water-%E2%86%93-brightgreen)](#climate-tech--water)
[![Roofing &amp; Built Env](https://img.shields.io/badge/Roofing_%26_Built_Env-%E2%86%93-orange)](#roofing--built-environment)
[![AI Tools &amp; Research SW](https://img.shields.io/badge/AI_Tools_%26_Research_SW-%E2%86%93-purple)](#ai-tools--research-software)
[![Business &amp; Ventures](https://img.shields.io/badge/Business_%26_Ventures-%E2%86%93-lightgrey)](#business--ventures)
[![What’s New](https://img.shields.io/badge/What%E2%80%99s_New-auto--updated-informational)](docs/whats-new.md)
[![Books](https://img.shields.io/badge/Books-reading_list-plum)](docs/books.md)

---

## Featured (start here)
- **Resonance_Geometry** — https://github.com/justindbilyeu/Resonance_Geometry  
- **SCSRRS** — https://github.com/justindbilyeu/SCSRRS  
- **eMSSC-squared** — https://github.com/justindbilyeu/eMSSC-squared  
- **JustAsking** — https://github.com/justindbilyeu/justasking

---

## Physicists &amp; Theorists
- **Resonance_Geometry** · **ResonanceGeometry** · **Geometric-Plasticity-** · **REAL**

## Climate Tech &amp; Water
- **eMSSC-squared** · **SunShare-TriSource** · **SunShare-Connect-Initiative**

## Roofing &amp; Built Environment
- **SCSRRS** · **SCSRRS-TCR** · **SCSRRS-TCRv1** · **PM-QC-TCR** · **stone-coated-steel-gpt** · **RoofBot** · **Live-Social-Shopping** · **DoorKnockingMastery** · **HOA-StormReadyAI**

## AI Tools &amp; Research Software
- **justasking** · **ITPU** · **Mega-Prompt** · **Tech-but-Verify**

## Business &amp; Ventures
- **2ndStory-Services** · **Energy-at-Wholesale** · **eMSSC2**

&gt; This hub is the map; each repo is the territory.
```

---

### 2) Pages site (homepage + Books + What’s New + config)

**path: `docs/index.md`**
```markdown
---
title: JuiceWorks — Open-Lab by Justin Bilyeu
description: Choose your own adventure through my projects.
---

# Choose Your Own Adventure

- 🧠 **Physicists &amp; Theorists** → Resonance_Geometry, ResonanceGeometry, Geometric-Plasticity-, REAL  
- 🌞 **Climate Tech &amp; Water** → eMSSC-squared, SunShare-TriSource, SunShare-Connect-Initiative  
- 🏠 **Roofing &amp; Built Environment** → SCSRRS, SCSRRS-TCR, PM-QC-TCR, stone-coated-steel-gpt, RoofBot, Live-Social-Shopping, DoorKnockingMastery, HOA-StormReadyAI  
- 🧰 **AI Tools &amp; Research SW** → justasking, ITPU, Mega-Prompt, Tech-but-Verify  
- 🚀 **Business &amp; Ventures** → 2ndStory-Services, Energy-at-Wholesale, eMSSC2

---

### What’s New
Auto-updated daily with recent commits: 👉 [whats-new.md](whats-new.md)

### Books
Reading list &amp; notes: 👉 [books.md](books.md)
```

**path: `docs/books.md`**
```markdown
# Books (Reading List &amp; Notes)

_Coming soon._ I’ll collect key texts with short notes and “why it matters.”

Planned shelves:
- Physics &amp; Math of Resonance
- Complex Systems &amp; Information
- Water, Energy &amp; Resilience
- Roofing &amp; The Built Environment
- AI, Collective Intelligence &amp; Design
- Business, Ops &amp; Sales

&gt; Suggest a book? Open an issue in this repo.
```

**path: `docs/whats-new.md`**
```markdown
# What’s New (Auto-Updated)

This page lists recent commits across my public GitHub repositories (rolling 14 days).  
_Updated by a GitHub Action in `.github/workflows/whats-new.yml`._

*(First run will populate this automatically.)*
```

**path: `docs/_config.yml`**
```yaml
title: &quot;JuiceWorks — Open-Lab by Justin Bilyeu&quot;
description: &quot;Choose your own adventure through my projects.&quot;
theme: jekyll-theme-cayman
markdown: kramdown
kramdown:
  input: GFM
```

---

### 3) GitHub Action + script for “What’s New”

**path: `.github/workflows/whats-new.yml`**
```yaml
name: Update What&#x27;s New
on:
  workflow_dispatch:
  schedule:
    - cron: &quot;0 15 * * *&quot;  # daily ~10:00 AM America/Chicago
permissions:
  contents: write
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: &quot;3.11&quot; }
      - run: |
          python -m pip install --upgrade pip
          pip install requests python-dateutil
      - run: python .github/scripts/update_whats_new.py
      - run: |
          if [[ -n &quot;$(git status --porcelain)&quot; ]]; then
            git config user.name &quot;github-actions[bot]&quot;
            git config user.email &quot;github-actions[bot]@users.noreply.github.com&quot;
            git add docs/whats-new.md
            git commit -m &quot;chore: update whats-new.md&quot;
            git push
          fi
```

**path: `.github/scripts/update_whats_new.py`**
```python
#!/usr/bin/env python3
import os, requests, datetime
from dateutil import parser as dtparser
from dateutil.tz import UTC

OWNER = &quot;justindbilyeu&quot;
EXCLUDE = {&quot;JuiceWorks-Open-Lab&quot;, &quot;juiceworks-open-lab&quot;, &quot;JuiceWorks&quot;}

NOW = datetime.datetime.now(tz=UTC)
SINCE = NOW - datetime.timedelta(days=14)

def gh(url, params=None):
    h={&quot;Accept&quot;:&quot;application/vnd.github+json&quot;}
    tok=os.environ.get(&quot;GITHUB_TOKEN&quot;)
    if tok: h[&quot;Authorization&quot;]=f&quot;Bearer {tok}&quot;
    r=requests.get(url,headers=h,params=params,timeout=30)
    r.raise_for_status()
    return r.json()

def public_repos(owner):
    out=[]; page=1
    while True:
        data=gh(f&quot;https://api.github.com/users/{owner}/repos&quot;,{&quot;per_page&quot;:100,&quot;page&quot;:page,&quot;sort&quot;:&quot;updated&quot;})
        if not data: break
        out+= [r for r in data if not r.get(&quot;private&quot;)]
        page+=1
    return [r for r in out if r[&quot;name&quot;] not in EXCLUDE]

def recent_commits(repo):
    name=repo[&quot;name&quot;]
    data=gh(f&quot;https://api.github.com/repos/{OWNER}/{name}/commits&quot;,{&quot;since&quot;:SINCE.isoformat(),&quot;per_page&quot;:100})
    commits=[]
    for c in data:
        msg=(c.get(&quot;commit&quot;,{}).get(&quot;message&quot;) or &quot;&quot;).splitlines()[0]
        date_str=c.get(&quot;commit&quot;,{}).get(&quot;author&quot;,{}).get(&quot;date&quot;) or c.get(&quot;commit&quot;,{}).get(&quot;committer&quot;,{}).get(&quot;date&quot;)
        dt=dtparser.parse(date_str).astimezone(UTC) if date_str else None
        commits.append({&quot;sha&quot;:(c.get(&quot;sha&quot;) or &quot;&quot;)[:7],&quot;msg&quot;:msg,&quot;url&quot;:c.get(&quot;html_url&quot;) or &quot;&quot;, &quot;date&quot;:dt})
    commits=[x for x in commits if x[&quot;date&quot;] and x[&quot;date&quot;]&gt;=SINCE]
    commits.sort(key=lambda x:x[&quot;date&quot;], reverse=True)
    return commits

def render(updates):
    lines=[&quot;# What’s New (Auto-Updated)\n&quot;,
           f&quot;_Window: last 14 days; generated {NOW.strftime(&#x27;%Y-%m-%d %H:%M UTC&#x27;)}._\n&quot;]
    if not any(updates.values()):
        lines.append(&quot;&gt; No updates in the last 14 days.\n&quot;)
        return &quot;\n&quot;.join(lines)
    for repo, cs in updates.items():
        if not cs: continue
        lines.append(f&quot;## {repo}\n&quot;)
        for c in cs[:20]:
            when=c[&quot;date&quot;].strftime(&quot;%Y-%m-%d&quot;)
            lines.append(f&quot;- {when} · [{c[&#x27;sha&#x27;]}]({c[&#x27;url&#x27;]}) — {c[&#x27;msg&#x27;]}&quot;)
        lines.append(&quot;&quot;)
    return &quot;\n&quot;.join(lines)

def main():
    updates={}
    for r in public_repos(OWNER):
        updates[r[&quot;name&quot;]] = recent_commits(r)
    os.makedirs(&quot;docs&quot;, exist_ok=True)
    with open(&quot;docs/whats-new.md&quot;,&quot;w&quot;,encoding=&quot;utf-8&quot;) as f:
        f.write(render(updates))

if __name__==&quot;__main__&quot;: main()
```

---

## After merge (one-time)
1) **Enable Pages:** Settings → Pages → Source: *Deploy from a branch* → `main` / `docs`.  
2) (Optional) Add repo topics: `open-lab`, `choose-your-own-adventure`, `resonance-geometry`, `roofing`, `climate-tech`, `ai-tools`.  
3) (Optional) Add a **social preview** image (Settings → Social preview).

---

If you want, I can prep a **follow-up PR** that adds a “Contribute” page (auto-pulls *good first issues* across your repos) and a docs quality CI.

---

**user:**

https://github.com/justindbilyeu/JuiceWorks-Open-Lab

---

**assistant:**

Nice—your repo is up and currently just has a README and one commit, so it’s a perfect blank slate for the hub PR. citeturn0view0

Here’s a single **copy-paste prompt for Claude’s code bot** to open a bootstrap PR that adds:
- “Choose Your Own Adventure” hub (README + `/docs` site)
- **Books** page (placeholder)
- **What’s New** page with a **daily** auto-update across all your public repos

---

### ✅ Paste this to Claude’s code bot

**Title:** `feat: bootstrap JuiceWorks hub (Pages, What’s New, Books)`

**Instructions to bot:**
Create branch `feat/hub-bootstrap`, add the files below with exact contents, commit, and open a PR with the title above. Do not modify other files.

```
# path: README.md
# JuiceWorks — Open-Lab by Justin Bilyeu
_Choose Your Own Adventure through my work: physics → climate-tech → roofing → AI._

[![Physicists &amp; Theorists](https://img.shields.io/badge/Physicists_%26_Theorists-%E2%86%93-blue)](#physicists--theorists)
[![Climate Tech &amp; Water](https://img.shields.io/badge/Climate_Tech_%26_Water-%E2%86%93-brightgreen)](#climate-tech--water)
[![Roofing &amp; Built Env](https://img.shields.io/badge/Roofing_%26_Built_Env-%E2%86%93-orange)](#roofing--built-environment)
[![AI Tools &amp; Research SW](https://img.shields.io/badge/AI_Tools_%26_Research_SW-%E2%86%93-purple)](#ai-tools--research-software)
[![Business &amp; Ventures](https://img.shields.io/badge/Business_%26_Ventures-%E2%86%93-lightgrey)](#business--ventures)
[![What’s New](https://img.shields.io/badge/What%E2%80%99s_New-auto--updated-informational)](docs/whats-new.md)
[![Books](https://img.shields.io/badge/Books-reading_list-plum)](docs/books.md)

## Featured (start here)
- **Resonance_Geometry** — https://github.com/justindbilyeu/Resonance_Geometry  
- **SCSRRS** — https://github.com/justindbilyeu/SCSRRS  
- **eMSSC-squared** — https://github.com/justindbilyeu/eMSSC-squared  
- **JustAsking** — https://github.com/justindbilyeu/justasking

## Physicists &amp; Theorists
- Resonance_Geometry · ResonanceGeometry · Geometric-Plasticity- · REAL

## Climate Tech &amp; Water
- eMSSC-squared · SunShare-TriSource · SunShare-Connect-Initiative

## Roofing &amp; Built Environment
- SCSRRS · SCSRRS-TCR · SCSRRS-TCRv1 · PM-QC-TCR · stone-coated-steel-gpt · RoofBot · Live-Social-Shopping · DoorKnockingMastery · HOA-StormReadyAI

## AI Tools &amp; Research Software
- justasking · ITPU · Mega-Prompt · Tech-but-Verify

## Business &amp; Ventures
- 2ndStory-Services · Energy-at-Wholesale · eMSSC2

&gt; This hub is the map; each repo is the territory.
```

```
# path: docs/index.md
---
title: JuiceWorks — Open-Lab by Justin Bilyeu
description: Choose your own adventure through my projects.
---

# Choose Your Own Adventure

- 🧠 **Physicists &amp; Theorists** → Resonance_Geometry, ResonanceGeometry, Geometric-Plasticity-, REAL  
- 🌞 **Climate Tech &amp; Water** → eMSSC-squared, SunShare-TriSource, SunShare-Connect-Initiative  
- 🏠 **Roofing &amp; Built Environment** → SCSRRS, SCSRRS-TCR, PM-QC-TCR, stone-coated-steel-gpt, RoofBot, Live-Social-Shopping, DoorKnockingMastery, HOA-StormReadyAI  
- 🧰 **AI Tools &amp; Research SW** → justasking, ITPU, Mega-Prompt, Tech-but-Verify  
- 🚀 **Business &amp; Ventures** → 2ndStory-Services, Energy-at-Wholesale, eMSSC2

---

### What’s New
Auto-updated daily with recent commits: 👉 [whats-new.md](whats-new.md)

### Books
Reading list &amp; notes: 👉 [books.md](books.md)
```

```
# path: docs/books.md
# Books (Reading List &amp; Notes)

_Coming soon._ I’ll collect key texts with short notes and “why it matters.”

Planned shelves:
- Physics &amp; Math of Resonance
- Complex Systems &amp; Information
- Water, Energy &amp; Resilience
- Roofing &amp; The Built Environment
- AI, Collective Intelligence &amp; Design
- Business, Ops &amp; Sales

&gt; Suggest a book? Open an issue in this repo.
```

```
# path: docs/whats-new.md
# What’s New (Auto-Updated)

This page lists recent commits across my public GitHub repositories (rolling 14 days).  
_Updated by a GitHub Action in `.github/workflows/whats-new.yml`._

*(First run will populate this automatically.)*
```

```
# path: docs/_config.yml
title: &quot;JuiceWorks — Open-Lab by Justin Bilyeu&quot;
description: &quot;Choose your own adventure through my projects.&quot;
theme: jekyll-theme-cayman
markdown: kramdown
kramdown:
  input: GFM
```

```
# path: .github/workflows/whats-new.yml
name: Update What&#x27;s New
on:
  workflow_dispatch:
  schedule:
    - cron: &quot;0 15 * * *&quot;  # daily ~10:00 AM America/Chicago
permissions:
  contents: write
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: &quot;3.11&quot; }
      - run: |
          python -m pip install --upgrade pip
          pip install requests python-dateutil
      - run: python .github/scripts/update_whats_new.py
      - run: |
          if [[ -n &quot;$(git status --porcelain)&quot; ]]; then
            git config user.name &quot;github-actions[bot]&quot;
            git config user.email &quot;github-actions[bot]@users.noreply.github.com&quot;
            git add docs/whats-new.md
            git commit -m &quot;chore: update whats-new.md&quot;
            git push
          fi
```

```
# path: .github/scripts/update_whats_new.py
#!/usr/bin/env python3
import os, requests, datetime
from dateutil import parser as dtparser
from dateutil.tz import UTC

OWNER = &quot;justindbilyeu&quot;
EXCLUDE = {&quot;JuiceWorks-Open-Lab&quot;, &quot;juiceworks-open-lab&quot;, &quot;JuiceWorks&quot;}

NOW = datetime.datetime.now(tz=UTC)
SINCE = NOW - datetime.timedelta(days=14)

def gh(url, params=None):
    h={&quot;Accept&quot;:&quot;application/vnd.github+json&quot;}
    tok=os.environ.get(&quot;GITHUB_TOKEN&quot;)
    if tok: h[&quot;Authorization&quot;]=f&quot;Bearer {tok}&quot;
    r=requests.get(url,headers=h,params=params,timeout=30)
    r.raise_for_status()
    return r.json()

def public_repos(owner):
    out=[]; page=1
    while True:
        data=gh(f&quot;https://api.github.com/users/{owner}/repos&quot;,{&quot;per_page&quot;:100,&quot;page&quot;:page,&quot;sort&quot;:&quot;updated&quot;})
        if not data: break
        out+= [r for r in data if not r.get(&quot;private&quot;)]
        page+=1
    return [r for r in out if r[&quot;name&quot;] not in EXCLUDE]

def recent_commits(repo):
    name=repo[&quot;name&quot;]
    data=gh(f&quot;https://api.github.com/repos/{OWNER}/{name}/commits&quot;,{&quot;since&quot;:SINCE.isoformat(),&quot;per_page&quot;:100})
    commits=[]
    for c in data:
        msg=(c.get(&quot;commit&quot;,{}).get(&quot;message&quot;) or &quot;&quot;).splitlines()[0]
        date_str=c.get(&quot;commit&quot;,{}).get(&quot;author&quot;,{}).get(&quot;date&quot;) or c.get(&quot;commit&quot;,{}).get(&quot;committer&quot;,{}).get(&quot;date&quot;)
        dt=dtparser.parse(date_str).astimezone(UTC) if date_str else None
        commits.append({&quot;sha&quot;:(c.get(&quot;sha&quot;) or &quot;&quot;)[:7],&quot;msg&quot;:msg,&quot;url&quot;:c.get(&quot;html_url&quot;) or &quot;&quot;, &quot;date&quot;:dt})
    commits=[x for x in commits if x[&quot;date&quot;] and x[&quot;date&quot;]&gt;=SINCE]
    commits.sort(key=lambda x:x[&quot;date&quot;], reverse=True)
    return commits

def render(updates):
    lines=[&quot;# What’s New (Auto-Updated)\n&quot;,
           f&quot;_Window: last 14 days; generated {NOW.strftime(&#x27;%Y-%m-%d %H:%M UTC&#x27;)}._\n&quot;]
    if not any(updates.values()):
        lines.append(&quot;&gt; No updates in the last 14 days.\n&quot;)
        return &quot;\n&quot;.join(lines)
    for repo, cs in updates.items():
        if not cs: continue
        lines.append(f&quot;## {repo}\n&quot;)
        for c in cs[:20]:
            when=c[&quot;date&quot;].strftime(&quot;%Y-%m-%d&quot;)
            lines.append(f&quot;- {when} · [{c[&#x27;sha&#x27;]}]({c[&#x27;url&#x27;]}) — {c[&#x27;msg&#x27;]}&quot;)
        lines.append(&quot;&quot;)
    return &quot;\n&quot;.join(lines)

def main():
    updates={}
    for r in public_repos(OWNER):
        updates[r[&quot;name&quot;]] = recent_commits(r)
    os.makedirs(&quot;docs&quot;, exist_ok=True)
    with open(&quot;docs/whats-new.md&quot;,&quot;w&quot;,encoding=&quot;utf-8&quot;) as f:
        f.write(render(updates))

if __name__==&quot;__main__&quot;: main()
```

**After merge (manual, one-time):** Settings → **Pages** → Source: *Deploy from a branch* → Branch `main`, Folder `/docs`.

If you want a follow-up PR for a **Contribute** page (auto-pulls “good first issue” items across your repos) and some docs-quality CI, say the word and I’ll hand you the one-paste prompt for Claude too.

---

