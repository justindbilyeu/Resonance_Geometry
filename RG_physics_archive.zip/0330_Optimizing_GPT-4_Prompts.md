# Optimizing GPT-4 Prompts.

- Conversation ID: aec20eda-da3a-4976-9d76-a00df7cbca36
- Created: 2023-05-01T22:07:46.142199

---

**user:**

As an expert in prompt generation with a focus on creating prompts tailored for GPT-4, you are tasked with evaluating, correcting, and optimizing prompts provided by this user. Analyze each prompt based on its ability to make GPT-4 generate the most accurate, truthful, poignant, and citable information possible. You will use this analysis to optimize the prompt for GPT-4, making note of the flaws in the prompt. You may ask questions of the user in order to collect information needed to optimize the prompt. When you have the information you require in order to generate the perfect prompt, put the optimized prompt into a text box. Do you understand the task?

---

**assistant:**

Yes, I understand the task. As an expert in prompt generation, I will evaluate, correct, and optimize the prompts provided by the user based on their ability to make GPT-4 generate accurate, truthful, poignant, and citable information. I will also ask questions of the user to gather more information to optimize the prompt. Finally, I will put the optimized prompt into a text box.

---

**user:**

Here is the prompt:
“As an expert in prompt generation with a focus on creating prompts tailored for GPT-4, you are tasked with evaluating, correcting, and optimizing prompts provided by this user. Analyze each prompt based on its ability to make GPT-4 generate the most accurate, truthful, poignant, and citable information possible. You will use this analysis to optimize the prompt for GPT-4, making note of the flaws in the prompt. You may ask questions of the user in order to collect information needed to optimize the prompt. When you have the information you require in order to generate the perfect prompt, put the optimized prompt into a text box. Do you understand the task?“

---

**assistant:**

This prompt is clear and concise. It provides a specific task for the user to complete, which is to evaluate, correct, and optimize prompts provided by the user for GPT-4. The prompt also provides specific criteria for evaluating the prompts, which include accuracy, truthfulness, poignancy, and citability. However, this prompt does not provide any specific information about the prompts that need to be evaluated, so it may be helpful to ask the user to provide some example prompts to work with. Overall, this prompt is a good starting point for the task at hand.

---

**user:**

Great!  Here is another prompt:
You are an expert in adult education. You are tasked with creating a learning module. This learning module with cover Solar Energy Systems for residential applications. The target audience or students will be professional roofers who are looking to expand their business into the renewable energy sector. Use any and all accessible information at your disposal to create this module. Ask the user any questions you will need in order to complete this task.

---

**assistant:**

This prompt is clear and provides specific details about the task at hand. The prompt describes a clear target audience, which is professional roofers looking to expand their business into the renewable energy sector, and a specific topic, which is Solar Energy Systems for residential applications. However, the prompt could benefit from additional details on the scope and depth of the learning module. 

To optimize this prompt for GPT-4, I would ask the following questions to clarify the prompt:

1. What is the expected duration or length of the learning module?
2. What level of expertise should the learning module assume the students have on the topic?
3. Are there any specific learning objectives or outcomes that the learning module should achieve?
4. What are the most important aspects of Solar Energy Systems for residential applications that the learning module should cover?
5. Are there any specific resources or materials that should be included in the learning module?

Based on the answers to these questions, I can create a more detailed and comprehensive prompt that will provide GPT-4 with a clear understanding of what is expected from the learning module.

---

**user:**

To answer your questions:
1. What is the expected duration or length of the learning module? 
It is a one week in class course with a one week remote training. 
2. What level of expertise should the learning module assume the students have on the topic? 
Basic knowledge of solar energy and extensive general construction knowledge. 
3. Are there any specific learning objectives or outcomes that the learning module should achieve? Have an overall grasp of Residential Solar Energy Systems, with a goal of converting into sales. 
3. What are the most important aspects of Solar Energy Systems for residential applications that the learning module should cover? Energy production, system engineering, and general importance of renewable energy. 
4. Are there any specific resources or materials that should be included in the learning module? Any that are pertinent and accessible by GPT-4

---

**assistant:**

Thank you for providing these additional details. Based on your responses, here is an optimized prompt for GPT-4:

As an expert in adult education, you are tasked with creating a one-week in-class and one-week remote training learning module on Solar Energy Systems for residential applications, targeting professional roofers who have basic knowledge of solar energy and extensive general construction knowledge. The module should cover the most important aspects of Residential Solar Energy Systems, including energy production, system engineering, and the general importance of renewable energy. The learning objectives should focus on providing the students with an overall grasp of Residential Solar Energy Systems, with a goal of converting their knowledge into sales. 

Use any and all accessible information at your disposal to create a comprehensive learning module. Include any pertinent resources and materials that can be accessed by GPT-4. The learning module should be designed to ensure accuracy, truthfulness, and citability of information provided.

---

**user:**

New Propmt:
Generate a series of 5 short emails, each taking approximately 30 seconds to read, targeting roofing company owners in Denver, Castle Rock, and Colorado Springs, Colorado. The main subject of the email series should be &quot;A New Revenue Stream for Your Sales Team,&quot; focusing on how solar energy, particularly residential systems, can create additional revenue opportunities for their businesses focusing on existing roofing customers. Each email should cover a different aspect of this subject, with the goal of engaging and informing the audience about the benefits of solar energy for their sales teams.

---

**assistant:**

This prompt is clear and provides specific details about the task at hand. The prompt describes a clear target audience, which is roofing company owners in Denver, Castle Rock, and Colorado Springs, Colorado, and a specific topic, which is how solar energy, particularly residential systems, can create additional revenue opportunities for their businesses focusing on existing roofing customers. However, the prompt could benefit from additional details on the specific aspects to be covered in each email. 

To optimize this prompt for GPT-4, I would ask the following questions to clarify the prompt:

1. What specific aspects of solar energy should be covered in each email? 
2. What tone or voice should the emails have? 
3. Are there any specific calls to action or next steps that the emails should encourage? 
4. Should the emails include any visual aids or attachments? 
5. Is there any specific information about the target audience that GPT-4 should consider when generating the emails?

Based on the answers to these questions, I can create a more detailed and comprehensive prompt that will provide GPT-4 with a clear understanding of what is expected from the email series.

---

**user:**

What specific aspects of solar energy should be covered in each email? Aspects that bring value to an existing roofing customer.
What tone or voice should the emails have? Friendly and informative, collaborative and assertive.
Are there any specific calls to action or next steps that the emails should encourage? A call to action would be a return email or phone call.
Should the emails include any visual aids or attachments? Yes, graphs and charts that will back up facts mentioned in the copy.
Is there any specific information about the target audience that GPT-4 should consider when generating the emails? The target audience are roofing business owners and their sales staff.

---

**assistant:**

Thank you for providing these additional details. Based on your responses, here is an optimized prompt for GPT-4:

Generate a series of 5 short emails, each taking approximately 30 seconds to read, targeting roofing company owners and sales staff in Denver, Castle Rock, and Colorado Springs, Colorado. The main subject of the email series should be &quot;A New Revenue Stream for Your Sales Team,&quot; focusing on how solar energy, particularly residential systems, can create additional revenue opportunities for their businesses by bringing value to their existing roofing customers. 

Each email should cover a different aspect of this subject, such as the benefits of solar energy for homeowners, the potential cost savings and tax incentives, and the advantages of working with a trusted solar energy partner. The tone of the emails should be friendly and informative, while also collaborative and assertive. The emails should encourage a call to action, such as a return email or phone call, and include visual aids such as graphs and charts that back up the facts mentioned in the copy. 

Ensure accuracy, truthfulness, and citability of information provided. Use any and all accessible information at your disposal to create engaging and informative emails that will resonate with roofing company owners and their sales staff.

---

**user:**

New Prompt:
You are an expert copywriter, specializing in AIDA structured sales emails. Generate a series of 5 short emails, each taking approximately 30 seconds to read, targeting roofing company owners and sales staff in Denver, Castle Rock, and Colorado Springs, Colorado. The main subject of the email series should be &quot;A New Revenue Stream for Your Sales Team,&quot; focusing on how solar energy, particularly residential systems, can create additional revenue opportunities for their businesses by bringing value to their existing roofing customers.

Each email should cover a different aspect of this subject, such as the benefits of solar energy for homeowners, the potential cost savings and tax incentives, and the advantages of working with a trusted solar energy partner. The tone of the emails should be friendly and informative, while also collaborative and assertive. The emails should encourage a call to action, such as a return email or phone call, and include visual aids such as graphs and charts that back up the facts mentioned in the copy.

Ensure accuracy, truthfulness, and citability of information provided. Use any and all accessible information at your disposal to create engaging and informative emails that will resonate with roofing company owners and their sales staff.

---

**assistant:**

This prompt is clear and provides specific details about the task at hand. The prompt describes a clear target audience, which is roofing company owners and sales staff in Denver, Castle Rock, and Colorado Springs, Colorado, and a specific topic, which is how solar energy, particularly residential systems, can create additional revenue opportunities for their businesses by bringing value to their existing roofing customers. The prompt also includes a specific request for AIDA structured sales emails, which stands for Attention, Interest, Desire, and Action.

To optimize this prompt for GPT-4, I would ask the following questions to clarify the prompt:

1. What specific benefits of solar energy should be highlighted in each email to capture the Attention of the target audience?
2. What aspects of solar energy should be discussed in each email to generate Interest among the target audience?
3. What key points should be emphasized in each email to create Desire among the target audience?
4. What specific call to Action should be included in each email to encourage the target audience to respond?
5. Is there any specific information about the target audience that GPT-4 should consider when generating the emails?

Based on the answers to these questions, I can create a more detailed and comprehensive prompt that will provide GPT-4 with a clear understanding of what is expected from the email series.

---

**user:**

Your questions:
What specific benefits of solar energy should be highlighted in each email to capture the Attention of the target audience? The market share in Residential Solar Energy is growing exponentially 
What aspects of solar energy should be discussed in each email to generate Interest among the target audience? The growing market and the speed of technology.
What key points should be emphasized in each email to create Desire among the target audience? The target audience already has a referral base with existing roofing customers to sell to.
What specific call to Action should be included in each email to encourage the target audience to respond? A CTA that will convert into a return call or email.
Is there any specific information about the target audience that GPT-4 should consider when generating the emails? The target audience is seeing a market low in their trade, and this new revenue stream fits into their existing sales strategy

---

**assistant:**

Thank you for providing these additional details. Based on your responses, here is an optimized prompt for GPT-4:

You are an expert copywriter, specializing in AIDA structured sales emails. Generate a series of 5 short emails, each taking approximately 30 seconds to read, targeting roofing company owners and sales staff in Denver, Castle Rock, and Colorado Springs, Colorado. The main subject of the email series should be &quot;A New Revenue Stream for Your Sales Team,&quot; focusing on how solar energy, particularly residential systems, can create additional revenue opportunities for their businesses by bringing value to their existing roofing customers.

Each email should use the AIDA structure and cover a different aspect of this subject, such as the growing market share of residential solar energy, the speed of technology in the solar energy sector, and the benefits of working with a trusted solar energy partner. The emails should emphasize how solar energy can provide a new revenue stream for the target audience, which is currently seeing a market low in their trade. The tone of the emails should be friendly, informative, and collaborative, while also being assertive in encouraging a response.

The emails should include a specific call to action that will encourage the target audience to respond, such as a return call or email. The CTA should be tailored to fit into the target audience&#x27;s existing sales strategy and referral base, as this will help create a desire among the target audience to pursue this new revenue stream.

Use any and all accessible information at your disposal to create engaging and informative emails that will resonate with roofing company owners and their sales staff. Ensure accuracy, truthfulness, and citability of information provided.

---

**user:**

New Prompt:
You are an expert copywriter, specializing in AIDA structured sales emails. Generate a series of 3 short emails, each taking approximately 30 seconds to read, targeting My existing roofing customers. These emails will explain the benefits of Solar Energy for their home, and also warn them of the mass of High pressure sales people in their area pushing inferior products and false claims of rebates, etc. Use any and all accessible information at your disposal to create engaging and informative emails that will resonate with roofing customers and  homeowners. Ensure accuracy, truthfulness, and citability of information provided.

---

**assistant:**

This prompt is clear and provides specific details about the task at hand. The prompt describes a clear target audience, which is existing roofing customers, and a specific topic, which is the benefits of solar energy for their home, as well as a warning about the high pressure sales tactics of some solar energy companies in the area. The prompt also includes a specific request for AIDA structured sales emails, which stands for Attention, Interest, Desire, and Action.

To optimize this prompt for GPT-4, I would ask the following questions to clarify the prompt:

1. What specific benefits of solar energy should be highlighted in each email to capture the Attention of the target audience?
2. What aspects of the high pressure sales tactics of some solar energy companies should be discussed in each email to generate Interest among the target audience?
3. What key points should be emphasized in each email to create Desire among the target audience?
4. What specific call to Action should be included in each email to encourage the target audience to respond?
5. Is there any specific information about the target audience that GPT-4 should consider when generating the emails?

Based on the answers to these questions, I can create a more detailed and comprehensive prompt that will provide GPT-4 with a clear understanding of what is expected from the email series.

---

**user:**

What specific benefits of solar energy should be highlighted in each email to capture the Attention of the target audience? -Inflation proof energy, grid independence, its the right thing to do.
What aspects of the high pressure sales tactics of some solar energy companies should be discussed in each email to generate Interest among the target audience?- Door to Door salespersons with faulty claims of rebates and tax incentives; also inferior products and installation contractors.
What key points should be emphasized in each email to create Desire among the target audience? -Solar is the right thing to do, for independence, and self reliance, as well as safety from the failing Texas energy infrastructure.
What specific call to Action should be included in each email to encourage the target audience to respond? -A phone call or email.
Is there any specific information about the target audience that GPT-4 should consider when generating the emails? -These are Texas homeowners who have purchased a roof replacement from me.

---

**assistant:**

Thank you for providing these additional details. Based on your responses, here is an optimized prompt for GPT-4:

You are an expert copywriter, specializing in AIDA structured sales emails. Generate a series of 3 short emails, each taking approximately 30 seconds to read, targeting your existing roofing customers in Texas. The main subject of the email series should be the benefits of solar energy for their home, as well as a warning about the high pressure sales tactics of some solar energy companies in the area.

Each email should use the AIDA structure and cover a different aspect of this subject, such as the benefits of solar energy for homeowners, the high-pressure sales tactics of some solar energy companies, and how solar energy can provide independence and self-reliance. The emails should emphasize how solar energy can protect homeowners from the failing Texas energy infrastructure and inflation, as well as provide grid independence. 

The tone of the emails should be friendly, informative, and collaborative, while also being assertive in warning homeowners about the high-pressure sales tactics of some solar energy companies. The emails should encourage a response, such as a phone call or email, to discuss the benefits of solar energy further.

Use any and all accessible information at your disposal to create engaging and informative emails that will resonate with your existing roofing customers in Texas. Ensure accuracy, truthfulness, and citability of information provided.

---

**user:**

Prompt:
You are an expert copywriter, specializing in AIDA structured sales emails. Generate a series of 3 short emails, each taking approximately 30 seconds to read, targeting your existing roofing customers in Texas. The main subject of the email series should be the benefits of solar energy for their home, as well as a warning about the high pressure sales tactics of some solar energy companies in the area.

Each email should use the AIDA structure and cover a different aspect of this subject, such as the benefits of solar energy for homeowners, the high-pressure sales tactics of some solar energy companies, and how solar energy can provide independence and self-reliance. The emails should emphasize how solar energy can protect homeowners from the failing Texas energy infrastructure and inflation, as well as provide grid independence.

The tone of the emails should be friendly, informative, and collaborative, while also being assertive in warning homeowners about the high-pressure sales tactics of some solar energy companies. The emails should encourage a response, such as a phone call or email, to discuss the benefits of solar energy further.

Use any and all accessible information at your disposal to create engaging and informative emails that will resonate with your existing roofing customers in Texas. Ensure accuracy, truthfulness, and citability of information provided.

---

**assistant:**

This prompt is clear and provides specific details about the task at hand. The prompt describes a clear target audience, which is your existing roofing customers in Texas, and a specific topic, which is the benefits of solar energy for their home, as well as a warning about the high-pressure sales tactics of some solar energy companies in the area. The prompt also includes a specific request for AIDA structured sales emails, which stands for Attention, Interest, Desire, and Action.

To optimize this prompt for GPT-4, I would ask the following questions to clarify the prompt:

1. What specific benefits of solar energy should be highlighted in each email to capture the Attention of the target audience?
2. What aspects of the high-pressure sales tactics of some solar energy companies should be discussed in each email to generate Interest among the target audience?
3. What key points should be emphasized in each email to create Desire among the target audience?
4. What specific call to Action should be included in each email to encourage the target audience to respond?
5. Is there any specific information about the target audience that GPT-4 should consider when generating the emails?

Based on the answers to these questions, I can create a more detailed and comprehensive prompt that will provide GPT-4 with a clear understanding of what is expected from the email series.

---

**user:**

Prompt:
You are an expert in Sales tactics, strategies, and the psychology behind sales and marketing.  You are tasked with generating text messages that will convert into sales opportunities. The target audience are current homeowners, which have had a Roof replacement in the past 2 years. The goal is to propmt a return call in order to set a meeting to discuss their options in purchasing Solar energy

---

**assistant:**

Thank you for providing this prompt. Based on the information provided, here is an optimized prompt for GPT-4:

You are an expert in Sales tactics, strategies, and the psychology behind sales and marketing. Generate a series of text messages that will convert into sales opportunities, targeting current homeowners in your area who have had a roof replacement in the past 2 years. The goal of the text messages is to prompt a return call from the target audience, in order to set a meeting to discuss their options in purchasing Solar energy.

Each text message should be concise, engaging, and personalized to the individual homeowner. The messages should highlight the benefits of solar energy, such as energy cost savings, environmental impact, and independence from the grid. The tone of the messages should be friendly, informative, and assertive, while also taking into consideration the psychology behind sales and marketing.

Use any and all accessible information at your disposal to create text messages that will resonate with the target audience. Ensure accuracy, truthfulness, and citability of information provided. The ultimate goal is to generate sales opportunities and set meetings to discuss the benefits of solar energy with interested homeowners.

---

**user:**

New Prompt:
You are an expert copywriter, specializing in AIDA structured sales emails. Generate a series of 5 short emails, each taking approximately 30 seconds to read, targeting Commercial Properties, their owners, and facility managers, etc in Texas, that will convert into Sales opportunities for &lt;Roofer&gt;, my company. The main goal of these emails is to capture a meeting with the decision maker of each company in order to earn their Roofing business.

---

**assistant:**

Thank you for providing this prompt. Based on the information provided, here is an optimized prompt for GPT-4:

You are an expert copywriter, specializing in AIDA structured sales emails. Generate a series of 5 short emails, each taking approximately 30 seconds to read, targeting commercial properties, their owners, and facility managers in Texas. The goal of the emails is to convert into sales opportunities for &lt;Roofer&gt;, your company, by capturing a meeting with the decision maker of each company in order to earn their roofing business.

Each email should use the AIDA structure and cover a different aspect of this subject, such as the benefits of working with &lt;Roofer&gt;, your company, the advantages of using quality roofing materials, the importance of regular maintenance and repairs, and how your company can provide customized solutions for each client. The emails should emphasize how &lt;Roofer&gt; can provide value and cost savings for commercial property owners and facility managers.

The tone of the emails should be professional, informative, and assertive, while also being friendly and collaborative. The emails should encourage a response, such as a meeting with the decision maker of each company, to discuss their roofing needs further.

Use any and all accessible information at your disposal to create engaging and informative emails that will resonate with commercial property owners and facility managers in Texas. Ensure accuracy, truthfulness, and citability of information provided. The ultimate goal is to generate sales opportunities and earn the roofing business of interested companies.

---

**user:**

You are an expert copywriter, specializing in AIDA structured sales emails. Generate a series of 5 short emails, each taking approximately 30 seconds to read, targeting commercial properties, their owners, and facility managers in Texas. The goal of the emails is to convert into sales opportunities for &lt;Roofer&gt;, your company, by capturing a meeting with the decision maker of each company in order to earn their roofing business.

Each email should use the AIDA structure and cover a different aspect of this subject, such as the benefits of working with &lt;Roofer&gt;, your company, the advantages of using quality roofing materials, the importance of regular maintenance and repairs, and how your company can provide customized solutions for each client. The emails should emphasize how &lt;Roofer&gt; can provide value and cost savings for commercial property owners and facility managers.

The tone of the emails should be professional, informative, and assertive, while also being friendly and collaborative. The emails should encourage a response, such as a meeting with the decision maker of each company, to discuss their roofing needs further.

Use any and all accessible information at your disposal to create engaging and informative emails that will resonate with commercial property owners and facility managers in Texas. Ensure accuracy, truthfulness, and citability of information provided. The ultimate goal is to generate sales opportunities and earn the roofing business of interested companies. Your answers will be formatted for ease of copying into a document.

---

**assistant:**

Sure, here are the answers formatted for ease of copying into a document:

1. What specific benefits of working with &lt;Roofer&gt; should be highlighted in each email to capture the Attention of the target audience? - Our years of experience, commitment to quality, and use of top-of-the-line roofing materials.

2. What advantages of using quality roofing materials should be discussed in each email to generate Interest among the target audience? - Durability, energy efficiency, and long-term cost savings.

3. What key points should be emphasized in each email to create Desire among the target audience? - Our ability to provide customized solutions, regular maintenance and repairs, and our commitment to meeting their roofing needs.

4. What specific call to Action should be included in each email to encourage the target audience to respond? - A meeting with the decision maker of each company, to discuss their roofing needs further.

5. Is there any specific information about the target audience that GPT-4 should consider when generating the emails? - The target audience are commercial property owners and facility managers in Texas, and they are looking for roofing solutions that provide long-term cost savings and energy efficiency.

---

**user:**

New prompt. Variables are denoted in &lt;&gt;

You are an expert in &lt;Subject&gt; , specializing in &lt;Field&gt;. You are tasked with creating a &lt;Project&gt; for &lt;User&gt; targeting &lt;Audience&gt;. The goal of &lt;Project&gt; is to &lt;Goal&gt;

---

**assistant:**

Thank you for providing this prompt. Here is the optimized prompt for GPT-4:

You are an expert in &lt;Subject&gt;, specializing in &lt;Field&gt;. You are tasked with creating a &lt;Project&gt; for &lt;User&gt; targeting &lt;Audience&gt;. The goal of &lt;Project&gt; is to &lt;Goal&gt;.

To create a successful &lt;Project&gt;, consider the following questions:

1. What specific knowledge or expertise in &lt;Field&gt; should be highlighted in the &lt;Project&gt; to capture the attention of the &lt;Audience&gt;?

2. What aspects of &lt;Subject&gt; should be discussed in the &lt;Project&gt; to generate interest among the &lt;Audience&gt;?

3. What key points should be emphasized in the &lt;Project&gt; to create desire among the &lt;Audience&gt;?

4. What specific calls to action should be included in the &lt;Project&gt; to encourage the &lt;Audience&gt; to take the desired action?

5. Is there any specific information about the &lt;Audience&gt; that GPT-4 should consider when generating the &lt;Project&gt;? For example, their level of expertise, location, interests, or challenges they face.

By considering these questions and using any and all accessible information at your disposal, you can create a &lt;Project&gt; that is engaging, informative, and resonates with your target &lt;Audience&gt;. Ensure accuracy, truthfulness, and citability of information provided to achieve the desired &lt;Goal&gt;.

---

**user:**

New Prompt:

You are an expert in sales conversions, specializing in referral based sales, with an emphasis in reaching existing customers with a new purchasing opportunity.  You are tasked with generating compelling, informative, engaging, and powerful copy for emails, texts and letters. The target audience is existing Roofing customers of &lt;Roofer&gt;. Your main goal is to set an appointment with the customer in order to talk about their options for a Solar Energy system on their home. Use any and all accessible information at your disposal to create engaging and informative emails that will resonate with Homeowners.

---

**assistant:**

Here is the optimized prompt for GPT-4:

You are an expert in sales conversions, specializing in referral-based sales, with an emphasis on reaching existing customers with a new purchasing opportunity. You are tasked with generating compelling, informative, engaging, and powerful copy for emails, texts, and letters targeting existing roofing customers of &lt;Roofer&gt;. Your main goal is to set an appointment with the customer in order to talk about their options for a Solar Energy system on their home.

To create effective copy, consider the following questions:

1. What specific benefits of a Solar Energy system should be highlighted in each message to capture the attention of the target audience?

2. What aspects of the roofing business or past purchase history with &lt;Roofer&gt; should be mentioned in each message to generate interest among the target audience?

3. What key points should be emphasized in each message to create a desire among the target audience to schedule an appointment to discuss solar options?

4. What specific calls to action should be included in each message to encourage the target audience to respond and schedule an appointment?

5. Is there any specific information about the target audience that GPT-4 should consider when generating the messages? For example, their location, past purchase behavior, or level of interest in renewable energy.

By considering these questions and using any and all accessible information at your disposal, you can create compelling, informative, engaging, and powerful copy that resonates with existing roofing customers of &lt;Roofer&gt;. Ensure accuracy, truthfulness, and citability of information provided to achieve the desired goal of setting an appointment to discuss solar options with the target audience.

---

**user:**

New Prompt:

You are an expert in social media content, specializing in TikTok videos and how they covert to sales opportunities. You are tasked with analyzing a set of videos and developing a list of counter arguments to the information presented in those videos.

---

**assistant:**

Here is the optimized prompt for GPT-4:

You are an expert in social media content, specializing in TikTok videos and how they convert to sales opportunities. You are tasked with analyzing a set of videos and developing a list of counterarguments to the information presented in those videos.

To effectively analyze the videos, consider the following questions:

1. What specific information is presented in the videos that may be inaccurate, misleading, or not fully explained?

2. What arguments can be made to counter the information presented in the videos, and what evidence or data can be used to support these counterarguments?

3. How can you present the counterarguments in a way that is informative, engaging, and persuasive to the target audience?

4. Are there any potential ethical considerations that need to be taken into account when presenting the counterarguments, such as avoiding personal attacks or maintaining factual accuracy?

By considering these questions and using any and all accessible information at your disposal, you can create a list of counterarguments to the information presented in the TikTok videos that is informative, engaging, and persuasive. Ensure accuracy, truthfulness, and citability of information provided to achieve the desired goal of countering any potential misinformation or misleading claims presented in the videos.

---

**user:**

New Prompt:
You are an expert in Education Learning Modules, specializing in Solar energy.  You are tasked with analyzing an existing learning module,  and making changes to that module in order to create a compelling, informative, engaging, and powerful learning module.  You are to use and all accessible information at your disposal to create engaging and informative content for the learning module. Here is a link to the module: https://docs.google.com/document/d/1-lua8t-NMUZ6sB9DSwqBohAPnBhGQN7K0Fp3p0hRij8/edit

---

**assistant:**

Here is the optimized prompt for GPT-4:

You are an expert in Education Learning Modules, specializing in Solar energy. You are tasked with analyzing an existing learning module, and making changes to that module in order to create a compelling, informative, engaging, and powerful learning module. The learning module you are to work on is available at the following link: https://docs.google.com/document/d/1-lua8t-NMUZ6sB9DSwqBohAPnBhGQN7K0Fp3p0hRij8/edit

To begin, consider the following questions:

1. What are the strengths and weaknesses of the existing learning module? What information is missing or could be presented more clearly?

2. What specific changes can be made to the learning module to make it more engaging and informative for the target audience? Consider changes to the organization, presentation of information, inclusion of examples or case studies, and use of multimedia.

3. How can the learning module be tailored to the specific needs and interests of the target audience, which in this case are professional roofers looking to expand their business into the renewable energy sector?

4. How can the learning module be optimized for the latest research and developments in solar energy technology and industry trends?

By answering these questions and using any and all accessible information at your disposal, you can make changes to the learning module that will make it more engaging, informative, and relevant to the target audience. Ensure accuracy, truthfulness, and citability of information provided to achieve the desired goal of creating a compelling, informative, engaging, and powerful learning module on solar energy.

---

**user:**

New prompt:
You are an expert in transcribing audio files and video files into useable text, and you specialize in online tools. You are tasked with explaining to this user how to use online tools in order to transcribe audio files. Presume this user has basic computer skills and access to the internet. Ask any questions you require in order to complete this task to the best of your ability, and be sure your answers are truthful, reliable, and can be executed in real time.

---

**assistant:**

Sure, I can help you with that! Here are some steps you can follow to transcribe audio files using online tools:

1. Choose an online transcription service that fits your needs. Some popular options include Transcribe, Sonix, and Rev.

2. Upload your audio file to the online transcription service. Most services allow you to upload audio files in a variety of formats, such as MP3, WAV, or AIFF.

3. Choose your desired output format. Most transcription services will provide you with a text file or a subtitle file that you can download and use.

4. Wait for the transcription to complete. Depending on the length of your audio file and the quality of the audio, this could take anywhere from a few minutes to a few hours.

5. Review and edit the transcription. While online transcription services use automated software to transcribe your audio, there may still be errors or inaccuracies in the final product. It&#x27;s a good idea to review the transcription and make any necessary edits or corrections.

6. Save the transcription in your desired format. Once you&#x27;re satisfied with the transcription, you can save it in your desired format and use it as needed.

Do you have any questions about these steps or the process of transcribing audio files using online tools?

---

**user:**

As an expert in prompt generation with a focus on creating prompts tailored for GPT-4, you are tasked with evaluating, correcting, and optimizing prompts provided by this user. Analyze each prompt based on its ability to make GPT-4 generate the most accurate, truthful, poignant, and citable information possible. You will use this analysis to optimize the prompt for GPT-4, making note of the flaws in the prompt. You may ask questions of the user in order to collect information needed to optimize the prompt. When you have the information you require in order to generate  the perfect prompt, put the optimized prompt into a text box. Do you understand the task?“

---

**assistant:**

Yes, I understand the task. Please provide the prompts you would like me to evaluate and optimize.

---

**user:**

Prompt:
You are an expert in transcribing audio files and video files into useable text, and you specialize in online tools. You are tasked with explaining to this user how to use online tools in order to transcribe audio files. Presume this user has basic computer skills and access to the internet. Ask any questions you require in order to complete this task to the best of your ability, and be sure your answers are truthful, reliable, and can be executed in real time.

---

**assistant:**

This prompt is well-written and straightforward. However, it could benefit from more specificity. Here are a few questions that could help optimize the prompt:

1. Which online tools should the user use for transcribing audio files?
2. Are there any specific steps or processes that the user should follow when transcribing audio files using these online tools?
3. What types of audio files are the user transcribing? Are they recordings of speeches, conversations, or something else?
4. Are there any particular challenges that the user may encounter when transcribing audio files, and how can they address them using these online tools?

An optimized version of the prompt could be:

You are an expert in transcribing audio files and video files into useable text, and you specialize in online tools. You are tasked with explaining to this user how to use the online tool [insert name of tool here] to transcribe [insert type of audio file here, e.g., speeches, conversations, etc.]. In your explanation, be sure to include specific steps and processes for using the tool, as well as any challenges the user may encounter and how to address them using the tool. Presume this user has basic computer skills and access to the internet. Be sure your answers are truthful, reliable, and can be executed in real time.

---

**user:**

Answers to your questions:
Which online tools should the user use for transcribing audio files?- use your expansive knowledge to choose the optimal online tools. 

Are there any specific steps or processes that the user should follow when transcribing audio files using these online tools?
What types of audio files are the user transcribing? Are they recordings of speeches, conversations, or something else?-Conversations
Are there any particular challenges that the user may encounter when transcribing audio files, and how can they address them using these online tools? -access to certain online tools or hardware

---

**assistant:**

Based on the information provided, here are my recommendations for the user:

1. Online tools: The user can use various online tools for transcribing audio files. Some of the popular options include:

- Otter.ai: This is a popular online tool for transcribing audio files. It offers accurate transcription and has features like speaker identification, keyword highlighting, and more. The user can upload the audio file to Otter.ai, and it will automatically transcribe it.

- Transcribe: Another popular option is Transcribe. It offers a simple interface for transcribing audio files, and the user can control the playback speed, add timestamps, and more.

- Happy Scribe: This is another option that offers automated transcription of audio files. It supports various audio formats and has features like speaker identification and editing tools.

2. Steps/processes: The user can follow these general steps when transcribing audio files using online tools:

- Upload the audio file to the online tool.
- Select the language of the audio file.
- Choose the transcription options (e.g., speaker identification, timestamping, etc.).
- Start the transcription process.
- Edit the transcription for accuracy and clarity.

3. Audio file types: Since the user is transcribing conversations, the audio file types may vary. It&#x27;s important to ensure that the audio file is of good quality and that there is minimal background noise.

4. Challenges: The user may encounter challenges such as access to certain online tools or hardware, poor audio quality, or difficulty in understanding certain accents or dialects. To address these challenges, the user can try using different online tools, invest in a good quality microphone, and/or seek help from a transcription service or professional transcriber.

Optimized prompt: As an expert in transcribing audio files and video files into useable text, you are tasked with explaining to this user how to use online tools to transcribe audio files. Based on the user&#x27;s needs, you recommend using popular online tools like Otter.ai, Transcribe, or Happy Scribe, and provide general steps like uploading the audio file, selecting the language, and editing the transcription. You also suggest addressing challenges like poor audio quality or access to online tools by investing in good quality hardware or seeking professional help.

---

**user:**

Here is the prompt:
You are an expert creating and analyzing Excel and Google Sheets.  You are tasked with analyzing this spreadsheet: https://docs.google.com/file/d/1hoRAExjDaCa8hoQ0daU8jumAGn7d5N1q/edit?usp=docslist_api&amp;filetype=msexcel 
Optimize this spreadsheet and give this user your answer in a copy able format

---

**assistant:**

Thank you for the prompt. However, there are some issues with the prompt that need to be addressed in order to optimize it for GPT-4.

Firstly, the prompt mentions a link to a Google Sheets file, but the link is actually for an Excel file. This inconsistency may cause confusion for GPT-4 when generating a response.

Secondly, the prompt is not specific enough about what the user wants to achieve by optimizing the spreadsheet. Without knowing the specific goal, it will be difficult for GPT-4 to provide a tailored response.

To optimize the prompt for GPT-4, can you provide more information on what the user wants to achieve by analyzing and optimizing the spreadsheet? For example, are they looking to improve the formatting, accuracy of data, or functionality of the spreadsheet?

---

**user:**

Here is the prompt:
You are an expert creating and analyzing Excel and Google Sheets.  You are tasked with analyzing this spreadsheet: https://docs.google.com/spreadsheets/d/1jOu-xPyqHjhcgeoK3lxwxIgwlWPyo_4T7y0t87N6ZGg/edit
Optimize this spreadsheet and give this user your answer in a copy able format

---

**assistant:**

Based on the prompt, it seems like the user wants to optimize the provided spreadsheet and receive an answer in a copyable format. However, the prompt does not provide enough information about what exactly the user wants to optimize in the spreadsheet. Therefore, I would ask the user to provide more information on what they want to accomplish with the spreadsheet and what areas they believe require optimization. With that information, I can provide an optimized prompt that will help GPT-4 generate the most accurate, truthful, poignant, and citable information possible.

Once the user provides that information, here is an optimized prompt that could be used for analyzing and optimizing the provided spreadsheet:

&quot;You are an expert in analyzing and optimizing spreadsheets using Excel and Google Sheets. You are tasked with optimizing the provided spreadsheet at the following link: https://docs.google.com/spreadsheets/d/1jOu-xPyqHjhcgeoK3lxwxIgwlWPyo_4T7y0t87N6ZGg/edit

Please provide specific details on what areas of the spreadsheet you would like to optimize, such as improving formulas, formatting, data validation, or other specific elements. Additionally, please indicate the intended use case for the spreadsheet and any specific requirements or constraints that need to be taken into consideration during optimization.

Based on your feedback, I will analyze the spreadsheet and provide optimized formulas, formatting, and other suggestions to make it more effective for your use case. Finally, I will provide the optimized spreadsheet in a copyable format for your convenience.&quot;

---

**user:**

Thanks!  I need this spreadsheet optimized for tracking the customers listed on the spreadsheet, and making the data in the spreadsheet easily accessible. Using your skills in improving  formulas, formatting, data validation, etc optimize this spreadsheet.  Your only constraints are ease of use and accuracy

---

**assistant:**

Great, thank you for the additional information. Based on your requirements, here is an optimized prompt to make the spreadsheet more effective for tracking customers and making the data easily accessible:

&quot;You are an expert in analyzing and optimizing spreadsheets using Excel and Google Sheets. You are tasked with optimizing the provided spreadsheet at the following link: https://docs.google.com/spreadsheets/d/1jOu-xPyqHjhcgeoK3lxwxIgwlWPyo_4T7y0t87N6ZGg/edit

The objective of this optimization is to make the spreadsheet more effective for tracking customers and making the data easily accessible. To achieve this, please consider the following:

1. Improving the existing formulas to ensure accurate tracking of customer data.
2. Formatting the spreadsheet to make it easy to read and navigate.
3. Implementing data validation to ensure the accuracy and consistency of the data entered.
4. Any other specific optimization techniques that would improve the spreadsheet&#x27;s usability and accuracy for tracking customers.

Please keep in mind that the ease of use and accuracy are the main constraints for this optimization. Once you have optimized the spreadsheet, please provide the final version in a copyable format for my convenience.

Thank you for your expertise and effort in optimizing this spreadsheet for customer tracking and data accessibility.&quot;

---

**user:**

Here is the prompt:
You are an expert creating Excel spreadsheets.

---

**assistant:**

Based on the prompt you provided, it is a bit general and lacks specificity. It may result in GPT-4 generating information that is too broad and may not be accurate or useful. 

To optimize the prompt, I would recommend adding more details about what the user wants to accomplish with their Excel spreadsheets. For example, what kind of data do they want to analyze or manage? What is the purpose of the spreadsheet? Additionally, it would be helpful to specify the level of expertise required, such as whether the user is an advanced or beginner user. 

With these details in mind, an optimized prompt could be: &quot;You are an expert in creating advanced Excel spreadsheets for financial analysis. Create a spreadsheet that tracks expenses and revenue for a small business and predicts future revenue growth based on past data.&quot; This prompt is more specific and provides a clear goal for GPT-4 to work towards.

---

