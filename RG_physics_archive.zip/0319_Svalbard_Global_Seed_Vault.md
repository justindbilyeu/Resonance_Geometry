# Svalbard Global Seed Vault

- Conversation ID: 67b76da3-e758-800c-9032-48496059a7f6
- Created: 2025-02-20T18:00:24.107699

---

**assistant:**

The Svalbard Global Seed Vault is located on the Norwegian island of Spitsbergen in the remote Arctic Svalbard archipelago. It&#x27;s designed to safely store duplicates of seeds from around the world, acting as a backup to preserve the genetic diversity of the world&#x27;s food crops.

---

