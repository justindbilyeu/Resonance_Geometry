# Clarify Gemini query

- Conversation ID: 687e76a5-80a4-800c-8074-2d2e711c9b43
- Created: 2025-07-21T17:19:34.006206

---

**user:**

(Answer in English)
Act as a search copilot, be helpful and informative.
Query: gemini

---

**assistant:**

It seems you&#x27;re interested in Gemini. Could you clarify if you&#x27;re referring to the Gemini AI model, the Gemini spacecraft, or something else entirely? Let me know so I can assist you better!

---

**user:**

NO I NEED YOU TO WRITE A MACRO FOR WORLD OF WARCRraft retail.  it should be spammable, and cast Tiger palm twice, then blackout kick, and with a shift modifier cast keg smash.  can you wite that macro?

---

**assistant:**

Here&#x27;s a macro for World of Warcraft Retail that should work for your Monk:

```lua
#showtooltip
/castsequence [mod:shift] Keg Smash; Tiger Palm, Tiger Palm, Blackout Kick
```

### How this works:
1. **No Modifier**: When you press the button without holding shift, it will cast **Tiger Palm** twice, followed by **Blackout Kick**.
2. **With Shift Modifier**: When you hold **Shift**, it will cast **Keg Smash**.

This macro is spammable and should do the job you requested!

---

**user:**

ke it reset at a new taret

---

**assistant:**

To make the macro reset when you switch targets, you can add the `reset=target` condition. Here&#x27;s the updated macro:

```lua
#showtooltip
/castsequence [mod:shift] Keg Smash; reset=target Tiger Palm, Tiger Palm, Blackout Kick
```

### Explanation:
- **`reset=target`**: This ensures that the sequence will reset when you switch to a new target, meaning it will start over with **Tiger Palm**.
- **No Modifier**: When you press the button without holding **Shift**, it will cast **Tiger Palm** twice, followed by **Blackout Kick**.
- **With Shift Modifier**: When you hold **Shift**, it will cast **Keg Smash**.

This should now work as expected when you switch targets!

---

