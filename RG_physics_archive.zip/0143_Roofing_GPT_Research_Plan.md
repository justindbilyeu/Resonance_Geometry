# Roofing GPT Research Plan

- Conversation ID: 687f9ee8-2918-8330-b0bc-b2c5e3a8c58a
- Created: 2025-07-22T14:23:37.878344

---

**user:**

We are tasked with creating a GPT for our team.  This GPT will be trained on General Roofing knowledge, and project management for a roofing company. Quality control will be a part of this teams role as well.  We need to create prompts for other llm’s (Grok, DeepSeek, Claude, and Gemini) to do research for our GPT. We will then take all of the data and research, and use GitHub to compress it all into packets to upload into the GPT.  Is this something you are able to assist with, and what would your next steps be?

---

**assistant:**

Absolutely—I can help you design, research, build, and harden this Roofing/PM/QC GPT end-to-end.

## How I’d tackle it (high level)

1. **Clarify scope &amp; users**
   - Who will use it (sales reps, PMs, supers, office staff)?
   - Daily tasks it must answer/perform (estimating, sub scheduling, WPI-8 checklists, safety audits, COI verification, punch lists, QC photo standards, etc.).
   - Guardrails: what it should *not* answer (legal advice? HR issues?).

2. **Define the GPT’s “brain”**
   - **Role / POV block** (tone, authority level, escalation rules).
   - **Task Library** (canonical actions: “Create a pre-install checklist”, “QC photo review rubric”, “Draft homeowner update email”, etc.).
   - **Reasoning rules** (always cite X, always ask for job # if missing, etc.).

3. **Knowledge architecture**
   - Taxonomy of topics:  
     *General Roofing* (materials, codes, hail/wind standards, insurance terms...)  
     *PM* (schedules, Gantt basics, change orders, subs, inspections, lien releases...)  
     *QC* (install specs per system, photo standards, punch lists, safety/OSHA touchpoints).  
   - Content types: SOPs, checklists, decision trees, quick facts, calculators/specs, templates.
   - Metadata &amp; chunking standard (YAML headers, ~400–600 words/chunk, tags, review_date, region, code_refs).

4. **Multi-LLM research pipeline**
   - Prompt packs for Grok, DeepSeek, Claude, Gemini.
   - Clear output spec (Markdown + YAML + numbered refs).
   - Assignment matrix: which model researches what (e.g., Claude for process/SOP clarity, DeepSeek for code-scraping &amp; numeric tables, Gemini for image/video extraction &amp; OSHA docs, Grok for quick contrarian takes / red teams).

5. **GitHub repo + build workflow**
   - `/chunks/&lt;domain&gt;/&lt;topic&gt;.md`  
   - `/prompts/` (research prompts, eval prompts, system prompts)  
   - `/eval/` (Q&amp;A set, hallucination traps)  
   - Actions script to validate YAML, flag missing citations, auto-generate an index.
   - Compression pipeline (remove fluff, normalize headings, run through tokenizer budget checks).

6. **Assemble &amp; deploy the GPT**
   - System prompt + Knowledge upload strategy (RAG vs. native file upload).
   - Tooling hooks (calculators, calendar, email templates) if you want.
   - Versioning &amp; update cadence.

7. **Test, red-team, iterate**
   - Create an evaluation set (50–100 real queries).
   - Run through all LLMs, compare, patch holes.
   - Log failure cases and update chunks/policies.

---

## What I need from you

- Primary user roles &amp; top 10 tasks each must solve with the GPT.
- Any internal docs/SOPs you already trust (so we don’t reinvent).
- Preferred tone (strict? conversational?) and must-have disclaimers.
- Tech constraints: Which GPT platform? Context window? Will you use OpenAI’s file system or your own RAG?
- Update/maintenance plan (who approves new chunks? how often?).

---

## My proposed “Next Steps” with you

**Step 1 — Rapid scoping call/brief (today or tomorrow)**
- I’ll send a short questionnaire; you fill or we talk it out.
- Output: a 1-page Scope + Taxonomy draft for sign-off.

**Step 2 — Draft the core system prompt + taxonomy**
- Deliver: v1 Role/POV block, response rules, and topic tree.

**Step 3 — Build the multi-LLM research prompt kit**
- Deliver: 6–8 reusable prompt templates (examples below).
- Create the repo skeleton &amp; CI/QA checklist.

**Step 4 — Run research sprints (using GGCDs)**
- You/Team/GGCDs generate chunks, we review/normalize/ingest.

**Step 5 — Assemble GPT + eval set**
- Upload content, tune behavior, run eval Q&amp;A, fix gaps.

**Step 6 — Launch &amp; maintain**
- Document SOP for adding/updating chunks.
- Optional: build a lightweight “task router” prompt so the GPT auto-picks relevant SOPs/templates.

---

## Starter Prompt Templates (you can hand to Grok/DeepSeek/Claude/Gemini)

### 1. Research SOP Prompt (Claude / DeepSeek)
```
You are Research-GPT, building a knowledge chunk for our Roofing/PM/QC assistant.

TOPIC: {e.g., “Pre-Install Checklist for Asphalt Shingles (Texas residential)”}

OUTPUT SPECS:
- 450 words max, Markdown.
- Start with YAML header:
---
title: pre_install_checklist_asphalt
domain: project_management
tags: [checklist, asphalt, pre-install, texas]
sources: [ASTM D7158, OSHA 1926 Subpart M, GAF spec doc]
review_date: 2025-07-22
---
- Use concise bullets, numbered steps where helpful.
- Include any code/standard numbers exactly.
- Finish with “References” list: [1], [2]... map to sources above.
- No marketing fluff. Be precise and task-focused.

RESEARCH NOW. Verify each claim. Provide citations.
```

### 2. Code/Standard Extractor Prompt (DeepSeek / Gemini)
```
Task: Extract exact, current requirements related to {UL 2218, WPI-8 inspections, OSHA fall protection thresholds}.

Deliver:
- Bullet list of requirements with clause numbers.
- Plain-English translation under each bullet.
- YAML header with `jurisdiction`, `code_year`.

Cross-check at least 2 primary sources. Cite both.
```

### 3. QC Photo Rubric Prompt (Claude)
```
Create a QC Photo Documentation Rubric for {Standing Seam Metal Install}.
Structure:
1. Required Angles (ridge, eave, valley, penetration).
2. Minimum photo count.
3. Common fail points to capture.
4. Acceptance criteria checklist.

≤ 350 words, YAML header, references to manufacturer spec (e.g., MBCI installation manual).
```

### 4. Red-Team / Hallucination Trap Prompt (Grok)
```
Find 5 likely failure modes or hallucination traps for our Roofing/PM/QC GPT when answering about {insurance depreciation, code upgrades, manufacturer warranties}.
For each:
- Describe the trap.
- Provide a guardrail rule or clarifying question the GPT should ask.
- Suggest a test question to trigger it.
```

### 5. Template Writer Prompt (Gemini)
```
Generate a homeowner update email template for the “Materials Delivered / Pre-Install” stage.

Sections:
- Friendly intro, confirm delivery dates.
- Expectations (noise, driveway access).
- Safety note (kids/pets).
- Contact info &amp; escalation path.

&lt;= 250 words, placeholders in {{double_braces}}.
YAML header: title, stage, tags.
```

---

## GitHub Repo Skeleton (suggested)

```
/README.md
/chunks/
  /roofing_basics/
  /codes_and_standards/
  /project_management/
  /quality_control/
  /insurance_and_finance/
  /templates_and_scripts/
/prompts/
  research_sop.md
  code_extractor.md
  red_team.md
/eval/
  qna_set_v1.json
  hallucination_traps.md
/scripts/
  validate_yaml.py
  chunk_linter.py
```

---

## Want me to spin up the first artifacts?

If yes, I’ll:
1. Draft the Scope/Taxonomy + System Prompt v1.
2. Give you the full prompt kit.
3. Set up the repo scaffold with validation scripts.
4. Seed 2–3 exemplar chunks so your team sees the pattern.

Just say “Go” and answer the clarifiers above. I’ll move.

---

Anything you’d tweak before we start?

---

**user:**

Le t me get this information for you and return

---

**assistant:**

Sounds good—grab what you need.

**While you’re collecting it, here’s a quick fill-in checklist you can drop info into:**

1. **Users &amp; Use-Cases**
   - Roles (sales rep, PM, QC inspector, admin, etc.)
   - Top 10 questions/tasks each role will ask the GPT

2. **Authoritative Sources You Already Trust**
   - Internal SOPs / checklists / contracts
   - Manufacturer install manuals you use most
   - Code/standard docs (IBC/IRC, OSHA, UL 2218, Texas WPI-8, etc.)

3. **Tone &amp; Guardrails**
   - Voice (strict, friendly, hybrid?)
   - “Never answer” areas (legal advice, HR, medical, etc.)
   - Mandatory disclaimers or escalation rules

4. **Platform Constraints**
   - Which GPT host (OpenAI custom GPT, RAG stack, etc.)
   - Context/file limits we must honor
   - Tooling you want integrated (calculators, calendars, email templates)

5. **Maintenance**
   - Who approves new chunks
   - Update cadence (monthly, per code change, etc.)

---

### What I can prep in the meantime (just say the word):
- **v1 System/Role prompt** draft.
- **Repo skeleton + YAML/markdown chunk template**.
- **Multi-LLM research prompt pack** (for Grok/DeepSeek/Claude/Gemini).
- **Eval/QC checklist** for catching hallucinations.

Ping me when you’re back, or tell me what to start drafting now and I’ll move.

---

**user:**

Based on your current knowledge, give me a list of the 10 physical tools a roofing project manager needs everyday

---

**assistant:**

### Everyday Field Kit for a Roofing Project Manager  

| # | Tool | Why It’s in the Bag |
|---|------|---------------------|
| 1 | **25–30 ft tape measure** | Quick checks on eave/rake lengths, material take-offs, setback verification. |
| 2 | **Chalk line (blue &amp; red reels)** | Snapping straight reference lines for underlayment laps, starter rows, and metal panel alignment. |
| 3 | **Digital/analog pitch gauge (inclinometer)** | Confirms roof slope for code compliance, fastener spacing, and safety‐gear anchoring angles. |
| 4 | **Moisture meter (pin or pinless)** | Spot-checks decking and interior ceilings for hidden water intrusion before and after install. |
| 5 | **Heavy-duty utility knife with rapid-change blades** | Trimming underlayment, cutting samples, and opening bundles/boxes. |
| 6 | **Magnetic pickup tool (“nail magnet”)** | Sweeps work areas for stray nails and screws during daily QC walk-throughs. |
| 7 | **Inspection flashlight / headlamp** | Examines attic penetrations, chimney crickets, or evening punch-list items in low light. |
| 8 | **Smartphone or rugged tablet with camera apps** | Captures progress photos, drone feeds, punch-list notes, and real-time messaging with subs/homeowners. |
| 9 | **Adjustable ladder stabilizer (plus 24-32 ft extension ladder)** | Provides safe, code-compliant roof access without crushing gutters. |
|10 | **PPE bundle (hard hat, ANSI-rated safety glasses, Class A fall-arrest harness &amp; lanyard, cut-resistant gloves)** | Meets OSHA/TDI and insurance mandates while modeling safety culture for the crew. |

&gt; **Pro tip:** Keep a small **“red-tag” kit** (bright zip ties, duct tape, Sharpie) for flagging defects on the spot so crews know exactly what needs correction during the day.

---

**user:**

We are going to prompt the other LLM’s to gather data/information for our Roofing Project Manager GPT. draft prompts for DeepSeek, Claude, Grok, and Gemini , according to their strengths task them with gathering all pertinent data for a roofing project manager… specifically for central Texas (Austin). We are looking for building codes, practices, ordinances, etc. we also need data for asphalt shingles, metal, tile and flat roofing …

---

**assistant:**

Below are **four ready-to-copy research prompts**—one each for DeepSeek, Claude, Grok, and Gemini—tailored to their strengths.  
Paste each prompt into the corresponding LLM chat and let it run; the outputs will slot straight into your GitHub `/chunks/` folder.

---

## 1 ▸ DeepSeek — **“Code-Scraper &amp; Data Extractor”**

```
SYSTEM: You are DeepSeek-ResearchBot, optimized for pulling authoritative code/standard text and numeric parameters.

TASK: Build four Markdown knowledge chunks capturing **all legally binding roofing requirements for Central Texas (Austin / Travis County)**
      across these roof classes: asphalt shingles, metal panels, clay/concrete tile, low-slope (TPO/MB).

SCOPE:
  • City of Austin Building Code &amp; Local Amendments (currently adopts 2021 IRC/IBC with Austin mods)
  • Travis County ordinances that affect roofing (stormwater, tree protection, dumpster, noise)
  • Texas statutes affecting roofing (Business &amp; Commerce Code, TDI bulletins, WPI-8 notes—even though Austin isn’t coastal)
  • ANSI/SPRI ES-1, UL 2218, ASTM D7158/D3161, FM 4473 hail, OSHA 1926 Subpart M safety thresholds
  • Required design wind speed (115 mph ultimate per ASCE 7-16, Risk Cat II) &amp; exposure categories
  • Permit workflow and inspection stages unique to Austin (online AB+C portal)

OUTPUT SPEC — produce **one .md file per roof class** (4 files total):
---
title: &lt;slugified_roof_class&gt;_code_central_tx
domain: codes_and_standards
jurisdiction: austin_tx
code_year: 2021
tags: [code, &lt;roof_class&gt;, texas, pm]
review_date: 2025-07-24
---
### Key Numerical Requirements
| Parameter | Value | Source |
|-----------|-------|--------|
| Min slope | … | IRC R905.2.2 |
| Fastener spec | … | ASTM D3161-19 … |

### Clause-by-Clause Summary
- **IRC R905.2.8.5** — 4 nails per shingle; 6 nails in &gt;110 mph zones. &lt;Plain-English&gt;
- **Austin Amendment §R403.4** — Ice-barrier not required unless ...

### Permit &amp; Inspection Flow
1. AB+C application (roof replacement) → upload wind calc.
2. “497 Roof Final” inspection after decking visible, etc.

### References
[1] 2021 IRC with Austin Amendments §R905 (download link)  
[2] Austin Code Ord. 20240418-050 §25-11-39  
[3] OSHA 1926.501(b)(13) Fall Protection  
...
```
*DeepSeek Tips*: ask for **verbatim clause numbers** and a short “plain-English” translation under each bullet.

---

## 2 ▸ Claude — **“SOP &amp; Checklist Synthesizer”**

```
SYSTEM: You are Claude-PM, a process-clarity specialist.

GOAL: Convert code text + manufacturer specs into field-ready SOP bundles for a Roofing Project Manager in Austin.

DELIVERABLES (one .md file per roof class, plus one permit-flowchart chunk):

Chunk format
---
title: &lt;roof_class&gt;_PM_SOP
domain: project_management
tags: [SOP, checklist, &lt;roof_class&gt;, texas]
review_date: 2025-07-24
---
## Pre-Construction Checklist (≤ 12 bullets)
## In-Progress QC Checklist (≤ 12 bullets)
## Final Inspection Checklist (≤ 12 bullets)
### Daily Safety Touchpoints
### Crew Briefing Script (≤ 120 words)

Embed any decision trees in simple Mermaid syntax.

Cite every requirement back to either DeepSeek code chunk IDs or manufacturer docs (reference ID &amp; clause/page).

BONUS CHUNK  
title: austin_permit_workflow_flowchart  
domain: project_management  
Render a Mermaid flowchart of the AB+C portal permit process -&gt; inspections -&gt; close-out.
```

---

## 3 ▸ Grok — **“Red-Team &amp; Pitfall Hunter”**

```
SYSTEM: You are Grok-Contrarian, hired to find blind spots and upcoming risks for roofing PMs in Austin.

TASK A: List **10 high-impact pitfalls** (code traps, supply-chain quirks, climatic gotchas) that regularly bite PMs.
  For each:  • Pitfall  • Why it happens  • Mitigation step  • Source/citation.

TASK B: Forecast **5 pending or rumored regulation changes** (IRC 2024 adoption, Austin energy codes, solar-ready mandates, etc.)
  For each:  • Change summary  • Likely adoption date  • How to pre-adapt  • Source.

OUTPUT SPEC
---
title: pm_risk_map_central_tx
domain: red_team
tags: [risk, pitfalls, code_change, texas]
review_date: 2025-07-24
---
### Pitfalls
1. **Ice-&amp;-Water Misapplication** — Austin rarely freezes, so crews skip it, but insurance requires it on &lt;3-in-12 slopes. *Mitigation:* ...

### Emerging Regulations
- **2024 IRC adoption** (city council draft) — Adds stricter roof deck nailing pattern (§R803). …
```

---

## 4 ▸ Gemini — **“Manufacturer Spec &amp; Comparative Data Wrangler”**

```
SYSTEM: You are Gemini-SpecBot, great at aggregating product manuals and visual assets.

SCOPE: Central-Texas-relevant products:
  • Asphalt: GAF Timberline HDZ, OC Duration, Malarkey Vista
  • Metal: MBCI 24 ga standing seam, Berridge Cee-Lok, Decra Shake XD (stone-coated)
  • Tile: Eagle concrete tile, Ludowici clay mission
  • Low-Slope: Carlisle Sure-Weld TPO, GAF Ruberoid SBS, Johns Manville PVC

DELIVERABLE: one comparative Markdown chunk:

---
title: roof_system_comparison_central_tx
domain: materials
tags: [materials, spec, comparison, texas]
review_date: 2025-07-24
---
| System | Min Slope | Weight (psf) | Fastener / Adhesive | Fire Class | Uplift Rating | Warranty (yrs) | Reference |
|--------|-----------|--------------|---------------------|------------|---------------|----------------|-----------|
| Timberline HDZ | 2:12 | 2.4 | 4 galv nails, ASTM F1667 | A | 130 mph w/ 6-nail | 50 yr ltd | GAF Doc 508 |
| ... | | | | | | | |

### Key Installation Notes (bullets per system)
### Supplier Mapping (Austin metro distributors)
### Embed-Ready Images
- ![Timberline](&lt;img_url&gt;)  *(filename: timberline_hdz.jpg)*
- ...

### References
Link each spec/manual with doc ID + page.
```
*Gemini tips*: use public manufacturer PDFs and provide direct download links; include thumbnail images or URLs for embed.

---

### How to use these prompts
1. Create `/prompts/` folder in GitHub and drop each block in its own file (e.g., `deepseek_code_scraper.md`).
2. Hand the correct prompt to each LLM session.
3. Save their outputs under `/chunks/…`.
4. Run your YAML/Markdown linter script; iterate if any citations are missing.

Let me know when you need the repo scaffold or evaluation checklist, and I’ll spin them up.

---

