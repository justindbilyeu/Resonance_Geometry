# Connect DJI RC to Wi-Fi

- Conversation ID: 688b6b8a-057c-8325-8dac-e67c378fac54
- Created: 2025-07-31T13:11:39.463038

---

**user:**

Hey dude, I have a DJI Mini 3 Pro, and it has the remote with the screen on it, and I&#x27;m having a hard time getting connected to a network. Can you explain how to get that done?

---

**assistant:**

Hey dude, yeah—I’ve got you. The DJI Mini 3 Pro with the **DJI RC (the remote with the built-in screen)** connects to Wi-Fi so it can do things like download maps, updates, and sync with your DJI account. Here&#x27;s how to get it connected to a Wi-Fi network:

---

### ✅ Step-by-Step: Connect DJI RC to Wi-Fi

1. **Power on the DJI RC**  
   Hold the power button until the screen lights up.

2. **Go to the Home Screen**  
   Swipe down from the top of the screen to open the **Quick Settings** panel.  
   Tap the gear icon ⚙️ to go into **Settings**.

3. **Tap “Network &amp; Internet” or “Wi-Fi”**  
   (Depending on firmware version, this might be labeled differently.)

4. **Toggle Wi-Fi ON**  
   If it’s off, flip it on.

5. **Select Your Wi-Fi Network**  
   Choose your Wi-Fi from the list and enter the password if needed.

6. **Wait for Connection**  
   Once connected, you should see a ✅ checkmark or the Wi-Fi symbol appear in the status bar.

---

### 🔧 If You&#x27;re Having Trouble Connecting:

- **Double-check your password** — sounds basic, but it’s a common one.
- **Make sure the signal is strong** — if your router is far away or obstructed, it might not connect.
- **Forget and re-join** — tap the network, choose **Forget**, and try again.
- **Restart the DJI RC** — sometimes a reboot helps.
- **Update firmware later** — you can fly without Wi-Fi, just skip the update if you’re in the field.

---

Want me to walk you through hotspotting from your phone instead? Or are you trying to connect at home?

---

**assistant:**

Thanks for the photo! You’ve got the **DJI RC (with screen)** fired up and sitting on the startup/home screen. Here’s how to get to the Wi-Fi settings from where you are:

---

### 🔌 How to Connect DJI RC to Wi-Fi (From Your Current Screen):

1. **Swipe Down from the Top of the Screen**  
   Just like on a smartphone — swipe down once to reveal the status bar.

2. **Swipe Down Again for Full Quick Settings**  
   This second swipe should open a panel with brightness, airplane mode, Wi-Fi, Bluetooth, etc.

3. **Tap the Wi-Fi Icon**  
   If it’s gray, tap it to enable Wi-Fi. Then tap the text **“Wi-Fi”** to open the network list.

4. **Choose Your Network &amp; Enter Password**  
   Pick your home Wi-Fi or hotspot, enter the password, and connect.

5. ✅ Once Connected  
   You’ll see the Wi-Fi icon lit up in the status bar. You’re good to go for syncing maps, firmware updates, and logging in.

---

### 🛠 Bonus Tip
If you’re trying to **fly without needing to update firmware**, you can usually **skip login** once you’re in the DJI Fly app. But for new accounts or after factory reset, Wi-Fi is mandatory just once.

Let me know if you&#x27;re trying to use a **mobile hotspot**, and I’ll guide you through that setup too.

---

**user:**

I&#x27;m on a job site trying to connect, so I don&#x27;t have Wi-Fi in that way, but I have my cell phone, the drone, and the drone remote control.

---

**assistant:**

Perfect — you&#x27;re in the field, and the **DJI RC just needs an internet connection**, which your **phone can provide via hotspot**.

Here’s exactly how to **connect your DJI RC to your phone’s hotspot** so you can get maps, unlock zones, or log in:

---

## 🔄 Step-by-Step: Use Phone Hotspot with DJI RC

### 📱 On Your Phone (Create the Hotspot)
1. **Open Settings &gt; Personal Hotspot**
2. Turn **&quot;Allow Others to Join&quot;** ON (iPhone)  
   OR  
   Go to **Hotspot &amp; Tethering &gt; Wi-Fi Hotspot** and turn it ON (Android)
3. **Take note of the Wi-Fi name and password**

---

### 🎮 On Your DJI RC (Connect to the Hotspot)
1. **Swipe Down from the Top** of the DJI RC screen  
   ➜ Swipe again to open full Quick Settings

2. **Tap the Wi-Fi icon** to enable it

3. **Tap the word &quot;Wi-Fi&quot; or the gear icon**  
   ➜ This opens the network list

4. **Select your phone&#x27;s hotspot name**  
   ➜ Enter the password and tap **Connect**

5. ✅ Once connected, you should see the **Wi-Fi icon light up** in the status bar

---

### 🧪 Test the Connection
- Open **Profile** or **SkyPixel** on the home screen — if it loads, you&#x27;re online.
- You can now sync maps, check for updates, unlock airspace zones, etc.

---

Let me know your phone model if you need hotspot steps for your specific device. Or I can walk you through unlocking a geofenced zone if that’s what you’re trying to do.

---

**user:**

I’ve connected the controller to Wi-Fi and to the drone itself and I’m still getting a network error. Can you help me?

---

**assistant:**

Yep — thanks for the photo. You’re definitely **in an Authorization Zone**, and your drone is connected, but DJI Fly is throwing the dreaded:

&gt; **“Server error. Wait a moment and try again.”**

This usually means **the controller is *not* actually reaching DJI’s servers**, *even though it shows connected to Wi-Fi*. Let’s walk through a focused fix:

---

## ✅ Quick Fix Checklist: DJI RC + Authorization Zone Unlock

### 1. ✅ **Verify Wi-Fi Has Internet**
Even if Wi-Fi is connected, the RC may not have actual internet. Here’s how to double check:

- Swipe down twice from the top of the DJI RC screen
- Tap the ⚙️ Settings gear
- Tap **Wi-Fi** &gt; then look for the network you&#x27;re connected to
- If it says **“Connected, no internet”**, your phone&#x27;s hotspot may not be working right

🛠 **Fix**:  
- Try toggling your phone’s hotspot **off then on again**  
- Make sure **cell data** is enabled on your phone  
- On DJI RC, tap **Forget** the network, reconnect from scratch

---

### 2. 🔐 **Log in to DJI Account Again**
Sometimes a token or login expires, and it won’t let you unlock zones:

- On DJI RC home screen, tap **Profile**
- Log in again to your DJI account if prompted

---

### 3. 🧭 Use DJI Fly Safe Unlock Tool on Phone (if RC still fails)
If the RC is stubborn:

- On your **phone**, go to:  
  [https://www.dji.com/flysafe/self-unlock](https://www.dji.com/flysafe/self-unlock)

- Log in to your DJI account
- Select your drone (DJI Mini 3 Pro)
- Use the **map to choose your location**
- Submit the unlock request manually
- Then try syncing licenses on your RC:  
  ➜ In DJI RC: **Profile &gt; Fly Safe &gt; Sync Unlock Zones**

---

### 4. ✅ Confirm Controller’s Date/Time is Correct
Weird but true: if the RC&#x27;s system clock is off, some DJI server connections fail.

- Swipe down &gt; Settings ⚙️ &gt; System &gt; Date &amp; Time  
- Make sure it’s auto-set or accurate to your time zone

---

## 🚀 Once You’re Connected

Try unlocking again from the DJI Fly interface:
- Tap the red **Authorization Zone**
- Tap **Unlock**
- If successful, it’ll allow takeoff

---

Let me know:
- Your **phone model**
- Whether the DJI RC shows **“Connected, Internet Available”**
- If it shows **no internet**, I can walk you through getting hotspot internet flowing again

Want me to write a backup **manual unlock checklist** you can keep on your phone for job sites?

---

