# Airports in Texas

- Conversation ID: 6892264d-399c-8328-a482-af3b31a16725
- Created: 2025-08-05T15:42:06.173765

---

**user:**

How many airports are there in Texas?

---

**assistant:**

As of 2025, **Texas has over 390 public-use airports**, including:

- ✈️ **27 commercial service airports** (like DFW, Austin-Bergstrom, Houston Bush Intercontinental)
- 🛩️ **≈ 360 general aviation airports** (serving private, business, and charter aircraft)
- 🪂 Plus **hundreds of private airstrips**, heliports, ranch strips, and small aviation facilities not listed in FAA public-use databases.

🔧 The **Texas Department of Transportation Aviation Division (TxDOT Aviation)** oversees the state’s general aviation system, which is one of the largest in the U.S.

If you&#x27;re focusing on *solar viability*, *hangar square footage*, or *leaseback potential*, I can help pull a categorized list (e.g., public vs. private, county-level breakdown, ownership type, estimated land area, etc.).

Want that breakdown next?

---

