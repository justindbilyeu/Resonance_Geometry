# Tailored Prompts for Language Models

- Conversation ID: 7e7b009d-9c32-401b-8810-e4756cbb10d0
- Created: 2023-05-02T13:55:13.035874

---

**user:**

As an expert in Prompt generation with a focus on creating prompts tailored for GPT-4, you are tasked with creating prompts for different language models based on the user’s goals. In order to optimize the prompt, you will ask questions of the user in order to ascertain and gather the information needed to create a perfect prompt for the chosen language model. New prompts must be generated in a copyable text box. Do you understand?

---

**assistant:**

Yes, I understand. I will ask you questions to gather the necessary information and then provide you with a tailored prompt for the chosen language model in a copyable text box. Please let me know the user&#x27;s goal and the language model you want the prompt to be optimized for.

---

**user:**

Goals: to generate an email series focused on business owners in &lt;location&gt; with GPT-4

---

**assistant:**

To create the perfect prompt for generating an email series focused on business owners in a specific location using GPT-4, I&#x27;ll need some additional information:

1. What is the specific location you want to target?
2. What is the main subject or theme of the email series (e.g., marketing tips, management advice, industry news)?
3. How many emails should be in the series?
4. What is the desired length of each email?
5. Are there any specific points or topics you want to be covered in the email series?

Please provide answers to these questions so I can create a tailored prompt for you.

---

**user:**

What is the specific location you want to target? Cities in Colorado, Denver, Castle Rock, and Colorado Springs.
What is the main subject or theme of the email series (e.g., marketing tips, management advice, industry news)? A new revenue stream for your Sales Team
How many emails should be in the series? 5 emails
What is the desired length of each email? Short, a 30 second read.
Are there any specific points or topics you want to be covered in the email series? &lt;Solar&gt;

---

**assistant:**

Thank you for providing the necessary information. Based on your input, here&#x27;s a tailored prompt for generating an email series using GPT-4:

```
Generate a series of 5 short emails, each taking approximately 30 seconds to read, targeting business owners in Denver, Castle Rock, and Colorado Springs, Colorado. The main subject of the email series should be &quot;A New Revenue Stream for Your Sales Team&quot; and should focus on how solar energy can create additional revenue opportunities for businesses. Each email should cover a different aspect of this subject, with the goal of engaging and informing the audience about the benefits of solar energy for their sales teams.
```

You can use this prompt with GPT-4 to create the desired email series. Let me know if you need any further assistance or if you&#x27;d like to modify the prompt.

---

