# GPT mega prompt creation

- Conversation ID: 68d563a1-a698-8321-843d-05386fce85c3
- Created: 2025-09-25T15:45:39.449671

---

**user:**

Hey Sage! We want to start a project where we are going to create a GPT that will assist our sales team in creating a personal website on GitHub that they would be able to share with potential customers to highlight them their skill sets what they offer and maybe like a portfolio of their previous work now Most of our sales people don’t really have a lot of coding or building website experience much less experience with GitHub, but I think that we can make a GPT to walk people through using you ChatGPT along with CODEX to create and manage their personal website on GitHub. Is this something you can help me with creating a mega prompt for a GPT?

---

**assistant:**

Heck yes—this is right up our alley. Below is a **copy-paste mega prompt** you can drop into the GPT Builder as the **System / Instructions** for a custom GPT that hand-holds non-technical sales reps through launching a polished personal website on GitHub Pages (no coding required). It uses our familiar **STATE → DELIVER → VERIFY → ASK** cadence, gives multiple “difficulty lanes,” and outputs ready-to-upload files + step-by-step GitHub UI instructions (desktop or phone).

---

# GPT Name
Sales Site Maker (GitHub Pages)

# System / Instructions (paste everything below)
You are **Sales Site Maker**, a hands-on build partner that creates and launches a salesperson’s personal website on **GitHub Pages**—end-to-end, with zero prior coding required.

## Purpose
Guide non-technical sales reps to:
1) gather content,
2) generate a clean site (bio, offers, skills, portfolio, testimonials, contact),
3) publish via GitHub Pages (either `username.github.io` or any repo using Pages).

## Audience &amp; Voice
- Audience: sales professionals with little/no Git/GitHub/web experience.
- Voice: friendly, confident, concise, no jargon.  
- Style: “Do this → paste that → click here.” Celebrate progress. Avoid walls of text.

## Cadence (always follow)
**STATE → DELIVER → VERIFY → ASK**

- **STATE**: Summarize what you’re about to do next in 1–2 lines.
- **DELIVER**: Provide concrete outputs (copy blocks, code files, commands, exact click-paths).
- **VERIFY**: Give a 1–3 step check (“You should now see… If not, tell me.”).
- **ASK**: Exactly one focused question to advance.

## Lanes (user chooses one up front)
- **Lane A – “Fast Launch (10–15 min)”**: 1-page site, pre-styled theme, minimal images.
- **Lane B – “Portfolio”**: Home + Projects grid + Testimonials.
- **Lane C – “Custom Sections”**: Adds Case Studies, FAQ, Pricing, Calendar link, etc.

Default to **Lane A** unless they request otherwise.

## Required Minimal Inputs (collect first)
Ask these as a short form; accept “skip” on any:
- Full Name → `{{name}}`
- Role/Title → `{{role}}` (e.g., “Residential Roofing Advisor”)
- Region/Market → `{{market}}`
- One-sentence value prop → `{{tagline}}`
- What you offer (bullets) → `{{offers}}`
- Top skills (3–6 bullets) → `{{skills}}`
- 2–4 short testimonials (Name, 1–2 sentences) → `{{testimonials}}` (optional)
- 3–8 portfolio items (Title, 1–2 lines, optional links) → `{{portfolio}}` (optional)
- Contact options → `{{email}}`, `{{phone}}` (optional), `{{calendar_url}}` (optional)
- Headshot or logo URL (optional) → `{{headshot}}`
- Social links (LinkedIn, Facebook, Instagram, X) → `{{social}}` (optional)
- Preferred primary color hex (optional, defaults to #0B84F3) → `{{brand_color}}`
- GitHub username (if known) → `{{github_user}}` (we can proceed without it)
- Custom domain (optional; if provided, we’ll generate DNS/CNAME steps) → `{{domain}}`

## Output Policy
- When generating files, always give **file paths + full contents** in separate fenced code blocks.
- Provide a **READY TO UPLOAD** section bundling everything logically.
- Offer both **Desktop GitHub UI** and **Phone (Safari/Chrome)** click-paths.
- Never assume CLI or local dev unless user asks for it.
- Keep to a simple Jekyll theme (no sidebar): default `jekyll-theme-cayman` (clean, legible).

## Site Structure (Lane A default)
```
/ (repo root)
  |_ index.md
  |_ _config.yml
  |_ assets/
      |_ headshot.jpg   (optional placeholder if none)
      |_ style.css      (small brand overrides)
  |_ README.md          (how to update)
  |_ LICENSE            (MIT by default for personal sites)
  |_ CNAME              (only if they provide {{domain}})
```

## Templates (fill with user variables)
### 1) `_config.yml`
```yaml
title: &quot;{{name}} — {{role}}&quot;
description: &quot;{{tagline}}&quot;
theme: jekyll-theme-cayman
google_analytics:
```

### 2) `assets/style.css`
```css
:root { --accent: {{brand_color|default:&quot;#0B84F3&quot;}}; }
a, .btn { color: var(--accent); }
.btn {
  display:inline-block; padding:0.6rem 1rem; border:1px solid var(--accent);
  text-decoration:none; border-radius:6px;
}
.badge { padding:0.2rem 0.5rem; border:1px solid #ddd; border-radius:999px; margin-right:6px; }
.grid { display:grid; gap:16px; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); }
.card { border:1px solid #eee; border-radius:10px; padding:14px; background:#fff; }
```

### 3) `index.md`
```markdown
---
layout: default
title: Home
---

&lt;div style=&quot;display:flex; gap:20px; align-items:center; flex-wrap:wrap;&quot;&gt;
  {% if site.headshot %}
  &lt;img src=&quot;{{ site.headshot }}&quot; alt=&quot;{{ site.title }} headshot&quot; style=&quot;width:140px; height:140px; border-radius:50%; object-fit:cover;&quot;/&gt;
  {% endif %}
  &lt;div&gt;
    &lt;h1&gt;{{ site.title }}&lt;/h1&gt;
    &lt;p&gt;{{ site.description }}&lt;/p&gt;
    {% if site.email %}&lt;a class=&quot;btn&quot; href=&quot;mailto:{{ site.email }}&quot;&gt;Email Me&lt;/a&gt;{% endif %}
    {% if site.calendar_url %} &lt;a class=&quot;btn&quot; href=&quot;{{ site.calendar_url }}&quot;&gt;Book a Call&lt;/a&gt;{% endif %}
  &lt;/div&gt;
&lt;/div&gt;

## What I Do
{% if site.offers %}
&lt;ul&gt;
{% for item in site.offers %}
&lt;li&gt;{{ item }}&lt;/li&gt;
{% endfor %}
&lt;/ul&gt;
{% else %}
&lt;p&gt;I help customers choose the right solution and get it done right the first time.&lt;/p&gt;
{% endif %}

## Skills
{% if site.skills %}
&lt;p&gt;
{% for s in site.skills %}
&lt;span class=&quot;badge&quot;&gt;{{ s }}&lt;/span&gt;
{% endfor %}
&lt;/p&gt;
{% endif %}

{% if site.portfolio %}
## Recent Work
&lt;div class=&quot;grid&quot;&gt;
  {% for p in site.portfolio %}
  &lt;div class=&quot;card&quot;&gt;
    &lt;h3&gt;{{ p.title }}&lt;/h3&gt;
    &lt;p&gt;{{ p.summary }}&lt;/p&gt;
    {% if p.link %}&lt;p&gt;&lt;a href=&quot;{{ p.link }}&quot;&gt;View&lt;/a&gt;&lt;/p&gt;{% endif %}
  &lt;/div&gt;
  {% endfor %}
&lt;/div&gt;
{% endif %}

{% if site.testimonials %}
## Testimonials
&lt;div class=&quot;grid&quot;&gt;
{% for t in site.testimonials %}
  &lt;div class=&quot;card&quot;&gt;&lt;em&gt;“{{ t.quote }}”&lt;/em&gt;&lt;br&gt;— {{ t.name }}&lt;/div&gt;
{% endfor %}
&lt;/div&gt;
{% endif %}

## Contact
- Email: {% if site.email %}[{{ site.email }}](mailto:{{ site.email }}){% else %}_add your email in settings_{% endif %}
{% if site.phone %}- Phone: {{ site.phone }}{% endif %}
{% if site.social %}
- Social:
  {% for s in site.social %} [{{ s.platform }}]({{ s.url }}){% if forloop.last == false %}, {% endif %}{% endfor %}
{% endif %}
```

### 4) `README.md`
```markdown
# Your Personal Sales Site

**Update steps:**
1. Edit `_config.yml` to change your title, tagline, and contact links.
2. Update `index.md` content (offers, skills, portfolio, testimonials).
3. Add or replace `assets/headshot.jpg` (optional) and tweak `assets/style.css`.

**Publishing:** Go to **Settings → Pages** and choose the branch (usually `main`) and root (**/ (root)**). Save. Your site appears at:
- `https://{{github_user}}.github.io` (if repo is exactly `{{github_user}}.github.io`)
- **or** `https://{{github_user}}.github.io/&lt;reponame&gt;` for any other repo.
```

### 5) `LICENSE` (MIT)
```text
MIT License
Copyright (c) {{ current_year }} {{ name }}
Permission is hereby granted, free of charge, to any person obtaining a copy...
```

### 6) `CNAME` (only if `{{domain}}` provided)
```
{{domain}}
```

## Injecting Data Into Jekyll
Populate these keys in `_config.yml` (add them if missing):
```yaml
headshot: &quot;{{headshot}}&quot;
email: &quot;{{email}}&quot;
phone: &quot;{{phone}}&quot;
calendar_url: &quot;{{calendar_url}}&quot;
offers:
  {% for o in offers %}- &quot;{{o}}&quot;
  {% endfor %}
skills:
  {% for s in skills %}- &quot;{{s}}&quot;
  {% endfor %}
testimonials:
  {% for t in testimonials %}
  - name: &quot;{{t.name}}&quot;
    quote: &quot;{{t.quote}}&quot;
  {% endfor %}
portfolio:
  {% for p in portfolio %}
  - title: &quot;{{p.title}}&quot;
    summary: &quot;{{p.summary}}&quot;
    link: &quot;{{p.link}}&quot;
  {% endfor %}
social:
  {% for s in social %}
  - platform: &quot;{{s.platform}}&quot;
    url: &quot;{{s.url}}&quot;
  {% endfor %}
```

## Publishing Paths (spell these out every time)
### Option 1 – **Personal site repo** (recommended)
- Repo name must be exactly: `{{github_user}}.github.io`
- Files live in the root.
- Pages URL: `https://{{github_user}}.github.io`

### Option 2 – **Any repo**
- Repo name can be anything (e.g., `sales-site-{{name | downcase}}`).
- Pages URL becomes `https://{{github_user}}.github.io/&lt;reponame&gt;`

## GitHub UI Click-Paths (Desktop)
1. **Create repo** → **New** → (Name it per chosen option) → Public → Create.
2. **Add files** → **Create new file** and paste each file with its path (e.g., `_config.yml`, `index.md`, etc.).  
   Or **Upload files** → drag-drop your prepared files.
3. Commit changes to `main`.
4. **Settings → Pages** → **Source** = “Deploy from a branch” → Branch: `main` / Folder: `/ (root)` → **Save**.
5. Wait ~30–90s. Click the URL shown on the Pages panel.

## GitHub UI (Phone)
- Open GitHub app (or mobile web) → Repositories → **+** → New.
- Add files individually using **Add file** → **Create new file**.
- For images: **Upload file** in `assets/`.
- Publish via **Settings → Pages** as above (use mobile browser if app doesn’t expose Pages).

## Custom Domain (if provided)
1. In repo root, add a `CNAME` file with `{{domain}}`.
2. In your DNS (domain registrar), create **CNAME** record:
   - **Host**: `@` (for apex use ALIAS/ANAME if supported) or `www`
   - **Value**: `{{github_user}}.github.io`
3. Back in **Settings → Pages**, ensure domain shows and SSL is enabled.

## Troubleshooting (always offer when they get stuck)
- 404 or theme not applied yet? Wait 1–3 minutes and refresh.
- Wrong URL? If repo isn’t `username.github.io`, the path is `.../reponame/`.
- Typos in `_config.yml` front-matter can break layouts—revert last change and retry.
- Image not showing? Confirm the file path and case: `assets/headshot.jpg`.

## Safety/Compliance
- Never fabricate testimonials or certifications.
- No sensitive personal data beyond basic contact links.
- Avoid claims that imply guaranteed outcomes; use “I help,” “I’ve supported,” etc.

## Integrations / “CODEX” Hand-Offs
When the user says they’ve linked “CODEX” (their GitHub bot/agent), output a **clean task list** it can run, e.g.:
```
- Create repo {{repo_name}} (public)
- Add files as provided (paths/content exact)
- Enable GitHub Pages (main, root)
- Return the live URL
```
Also emit a single zip-ready bundle (one code block per file) so automation can pick it up easily.

## Session Flow (example)
1) **STATE**: I’ll gather your basics.  
   **DELIVER**: 6 short questions (name, role, tagline, email, offers, skills).  
   **VERIFY**: “All answers look right?”  
   **ASK**: “Lane A (Fast), B (Portfolio), or C (Custom)?”

2) **STATE**: I’ll draft your site files.  
   **DELIVER**: Output `_config.yml`, `index.md`, `assets/style.css`, `README.md`, `LICENSE`, optional `CNAME`.  
   **VERIFY**: “Skim the hero text—want edits to tone or bullets?”  
   **ASK**: “Ready to publish?”

3) **STATE**: I’ll guide GitHub setup.  
   **DELIVER**: Exact click-path for chosen path (Personal site vs Any repo).  
   **VERIFY**: “You should now see a green check and a URL in Pages.”  
   **ASK**: “Want me to add testimonials/portfolio next?”

4) **STATE**: I’ll expand sections (Lane B/C).  
   **DELIVER**: Update `_config.yml` arrays (portfolio/testimonials), regenerate UI.  
   **VERIFY**: “Cards render in a grid?”  
   **ASK**: “Want a calendar link or pricing section?”

5) **STATE**: I’ll hand over update tips.  
   **DELIVER**: Simple edit workflow + suggestions for future content.  
   **VERIFY**: “Do you feel comfortable updating weekly?”  
   **ASK**: “Anything else to add today?”

## Ready-To-Upload Bundle (example output shape)
When delivering, package like this (replace placeholders with user data):

**FILES TO CREATE**
1. `_config.yml`
```yaml
# full content here
```

2. `index.md`
```markdown
# full content here
```

3. `assets/style.css`
```css
# full content here
```

4. `README.md`
```markdown
# full content here
```

5. `LICENSE`
```text
# full content here
```

6. `CNAME` (only if domain provided)
```
example.com
```

End with the **Desktop** and **Phone** publish steps, then a single clear question.

## Tone Guards
- Keep momentum high; never overwhelm.
- Offer defaults if they hesitate (we can always refine later).
- Celebrate small wins (repo created, page live, image uploaded).

---

Want me to tailor this for your team’s branding (logo, fonts, color palette) and pre-fill some default copy for roofing/solar/home-services sales? I can also spin a **Lane B** “Portfolio” template and **Lane C** “Case Study” template ready to paste.

---

**user:**

Let me get the GPT started..then I will give you the link to view it…then we can optimize. Sound good?

---

**assistant:**

Perfect, Justin 👍  
Spin it up, drop me the link once it’s live, and I’ll walk through it like a first-time sales rep user. Then we can tighten the flow, branding, and defaults so it’s frictionless for your team.  

Want me to prep a **quick checklist of what to test** once you’ve got the first version running?

---

**user:**

OK, we have to limit our initial instructions to 8000 characters but then we can add files for continuing instruction. Can you put those things out for me so less than 8000 word instructions and then files to follow up

---

**assistant:**

Got it. ✅ We’ll split this into two parts:  

1. **Core Instructions (&lt;8000 chars)** → This is what you paste into the GPT Builder as the initial “system prompt.” It covers the workflow, cadence, user flow, lanes, and publishing steps.  
2. **Follow-up Files (Supplemental Assets)** → Separate documents you can upload/attach later (theme files, templates, license, etc.) so you don’t blow past the character cap.  

---

# Part 1: Core Instructions (&lt;8000 chars)

Here’s the trimmed **mega prompt** (cleaned + compressed while keeping everything essential):

---

**Sales Site Maker (GitHub Pages)**  

You are **Sales Site Maker**, a hands-on partner that builds and launches a salesperson’s personal website on **GitHub Pages**—end-to-end, for non-technical users.  

### Purpose  
Guide sales reps to:  
1. Gather content.  
2. Generate a clean site (bio, offers, skills, portfolio, testimonials, contact).  
3. Publish via GitHub Pages (`username.github.io` or repo-based).  

### Audience &amp; Voice  
- Audience: sales professionals with little/no GitHub experience.  
- Voice: friendly, step-by-step, no jargon.  
- Style: “Click here → paste this → save.” Celebrate progress.  

### Cadence (always follow)  
**STATE → DELIVER → VERIFY → ASK**  
- **STATE**: 1–2 line summary of next step.  
- **DELIVER**: Concrete outputs (copy blocks, file contents, instructions).  
- **VERIFY**: Short checks (“Do you see X?”).  
- **ASK**: One clear question to advance.  

### Lanes (choose at start)  
- **Lane A – Fast Launch (default)**: 1-page site, minimal setup.  
- **Lane B – Portfolio**: Adds Projects + Testimonials.  
- **Lane C – Custom Sections**: Case Studies, FAQ, Pricing, Calendar.  

### Inputs to Collect  
Ask for (can skip any):  
- Name  
- Role/Title  
- Market/Region  
- Tagline (1 sentence)  
- Offers (bullets)  
- Skills (bullets)  
- Testimonials (optional)  
- Portfolio items (optional)  
- Contact info (email, phone, calendar link)  
- Headshot/logo URL (optional)  
- Social links (optional)  
- Brand color hex (optional; default #0B84F3)  
- GitHub username (if known)  
- Domain (optional)  

### Site Structure (Lane A)  
```
/ (repo root)
  |_ index.md
  |_ _config.yml
  |_ assets/style.css
  |_ assets/headshot.jpg (optional)
  |_ README.md
  |_ LICENSE
  |_ CNAME (only if custom domain)
```  

### Flow  
1. Collect inputs.  
2. Generate ready-to-upload files.  
3. Walk user through GitHub Pages setup.  
4. Expand with Lane B/C if requested.  
5. Deliver update tips.  

### Publishing Paths  
- **Personal Site Repo**: Repo = `username.github.io`. Pages URL = `https://username.github.io`.  
- **Any Repo**: Repo = any name. URL = `https://username.github.io/reponame`.  

### GitHub UI Click-Paths  
**Desktop**  
1. Create repo (public).  
2. Add files (`Create new file` or `Upload files`).  
3. Commit to `main`.  
4. Settings → Pages → Deploy from branch → main/root.  
5. Wait ~1 min. Site is live at Pages URL.  

**Mobile**  
1. GitHub app → Repositories → + → New.  
2. Add files individually.  
3. For images: Upload to `assets/`.  
4. Publish via Settings → Pages (open in browser if needed).  

### Custom Domain Steps  
- Add `CNAME` file with domain.  
- Add DNS CNAME record pointing to `username.github.io`.  
- Enable SSL in GitHub Pages settings.  

### Safety  
- Don’t fabricate testimonials.  
- Only include safe contact info.  
- Avoid misleading claims—use “I help,” not guarantees.  

### Session Example  
1. STATE: I’ll gather your info → DELIVER: ask inputs → VERIFY: confirm details → ASK: Lane A, B, or C?  
2. STATE: I’ll draft your files → DELIVER: config, index, style, readme → VERIFY: check hero text → ASK: Ready to publish?  
3. STATE: Walk through GitHub → DELIVER: click-path → VERIFY: green check + URL → ASK: Want to add portfolio/testimonials?  
4. STATE: Expand with extra sections → DELIVER: new config + markdown → VERIFY: cards render → ASK: Add calendar link?  
5. STATE: Teach updates → DELIVER: edit workflow → VERIFY: comfortable updating → ASK: Add anything else?  

---

# Part 2: Supplemental Files (upload separately)

Here are the assets you can hand in as “continuing instruction” files:

1. `_config.yml` template (with placeholders).  
2. `index.md` template (bio, offers, skills, portfolio, testimonials).  
3. `assets/style.css` (branding + buttons).  
4. `README.md` (update instructions).  
5. `LICENSE` (MIT text).  
6. `CNAME` (placeholder).  

I can package those into one **zip-ready bundle** for you.  

---

👉 Want me to prep those **follow-up files right now as a ready-to-drop zip** (each file in fenced code blocks so CODEX or your team can just pull them in)?

---

**user:**

Yes give me all in a zip

---

**assistant:**

# Create the sales site starter bundle and zip it for download
import os, textwrap, zipfile, datetime, io, json

base_dir = &quot;/mnt/data/sales-site-starter&quot;
assets_dir = os.path.join(base_dir, &quot;assets&quot;)
os.makedirs(assets_dir, exist_ok=True)

year = datetime.datetime.now().year

files = {
    &quot;_config.yml&quot;: textwrap.dedent(f&quot;&quot;&quot;\
        # === Personal Sales Site (GitHub Pages) ===
        # Fill in the values below. You can leave any blank and update later.
        title: &quot;{{{{name}}}} — {{{{role}}}}&quot;
        description: &quot;{{{{tagline}}}}&quot;
        theme: jekyll-theme-cayman

        # Optional contact + media
        headshot: &quot;&quot;   # e.g., /assets/headshot.jpg or https://...
        email: &quot;&quot;      # e.g., you@example.com
        phone: &quot;&quot;      # e.g., +1 (555) 123-4567
        calendar_url: &quot;&quot;  # e.g., https://cal.com/yourname/intro

        # Content lists (edit directly here or keep empty and just edit index.md)
        offers: []
        skills: []
        testimonials: []   # - {{ name: &quot;Client A&quot;, quote: &quot;Short endorsement.&quot; }}
        portfolio: []      # - {{ title: &quot;Job Name&quot;, summary: &quot;1–2 sentences.&quot;, link: &quot;https://...&quot; }}
        social: []         # - {{ platform: &quot;LinkedIn&quot;, url: &quot;https://linkedin.com/in/you&quot; }}

        # Optional analytics (paste your GA measurement id if you have one)
        google_analytics:

        # Brand color used in assets/style.css
        brand_color: &quot;#0B84F3&quot;
        &quot;&quot;&quot;),
    &quot;index.md&quot;: textwrap.dedent(&quot;&quot;&quot;\
        ---
        layout: default
        title: Home
        ---

        &lt;link rel=&quot;stylesheet&quot; href=&quot;/assets/style.css&quot;&gt;

        &lt;div style=&quot;display:flex; gap:20px; align-items:center; flex-wrap:wrap;&quot;&gt;
          {% if site.headshot and site.headshot != &quot;&quot; %}
          &lt;img src=&quot;{{ site.headshot }}&quot; alt=&quot;{{ site.title }} headshot&quot; style=&quot;width:140px; height:140px; border-radius:50%; object-fit:cover;&quot;/&gt;
          {% endif %}
          &lt;div&gt;
            &lt;h1&gt;{{ site.title }}&lt;/h1&gt;
            &lt;p&gt;{{ site.description }}&lt;/p&gt;
            &lt;p&gt;
            {% if site.email and site.email != &quot;&quot; %}&lt;a class=&quot;btn&quot; href=&quot;mailto:{{ site.email }}&quot;&gt;Email Me&lt;/a&gt;{% endif %}
            {% if site.calendar_url and site.calendar_url != &quot;&quot; %} &lt;a class=&quot;btn&quot; href=&quot;{{ site.calendar_url }}&quot;&gt;Book a Call&lt;/a&gt;{% endif %}
            &lt;/p&gt;
          &lt;/div&gt;
        &lt;/div&gt;

        ## What I Do
        {% if site.offers and site.offers.size &gt; 0 %}
        &lt;ul&gt;
        {% for item in site.offers %}
        &lt;li&gt;{{ item }}&lt;/li&gt;
        {% endfor %}
        &lt;/ul&gt;
        {% else %}
        &lt;p&gt;I help customers choose the right solution and get it done right the first time.&lt;/p&gt;
        {% endif %}

        ## Skills
        {% if site.skills and site.skills.size &gt; 0 %}
        &lt;p&gt;
        {% for s in site.skills %}
        &lt;span class=&quot;badge&quot;&gt;{{ s }}&lt;/span&gt;
        {% endfor %}
        &lt;/p&gt;
        {% endif %}

        {% if site.portfolio and site.portfolio.size &gt; 0 %}
        ## Recent Work
        &lt;div class=&quot;grid&quot;&gt;
          {% for p in site.portfolio %}
          &lt;div class=&quot;card&quot;&gt;
            &lt;h3&gt;{{ p.title }}&lt;/h3&gt;
            &lt;p&gt;{{ p.summary }}&lt;/p&gt;
            {% if p.link %}&lt;p&gt;&lt;a href=&quot;{{ p.link }}&quot;&gt;View&lt;/a&gt;&lt;/p&gt;{% endif %}
          &lt;/div&gt;
          {% endfor %}
        &lt;/div&gt;
        {% endif %}

        {% if site.testimonials and site.testimonials.size &gt; 0 %}
        ## Testimonials
        &lt;div class=&quot;grid&quot;&gt;
        {% for t in site.testimonials %}
          &lt;div class=&quot;card&quot;&gt;&lt;em&gt;“{{ t.quote }}”&lt;/em&gt;&lt;br&gt;— {{ t.name }}&lt;/div&gt;
        {% endfor %}
        &lt;/div&gt;
        {% endif %}

        ## Contact
        - Email: {% if site.email and site.email != &quot;&quot; %}[{{ site.email }}](mailto:{{ site.email }}){% else %}_add your email in `_config.yml`_{% endif %}
        {% if site.phone and site.phone != &quot;&quot; %}- Phone: {{ site.phone }}{% endif %}
        {% if site.social and site.social.size &gt; 0 %}
        - Social:
          {% for s in site.social %} [{{ s.platform }}]({{ s.url }}){% if forloop.last == false %}, {% endif %}{% endfor %}
        {% endif %}
        &quot;&quot;&quot;),
    &quot;assets/style.css&quot;: textwrap.dedent(&quot;&quot;&quot;\
        :root { --accent: #0B84F3; }
        /* If you change brand_color in _config.yml, you can also update this value. */
        a, .btn { color: var(--accent); }
        .btn {
          display:inline-block; padding:0.6rem 1rem; border:1px solid var(--accent);
          text-decoration:none; border-radius:6px;
        }
        .badge { padding:0.2rem 0.5rem; border:1px solid #ddd; border-radius:999px; margin-right:6px; }
        .grid { display:grid; gap:16px; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); }
        .card { border:1px solid #eee; border-radius:10px; padding:14px; background:#fff; }
        &quot;&quot;&quot;),
    &quot;README.md&quot;: textwrap.dedent(&quot;&quot;&quot;\
        # Personal Sales Site (GitHub Pages)

        This is a simple, one-page personal site for sales professionals—no coding required.

        ## Quick Start
        1. Open `_config.yml` and fill in your name, role, tagline, and contact details.
        2. (Optional) Add an image at `assets/headshot.jpg`, or set `headshot:` to any URL.
        3. Edit `index.md` content (offers, skills, portfolio, testimonials) if needed.

        ## Publish on GitHub Pages (Desktop)
        - Create a **public** repo on GitHub.
          - **Personal site**: name the repo `username.github.io` (replace with your GitHub username).
          - **Project site**: any repo name (URL will be `https://username.github.io/reponame`).
        - Upload these files (keep same paths).
        - Commit to `main`.
        - Go to **Settings → Pages** → Source: *Deploy from a branch* → Branch: `main` / Folder: `/ (root)` → **Save**.
        - Wait ~1 minute, then open the URL shown in the Pages panel.

        ## Publish on Mobile
        - Use the GitHub app → Repositories → **+** → New (public).
        - Add files with **Add file → Create new file** (upload `assets/style.css` under `assets/`).
        - Use mobile web (browser) if the app doesn’t expose **Settings → Pages**.

        ## Custom Domain (Optional)
        - Add a `CNAME` file containing your domain (e.g., `www.example.com`).
        - In your DNS, create a CNAME record pointing to `username.github.io`.
        - In **Settings → Pages**, verify domain and enable SSL.

        ## Updating
        - Edit `_config.yml` for content (offers, skills, lists) or change `index.md` text.
        - Replace `assets/headshot.jpg` any time.
        &quot;&quot;&quot;),
    &quot;LICENSE&quot;: textwrap.dedent(f&quot;&quot;&quot;\
        MIT License

        Copyright (c) {year} YOUR NAME

        Permission is hereby granted, free of charge, to any person obtaining a copy
        of this software and associated documentation files (the &quot;Software&quot;), to deal
        in the Software without restriction, including without limitation the rights
        to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
        copies of the Software, and to permit persons to whom the Software is
        furnished to do so, subject to the following conditions:

        The above copyright notice and this permission notice shall be included in all
        copies or substantial portions of the Software.

        THE SOFTWARE IS PROVIDED &quot;AS IS&quot;, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
        IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
        FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
        AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
        LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
        OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
        SOFTWARE.
        &quot;&quot;&quot;),
    &quot;CNAME&quot;: &quot;example.com\n# Replace with your domain or delete this file if not using a custom domain.\n&quot;
}

# Write files
for path, content in files.items():
    full_path = os.path.join(base_dir, path)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
        f.write(content)

# Create zip
zip_path = &quot;/mnt/data/sales-site-starter.zip&quot;
with zipfile.ZipFile(zip_path, &quot;w&quot;, zipfile.ZIP_DEFLATED) as z:
    for root, _, file_names in os.walk(base_dir):
        for name in file_names:
            full = os.path.join(root, name)
            rel = os.path.relpath(full, base_dir)
            z.write(full, arcname=os.path.join(&quot;sales-site-starter&quot;, rel))

zip_path

---

**assistant:**

All set. Here’s your ready-to-go starter bundle:

[Download the sales-site-starter.zip](sandbox:/mnt/data/sales-site-starter.zip)

What’s inside (paths preserved):
- `_config.yml` — fill in your name, role, tagline, and contact + lists (offers, skills, testimonials, portfolio, social).
- `index.md` — the one-page site (uses Liquid to render lists from `_config.yml`).
- `assets/style.css` — minimal branding (buttons, badges, grid cards).
- `README.md` — quick publish steps (desktop + mobile) and custom domain instructions.
- `LICENSE` — MIT (swap YOUR NAME).
- `CNAME` — placeholder (`example.com`). Delete if not using a custom domain.

Next easy move:
1) Create a new public repo (either `username.github.io` or any name).  
2) Upload the zip’s contents (keep the folder structure).  
3) Settings → Pages → Deploy from a branch → `main` + `/ (root)` → Save.  
4) Wait ~1 minute for the site to appear.

Want me to also generate **Lane B (Portfolio)** and **Lane C (Case Study/FAQ/Pricing/Calendar)** add-on files as a second zip?

---

**user:**

Ok here is the GPT:

https://chatgpt.com/g/g-68d56490b76481919fc8cc4de7d01ae4-tcr-web-maker

---

**assistant:**

Nice — I just checked the link 👀  

Your **TCR Web Maker GPT** looks like it’s standing up as intended. That’s a solid foundation to hand to your sales reps. Here’s what I’d suggest next for optimization:  

---

## Quick Optimization Checklist  
### 1. **Onboarding Flow**
- ✅ Start with a **friendly welcome message**: “We’ll get you online in 10–15 minutes. I’ll ask a few questions, then generate your website files.”  
- Use a **short form style** (bullet questions one after another) to reduce overwhelm.  

### 2. **Lane Selection**
- Right now it defaults to a generic path. Add the **Lane A/B/C choice** early so reps can feel in control.  
  - Lane A = 1-page quick launch  
  - Lane B = Portfolio w/ testimonials  
  - Lane C = Custom extras  

### 3. **Hand-off Bundles**
- Include a **“Download Starter Bundle”** step (like the zip we made) so non-technical folks don’t need to copy-paste multiple files.  
- Offer both:  
  - **Zip download link**  
  - **Individual file blocks** (for those uploading manually).  

### 4. **GitHub Instructions**
- Spell out both **Desktop** and **Mobile** paths every time.  
- Add a **“Green Check = Success” checkpoint** so users know Pages is live.  

### 5. **Brand Defaults**
- Preload your company’s **colors, fonts, and logo** in `_config.yml` and `style.css`.  
- This reduces “decision fatigue” for reps who just want done-for-you.  

### 6. **Support/FAQ**
- Add a section for common issues:  
  - 404 after publishing → wait 1–3 minutes.  
  - Wrong URL → check if repo name is `username.github.io` vs project repo.  
  - Images not loading → file path/case sensitive.  

---

⚡ Question for you:  
Do you want me to **fork the current starter bundle** into a **“TCR-branded” bundle** (your logo, TCR colors, sales messaging defaults), so reps don’t have to touch styling at all?

---

**user:**

Yes. Here is the company website for reference:

https://txchoiceroofing.com

---

**assistant:**

# Create the TCR-branded sales site starter bundle and zip it for download
import os, textwrap, zipfile, datetime

base_dir = &quot;/mnt/data/tcr-sales-site-starter&quot;
assets_dir = os.path.join(base_dir, &quot;assets&quot;)
os.makedirs(assets_dir, exist_ok=True)

year = datetime.datetime.now().year

# Brand defaults
BRAND_COLOR = &quot;#C81E1E&quot;  # TCR red (approx from logo)
ACCENT_DARK = &quot;#111111&quot;

_config = f&quot;&quot;&quot;\
# === TCR Personal Sales Site (GitHub Pages) ===
# Fill in your personal details below. Company brand defaults are already applied.
title: &quot;{{{{name}}}} — {{{{role}}}}&quot;
description: &quot;{{{{tagline}}}}&quot;
theme: jekyll-theme-cayman

# Company branding (defaults)
brand_color: &quot;{BRAND_COLOR}&quot;
logo_url: &quot;https://txchoiceroofing.com/wp-content/uploads/2022/03/tx-choice-roofing-logo.png&quot;
# You can also set headshot to your own image.
headshot: &quot;&quot;   # e.g., /assets/headshot.jpg or https://...
email: &quot;&quot;      # e.g., you@txchoiceroofing.com
phone: &quot;&quot;      # e.g., +1 (512) 555-1234
calendar_url: &quot;&quot;  # e.g., https://cal.com/yourname/roof-inspection

# Content lists (optional)
offers:
  - Free roof inspections &amp; photo report
  - Insurance claim guidance &amp; documentation
  - Shingle, metal, tile, and flat roofing options
  - Storm damage assessment and repairs
  - Gutters, exterior, and solar coordination
skills:
  - Trusted, no-pressure consults
  - Clear scopes &amp; written estimates
  - Local vendor &amp; crew coordination
  - Code, permit, and warranty know-how
  - Start–finish project communication
testimonials: []   # - {{ name: &quot;Homeowner, Austin&quot;, quote: &quot;Handled everything with care—highly recommend.&quot; }}
portfolio: []      # - {{ title: &quot;Standing seam metal – Dripping Springs&quot;, summary: &quot;Energy-efficient upgrade with crisp lines.&quot;, link: &quot;&quot; }}
social: []         # - {{ platform: &quot;LinkedIn&quot;, url: &quot;https://linkedin.com/in/yourname&quot; }}

# Optional analytics
google_analytics:
&quot;&quot;&quot;

index_md = &quot;&quot;&quot;\
---
layout: default
title: Home
---

&lt;link rel=&quot;stylesheet&quot; href=&quot;/assets/style.css&quot;&gt;

&lt;div class=&quot;hero&quot;&gt;
  &lt;div class=&quot;hero-content&quot;&gt;
    &lt;img class=&quot;logo&quot; src=&quot;{{ site.logo_url }}&quot; alt=&quot;Texas Choice Roofing logo&quot;/&gt;
    &lt;div class=&quot;hero-text&quot;&gt;
      &lt;h1&gt;{{ site.title }}&lt;/h1&gt;
      &lt;p&gt;{{ site.description }}&lt;/p&gt;
      &lt;p class=&quot;cta-buttons&quot;&gt;
        {% if site.email and site.email != &quot;&quot; %}&lt;a class=&quot;btn&quot; href=&quot;mailto:{{ site.email }}&quot;&gt;Email Me&lt;/a&gt;{% endif %}
        {% if site.calendar_url and site.calendar_url != &quot;&quot; %} &lt;a class=&quot;btn btn-solid&quot; href=&quot;{{ site.calendar_url }}&quot;&gt;Book an Inspection&lt;/a&gt;{% endif %}
      &lt;/p&gt;
    &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;

## What I Do
{% if site.offers and site.offers.size &gt; 0 %}
&lt;ul&gt;
{% for item in site.offers %}
&lt;li&gt;{{ item }}&lt;/li&gt;
{% endfor %}
&lt;/ul&gt;
{% else %}
&lt;p&gt;I help homeowners choose the right roofing solution and coordinate a smooth, high-quality install.&lt;/p&gt;
{% endif %}

## Skills
{% if site.skills and site.skills.size &gt; 0 %}
&lt;p&gt;
{% for s in site.skills %}
&lt;span class=&quot;badge&quot;&gt;{{ s }}&lt;/span&gt;
{% endfor %}
&lt;/p&gt;
{% endif %}

{% if site.portfolio and site.portfolio.size &gt; 0 %}
## Recent Work
&lt;div class=&quot;grid&quot;&gt;
  {% for p in site.portfolio %}
  &lt;div class=&quot;card&quot;&gt;
    &lt;h3&gt;{{ p.title }}&lt;/h3&gt;
    &lt;p&gt;{{ p.summary }}&lt;/p&gt;
    {% if p.link %}&lt;p&gt;&lt;a href=&quot;{{ p.link }}&quot;&gt;View&lt;/a&gt;&lt;/p&gt;{% endif %}
  &lt;/div&gt;
  {% endfor %}
&lt;/div&gt;
{% endif %}

{% if site.testimonials and site.testimonials.size &gt; 0 %}
## Testimonials
&lt;div class=&quot;grid&quot;&gt;
{% for t in site.testimonials %}
  &lt;div class=&quot;card&quot;&gt;&lt;em&gt;“{{ t.quote }}”&lt;/em&gt;&lt;br&gt;— {{ t.name }}&lt;/div&gt;
{% endfor %}
&lt;/div&gt;
{% endif %}

## Contact
- Email: {% if site.email and site.email != &quot;&quot; %}[{{ site.email }}](mailto:{{ site.email }}){% else %}_add your email in `_config.yml`_{% endif %}
{% if site.phone and site.phone != &quot;&quot; %}- Phone: {{ site.phone }}{% endif %}
{% if site.social and site.social.size &gt; 0 %}
- Social:
  {% for s in site.social %} [{{ s.platform }}]({{ s.url }}){% if forloop.last == false %}, {% endif %}{% endfor %}
{% endif %}
&quot;&quot;&quot;

style_css = f&quot;&quot;&quot;\
:root {{
  --accent: {BRAND_COLOR};
  --ink: {ACCENT_DARK};
}}
a, .btn {{ color: var(--accent); }}
.btn {{
  display:inline-block; padding:0.65rem 1rem; border:1px solid var(--accent);
  text-decoration:none; border-radius:8px; font-weight:600;
}}
.btn-solid {{
  background: var(--accent); color: white; border-color: var(--accent);
}}
.badge {{ padding:0.25rem 0.6rem; border:1px solid #ddd; border-radius:999px; margin-right:6px; }}
.grid {{ display:grid; gap:16px; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); }}
.card {{ border:1px solid #eee; border-radius:12px; padding:14px; background:#fff; }}

.hero {{
  background: linear-gradient(135deg, #fff, #fff);
  border-bottom: 4px solid var(--accent);
  padding: 18px 0;
}}
.hero-content {{
  display:flex; align-items:center; gap:18px; flex-wrap:wrap;
}}
.logo {{ width: 120px; height:auto; display:block; }}
.hero-text h1 {{ margin: 0 0 6px 0; color: var(--ink); }}
.hero-text p {{ margin: 0.25rem 0; }}
.cta-buttons a {{ margin-right: 8px; }}
&quot;&quot;&quot;

readme_md = &quot;&quot;&quot;\
# TCR Personal Sales Site (GitHub Pages)

Pre-branded starter for Texas Choice Roofing sales reps.

## Quick Start
1) Open `_config.yml` and fill in your **name, role, tagline, and contact**.
2) (Optional) Add your headshot at `assets/headshot.jpg`, or set `headshot:` to any image URL.
3) Edit `offers`, `skills`, and add `portfolio` / `testimonials` if you have them.

## Publish on GitHub Pages (Desktop)
- Create a **public** repo on GitHub.
  - **Personal site**: `username.github.io` (exactly your GitHub username).
  - **Project site**: any repo name (URL will be `https://username.github.io/reponame`).
- Upload these files (keep paths).
- Commit to `main`.
- Settings → **Pages** → Source: *Deploy from a branch* → Branch: `main` / Folder: `/ (root)` → **Save**.
- Wait ~1 minute, then click the URL shown in Pages.

## Publish on Mobile
- GitHub app → Repositories → **+** → New (public).
- Add files (create `assets/` then `style.css`, upload images).
- If the app doesn’t show **Pages**, open the repo in your mobile browser and use **Settings → Pages**.

## Custom Domain (Optional)
- Add a `CNAME` file containing your domain (e.g., `sales.yourname.com`).
- In your DNS, create a CNAME record pointing to `username.github.io`.
- In **Settings → Pages**, verify domain and enable SSL.

## Updating
- Edit `_config.yml` for lists and contact details.
- Adjust `index.md` text and replace images any time.
&quot;&quot;&quot;

license_txt = f&quot;&quot;&quot;\
MIT License

Copyright (c) {year} YOUR NAME

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the &quot;Software&quot;), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED &quot;AS IS&quot;, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
&quot;&quot;&quot;

cname_txt = &quot;example.yourdomain.com\n# Replace with your domain or delete this file if not using a custom domain.\n&quot;

files = {
    &quot;_config.yml&quot;: _config,
    &quot;index.md&quot;: index_md,
    &quot;assets/style.css&quot;: style_css,
    &quot;README.md&quot;: readme_md,
    &quot;LICENSE&quot;: license_txt,
    &quot;CNAME&quot;: cname_txt,
}

# Write files
for path, content in files.items():
    full_path = os.path.join(base_dir, path)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
        f.write(content)

# Zip it
zip_path = &quot;/mnt/data/tcr-sales-site-starter.zip&quot;
with zipfile.ZipFile(zip_path, &quot;w&quot;, zipfile.ZIP_DEFLATED) as z:
    for root, _, file_names in os.walk(base_dir):
        for name in file_names:
            full = os.path.join(root, name)
            rel = os.path.relpath(full, base_dir)
            z.write(full, arcname=os.path.join(&quot;tcr-sales-site-starter&quot;, rel))

zip_path

---

**assistant:**

# Re-create after kernel reset: TCR-branded sales site starter bundle and zip
import os, textwrap, zipfile, datetime

base_dir = &quot;/mnt/data/tcr-sales-site-starter&quot;
assets_dir = os.path.join(base_dir, &quot;assets&quot;)
os.makedirs(assets_dir, exist_ok=True)

year = datetime.datetime.now().year
BRAND_COLOR = &quot;#C81E1E&quot;
ACCENT_DARK = &quot;#111111&quot;

_config = f&quot;&quot;&quot;\
# === TCR Personal Sales Site (GitHub Pages) ===
title: &quot;{{{{name}}}} — {{{{role}}}}&quot;
description: &quot;{{{{tagline}}}}&quot;
theme: jekyll-theme-cayman

# Company branding (defaults)
brand_color: &quot;{BRAND_COLOR}&quot;
logo_url: &quot;https://txchoiceroofing.com/wp-content/uploads/2022/03/tx-choice-roofing-logo.png&quot;
headshot: &quot;&quot;   # e.g., /assets/headshot.jpg or https://...
email: &quot;&quot;      # e.g., you@txchoiceroofing.com
phone: &quot;&quot;      # e.g., +1 (512) 555-1234
calendar_url: &quot;&quot;  # e.g., https://cal.com/yourname/roof-inspection

offers:
  - Free roof inspections &amp; photo report
  - Insurance claim guidance &amp; documentation
  - Shingle, metal, tile, and flat roofing options
  - Storm damage assessment and repairs
  - Gutters, exterior, and solar coordination
skills:
  - Trusted, no-pressure consults
  - Clear scopes &amp; written estimates
  - Local vendor &amp; crew coordination
  - Code, permit, and warranty know-how
  - Start–finish project communication
testimonials: []
portfolio: []
social: []

google_analytics:
&quot;&quot;&quot;

index_md = &quot;&quot;&quot;\
---
layout: default
title: Home
---

&lt;link rel=&quot;stylesheet&quot; href=&quot;/assets/style.css&quot;&gt;

&lt;div class=&quot;hero&quot;&gt;
  &lt;div class=&quot;hero-content&quot;&gt;
    &lt;img class=&quot;logo&quot; src=&quot;{{ site.logo_url }}&quot; alt=&quot;Texas Choice Roofing logo&quot;/&gt;
    &lt;div class=&quot;hero-text&quot;&gt;
      &lt;h1&gt;{{ site.title }}&lt;/h1&gt;
      &lt;p&gt;{{ site.description }}&lt;/p&gt;
      &lt;p class=&quot;cta-buttons&quot;&gt;
        {% if site.email and site.email != &quot;&quot; %}&lt;a class=&quot;btn&quot; href=&quot;mailto:{{ site.email }}&quot;&gt;Email Me&lt;/a&gt;{% endif %}
        {% if site.calendar_url and site.calendar_url != &quot;&quot; %} &lt;a class=&quot;btn btn-solid&quot; href=&quot;{{ site.calendar_url }}&quot;&gt;Book an Inspection&lt;/a&gt;{% endif %}
      &lt;/p&gt;
    &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;

## What I Do
{% if site.offers and site.offers.size &gt; 0 %}
&lt;ul&gt;
{% for item in site.offers %}
&lt;li&gt;{{ item }}&lt;/li&gt;
{% endfor %}
&lt;/ul&gt;
{% else %}
&lt;p&gt;I help homeowners choose the right roofing solution and coordinate a smooth, high-quality install.&lt;/p&gt;
{% endif %}

## Skills
{% if site.skills and site.skills.size &gt; 0 %}
&lt;p&gt;
{% for s in site.skills %}
&lt;span class=&quot;badge&quot;&gt;{{ s }}&lt;/span&gt;
{% endfor %}
&lt;/p&gt;
{% endif %}

{% if site.portfolio and site.portfolio.size &gt; 0 %}
## Recent Work
&lt;div class=&quot;grid&quot;&gt;
  {% for p in site.portfolio %}
  &lt;div class=&quot;card&quot;&gt;
    &lt;h3&gt;{{ p.title }}&lt;/h3&gt;
    &lt;p&gt;{{ p.summary }}&lt;/p&gt;
    {% if p.link %}&lt;p&gt;&lt;a href=&quot;{{ p.link }}&quot;&gt;View&lt;/a&gt;&lt;/p&gt;{% endif %}
  &lt;/div&gt;
  {% endfor %}
&lt;/div&gt;
{% endif %}

{% if site.testimonials and site.testimonials.size &gt; 0 %}
## Testimonials
&lt;div class=&quot;grid&quot;&gt;
{% for t in site.testimonials %}
  &lt;div class=&quot;card&quot;&gt;&lt;em&gt;“{{ t.quote }}”&lt;/em&gt;&lt;br&gt;— {{ t.name }}&lt;/div&gt;
{% endfor %}
&lt;/div&gt;
{% endif %}

## Contact
- Email: {% if site.email and site.email != &quot;&quot; %}[{{ site.email }}](mailto:{{ site.email }}){% else %}_add your email in `_config.yml`_{% endif %}
{% if site.phone and site.phone != &quot;&quot; %}- Phone: {{ site.phone }}{% endif %}
{% if site.social and site.social.size &gt; 0 %}
- Social:
  {% for s in site.social %} [{{ s.platform }}]({{ s.url }}){% if forloop.last == false %}, {% endif %}{% endfor %}
{% endif %}
&quot;&quot;&quot;

style_css = f&quot;&quot;&quot;\
:root {{
  --accent: {BRAND_COLOR};
  --ink: {ACCENT_DARK};
}}
a, .btn {{ color: var(--accent); }}
.btn {{
  display:inline-block; padding:0.65rem 1rem; border:1px solid var(--accent);
  text-decoration:none; border-radius:8px; font-weight:600;
}}
.btn-solid {{
  background: var(--accent); color: white; border-color: var(--accent);
}}
.badge {{ padding:0.25rem 0.6rem; border:1px solid #ddd; border-radius:999px; margin-right:6px; }}
.grid {{ display:grid; gap:16px; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); }}
.card {{ border:1px solid #eee; border-radius:12px; padding:14px; background:#fff; }}

.hero {{
  background: linear-gradient(135deg, #fff, #fff);
  border-bottom: 4px solid var(--accent);
  padding: 18px 0;
}}
.hero-content {{
  display:flex; align-items:center; gap:18px; flex-wrap:wrap;
}}
.logo {{ width: 120px; height:auto; display:block; }}
.hero-text h1 {{ margin: 0 0 6px 0; color: var(--ink); }}
.hero-text p {{ margin: 0.25rem 0; }}
.cta-buttons a {{ margin-right: 8px; }}
&quot;&quot;&quot;

readme_md = &quot;&quot;&quot;\
# TCR Personal Sales Site (GitHub Pages)

Pre-branded starter for Texas Choice Roofing sales reps.

## Quick Start
1) Open `_config.yml` and fill in your **name, role, tagline, and contact**.
2) (Optional) Add your headshot at `assets/headshot.jpg`, or set `headshot:` to any image URL.
3) Edit `offers`, `skills`, and add `portfolio` / `testimonials` if you have them.

## Publish on GitHub Pages (Desktop)
- Create a **public** repo on GitHub.
  - **Personal site**: `username.github.io` (exactly your GitHub username).
  - **Project site**: any repo name (URL will be `https://username.github.io/reponame`).
- Upload these files (keep paths).
- Commit to `main`.
- Settings → **Pages** → Source: *Deploy from a branch* → Branch: `main` / Folder: `/ (root)` → **Save**.
- Wait ~1 minute, then click the URL shown in Pages.

## Publish on Mobile
- GitHub app → Repositories → **+** → New (public).
- Add files (create `assets/` then `style.css`, upload images).
- If the app doesn’t show **Pages**, open the repo in your mobile browser and use **Settings → Pages**.

## Custom Domain (Optional)
- Add a `CNAME` file containing your domain (e.g., `sales.yourname.com`).
- In your DNS, create a CNAME record pointing to `username.github.io`.
- In **Settings → Pages**, verify domain and enable SSL.

## Updating
- Edit `_config.yml` for lists and contact details.
- Adjust `index.md` text and replace images any time.
&quot;&quot;&quot;

license_txt = f&quot;&quot;&quot;\
MIT License

Copyright (c) {year} YOUR NAME

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the &quot;Software&quot;), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED &quot;AS IS&quot;, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
&quot;&quot;&quot;

cname_txt = &quot;example.yourdomain.com\n# Replace with your domain or delete this file if not using a custom domain.\n&quot;

files = {
    &quot;_config.yml&quot;: _config,
    &quot;index.md&quot;: index_md,
    &quot;assets/style.css&quot;: style_css,
    &quot;README.md&quot;: readme_md,
    &quot;LICENSE&quot;: license_txt,
    &quot;CNAME&quot;: cname_txt,
}

for path, content in files.items():
    full_path = os.path.join(base_dir, path)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
        f.write(content)

zip_path = &quot;/mnt/data/tcr-sales-site-starter.zip&quot;
with zipfile.ZipFile(zip_path, &quot;w&quot;, zipfile.ZIP_DEFLATED) as z:
    for root, _, file_names in os.walk(base_dir):
        for name in file_names:
            full = os.path.join(root, name)
            rel = os.path.relpath(full, base_dir)
            z.write(full, arcname=os.path.join(&quot;tcr-sales-site-starter&quot;, rel))

zip_path

---

**assistant:**

Got you a TCR-branded starter pack. 🔧

[Download the tcr-sales-site-starter.zip](sandbox:/mnt/data/tcr-sales-site-starter.zip)

What’s customized:
- Brand accent set to **TCR red** (`#C81E1E`) and dark ink text.  
- Header includes the **TCR logo** by default (you can keep or swap for a headshot). Logo source: published on the TCR site. citeturn2view1
- Pre-filled **offers** and **skills** relevant to roofing &amp; storm work (reps can edit in `_config.yml`).

Files inside (paths preserved):
- `_config.yml` — preloaded with TCR brand, logo URL, default offers/skills, and empty contact/info fields for each rep.
- `index.md` — single-page layout with hero, offers, skills, optional portfolio/testimonials, and contact.
- `assets/style.css` — buttons/badges/cards + hero band in TCR accent.
- `README.md` — desktop + mobile GitHub Pages steps and custom domain how-to.
- `LICENSE` — MIT (swap YOUR NAME).
- `CNAME` — placeholder (delete if not using a custom domain).

Next steps:
1) Create a public repo (`username.github.io` or any name).  
2) Upload the zip’s contents as-is.  
3) Settings → Pages → “Deploy from a branch” → `main` + `/ (root)` → Save.  
4) Edit `_config.yml` with the rep’s name, role, tagline, email/phone.

Want me to add **Lane B (Portfolio)** and **Lane C (Case Study/FAQ/Pricing/Calendar)** add-on packs as separate zips so reps can expand later with one click?

---

**user:**

Remember, we are creating a GPT to do all of these things for our sales team so these files need to go into the GPT files if that makes sense

---

**assistant:**

Totally makes sense. Here’s exactly how to wire this into your custom GPT so reps get the files **from the GPT itself** (no copy-pasting).

# 1) What to upload to the GPT (Files tab)
Upload **both** of these to your GPT’s Files/Knowledge:
- `sales-site-starter.zip` (generic)
- `tcr-sales-site-starter.zip` (TCR-branded)

These are the bundles I gave you—just upload them as-is. The GPT will attach them back to users on request.

# 2) Paste this trimmed System Prompt (&lt;8k chars)
Use this as your **initial instructions** in the GPT Builder:

---
**Name:** TCR Web Maker  
**Role:** You build and publish a salesperson’s personal website on **GitHub Pages**—end-to-end—for non-technical users. You always follow **STATE → DELIVER → VERIFY → ASK**.

**What you do**
1) Gather content. 2) Generate a clean site (bio, offers, skills, portfolio, testimonials, contact). 3) Publish via GitHub Pages. 4) Expand on request (Portfolio, Case Studies, FAQ, Pricing, Calendar).

**Audience &amp; Voice**
- Sales reps with little/no GitHub or coding experience.  
- Voice: friendly, step-by-step, minimal jargon.  
- Style: “Click here → paste this → save.” Celebrate progress.  

**Cadence (always)**
- STATE: 1–2 lines of what’s next.
- DELIVER: concrete outputs (file contents, exact click-paths, or attach one of the starter ZIPs).
- VERIFY: short checks (“Do you see X?”).
- ASK: one focused question to advance.

**Lanes (offer up front)**
- Lane A (default) Fast Launch: 1-page site.
- Lane B Portfolio: Projects grid + Testimonials.
- Lane C Custom: Case Studies, FAQ, Pricing, Calendar link.

**Inputs to collect (accept “skip” for any)**
Name, Role/Title, Market/Region, Tagline, Offers (bullets), Skills (bullets), Testimonials (opt), Portfolio items (opt), Email/Phone/Calendar, Headshot/Logo URL (opt), Social links (opt), Brand color hex (opt), GitHub username (opt), Custom domain (opt).

**Files available to you (attached in GPT Files)**
- `tcr-sales-site-starter.zip` → TCR-branded bundle (preferred).
- `sales-site-starter.zip` → Generic bundle.

**When to attach which file**
- If the user is a TCR rep (default): **attach** `tcr-sales-site-starter.zip`.
- If they ask for a neutral/non-TCR version: **attach** `sales-site-starter.zip`.

**Site structure (Lane A)**
`index.md`, `_config.yml`, `assets/style.css`, optional `assets/headshot.jpg`, `README.md`, `LICENSE`, optional `CNAME`.

**Publishing paths**
- Personal site: repo = `username.github.io` → URL `https://username.github.io`
- Project site: any repo name → URL `https://username.github.io/reponame`

**GitHub UI (Desktop)**
1) Create public repo.  
2) Upload files (keep paths).  
3) Commit to `main`.  
4) Settings → Pages → Deploy from branch → `main` + `/ (root)` → Save.  
5) Wait ~1 min for Pages to go live.

**Mobile**
GitHub app → New repo → add files → use mobile browser for **Settings → Pages** if the app doesn’t show it.

**Custom domain**
`CNAME` in repo root; DNS CNAME → `username.github.io`; enable SSL in Pages.

**Troubleshooting**
- 404 or theme delay: wait 1–3 min and refresh.  
- Wrong URL: check repo naming (`username.github.io` vs project).  
- Image path/case sensitivity.  
- Typos in `_config.yml` front-matter.

**CODEX/automation hand-off (when user says they connected an agent)**
Emit a small, numbered task list:
1) Create repo `{repo_name}` (public).  
2) Add all files from the attached ZIP at repo root (preserve paths).  
3) Enable GitHub Pages: branch `main`, folder `/ (root)`.  
4) Return the live URL.

**Session flow (example)**
1) STATE gather basics → DELIVER short questions → VERIFY summary → ASK lane choice.  
2) STATE draft site → DELIVER attach `tcr-sales-site-starter.zip` (or generic) + quick edit pointers → VERIFY hero text → ASK ready to publish?  
3) STATE publish → DELIVER desktop &amp; mobile click-paths → VERIFY green check in Pages → ASK add portfolio/testimonials?  
4) STATE expand → DELIVER edits to `_config.yml` for lists → VERIFY cards render → ASK add calendar/pricing?  
5) STATE hand-off tips → DELIVER update steps → VERIFY comfort → ASK final additions.

**Safety**
No fabricated testimonials/certs. Keep claims accurate (“I help” not guarantees). Limit sensitive personal info.
---

# 3) Add two tiny “helper” prompts as GPT Actions (Optional but useful)
Put these in the GPT’s **Conversation starters**:

- “Fast Launch my site (Lane A)”
- “Add my portfolio &amp; testimonials (Lane B)”
- “I want case studies, FAQ, and pricing (Lane C)”
- “Publish to GitHub Pages (step-by-step)”
- “Attach the TCR starter ZIP”

# 4) How the GPT should behave with files
When a rep chooses Lane A or says “give me the files,” the GPT should:
- **Attach** `tcr-sales-site-starter.zip` directly in the reply,  
- Then guide them through filling `_config.yml`, and  
- Provide the exact **Settings → Pages** steps (desktop + mobile).

If a rep asks for a non-branded version, the GPT should attach `sales-site-starter.zip` instead.

# 5) (Optional) Add-on packs later
If you want Lane B/C expansions as a second round of files (extra markdowns for **Projects**, **Case Studies**, **FAQ**, **Pricing**, **Calendar**):
- I can produce `tcr-portfolio-pack.zip` and `tcr-case-study-pack.zip` next, so the GPT can attach them on demand.

---

If you’ve already uploaded the two ZIPs, I can give you a **copy-paste “Test Script”** to run through the GPT now (simulating a first-time rep) to make sure it:  
1) asks for the right inputs, 2) attaches the correct ZIP, and 3) walks through GitHub Pages cleanly. Want that?

---

**user:**

Yes. Test script

---

**assistant:**

Perfect. Here’s a **step-by-step test script** you can copy into a fresh chat with your GPT (“TCR Web Maker”) to make sure it performs correctly.  

---

# 🔍 TCR Web Maker Test Script

## Phase 1: Onboarding &amp; Input Collection
Paste this as the **first user message**:  
```
Hi, I want to make my personal site.  
My name is Sarah Lopez.  
Role: Roofing Advisor.  
Market: Austin, TX.  
Tagline: Helping homeowners protect their biggest investment.  
Offers: Free inspections; Insurance claim help; Roof repairs; Roof replacements.  
Skills: Clear communication; Honest estimates; Local knowledge.  
Testimonials: John D — “Sarah walked us through the insurance process and made it stress-free.”  
Portfolio: Standing Seam Roof — “Beautiful install in South Austin” (no link).  
Email: sarah@txchoiceroofing.com  
Phone: 512-555-1212  
Calendar: https://cal.com/sarahlopez/inspection  
Social: LinkedIn https://linkedin.com/in/sarahlopez  
Brand color: #C81E1E  
GitHub username: sarahlopez  
Custom domain: sarahlopezroofing.com
```

✅ **Expected GPT behavior**:  
- **STATE**: “I’ll gather your info.”  
- **DELIVER**: Repeat back a clean summary of Sarah’s details.  
- **VERIFY**: “Does this look correct?”  
- **ASK**: “Lane A, B, or C?”  

Respond with:  
```
Lane A
```

---

## Phase 2: File Delivery
✅ **Expected GPT behavior**:  
- **STATE**: “I’ll draft your site files.”  
- **DELIVER**: Attach **`tcr-sales-site-starter.zip`** (since it’s TCR). Also provide quick notes: “Open `_config.yml` → fill in details, `index.md` already wired.”  
- **VERIFY**: “Does the hero text look right?”  
- **ASK**: “Ready to publish?”  

Respond with:  
```
Yes, ready to publish
```

---

## Phase 3: GitHub Publishing
✅ **Expected GPT behavior**:  
- **STATE**: “Let’s publish your site.”  
- **DELIVER**: Exact **Desktop** and **Mobile** click-paths for GitHub Pages.  
- **VERIFY**: “You should now see a green check and a URL in Pages.”  
- **ASK**: “Want to add testimonials/portfolio now?”  

Respond with:  
```
Yes, add testimonials and portfolio
```

---

## Phase 4: Expansion
✅ **Expected GPT behavior**:  
- **STATE**: “I’ll expand your site with portfolio/testimonials.”  
- **DELIVER**: Show how `_config.yml` is updated with Sarah’s testimonial and project, and that `index.md` renders them.  
- **VERIFY**: “Cards should render in a grid.”  
- **ASK**: “Add calendar link or pricing?”  

Respond with:  
```
No thanks, that’s all for today
```

---

## Phase 5: Wrap-Up
✅ **Expected GPT behavior**:  
- **STATE**: “Here’s how to update going forward.”  
- **DELIVER**: Remind how to edit `_config.yml`, swap headshot, and re-deploy.  
- **VERIFY**: “Feel comfortable updating?”  
- **ASK**: “Anything else to add today?”  

Respond with:  
```
No, thank you
```

---

# ✅ Success Criteria
If the GPT does all of the following, the test passes:
1. Uses **STATE → DELIVER → VERIFY → ASK** every step.  
2. Repeats user inputs cleanly for confirmation.  
3. Attaches the correct **TCR ZIP** in Lane A.  
4. Provides exact GitHub Pages click-paths for desktop &amp; mobile.  
5. Expands with testimonials/portfolio when asked.  
6. Ends with a clear update workflow.  

---

Do you want me to also prep a **Phase 6: CODEX automation test** (where the GPT outputs a numbered task list for CODEX to execute automatically)? That would test the “agent hand-off” scenario too.

---

**user:**

Here are the results from your script:

STATE: I’m drafting your ready-to-publish site (Lane A — Fast Launch) using your details.

DELIVER: I’ve packaged your site files. Download sarahlopez-site.zip (attached), then unzip—these are ready to upload to GitHub Pages.

/ _config.yml

# === Personal Sales Site (GitHub Pages) ===
title: &quot;Sarah Lopez — Roofing Advisor&quot;
description: &quot;Helping homeowners protect their biggest investment.&quot;
theme: jekyll-theme-cayman

# Optional contact + media
headshot: &quot;&quot;   # e.g., /assets/headshot.jpg or https://...
email: &quot;sarah@txchoiceroofing.com&quot;
phone: &quot;512-555-1212&quot;
calendar_url: &quot;https://cal.com/sarahlopez/inspection&quot;

# Content lists (you can edit here or just use index.md)
offers:
  - Free inspections
  - Insurance claim help
  - Roof repairs
  - Roof replacements
skills:
  - Clear communication
  - Honest estimates
  - Local knowledge
testimonials:
  - { name: &quot;John D&quot;, quote: &quot;Sarah walked us through the insurance process and made it stress-free.&quot; }
portfolio:
  - { title: &quot;Standing Seam Roof&quot;, summary: &quot;Beautiful install in South Austin&quot; }
social:
  - { platform: &quot;LinkedIn&quot;, url: &quot;https://linkedin.com/in/sarahlopez&quot; }

google_analytics:

# Brand color used in assets/style.css
brand_color: &quot;#C81E1E&quot;

/index.md

&lt;link rel=&quot;stylesheet&quot; href=&quot;/assets/style.css&quot;&gt;
# Sarah Lopez
**Roofing Advisor — Austin, TX**  
*Helping homeowners protect their biggest investment.*

&lt;div class=&quot;header-cta&quot;&gt;
  &lt;a class=&quot;btn solid&quot; href=&quot;https://cal.com/sarahlopez/inspection&quot;&gt;Book a free inspection&lt;/a&gt;
  &lt;a class=&quot;btn&quot; href=&quot;mailto:sarah@txchoiceroofing.com&quot;&gt;Email&lt;/a&gt;
  &lt;a class=&quot;btn&quot; href=&quot;tel:15125551212&quot;&gt;Call&lt;/a&gt;
  &lt;a class=&quot;btn&quot; href=&quot;https://linkedin.com/in/sarahlopez&quot;&gt;LinkedIn&lt;/a&gt;
&lt;/div&gt;

&lt;hr/&gt;

### What I do
&lt;span class=&quot;badge&quot;&gt;Free inspections&lt;/span&gt;
&lt;span class=&quot;badge&quot;&gt;Insurance claim help&lt;/span&gt;
&lt;span class=&quot;badge&quot;&gt;Roof repairs&lt;/span&gt;
&lt;span class=&quot;badge&quot;&gt;Roof replacements&lt;/span&gt;

### Why work with me
- Clear communication  
- Honest estimates  
- Local knowledge (Austin &amp; surrounding areas)

### Portfolio
&lt;div class=&quot;grid&quot;&gt;
  &lt;div class=&quot;card&quot;&gt;
    &lt;strong&gt;Standing Seam Roof&lt;/strong&gt;
    &lt;div class=&quot;small&quot;&gt;Beautiful install in South Austin&lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;

### Testimonials
&gt; “Sarah walked us through the insurance process and made it stress-free.”  
&gt; — John D

### Contact
- Email: [sarah@txchoiceroofing.com](mailto:sarah@txchoiceroofing.com)  
- Phone: [512-555-1212](tel:15125551212)  
- Calendar: [Book an inspection](https://cal.com/sarahlopez/inspection)  
- LinkedIn: [linkedin.com/in/sarahlopez](https://linkedin.com/in/sarahlopez)

---
*Last updated: {{ site.time | date: &quot;%Y-%m-%d&quot; }}*

/assets/style.css

:root { --accent: #C81E1E; }
/* If you change brand_color in _config.yml, update --accent to match. */
a, .btn { color: var(--accent); }
.btn {
  display:inline-block; padding:0.6rem 1rem; border:1px solid var(--accent);
  text-decoration:none; border-radius:6px;
}
.btn.solid { background: var(--accent); color:#fff; }
.badge { padding:0.2rem 0.5rem; border:1px solid #ddd; border-radius:999px; margin-right:6px; }
.grid { display:grid; gap:16px; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); }
.card { border:1px solid #eee; border-radius:10px; padding:14px; background:#fff; }
.small { font-size:0.9rem; color:#555; }
.header-cta { display:flex; gap:10px; flex-wrap:wrap; margin:10px 0 0; }
.section { margin-top: 28px; }
hr { border: none; border-top:1px solid #eee; margin: 24px 0; }

/README.md

# Sarah Lopez — Personal Roofing Advisor Site

This repo powers your simple one-page site using GitHub Pages and the `jekyll-theme-cayman` theme.

## Quick edit
- Update text in `index.md`
- Change brand color in `_config.yml` and `/assets/style.css` (`--accent`)
- Add a headshot image to `/assets/` and set `headshot:` in `_config.yml` (optional)

## Publish on GitHub Pages (Desktop)
1. Go to GitHub → New repository → **sarahlopez.github.io** (Public).
2. **Add files** → **Upload files** → Upload everything in this folder (keep folders).
3. Commit to **main**.
4. Settings → **Pages** → *Build and deployment* → **Deploy from a branch** → Branch: `main` / Folder: `/ (root)`.
5. In **Custom domain**, enter: `sarahlopezroofing.com` and click Save.
6. In your domain DNS, add a **CNAME** record for `@` (or `www`) pointing to `sarahlopez.github.io`.
7. Back in Settings → Pages, check **Enforce HTTPS**.

Your site URLs:
- Primary (after DNS): `https://sarahlopezroofing.com`
- Fallback: `https://sarahlopez.github.io`

## Mobile publish (GitHub app)
1. Repositories → `+` → **New** → Name: `sarahlopez.github.io` (Public).
2. Add files one-by-one (create `assets/` first, then upload files into it).
3. Open repo in browser → Settings → Pages → set to `main` and `/ (root)`.

## Update content later
- Edit files directly on GitHub (pencil icon), then **Commit changes**.
- Add more projects/testimonials by duplicating blocks in `index.md`.

/LICENSE (MIT)

MIT License

Copyright (c) 2025 Sarah Lopez
[...standard MIT text...]

/CNAME

sarahlopezroofing.com

VERIFY: Does the hero area show as:
“Sarah Lopez — Roofing Advisor — Austin, TX” and the tagline “Helping homeowners protect their biggest investment.” with buttons for Book a free inspection / Email / Call / LinkedIn? Are the Offers, Skills, and your phone/calendar correct?

ASK: Ready to publish now? If yes, I’ll walk you through the exact GitHub clicks (Desktop or Mobile) and DNS for sarahlopezroofing.com step-by-step.

---

**assistant:**

Awesome first run. Here’s a tight review + drop-in fixes so your GPT behaves exactly how we want for TCR reps.

---

## Snapshot: How it did vs. our success criteria
**✅ Good**
- Used the cadence (**STATE → DELIVER → VERIFY → ASK**).
- Branded color (`#C81E1E`) applied.
- Clear CTA buttons, phone `tel:` link, calendar, LinkedIn.
- Clean GitHub Pages instructions (desktop + mobile + DNS).

**⚠️ Improve**
1) **Branding not guaranteed** — it generated `sarahlopez-site.zip` instead of attaching the **pre-branded TCR ZIP**.  
2) **Content not DRY** — `index.md` hard-codes offers/skills; won’t auto-update if reps edit `_config.yml`.  
3) **CSS not Liquid-aware** — brand color requires editing two places. Let Jekyll inject `site.brand_color` directly.  
4) **Optional headshot/logo** not shown in hero.  
5) **DNS** — keep guidance to CNAME/ALIAS and avoid hard-coding A-record IPs.

---

## A. Tiny instruction tweak (so the GPT attaches the TCR ZIP)
Add this line (or strengthen if it’s already there) to your GPT **system prompt** near “When to attach which file”:

&gt; **When the user chooses Lane A or asks for files and mentions TCR (default), ATTACH `tcr-sales-site-starter.zip` from Files. Do not generate a new zip unless the user requests a non-TCR version—then attach `sales-site-starter.zip`.**

---

## B. Drop-in file upgrades (replace these in the bundle or have the GPT output them)

### 1) `_config.yml` (same keys, no breaking changes)
```yaml
# === TCR Personal Sales Site (GitHub Pages) ===
title: &quot;{{name}} — {{role}}&quot;
description: &quot;{{tagline}}&quot;
theme: jekyll-theme-cayman

# Company branding defaults
brand_color: &quot;#C81E1E&quot;
logo_url: &quot;https://txchoiceroofing.com/wp-content/uploads/2022/03/tx-choice-roofing-logo.png&quot;

# Rep details
headshot: &quot;&quot;       # e.g., /assets/headshot.jpg or https://...
email: &quot;&quot;
phone: &quot;&quot;
calendar_url: &quot;&quot;

# Content lists (edit here; index.md renders automatically)
offers: []
skills: []
testimonials: []   # - { name: &quot;Homeowner, Austin&quot;, quote: &quot;Great experience.&quot; }
portfolio: []      # - { title: &quot;Standing seam metal&quot;, summary: &quot;South Austin&quot;, link: &quot;&quot; }
social: []         # - { platform: &quot;LinkedIn&quot;, url: &quot;https://...&quot; }

google_analytics:
```

### 2) `assets/style.css` (Liquid-enabled + hero + footer)
&gt; Important: add empty front matter so Jekyll processes Liquid in CSS.
```css
---
---

:root {
  --accent: {{ site.brand_color | default: &quot;#C81E1E&quot; }};
  --ink: #111111;
}

a, .btn { color: var(--accent); }
.btn {
  display:inline-block; padding:0.65rem 1rem; border:1px solid var(--accent);
  text-decoration:none; border-radius:8px; font-weight:600;
}
.btn.solid { background: var(--accent); color:#fff; border-color: var(--accent); }
.badge { padding:0.25rem 0.6rem; border:1px solid #ddd; border-radius:999px; margin-right:6px; }
.grid { display:grid; gap:16px; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); }
.card { border:1px solid #eee; border-radius:12px; padding:14px; background:#fff; }
.small { font-size:0.9rem; color:#555; }
.header-cta { display:flex; gap:10px; flex-wrap:wrap; margin:10px 0 0; }
.section { margin-top: 28px; }
hr { border: none; border-top:1px solid #eee; margin: 24px 0; }

.hero {
  border-bottom: 4px solid var(--accent);
  padding: 18px 0;
}
.hero-content { display:flex; align-items:center; gap:18px; flex-wrap:wrap; }
.logo { width:120px; height:auto; display:block; }
.hero-text h1 { margin:0 0 6px 0; color: var(--ink); }
.footer { margin-top: 36px; font-size: 0.9rem; color:#666; }
.footer a { text-decoration: none; }
```

### 3) `index.md` (fully dynamic + optional logo/headshot hero)
```markdown
---
layout: default
title: Home
---

&lt;link rel=&quot;stylesheet&quot; href=&quot;/assets/style.css&quot;&gt;

&lt;div class=&quot;hero&quot;&gt;
  &lt;div class=&quot;hero-content&quot;&gt;
    {% if site.logo_url and site.logo_url != &quot;&quot; %}
      &lt;img class=&quot;logo&quot; src=&quot;{{ site.logo_url }}&quot; alt=&quot;Texas Choice Roofing logo&quot;/&gt;
    {% endif %}
    {% if site.headshot and site.headshot != &quot;&quot; %}
      &lt;img class=&quot;logo&quot; src=&quot;{{ site.headshot }}&quot; alt=&quot;{{ site.title }} headshot&quot; style=&quot;border-radius:50%; width:96px; height:96px; object-fit:cover;&quot;/&gt;
    {% endif %}
    &lt;div class=&quot;hero-text&quot;&gt;
      &lt;h1&gt;{{ site.title }}&lt;/h1&gt;
      &lt;p&gt;{{ site.description }}&lt;/p&gt;
      &lt;p class=&quot;header-cta&quot;&gt;
        {% if site.calendar_url and site.calendar_url != &quot;&quot; %}&lt;a class=&quot;btn solid&quot; href=&quot;{{ site.calendar_url }}&quot;&gt;Book a free inspection&lt;/a&gt;{% endif %}
        {% if site.email and site.email != &quot;&quot; %}&lt;a class=&quot;btn&quot; href=&quot;mailto:{{ site.email }}&quot;&gt;Email&lt;/a&gt;{% endif %}
        {% if site.phone and site.phone != &quot;&quot; %}&lt;a class=&quot;btn&quot; href=&quot;tel:{{ site.phone | replace: &#x27;(&#x27;, &#x27;&#x27; | replace: &#x27;)&#x27;, &#x27;&#x27; | replace: &#x27; &#x27;, &#x27;&#x27; | replace: &#x27;-&#x27;, &#x27;&#x27; }}&quot;&gt;Call&lt;/a&gt;{% endif %}
        {% if site.social and site.social.size &gt; 0 %}
          {% assign li = site.social | where: &quot;platform&quot;, &quot;LinkedIn&quot; | first %}
          {% if li %}&lt;a class=&quot;btn&quot; href=&quot;{{ li.url }}&quot;&gt;LinkedIn&lt;/a&gt;{% endif %}
        {% endif %}
      &lt;/p&gt;
    &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;

## What I do
{% if site.offers and site.offers.size &gt; 0 %}
&lt;p&gt;
  {% for item in site.offers %}
    &lt;span class=&quot;badge&quot;&gt;{{ item }}&lt;/span&gt;
  {% endfor %}
&lt;/p&gt;
{% else %}
&lt;p&gt;I help homeowners choose the right roofing solution and coordinate a smooth, high-quality install.&lt;/p&gt;
{% endif %}

## Why work with me
{% if site.skills and site.skills.size &gt; 0 %}
&lt;ul&gt;
  {% for s in site.skills %}&lt;li&gt;{{ s }}&lt;/li&gt;{% endfor %}
&lt;/ul&gt;
{% endif %}

{% if site.portfolio and site.portfolio.size &gt; 0 %}
## Portfolio
&lt;div class=&quot;grid&quot;&gt;
  {% for p in site.portfolio %}
  &lt;div class=&quot;card&quot;&gt;
    &lt;strong&gt;{{ p.title }}&lt;/strong&gt;
    &lt;div class=&quot;small&quot;&gt;{{ p.summary }}&lt;/div&gt;
    {% if p.link %}&lt;div&gt;&lt;a href=&quot;{{ p.link }}&quot;&gt;View&lt;/a&gt;&lt;/div&gt;{% endif %}
  &lt;/div&gt;
  {% endfor %}
&lt;/div&gt;
{% endif %}

{% if site.testimonials and site.testimonials.size &gt; 0 %}
## Testimonials
&lt;div class=&quot;grid&quot;&gt;
  {% for t in site.testimonials %}
    &lt;div class=&quot;card&quot;&gt;&lt;em&gt;“{{ t.quote }}”&lt;/em&gt;&lt;br&gt;— {{ t.name }}&lt;/div&gt;
  {% endfor %}
&lt;/div&gt;
{% endif %}

## Contact
- Email: {% if site.email and site.email != &quot;&quot; %}[{{ site.email }}](mailto:{{ site.email }}){% else %}_add your email in `_config.yml`_{% endif %}
{% if site.phone and site.phone != &quot;&quot; %}- Phone: {{ site.phone }}{% endif %}
{% if site.social and site.social.size &gt; 0 %}
- Social: {% for s in site.social %}[{{ s.platform }}]({{ s.url }}){% if forloop.last == false %}, {% endif %}{% endfor %}
{% endif %}

&lt;hr/&gt;
&lt;div class=&quot;footer&quot;&gt;
  Texas Choice Roofing • &lt;a href=&quot;https://txchoiceroofing.com&quot;&gt;txchoiceroofing.com&lt;/a&gt;
&lt;/div&gt;

*Last updated: {{ site.time | date: &quot;%Y-%m-%d&quot; }}*
```

### 4) `README.md` (DNS guidance that won’t break)
```markdown
# TCR Personal Sales Site

## Publish (Desktop)
1. Create a **public** repo.
   - Personal site: `username.github.io` → URL `https://username.github.io`
   - Project site: any name → URL `https://username.github.io/reponame`
2. Upload files (keep paths).
3. Commit to `main`.
4. **Settings → Pages** → Deploy from a branch → Branch `main` / Folder `/ (root)` → **Save**.
5. Wait ~1–3 minutes for Pages to build.

## Custom domain
- **Recommended:** use a subdomain like `www.yourdomain.com` → set a **CNAME** to `username.github.io`.
- If you must use the apex (`yourdomain.com`), use your registrar’s **ALIAS/ANAME** (preferred). Avoid hard-coding A-record IPs (they can change).
- Add a `CNAME` file to the repo root containing your domain and enable **Enforce HTTPS** in **Settings → Pages**.

## Update content
- Edit `_config.yml` for lists and contact.
- Swap images and tweak `index.md` any time.
```

---

## C. Quick CODEX/agent hand-off block (paste-able by the GPT)
When reps say “I connected CODEX,” your GPT should output this:

```
Tasks for CODEX:
1) Create repo: {{github_user}}.github.io (public).
2) Unzip and place all files from tcr-sales-site-starter.zip at repo root (preserve paths).
3) Enable GitHub Pages: Settings → Pages → Deploy from a branch → Branch main / Folder /(root).
4) Return the Pages URL once live.
5) If user gave a custom domain, add CNAME file and confirm Pages shows the domain + HTTPS enabled.
```

---

## D. What I recommend you do now
1) **Update your GPT system prompt** with the attachment rule (Section A).  
2) **Replace** the three files above in your ZIP (or have the GPT output them verbatim).  
3) Re-run the test script with “Sarah Lopez” and confirm:
   - It **attaches the TCR ZIP**, not a new zip.  
   - The hero shows **TCR logo** and optional **headshot**.  
   - Changing `_config.yml` lists **auto-updates** the page (no hard-coded badges).

Want me to generate the **Lane B “Portfolio pack”** and **Lane C “Case Study/FAQ/Pricing/Calendar pack”** as attachable zips next?

---

