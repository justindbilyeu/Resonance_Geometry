# Wolfram simulation prompt

- Conversation ID: 68a3c6df-d624-832a-a000-878ea337ab91
- Created: 2025-08-19T00:35:49.950281

---

**user:**

give me a prompt for Wolfram to simulate our prototype, is that something you can do?

---

**assistant:**

Absolutely. Here’s a copy-ready Wolfram Language prompt to simulate the **Tri-Source Water Node™ prototype** (PV → battery → loads for MSSC pumps + AWG + optional desal). It pulls hourly weather for Austin, computes a simple clear-sky irradiance with cloud adjustment, runs an hour-by-hour energy allocator (PV → base loads → AWG → desal → battery), and outputs water/energy balances and plots.

# Context &amp; Objective
Simulate 7–14 days of operation for the SunShare Tri-Source Water Node™ prototype in Austin, TX: PV generation, battery SoC, MSSC base loads, AWG water output (liters), optional desal energy, unmet load, and daily KPIs.

# Assumptions
- Site: Austin, TX, USA.
- PV: fixed-tilt, derated by `PVDerate`.
- Irradiance: clear-sky model using sun elevation &amp; air mass, scaled by `(1 – CloudFraction)`.
- Loads: constant MSSC base power; AWG/desal sized dynamically from available energy.
- AWG SEC (kWh/L): empirical function of T(°C), RH(%); adjustable.
- Desal SEC (kWh/L): parameterized (e.g., RO ≈ 0.003–0.006 kWh/L for brackish; MD higher).
- Battery: simple coulomb counter with round-trip efficiency; no thermal/aging model.

# Wolfram Prompt (paste everything below into a fresh notebook)

```wl
(* === SunShare Tri-Source Water Node™ — Hourly Simulation === *)

(* -------- Parameters -------- *)
params = &lt;|
  &quot;Site&quot; -&gt; Entity[&quot;City&quot;, {&quot;Austin&quot;, &quot;Texas&quot;, &quot;UnitedStates&quot;}],
  &quot;StartDate&quot; -&gt; DateObject[{2025, 9, 1}, TimeZone -&gt; &quot;America/Chicago&quot;],
  &quot;Days&quot; -&gt; 7, (* set to 14, 30, etc. as needed *)
  &quot;PVkW&quot; -&gt; 5.0,                  (* DC nameplate kW *)
  &quot;PVDerate&quot; -&gt; 0.82,            (* wiring, temp, inverter, soiling *)
  &quot;ArrayTiltDeg&quot; -&gt; 25,          (* fixed tilt assumption *)
  &quot;ArrayAzimuthDeg&quot; -&gt; 180,      (* 180=south *)
  &quot;BatteryKWh&quot; -&gt; 10.0,
  &quot;BatteryMinSOC&quot; -&gt; 0.10,       (* fraction of capacity *)
  &quot;BatteryRoundTripEff&quot; -&gt; 0.92, (* one-way eff =~ Sqrt(RT) in allocator *)
  &quot;BaseLoad_kW&quot; -&gt; 0.20,         (* MSSC aeration/recirc/etc. continuous *)
  &quot;UseAWG&quot; -&gt; True,
  &quot;DailyPotableTarget_L&quot; -&gt; 60,  (* liters/day target from AWG *)
  &quot;AWGMax_kW&quot; -&gt; 3.0,            (* cap AWG draw per hour *)
  &quot;UseDesal&quot; -&gt; False,           (* toggle *)
  &quot;DailyDesalTarget_L&quot; -&gt; 0,     (* liters/day via RO/MD (if enabled) *)
  &quot;Desal_kWhPerL&quot; -&gt; 0.004,      (* RO @ ~4 kWh/m^3 = 0.004 kWh/L; adjust for salinity *)
  &quot;AllowGrid&quot; -&gt; False           (* if True, unmet load draws &quot;grid&quot; *)
|&gt;;

(* Empirical AWG Specific Energy Consumption [kWh/L] as a function of T (°C) and RH (%) *)
AWGSECkWhPerL[Tc_, rh_] := Module[
  {base = 0.35 + 0.008 Max[0, 25 - Tc] + 0.004 Max[0, 60 - rh]},
  Clip[base, {0.25, 1.5}]
];

(* -------- Time axis &amp; weather -------- *)
times = DateRange[
  params[&quot;StartDate&quot;],
  params[&quot;StartDate&quot;] + Quantity[params[&quot;Days&quot;], &quot;Days&quot;],
  Quantity[1, &quot;Hours&quot;]
];

(* Pull hourly weather: Temperature (°C), RH (%), Cloud fraction (0..1) *)
tempTS = WeatherData[params[&quot;Site&quot;], &quot;Temperature&quot;, {First@times, Last@times, &quot;Hour&quot;}];
rhTS   = WeatherData[params[&quot;Site&quot;], &quot;RelativeHumidity&quot;, {First@times, Last@times, &quot;Hour&quot;}];
cloudTS = WeatherData[params[&quot;Site&quot;], &quot;CloudCoverFraction&quot;, {First@times, Last@times, &quot;Hour&quot;}];

(* Safe align and fill missing values *)
align = TimeSeriesThread[
  {#1, #2, #3} &amp;,
  {TimeSeries[tempTS, MissingDataMethod -&gt; &quot;Interpolation&quot;],
   TimeSeries[rhTS,   MissingDataMethod -&gt; &quot;Interpolation&quot;],
   TimeSeries[cloudTS, MissingDataMethod -&gt; {&quot;Constant&quot;, 0.5}]}
];

(* Convert quantities to pure scalars in canonical units *)
weather = TimeSeries[
  Map[
    {
      UnitConvert[#[[1]], &quot;DegreesCelsius&quot;] // QuantityMagnitude,
      QuantityMagnitude[#[[2]]], (* RH in % already unitless *)
      QuantityMagnitude[#[[3]]]  (* cloud fraction 0..1 *)
    } &amp;,
    Normal[align][&quot;Values&quot;]
  ],
  {Normal[align][&quot;Times&quot;]}
];

(* -------- Solar model: clear-sky GHI with cloud scaling -------- *)
deg2rad = N@Degree;
solI0 = 1361; (* W/m^2 extraterrestrial DNI approximation *)

airMass[zenDeg_] := Module[{z = zenDeg},
  If[z &gt;= 90, Infinity,
   1./(Cos[z deg2rad] + 0.50572 (96.07995 - z)^(-1.6364))
  ]
];

(* Simplified transmittance model *)
transmittance[am_] := If[am === Infinity, 0., 0.7^(am^0.678)];

sunGeom[t_] := Module[{sp, zen},
  sp = SunPosition[params[&quot;Site&quot;], t, &quot;AltitudeAzimuth&quot;];
  (* sp = {altitude, azimuth} in degrees *)
  &lt;|&quot;Alt&quot; -&gt; sp[[1]], &quot;Az&quot; -&gt; sp[[2]], &quot;Zen&quot; -&gt; 90 - sp[[1]]|&gt;
];

(* Hourly GHI estimate with cloud attenuation *)
ghiTS = TimeSeries[
  Table[
    Module[{t = times[[i]], g = sunGeom[t], am, trans, cosZ, ghiClear, cloud},
      cloud = weather[t][[3]] /. Missing[__] -&gt; 0.5;
      cosZ = Max[0, Cos[g[&quot;Zen&quot;] deg2rad]];
      am = airMass[g[&quot;Zen&quot;]];
      trans = transmittance[am];
      ghiClear = solI0 * trans * cosZ;
      (1 - cloud) * ghiClear
    ],
    {i, Length[times]}
  ],
  {times}
];

(* PV AC power (kW) *)
pvAC_kW = TimeSeries[
  (params[&quot;PVkW&quot;] * params[&quot;PVDerate&quot;]) * (UnitConvert[ghiTS, &quot;Watts&quot;/&quot;Meters&quot;^2][&quot;Values&quot;]/1000.0),
  {times}
];

(* -------- Demand shaping per hour -------- *)
dailyAWGGoal = If[TrueQ@params[&quot;UseAWG&quot;], params[&quot;DailyPotableTarget_L&quot;], 0];
dailyDesalGoal = If[TrueQ@params[&quot;UseDesal&quot;], params[&quot;DailyDesalTarget_L&quot;], 0];

(* Distribute daily water targets uniformly across daytime hours with PV &gt; small epsilon *)
pvPosMask = Map[If[# &gt; 0.05, 1, 0] &amp;, pvAC_kW[&quot;Values&quot;]];
pvPosHoursByDay = 
  GatherBy[Transpose[{times, pvPosMask}], (DateValue[#[[1]], &quot;Date&quot;] &amp;)];

awgSchedule_Lph =
  Flatten@Map[
    Function[dayGroup,
      Module[{dayDate = DateValue[dayGroup[[1, 1]], &quot;Date&quot;],
              mask = dayGroup[[All, 2]], n = Total[dayGroup[[All, 2]]]},
        Table[
          If[mask[[j]] == 1 &amp;&amp; dailyAWGGoal &gt; 0, dailyAWGGoal/Max[1, n], 0],
          {j, Length[dayGroup]}
        ]
      ]
    ],
    pvPosHoursByDay
  ];

desalSchedule_Lph =
  Flatten@Map[
    Function[dayGroup,
      Module[{dayDate = DateValue[dayGroup[[1, 1]], &quot;Date&quot;],
              mask = dayGroup[[All, 2]], n = Total[dayGroup[[All, 2]]]},
        Table[
          If[mask[[j]] == 1 &amp;&amp; dailyDesalGoal &gt; 0, dailyDesalGoal/Max[1, n], 0],
          {j, Length[dayGroup]}
        ]
      ]
    ],
    pvPosHoursByDay
  ];

(* -------- Simulation loop -------- *)
nH = Length[times];
soc = ConstantArray[params[&quot;BatteryMinSOC&quot;], nH];  (* fraction of capacity *)
batteryKWh = params[&quot;BatteryKWh&quot;];
batteryMinKWh = params[&quot;BatteryMinSOC&quot;] * batteryKWh;
oneWayEff = Sqrt[params[&quot;BatteryRoundTripEff&quot;]];

baseLoad = ConstantArray[params[&quot;BaseLoad_kW&quot;], nH];
pv = pvAC_kW[&quot;Values&quot;];

awgDraw_kW = ConstantArray[0., nH];
awgWater_L = ConstantArray[0., nH];
desalDraw_kW = ConstantArray[0., nH];
desalWater_L = ConstantArray[0., nH];
unserved_kWh = ConstantArray[0., nH];

hourlyT = weather[&quot;Values&quot;][[All, 1]];
hourlyRH = weather[&quot;Values&quot;][[All, 2]];

(* allocator *)
batteryKWhState = batteryMinKWh;

Do[
  Module[
    {
      pvAvail = pv[[h]], demandBase = baseLoad[[h]], netPV,
      awgNeedL = awgSchedule_Lph[[h]], desalNeedL = desalSchedule_Lph[[h]],
      secAWG = If[awgNeedL &gt; 0, AWGSECkWhPerL[hourlyT[[h]], hourlyRH[[h]]], 0.],
      awgEnergyReq_kWh, awgPower_kW_cap, awgEnergyDelivered_kWh,
      desalEnergyReq_kWh, desalEnergyDelivered_kWh,
      deficit_kWh = 0., surplus_kWh = 0., gridHelp = 0.
    },

    (* 1) Serve base load with PV then battery *)
    netPV = pvAvail - demandBase;
    If[netPV &gt;= 0,
      (* charge battery with surplus *)
      surplus_kWh = netPV; 
      batteryKWhState = Min[
        batteryKWh,
        batteryKWhState + surplus_kWh * oneWayEff
      ];
      ,
      (* need energy: discharge battery if possible *)
      deficit_kWh = -netPV;
      Module[{possible = (batteryKWhState - batteryMinKWh) * oneWayEff},
        If[possible &gt;= deficit_kWh,
          batteryKWhState -= deficit_kWh / oneWayEff,
          (* battery insufficient *)
          If[TrueQ@params[&quot;AllowGrid&quot;],
            gridHelp = deficit_kWh - possible; 
            batteryKWhState = batteryMinKWh;,
            unserved_kWh[[h]] += deficit_kWh - possible;
            batteryKWhState = batteryMinKWh;
          ]
        ]
      ];
    ];

    (* 2) Allocate energy to AWG within cap *)
    If[TrueQ@params[&quot;UseAWG&quot;] &amp;&amp; awgNeedL &gt; 0,
      awgEnergyReq_kWh = secAWG * awgNeedL;
      awgPower_kW_cap = params[&quot;AWGMax_kW&quot;];
      (* use available PV surplus in this hour (if any), else battery *)
      Module[
        {allocFromPV = Max[0, pvAvail - demandBase], allocCap = awgPower_kW_cap},
        (* PV-limited allocation *)
        Module[{pvAlloc_kWh = Min[allocFromPV, awgEnergyReq_kWh, allocCap]},
          awgEnergyDelivered_kWh = pvAlloc_kWh;
          (* then optional from battery *)
          If[awgEnergyReq_kWh &gt; awgEnergyDelivered_kWh,
            Module[
              {remain = awgEnergyReq_kWh - awgEnergyDelivered_kWh,
               battPossible = (batteryKWhState - batteryMinKWh) * oneWayEff},
              If[battPossible &gt; 0,
                Module[{fromBatt = Min[remain, battPossible, allocCap - pvAlloc_kWh]},
                  batteryKWhState -= fromBatt / oneWayEff;
                  awgEnergyDelivered_kWh += fromBatt;
                ];
              ];
            ];
          ];
        ];
      ];
      awgWater_L[[h]] = If[secAWG &gt; 0, awgEnergyDelivered_kWh/secAWG, 0.];
      awgDraw_kW[[h]] = awgEnergyDelivered_kWh; (* per hour step, kWh ~ kW·h; step=1h *)
    ];

    (* 3) Allocate energy to Desal if enabled *)
    If[TrueQ@params[&quot;UseDesal&quot;] &amp;&amp; desalNeedL &gt; 0,
      desalEnergyReq_kWh = params[&quot;Desal_kWhPerL&quot;] * desalNeedL;
      Module[
        {allocFromPV = Max[0, pvAvail - demandBase - awgDraw_kW[[h]]],
         fromPV = 0., fromBatt = 0.},
        fromPV = Min[allocFromPV, desalEnergyReq_kWh];
        desalEnergyDelivered_kWh = fromPV;
        If[desalEnergyReq_kWh &gt; fromPV,
          Module[
            {remain = desalEnergyReq_kWh - fromPV,
             battPossible = (batteryKWhState - batteryMinKWh) * oneWayEff},
            fromBatt = Min[remain, battPossible];
            batteryKWhState -= fromBatt / oneWayEff;
            desalEnergyDelivered_kWh += fromBatt;
          ];
        ];
        desalWater_L[[h]] = desalEnergyDelivered_kWh/params[&quot;Desal_kWhPerL&quot;];
        desalDraw_kW[[h]] = desalEnergyDelivered_kWh;
      ];
    ];

    (* store SOC *)
    soc[[h]] = batteryKWhState / batteryKWh;

  ],
  {h, 1, nH}
];

(* -------- Outputs -------- *)
totalPV_kWh = Total[pv];
totalBase_kWh = Total[baseLoad];
totalAWG_kWh = Total[awgDraw_kW];
totalDesal_kWh = Total[desalDraw_kW];
totalUnserved_kWh = Total[unserved_kWh];

totalAWG_L = Total[awgWater_L];
totalDesal_L = Total[desalWater_L];

dailySummary = GroupBy[
  Table[
    With[{d = DateValue[times[[i]], &quot;Date&quot;]},
      d -&gt; &lt;|
        &quot;PV_kWh&quot; -&gt; pv[[i]],
        &quot;Base_kWh&quot; -&gt; baseLoad[[i]],
        &quot;AWG_kWh&quot; -&gt; awgDraw_kW[[i]],
        &quot;Desal_kWh&quot; -&gt; desalDraw_kW[[i]],
        &quot;AWG_L&quot; -&gt; awgWater_L[[i]],
        &quot;Desal_L&quot; -&gt; desalWater_L[[i]],
        &quot;Unserved_kWh&quot; -&gt; unserved_kWh[[i]]
      |&gt;
    ],
    {i, nH}
  ],
  First -&gt; (Total /@ Merge[Last /@ #, Total] &amp;)
];

summary = &lt;|
  &quot;Totals&quot; -&gt; &lt;|
    &quot;PV_kWh&quot; -&gt; totalPV_kWh,
    &quot;Base_kWh&quot; -&gt; totalBase_kWh,
    &quot;AWG_kWh&quot; -&gt; totalAWG_kWh,
    &quot;Desal_kWh&quot; -&gt; totalDesal_kWh,
    &quot;Unserved_kWh&quot; -&gt; totalUnserved_kWh,
    &quot;AWG_L&quot; -&gt; totalAWG_L,
    &quot;Desal_L&quot; -&gt; totalDesal_L
  |&gt;,
  &quot;Daily&quot; -&gt; dailySummary
|&gt;;

summary // Dataset

(* -------- Plots -------- *)
ListLinePlot[
  {
    TimeSeries[pv, {times}],
    TimeSeries[baseLoad, {times}],
    TimeSeries[awgDraw_kW, {times}],
    TimeSeries[desalDraw_kW, {times}]
  },
  PlotLegends -&gt; {&quot;PV kWh&quot;, &quot;Base kWh&quot;, &quot;AWG kWh&quot;, &quot;Desal kWh&quot;},
  Frame -&gt; True, FrameLabel -&gt; {&quot;Time&quot;, &quot;kWh per hour&quot;}, ImageSize -&gt; Large
]

ListLinePlot[TimeSeries[soc, {times}],
  Frame -&gt; True, FrameLabel -&gt; {&quot;Time&quot;, &quot;Battery SOC (fraction)&quot;},
  PlotLegends -&gt; {&quot;SOC&quot;}, ImageSize -&gt; Large
]

ListLinePlot[
  {
    TimeSeries[awgWater_L, {times}],
    TimeSeries[desalWater_L, {times}]
  },
  PlotLegends -&gt; {&quot;AWG L/h&quot;, &quot;Desal L/h&quot;},
  Frame -&gt; True, FrameLabel -&gt; {&quot;Time&quot;, &quot;Liters per hour&quot;}, ImageSize -&gt; Large
]

BarChart[
  Values@Map[
    &lt;|&quot;AWG_L/day&quot; -&gt; #[&quot;AWG_L&quot;], &quot;Desal_L/day&quot; -&gt; #[&quot;Desal_L&quot;]|&gt; &amp;,
    summary[&quot;Daily&quot;]
  ],
  ChartLegends -&gt; Placed[{&quot;AWG L/day&quot;, &quot;Desal L/day&quot;}, Right],
  ChartLayout -&gt; &quot;Stacked&quot;,
  Frame -&gt; True, ImageSize -&gt; Large
]
```

# Reasoned Path (what this sim does)
1. Pulls hourly **Temperature, RH, CloudFraction** for Austin and aligns series.  
2. Computes **clear-sky GHI** from the sun’s zenith and an air-mass transmittance, attenuated by `(1 – cloud)`.  
3. Converts GHI → **PV AC kW** with a derating factor.  
4. Runs an hourly allocator: serve **MSSC base load**, then use surplus PV (and battery) for **AWG** (to hit daily liters) and optional **desal**.  
5. Tracks **battery SOC**, **unserved energy**, and **water outputs**; summarizes totals and daily KPIs; plots PV vs. loads, SOC, and water time series.

# Risks &amp; Unknowns
- **Irradiance model** is simplified. For higher fidelity, replace with `SolarRadiationData` (if available) or import measured GHI.  
- **AWG SEC** function is empirical. Replace with a psychrometric model tied to coil COP and latent load if you have device curves.  
- **Desal SEC** is a coarse average; brine salinity and recovery ratio will shift it.  
- **Thermal limits &amp; curtailment** (panel temperature, inverter clipping) are not explicitly modeled.

# Actions (Next 1–3 Moves)
1. **Swap in real inputs:** measured PV IV curves, local GHI, and AWG performance map (SEC vs. {T, RH, airflow}).  
2. **Stress test:** vary `PVkW`, `BatteryKWh`, `BaseLoad_kW`, and `DailyPotableTarget_L` with `Manipulate[]` to find the cheapest spec that hits 60–65 L/day.  
3. **Scenario pack:** run 12-month simulation using `DateRange` and export `Dataset` to CSV for investor slides.

# Model Prompts (for GGCDs or tools)
- **Wolfram (upgrade AWG physics):**  
  “Given hourly T (°C) and RH (%), derive AWG SEC from latent heat of condensation using a cooling system with COP(T) and approach ΔT to dewpoint. Assume airflow = Q̇_air and condensate collection efficiency η_c. Return SEC(T,RH,Q̇_air,COP,η_c) and fit COP(T) to a typical R-134a cycle curve.”

- **Wolfram (PV fidelity):**  
  “Replace the clear-sky irradiance with SolarRadiationData or a REST import of NREL NSRDB GHI/DNI/DHI for Austin, TX; add NOCT temperature model and DC→AC inverter curve; output PV AC per hour with clipping and thermal derate.”

- **DeepSeek/Gemini (optimization):**  
  “Run a parameter sweep over {PVkW, BatteryKWh, BaseLoad_kW, AWGMax_kW} to minimize capex while maintaining P( DailyPotable ≥ 60 L ) ≥ 0.9 across the worst 30-day weather window; include probabilistic cloud cover.”

# Citations / Calcs
- **Clear-sky/air-mass**: Kasten–Young AM approximation (uncited—standard formula).  
- **AWG SEC bounds**: typical 0.3–1.2 kWh/L depending on RH and COP (uncited—engineering estimate; refine with device data).  
- **RO SEC**: ~3–6 kWh/m³ for brackish feed (0.003–0.006 kWh/L) at moderate recovery (uncited—rule of thumb).

# Pre-Flight Checklist
- Reasoning precedes conclusions ✅  
- Units explicit; parameters adjustable ✅  
- Estimates labeled; swappable with measured curves ✅  
- Cheap tests proposed (parameter sweep, data swap) ✅  
- Paste-ready for a Wolfram notebook ✅

If you want this adapted to the **HomeNode™** residential variant (softening + drinking + greywater reuse) or to your **Einstein-frame field** model, say the word and I’ll swap in those physics.

---

