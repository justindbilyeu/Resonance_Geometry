# SCS Roof Facts

- Conversation ID: 687f99d2-b134-8332-a1f1-6d5c8120d40c
- Created: 2025-07-22T14:01:55.585333

---

**user:**

Good morning can you give me 10 facts about Stone Coated Steel Roof that the average person doesn’t know

---

**assistant:**

Here are **10 lesser-known facts about Stone Coated Steel (SCS) roofing** that most homeowners don’t realize:

1. **Hail Performance**: SCS roofs pass UL 2218 Class 4—the highest hail impact rating—resisting 2″ steel-ball drops with minimal cosmetic denting and no water intrusion [hail_UL2218_class4].

2. **Weight Savings**: At ~1.5 lb/ft², SCS panels are 6–10× lighter than concrete or clay tile, reducing structural load and often eliminating the need for roof reinforcement [definition.md].

3. **Galvalume Base Metal**: Most SCS panels use Galvalume (55% aluminum-zinc alloy) rather than traditional galvanized steel, offering 2–4× longer corrosion resistance near coastlines [galvalume_vs_galvanized.md].

4. **Recycled Content**: SCS systems are made from ~30–60% recycled steel and are fully recyclable at end of life [environmental_impact].

5. **Panel Bonding Method**: The stone granules are bonded with an acrylic resin or polyurethane, then oven-cured—not just glued on—which helps them withstand UV degradation and power-washing [granule_types_bonding].

6. **Ventilation Flexibility**: Most SCS ridge vents use a raised metal channel with breathable mesh—compatible with hip roofs, gables, or even cathedral ceilings [ridge_vent_detail.md].

7. **Fire Rating**: When installed over approved decking and underlayment, SCS roofs can achieve a Class A fire rating without special treatments [definition.md].

8. **Underlayment Compatibility**: Self-adhered membranes (like ice &amp; water shield) must be high-temp rated for use under SCS, especially in Texas heat [underlayment_requirements].

9. **ROI Beats Asphalt**: Over 30 years, SCS systems often save 15–25% more in avoided replacement and energy costs compared to asphalt in Texas homes [financing_roi.md].

10. **Granule Loss Is Minimal**: Even after 2″ hail, granule loss is typically under 3%, with panels retaining waterproof integrity [hail_UL2218_class4].

*Next action:* Use these talking points in your next homeowner consultation to build trust and highlight long-term value.

---

