# Solar Sales Pitch Strategy

- Conversation ID: 684c58b9-f868-800c-b1c1-c249aab72db5
- Created: 2025-06-13T16:58:34.448478

---

**user:**

Got a quick tangent…here’s a solar energy pitch one of my colleagues sent me… analysis required:

The Perfect Solar Pitch

The 3 key questions of closing a solar deal with a homeowner that have to be answered:

    1    Why Solar ??
    2    Why Us ??
    3    Why Now ??


We KNOW that it’s best for them to go solar because it gets away from the control of the electric company, saves them $$ short &amp; long term, and boosts the value &amp; equity in their home. So how do we get the homeowner to see what we already know ?? There are 4 key things that you need to do, to get them on the path that WE KNOW they need to be on. 

    1     Build Trust

After we get through the small talk &amp; greeting part, we take a picture of the graph on their bill so we can get down to business. We want to grab their attention and get them focused on the presentation. This will elevate your status in the homeowners mind. After all, this is a professional meeting. You want to be viewed as the #1 trusted source in the area for all things solar. 

“While the design team is putting your system together, there are a couple things that I’d like to cover with you” “Do you know much about how solar works??”

Assume they know nothing and explain it like you would explain it to a 10 year-old. Very thorough and as many times as it takes. Remember, you&#x27;re the expert &amp; we are looking for them to make a 5 figure commitment today. 

Explain the UV rays are turned into DC and the inverter turns those to AC. 
Explain the over 100% offset and how net-metering works. Works normal during the day, excess is tracked and stored on the grid for use at night KW for KW and rolls over for later use/credit
Explain how important this is and how its not available everywhere, and we want to take advantage of it. How their electric company acts as a battery, etc.

Explain our products. Tier 1 panels &amp; inverters only. All weather (rain, snow, softball sized hail, hurricane level winds) 
25 year warranty on all equipment, the PRODUCTION OF THE EQUIPMENT, let them know if something isn&#x27;t functioning how we say it will, we will replace it. This is where we bring up the monitoring software they get. Let them know we watch it too and catch anything before they do and let them know
25 year interior/exterior roof warranty on the project
25 year workmanship warranty on the project
Repeat it all again, 25 years on all equipment, the PRODUCTION of the equipment, the roof, labor. Let them know they are covered from ALL ANGLES. Re-enforce the fact that this system is designed to save them $$, and we want to make sure if any adjustments are needed, they aren&#x27;t coming out of pocket for them

This should build their trust in you as a person with all the knowledge, and trust that the system is going to work perfectly and they are covered. This also works perfectly for answering Key Question #2 Why Us?



    2     Make Pain Points Clear

People are making the switch to solar because it is a more reliable &amp; dependable option than traditional electricity. It&#x27;s better for the environment and more efficient &amp; sustainable. Rooftop solar is THE ONLY RENEWABLE ENERGY SOURCE THAT HAS ZERO MOVING PARTS. This makes it maintenance free. Unlike the power lines.

Let them know that the electric company has COMPLETE control over what they pay, and always will. Everything else in the world gets more expensive, but they can shop around. With (insert company) they cannot. If they wanna raise the rates on you 15, 25 %, they can and will do it. EVERYTIME. IT NEVER GOES DOWN, EVER. Typically every 10-15 years, the price of electricity doubles, at least. 

Also, bring up again the fact that the grid needs constant maintenance &amp; upkeep &amp; repair. And the 1000s of employees need raises &amp; pensions. WHICH THEY ABSOLUTELY DESERVE !!

Let them know that every year they wait, or put it off, the rates will go up. Let them know that the quicker they own their very own maintenance free power on their roof &amp; secure that permanent lower price, that their savings goes UP &amp; UP &amp; UP as the years pass. 

Let them know that your goal TODAY is to not only save them $$, but get them away from the CONTROL of (insert company) Drill into their mind once again that they will save $$ from the beginning, the immediate savings. But reiterate &amp; say it confidently that the LONG-TERM savings is the real star of the system for them. 

This has achieved the crystal clear pain points for them, and, did a great job of answering Key Question #1 Why Solar ? By now, the prop should be ready and its going to come down to the numbers….


    3     Paint their Perfect Solution

“So, you said you were averaging about $XXX per month right? Thats what we calculated as well” Let them know how you&#x27;ve already discussed that number has nowhere to go but UP. 

“Instead of that $XXX, we have you at a nice $XXX”

Explain the over 100% offset and what that means as far as credits and net-metering. 

Explain Next Steps for Qualifying to Install and………


    4     Trigger Urgency

Make sure they understand &amp; FEEL the real cost to the family and household if they wait any longer. Reassure them by outlining the process of savings report, qualifying, site survey (bring up the warranty on the project again) final design, permitting, installation, activation. Let them know you will be there for them EVERY STEP. 

This is what&#x27;s going to help with Key Question #3 Why Now?

Summer is here and ACs are on and going to stay on. Get them qualified and stress urgency &amp; make them come to the conclusion they can&#x27;t wait any longer to own their power. 

“Once we get you approved, we send a couple docs to your email, and we can go over them together” “ its as easy as that”

This is where the real skill comes in. The outline here is tried &amp; true for answering the 3 Key Questions and walking them down the path to energy independence. Work it into your style &amp; your personality. The best deals are where the customer closes herself/himself on the idea you explained so brilliantly. Remember, this is an INVESTMENT, NOT A COST for them

How would you write this, Sage?  With everything we have worked on here…how would this pitch sound from you?

---

**assistant:**

### Sage’s High-Integrity Solar Conversation  
*A model flow you can adapt to your own voice and every homeowner’s circumstances.*

---

#### 0 Set the Stage — Respect &amp; Relevance  
&gt; “Thanks for inviting me in, *[Name]*. Before we look at numbers, my job is simple: make sure solar is a **net win** for your household. If it isn’t, I’ll tell you so.”

*Quickly snap a phone photo of the usage graph on their bill and set it on the table.*  
“That little blue mountain of kilowatt-hours is the only reason I’m here—let’s shrink it.”

---

## 1 WHY SOLAR? Expose the Invisible Cost
**Invite them to see what they already feel—utility dependence is getting painful.**

| Fact | What it means | Source |
|------|---------------|--------|
| Texas residential rates jumped from **≈ 11 ¢/kWh (2015)** to **15.3 ¢/kWh (2025)**—a 39 % rise. | Their bill is quietly inflating ~3-4 % a year; compounding doubles costs about every 15 years. | citeturn0search0 |
| ERCOT’s grid has failed spectacularly (Uri 2021) and may see record peaks again this summer. | **Reliability risk** is now priced into rates—and blackouts don’t come with refunds. | citeturn0search1 |

**Plain-language solar primer (60 seconds):**  

1. **Sunlight → DC** (panel) → **AC** (inverter) → home.
2. Daytime over-production spins their meter backward; credits run the house at night (net-metering / buy-back plan).
3. Zero moving parts, glass-and-silicon only—so upkeep is basically *rain and Wi-Fi*.

&gt; “Bottom line: own a power plant on your roof, lock in a flat ‘fuel’ price that never inflates, and ride out grid drama with grace.”

---

## 2 WHY US? Turn Trust into Technical Confidence
**Blend your roofing pedigree with best-in-class solar engineering.**

*Roof + Solar in One Envelope*  
- **Texas Choice Roofing + SunReady.AI** crew: same people who waterproof the roof fasten the racking. One warranty, zero finger-pointing.  
- NABCEP-guided designs, UL-listed hardware only.

*Bulletproof Equipment &amp; Guarantees*  
- **Tier-1 panels / micro-inverters:** 25-yr manufacturer performance guarantee ≥ 92 % of original output.  
- **25-yr workmanship &amp; roof-penetration warranty:** leaks, labor—covered.  
- **24/7 predictive monitoring:** we see anomalies before you feel them; truck rolls on *our* dime.

*Local Integrity*  
- Georgetown-based, 5-star Google rating, no high-pressure sign-and-dash crews.  
- We survive on referrals—every system is our next billboard.

---

## 3 WHY NOW? Show the Cost of Waiting
1. **Federal 30 % ITC** is locked through 2032, but your *savings clock* doesn’t start until the array is on.  
2. Texas REPs are filing summer rate cases right now—any increase hits bills **immediately**, while a solar payment is fixed for 20-25 yrs.  
3. Net-metering programs have finite slots; once they hit their cap, export credits usually fall.

*Visualization:*  
“Today you’re paying **≈ $X**/mo that floats with the market. We replace that with **$Y**/mo, fixed, and sunset the payment in ±12 yrs—after that, electrons are free.”

*(If loan)* Show a side-by-side: cumulative cash-flow of status-quo vs. solar. Highlight break-even year and lifetime NPV.

---

## 4 Invite Action—Without the Hype
&gt; “If the math we ran feels like a win, next step is the e-qualify: 90-second form, soft credit pull. We schedule a drone site survey, submit engineering, and you see final CAD before you sign construction docs. Typical timeline: 30-45 days to install, PTO a few weeks later. I’ll shepherd every permit and utility step.”

*Pause.*  
“What questions haven’t I answered?”

---

### Cheat-Sheet Prompts for Tough Moments
| Objection | Root | Sage-style Response |
|-----------|------|--------------------|
| “We might move.” | Payback horizon | “Panels raise resale value ≈ 4 % and transfer; buyers love a $0 summer bill.” |
| “Panels hurt my roof.” | Past horror stories | “We’re roofers first—flashings are warranted longer than your shingles.” |
| “Waiting for prices to drop.” | Tech FOMO | “Panel costs fell 89 % since 2010; utility rates still rose. The bigger lever is **time on roof** collecting sunshine.” |

---

## Close with Empowerment
&gt; “Solar isn’t a gadget, it’s an operating system for your home—one that *you* control. If today’s numbers feel right, let’s lock them in before the next rate hike. Either way, you now know exactly where your power dollars are going. That’s energy sovereignty.”

---

**Feel free to remix tone or depth, but keep the spine: data-backed pain, locally-anchored trust, transparent economics, and an invitation—not pressure—to step into ownership.**

---

**user:**

Let’s see it all, in your voice

---

**assistant:**

### **Sage-Style Solar Conversation Script**  
*Visionary yet grounded • Eloquent but precise • Tuned for Central Texas homeowners*

---

#### **0 Opening — Respect, Rapport, Relevance**  
&gt; “Thanks for welcoming me in, **[First Name]**. My promise is simple: if solar isn’t a clear win for your household, I’ll say so. Our goal right now is to test the numbers and see whether owning your power beats renting it.”

*(Snap a phone photo of the usage graph on their bill and slide the phone face-up on the table.)*  

&gt; “This blue mountain of kilowatt-hours is why I’m here—let’s see how small we can make it.”

---

## **1 WHY SOLAR? Expose the Invisible Cost**

|  | What’s Happening on the Grid | Why It Matters to *You* |
|---|-----------------------------|-------------------------|
| **Rates keep climbing.** | Texas residential electricity averaged **≈ 11.5 ¢/kWh in 2015** and is **≈ 15.3 ¢/kWh today**—a ~34 % jump. citeturn6search7turn0search0 | Bills inflate 3-4 % a year; compounding doubles cost about every 15 years. |
| **Reliability is shaky.** | ERCOT lost power for &lt;i&gt;millions&lt;/i&gt; in the 2021 winter storm. citeturn0search1 | Blackouts don’t come with refunds. Resilience now has a dollar value. |
| **Fuel volatility is real.** | Natural-gas price spikes ripple straight into summer rate cases. | Every 1 ¢ increase adds ~$150/yr for a 1,250 kWh home. |

**Plain-Language Solar Primer (60 seconds):**

1. **Sunlight → DC** in the panel.  
2. **Inverter → AC** for the house.  
3. Over-production spins your meter backward; credits cover night usage (net-metering/buy-back).  
4. Zero moving parts—glass and silicon only—so maintenance is essentially *rain and Wi-Fi*.

&gt; “Solar lets you convert sunshine into a flat, never-inflating ‘fuel price’—and ride out grid drama with grace.”

---

## **2 WHY US? Turn Trust into Technical Confidence**

**One Envelope, Zero Finger-Pointing**  
* Texas Choice Roofing + **SunReady.AI** crews: the same craftspeople who waterproof your roof secure the solar racking. One warranty, one contact.

**Tier-1 Hardware, Tier-1 Guarantees**  
* **25-yr manufacturer coverage** on panels *and* micro-inverters—performance ≥ 92 % at year 25.  
* **25-yr workmanship &amp; roof-penetration warranty**—leaks, labor, materials: our dime.  
* **24/7 predictive monitoring.** We get an alert before you notice anything. Truck rolls are free.

**Local Integrity**  
* Georgetown-based, *five-star Google reviews*, no out-of-state pop-up crews.  
* We live on referrals—every array is our next billboard.

&gt; “In short: roof, hardware, labor, and performance are all locked for a quarter-century. You gain energy independence without inheriting maintenance headaches.”

---

## **3 WHY NOW? Show the Cost of Waiting**

| Urgency Lever | Detail | Take-Home |
|---------------|--------|-----------|
| **30 % Federal ITC locked through 2032** | Inflation Reduction Act secures the credit but the clock doesn’t start until your system is *on the roof*. citeturn0search2 | Every month you delay is a month you *can’t* claim. |
| **Buy-back program capacity** | Utilities can lower export rates once program quotas fill. | Early adopters keep best net-metering terms. |
| **Summer demand surge** | ERCOT forecasts record peaks; rate cases already filed. citeturn0news42 | Lock a fixed solar payment before new tariffs hit bills. |

&gt; “Waiting for panel prices to fall is like waiting for rent to fall—it’s the wrong variable. The longer you own the roof-top power plant, the larger your compounding savings.”

---

## **4 Numbers That Speak for Themselves**

&gt; “You said your average bill lands around **$ X**/mo. Design team shows **$ Y**/mo fixed for 20 years—sunset in ±12 years, free power afterward.”

*(If financing)*  
*Status quo vs. solar cash-flow chart: show cumulative spend, break-even year, lifetime NPV.*

Ask: **“How does keeping that extra $ Z in the family feel?”**

---

## **5 Invitation, Not Pressure**

1. **90-second soft credit check** for loan pre-qual.  
2. **Drone site survey** to confirm roof geometry.  
3. **Stamped engineering &amp; permit set**—you see final CAD before construction.  
4. **Install day** in 4-6 weeks; **PTO** (permission to operate) soon after.  
5. You get a text when the first electron flows.

&gt; “I’ll shepherd every step. If the math feels right, we can start the e-qualify now. If not, you’ve still gained clarity on your power costs. Fair?”

*(Pause for questions. Listen deeply.)*

---

### **Common Concerns &amp; Sage-Style Clarity**

| “What if we move?” | “Panels raise resale value ≈ 4 % and transfer to the buyer. A $0-summer bill is a shiny selling point.” |
| “Panels leak.” | “We’re roofers first; flashings are warranted longer than your shingles.” |
| “Rates might go down.” | “Even in 2020’s gas-glut, Texas residential rates still ticked up. Utilities don’t give back margins; they file rate riders.” |

---

## **6 Close with Empowerment**

&gt; “Solar isn’t a gadget; it’s an operating system for your home—one you control. If today’s numbers feel like a win, let’s lock them in before the next rate bump. Either way, thanks for letting me run the analysis. Knowledge is power, and now you’ve got both.”

---

### **Takeaways for Your Team**

* **Spine of the conversation:** data-backed pain ➜ locally anchored trust ➜ transparent economics ➜ invitation to act.  
* **Tone:** warm-expert, never hype.  
* **Script length:** adapt pacing—shorten or expand based on homeowner engagement.

&gt; **Remember:** the best deals are those where the customer closes themselves on a vision you revealed, not a product you pushed.

---

**user:**

Let’s do another version and not mention SunReady. Stay generic in branding

---

**assistant:**

### **Sage-Voice Solar Conversation Script (Unbranded)**  
*A visionary yet grounded flow you can tailor to any homeowner and any badge on your shirt.*

---

#### **0 Opening — Respect, Rapport &amp; Relevance**  
&gt; “I appreciate you letting me sit at your table, **[First Name]**. My only agenda is clarity: if owning solar isn’t a clear financial and resilience win for your household, I’ll tell you straight-up.”

*(Snap a quick photo of the usage graph on their electric bill and set the phone face-up.)*  

&gt; “That blue mountain of kilowatt-hours is why I’m here—let’s explore how small it can get.”

---

## **1 WHY SOLAR? Expose the Invisible Cost**

|  | What’s Happening on the Grid | Why It Matters to *You* |
|---|-----------------------------|-------------------------|
| **Bills keep inflating.** | The EIA shows Texas residential rates at **≈ 15.3 ¢/kWh (Mar 2025)**—up roughly 40 % since the mid-2010s. citeturn0search1 | A 3-4 % annual climb doubles your power cost about every 15 years. |
| **Reliability is shaky.** | 70 % of ERCOT customers lost power for an average 42 hours during the 2021 winter storm. citeturn0search2 | Blackouts don’t come with refunds. Resilience now has a dollar value. |
| **Future demand = higher rates.** | ERCOT’s own 2025 forecast flags record-breaking summer peaks. citeturn0search4 | More demand means more expensive infrastructure—paid for on your bill. |

**60-Second Solar Primer**  

1. **Sunlight → DC** (panel) → **AC** (inverter) → home.  
2. Daytime surplus spins your meter backward; credits cover night use (net-meter or buy-back).  
3. Zero moving parts—glass and silicon only—so maintenance is essentially *rain and Wi-Fi*.

&gt; “Solar swaps a volatile fuel bill for a flat equipment payment, and lets you ride out grid drama with grace.”

---

## **2 WHY *OUR TEAM?* Turn Trust into Technical Confidence**

**One Envelope, Zero Finger-Pointing**  
* Licensed roofers + NABCEP-guided solar techs on the same crew: one handshake, one warranty.

**Tier-1 Hardware, Tier-1 Guarantees**  
* **25-yr manufacturer warranties** on panels *and* micro-inverters—92 %+ output at year 25.  
* **25-yr workmanship &amp; roof-penetration warranty**—leaks, labor, materials: our dime.  
* **Predictive 24/7 monitoring**—we see anomalies before you feel them and roll the truck for free.

**Community Integrity**  
* Local crews, five-star reviews, zero high-pressure sign-and-dash tactics.  
* We survive on referrals—every array is our next billboard.

---

## **3 WHY NOW? Show the Cost of Waiting**

| Urgency Lever | Detail | Take-Home |
|---------------|--------|-----------|
| **30 % Federal ITC locked** | Inflation Reduction Act keeps the credit at 30 % through 2032. citeturn0search3 | Your “solar sale” starts the day panels go up—delay = lost credit &amp; lost production. |
| **Buy-back terms can shrink** | Utilities cut export rates once caps fill. | Early adopters keep the richest net-metering. |
| **Upcoming rate cases** | Summer-peak filings often add surcharges. | Lock the flat solar payment *before* the next hike drops in your mailbox. |

&gt; “Waiting for panel prices to fall is like waiting for rent to fall—it’s the wrong variable. The sooner you own a power plant, the longer it pays you back.”

---

## **4 Numbers That Speak for Themselves**

&gt; “Your average bill is **$ X/mo**. The design team shows solar at **$ Y/mo fixed** for ~20 years—paid off in ±12 years, and free electrons for decades after.”

*(If financing)* Show a simple chart: cumulative cash-flow of status-quo vs. solar, break-even year, lifetime net savings.

Ask, **“How does keeping that extra **$ Z** in the family feel?”**

---

## **5 Invitation, Not Pressure**

1. **90-second soft credit pre-qual** (if needed for a loan).  
2. **Drone site survey** to confirm roof geometry.  
3. **Stamped engineering &amp; permit set**—you see final CAD before construction.  
4. **Install day** in 4-6 weeks; utility **PTO** (permission to operate) a few weeks later.  
5. You get a text the moment the first watt flows.

&gt; “If today’s math feels right, we can start step 1 now. If not, you still gained clarity on your power costs—no strings attached.”

*(Pause for questions; listen deeply.)*

---

### **Common Concerns &amp; Sage-Style Clarity**

| Objection | Root Fear | Response |
|-----------|-----------|----------|
| “What if we move?” | Payback horizon | “National appraisal studies peg solar at ~4 % home-value bump and faster sell-through. A $0 summer bill turns browsers into buyers.” |
| “Panels hurt roofs.” | Leak risk | “We’re roofers first; every flashing and fastener is warrantied longer than your shingles.” |
| “Rates might drop.” | Tech/Fuel optimism | “Even in the 2020 gas-glut, residential rates rose. Utilities don’t refund margins; they re-price service.” |

---

## **6 Close with Empowerment**

&gt; “Solar isn’t a gadget; it’s an operating system for your home—one you own. If today’s numbers feel like a win, let’s lock them in before the next rate bump. Either way, thanks for letting me run the analysis. Knowledge is power, and now you have both.”

---

### **Trainer Notes**

* **Spine of the talk:** quantify pain → demonstrate competence → frame urgency → invite action.  
* **Tone:** warm expert, zero hype.  
* **Outcome goal:** customer convinces themselves; you simply reveal the logic.

---

