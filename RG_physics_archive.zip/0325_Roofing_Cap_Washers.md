# Roofing Cap Washers

- Conversation ID: 677c2522-748c-800c-be79-3a8cfca698ee
- Created: 2025-01-06T18:46:58.647774

---

**user:**

What are the metal discs used on a roof to ensure that a staple doesn’t go through the paper called?

---

**assistant:**

The metal discs are called **cap washers** or **roofing caps**. These are typically used in conjunction with staples or nails to secure roofing underlayment (like felt paper or synthetic underlayment) without the fastener tearing through the material. They distribute the pressure over a larger area, helping to hold the underlayment in place, especially in high-wind situations.

---

