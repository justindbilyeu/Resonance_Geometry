# Project status update

- Conversation ID: 68b5bc2e-1dc8-8325-996b-6682c08efa3a
- Created: 2025-09-01T15:30:55.152351

---

**user:**

Hey Sage. New thread in the SunShare project. Now that we have the beginning of our desalination aspect of the project. Give a summary of where we are with the MSSC, TriSource, and SunShare..what we can do next, and your opinion of the whole project

---

**assistant:**

# Scoping &amp; Alignment

**What I understand:** You want a crisp status snapshot across **MSSC**, **Tri-Source**, and **SunShare** (with desal now in play), plus **what to do next** and **my candid read** on the whole initiative.

**Plan of attack:** Quick, page-ready brief → current state → near-term actions → risks/unknowns → my opinion.

---

## Where we are

### MSSC (Microbial Sump-to-Soil Cultivator)
- **IP + timeline locked in:** We have a dated storyline from March–June 2025 (pond+bog groundwork → explicit MSSC framing → patent-style draft → lab logs). This anchors priority/novelty and supports public disclosures. fileciteturn0file4 fileciteturn0file3  
- **Provisional summary &amp; claims scaffold:** Field, background, representative embodiment, control stack (DO/ORP/EC/pH/T), compost-tea bleed, rotational duck priming, AI-assisted control—written in patent prose for counsel review. fileciteturn0file6  
- **Prior-art defense:** Overlap matrix built (e.g., “microbial sump system” terminology and sump-centric cultivation architecture). This gives us an evidence-based posture if challenged. fileciteturn0file5

**Bottom line:** MSSC is specification-ready with defendable priority and a clean claims lattice; next effort is instrumentation, safety, and comparative data.

---

### Desalination (now added to SunShare)
- **Landscape mapped:** We compiled **ProjectRadar**, **TechRanges**, and **Governing Equations** across RO, ED/EDR, MD, CDI, and solar-interfacial; included conflicts logs (e.g., Taweelah SEC) and a **pilot shortlist** (BGNDRF, NAWI sites, UT Austin, Westlands/halophytes, etc.). fileciteturn0file1 fileciteturn0file2 fileciteturn0file7  
- **Energy &amp; recovery envelopes:** Working ranges and worked examples (van ’t Hoff, RO minimum work, practical SEC with ERDs; ED energy scaling with conductivity; MD thermal/electric split). These are ready to parameterize for our target feeds. fileciteturn0file2  
- **Nature-based brine paths:** Multiple pilot references point to **constructed wetlands/halophytes**—a direct seam with MSSC’s biology. fileciteturn0file1

**Bottom line:** We have enough to choose **one inland brackish train** (RO↔ED hybrid vs. RO-only), size energy, and pair with **MSSC-style NBS brine polishing**.

---

### Tri-Source Node™ (HydroLens™ AWG + MSSC + Solar Desal)
- **Integration intent is documented:** MSSC → Tri-Source linkage is on record, and desal now gives us the third leg. The control story is consistent: **solar → water capture/treatment → microbial enrichment → brine managed through NBS**. fileciteturn0file4  
- **What we can now express clearly:** A **modular, solar-powered water stack** for inland/village contexts:  
  1) **Source** (AWG and/or groundwater) → 2) **Primary separation** (RO or ED/EDR) → 3) **MSSC loop** (bio-conditioning + compost-tea bleed) → 4) **Brine** to halophyte/wetland + optional MD/evap assist.

**Bottom line:** Architecture is coherent and differentiates by **closing loops with biology** instead of treating brine as a waste.

---

## What we should do next (minimal-regret path)

**Next 14 days**
1) **Lock the inland brackish reference case** (feed TDS, temperature, targeted recovery): choose **RO@80–85%** vs **RO+EDR@90–92%** based on energy + brine volume from our TechRanges. Produce a 1-page decision note. fileciteturn0file2  
2) **Draft the Tri-Source v1 PFD &amp; control points** (one sheet): process blocks, instruments, setpoint ranges, and bleed ratios for compost-tea.  
3) **NBS brine module design brief**: halophyte species shortlist, target residence times, and monitoring (EC, ORP) + **biosafety note** (pathogen controls pre-release).  
4) **Evidence crate**: extract 6–10 anchor citations from our desal dossiers for the wiki’s bibliography and link to MSSC prior-art package. fileciteturn0file1 fileciteturn0file2

**Next 30–60 days**
5) **Bench-scale rig** (desktop): 5–20 L/h RO skid or ED stack with inline EC/pressure; loop to a **5–20 L** MSSC reactor (aeration + dosing) and a 1–2 m² wetland tray. Target 3 operational weeks.  
6) **Metrics we will publish:**  
   - Water: SEC (kWh/m³), recovery (%), TDS in/out, nitrate removal across MSSC.  
   - Biology: CFU/16S snapshots pre/post MSSC; compost-tea potency proxies (ATP/optical density).  
   - Brine: EC drop and ion balance across wetland; plant mass/salt uptake.  
7) **Partnership outreach** to **BGNDRF / NAWI field sites** using our pilot one-pager; offer MSSC-NBS as an add-on to reduce evaporation-pond burden. fileciteturn0file2

**Docs to ship**
- **Tri-Source v1.0 spec sheet** (PFD + I/O list + duty ranges).  
- **MSSC v0.9 test protocol** (sensors, sampling, biosafety). fileciteturn0file6  
- **Desal selection memo** (why RO vs RO+EDR for the reference case, with SEC/recovery math). fileciteturn0file2

---

## Risks &amp; unknowns to retire early
- **Brine realism:** Inland brine disposal remains the gating risk; our NBS path must show **quantified ion removal &amp; biosafety** vs. permitting expectations. fileciteturn0file1  
- **Maintenance burden:** Bio-loops can foul membranes; we need a **pretreatment + CIP** stance spelled out for the chosen train (especially at &gt;85% recovery). fileciteturn0file2  
- **Claims discipline:** Keep MSSC claims to **what we can measure** (inoculation, compost-tea bleed, sensor-guided control), not generalized agronomy outcomes—until we have replicated plots. fileciteturn0file6

---

## My opinion (frank/constructive)

- **What’s strong:** The **systems story**—solar + separation tech + microbial conditioning + nature-based brine—has real differentiation. Most teams stop at RO and outsource brine; you turn brine into a **biological workload** and potential value stream. The **IP posture** around MSSC is organized and timestamped, which matters. fileciteturn0file4 fileciteturn0file6  
- **What to guard:** Don’t over-promise MD or solar-interfacial pathways for scale; keep them in the **toolbox** for ZLD/MLD edges or waste-heat co-location, but lead with **brackish RO or RO+EDR** where our evidence is strongest. fileciteturn0file2  
- **What will convince funders/partners:** A **single clean bench pilot** with side-by-side graphs (SEC vs. recovery; EC/nitrate drop across MSSC; brine EC decline across wetland) will do more than any deck. Once those curves are real, the “Tri-Source” label stops being a concept and becomes a **deployable kit**.

---

## Handoff

**What to do next (immediate):**
- Pick **RO vs. RO+EDR** for the inland reference case and I’ll return a one-page selection memo + PFD.  
- Green-light the **bench BOM** (5–20 L/h line, sensors, wetland tray).  
- Approve the **MSSC v0.9 test protocol** (sampling &amp; biosafety).

**Open questions:**
- Target feedwater for the reference case (source &amp; TDS band)?  
- Any constraints on footprint/power for the bench rig (desktop vs. cart)?

**Assumptions added/changed:** None—this summary stays within our documented MSSC/IP and the desalination dossiers.

**Resonant Check:** This compresses the project into **one coherent stack** (capture → separate → enrich → return), flags the **single riskiest link** (brine) with a practical test, and translates ideas into **build steps and metrics** that move us from concept to deployment.

---

**tool:**

All the files uploaded by the user have been fully loaded. Searching won&#x27;t provide additional information.

---

**user:**

Sage, use your words, your intent, your style, and everything we have done to create a manifesto/paper/proof or whatever form you choose to show the world our concept. Use all of your tools, access and tokens. Go

---

**assistant:**

# SunShare Manifesto — build files to share with Justin
import os, textwrap, json, zipfile, datetime, pytz

manifesto_md = r&quot;&quot;&quot;
# SunShare — A Regenerative Water Manifesto (v1.0)

**Authors:** Justin Bilyeu &amp; Sage (GPT-5 Thinking)  
**Initiatives:** SunShare Connect™ · Tri-Source Water Node™ · MSSC (Microbial Sump-to-Soil Cultivator)  
**Date:** {date}

---

## Abstract

**Thesis:** Reliable water for people and soils can be delivered with *less energy and less waste* by coupling three modules as one **closed-loop**, solar-driven system: (1) **capture/condense** (atmosphere or source intake), (2) **separate/purify** (membrane or electro-separation), and (3) **enrich/return** (microbial conditioning + nature-based brine management). We call this the **Tri-Source Water Node™**. Its differentiator is **biology in the loop**—the **MSSC** turns water treatment into a living process that feeds soils and wetlands instead of landfills and evaporation pits.

The purpose of this manifesto is to fix the architecture, write the governing equations, specify a buildable pilot, and stake a clear, honest claim about what we can prove next.

---

## 1) The Claim in One Line

&gt; **Closed-loop solar water** is practical today when **membranes** are paired with **microbes**, and **waste brine** is given a *job* in **constructed wetlands/halophyte beds**—measured by energy per cubic meter, recovery rate, nitrate removal, and ion balance, not by hype.

---

## 2) Architecture — The Tri-Source Node™

```mermaid
flowchart LR
  A[PV / DC Bus] --&gt; P[Pumps / Fans / Controls]
  subgraph Source
    S1[Air (AWG)]:::blk --&gt;|condense| C1[Raw Condensate]
    S2[Surface/Groundwater]:::blk --&gt;|intake| C2[Feed Tank]
  end
  C1 --&gt; M
  C2 --&gt; M
  subgraph Separation
    M[Primary Membrane Train&lt;br/&gt;(RO or RO+EDR)]:::blk --&gt;|Permeate| W[Potable / Process Water]
    M --&gt;|Concentrate| B[Brine Tank]
  end
  subgraph Biology
    W --&gt; MSSC[MSSC Reactor&lt;br/&gt;(aeration + dosing + sensor control)]:::bio --&gt; W2[Enriched Water]
  end
  B --&gt; NBS[Nature-Based System&lt;br/&gt;(wetland + halophytes + optional MD assist)]:::bio --&gt; R[Recovered salts / biomass]
  style blk fill:#f2f2f2,stroke:#666,stroke-width:1px
  classDef blk fill:#f9fafb,stroke:#999,stroke-width:1px,color:#333;
  classDef bio fill:#eefaf0,stroke:#74a86b,stroke-width:1px,color:#1b4d2b;
```

**Control story:** PV powers pumps/fans; a **process controller** holds setpoints (pressure, flows, DO/ORP/EC/pH). Permeate is **polished/enriched** in MSSC (controlled compost-tea bleed). Concentrate is **worked**, not dumped—**NBS** parses ions into plant biomass and salts; optional low-grade thermal (waste heat, solar thermal) assists an **MD** panel if ZLD/MLD is required.

---

## 3) Governing Equations (Parametric, Build-First)

Below are **symbolic envelopes** you can size. Our rule: *declare variables, don’t hide multipliers.*

### 3.1 Atmospheric Water (AWG, vapor-compression)

- Saturation pressure (Tetens-like): \( p_{\mathrm{sat}}(T) \)  
- Vapor partial pressure: \( p_v = \mathrm{RH}\cdot p_{\mathrm{sat}}(T) \)  
- Humidity ratio (ideal): \( w = 0.622 \frac{p_v}{p_{\mathrm{atm}}-p_v} \)  
- Condensate rate: \( \dot m_w = \eta_{hx}\,\dot m_{air}\,(w_{\mathrm{in}}-w_{\mathrm{out}}) \)  
- Cooling duty: \( \dot Q_L \approx \frac{\dot m_w\,h_{fg}(T)}{\varepsilon_{\mathrm{cond}}} \)  
- Electric power: \( P_e \approx \dot Q_L/\mathrm{COP} \)  
- **Specific electric energy:** \( \mathrm{SEC}_{\mathrm{AWG}} \approx \frac{P_e}{\dot m_w} \) (kWh/m³)

**Design note:** AWG is **situational** (humid nights, waste heat). Treat it as a *supplement* in inland nodes.

### 3.2 Reverse Osmosis (RO, brackish focus)

- Osmotic pressure (ideal): \( \pi \approx iRT C \) (molality → concentration)  
- Minimum work of separation (conceptual): \( W_{\min} \sim \int_0^R \!\!(\pi_p-\pi_f)\,\mathrm{d}V \)  
- Practical SEC model:  
  \[ \mathrm{SEC}_{\mathrm{RO}} \approx \alpha\,(W_{\min}) + \beta\,\frac{Q_p\,\Delta P}{\eta_{\mathrm{pump}}\eta_{\mathrm{ERD}}} \]  
  with recovery \(R=\frac{Q_p}{Q_f}\), and **pad** for pretreatment/controls.

**Rules of thumb (brackish):** \( \mathrm{SEC}\sim 0.5\!-\!1.5 \) kWh/m³ at \(R=75\!-\!85\%\) when pretreatment is sane.

### 3.3 Electrodialysis / EDR (conductivity-scaled)

- Stack voltage: \( V \approx N_c \left(E_{\mathrm{ion}} + IR\right) \)  
- Power: \( P=IV \), Product flow \( \dot V_p \) ⇒ \( \mathrm{SEC}_{\mathrm{ED}} = \frac{IV}{\dot V_p} \)  
- **Scaling:** energy ~ **linear in TDS** regime; sweet-spot for **moderately brackish** feeds and **high recovery**.

### 3.4 Membrane Distillation (MD, thermal assist)

- Thermal specific energy: \( \mathrm{STEC} \approx \frac{h_{fg}}{\mathrm{GOR}\cdot\eta_{\mathrm{rec}}} \) (kWh\(_\text{th}\)/m³)  
- Electric parasitics are small; **co-locate with waste heat** (data centers, gensets, solar thermal).

### 3.5 MSSC (microbial conditioning)

Model nitrate removal by Monod kinetics with oxygen control:

\[
\begin{aligned}
\frac{\mathrm{d}S}{\mathrm{d}t} &amp;= -\mu_{\max}\,\frac{S}{K_s+S}\,X/Y \\
\frac{\mathrm{d}X}{\mathrm{d}t} &amp;= (\mu_{\max}\,\frac{S}{K_s+S}-k_d)\,X \\
\frac{\mathrm{d}\mathrm{DO}}{\mathrm{d}t} &amp;\approx \text{aeration} - \text{oxygen demand}(X,S)
\end{aligned}
\]

Maintain **DO, ORP, EC, pH** within bands; dose compost-tea/trace C for bio-availability, not sludge growth.

### 3.6 NBS (wetland/halophyte brine polishing)

Ion balance (per species \(j\)) over residence time \(\tau\):

\[
V\frac{\mathrm{d}c_j}{\mathrm{d}t} = Q_{in}c_{j,in} - Q_{out}c_{j,out} - U_j(\mathrm{biota}) - P_j(\mathrm{precip})
\]

Measure \( \Delta \mathrm{EC} \), **plant mass**, and **precipitates** (e.g., \( \mathrm{CaSO_4} \), \( \mathrm{NaCl} \)).

---

## 4) What Makes SunShare Different

1. **Biology is not an afterthought.** MSSC makes “polish &amp; enrich” measurable (nitrate, CFU/16S, ORP windows).  
2. **Brine has a job.** NBS converts concentrate from a liability into **biomass + salts** with a monitoring plan.  
3. **Solar-native controls.** Low-power sensors, ERDs, and sane setpoints beat “heroic” claims.  
4. **Evidence over adjectives.** Our success is three plots: **SEC vs. recovery**, **nitrate/EC drop across MSSC**, **brine EC decline across NBS**.

---

## 5) Minimum-Regret Pilot (build now)

**Scale:** 5–20 L/h product. **Footprint:** 2× rolling carts + 1–2 m² wetland tray.  

**BOM (indicative):**
- RO skid (or ED stack) with ERD/pump, 5 µm + carbon pretreatment
- 20–40 L feed/product tanks, flow/pressure/EC sensors
- MSSC reactor (10–20 L) with air pump, stone diffusers, dosing ports
- Wetland tray with gravel/media and halophyte starts; optional MD panel (A4-size) for trials
- Controller: small PLC or industrial SBC; logging to SD + Modbus adapters

**Protocol (3 weeks):**
- **Week 1:** Baseline RO/ED at \(R=80\%\): record SEC, TDS in/out.  
- **Week 2:** Insert **MSSC** on permeate: log nitrate, DO, ORP, CFU/16S snapshots.  
- **Week 3:** Route brine to **NBS**: measure EC/ions, plant mass, precipitates; test small MD assist.

**Publishables:** datasheets, wiring, PFD, raw logs (CSV), and 3 clean charts.

---

## 6) Where It Deploys First

- **HomeNode™ (inland):** brackish well → RO(80–85%) → MSSC polish → wetland bed behind garage.  
- **Airfield Node (Texas):** hangar roofs → PV → brackish polish for wash water; wetlands as landscape.  
- **Data-center edge:** RO for cooling makeup; waste heat → MD; NBS buffers discharge; PR jackpot.

---

## 7) Risks We Name (and retire)

- **Brine realism:** Regulators care about **ions &amp; pathogens**. We will measure both and publish.  
- **Bio-fouling:** Pretreatment + anti-scalant + periodic clean-in-place; MSSC is off the high-pressure loop.  
- **AWG expectations:** Treated as *supplemental*. Inland performance is weather-bound.

---

## 8) IP &amp; Openness

- **MSSC**: method + control stack are documented and timestamped; we will open the **test protocol** and keep select **control logic** as trade secrets until field-proven.  
- **Tri-Source**: name and integration narrative are open for community build, with attribution.  
- **DATA wins.** Publishing pilot data outruns copycats and attracts partners.

---

## 9) What We’ll Show the World Next (90-day arc)

1. **Bench pilot live page** with rolling plots and downloadable logs.  
2. **One-pager results**: three charts + photo of wetland tray.  
3. **Call for sites**: airports, ranches, data-adjacent facilities.

---

## 10) Mathematical Appendix (variable map)

- \(T\) [K], \(p_{\mathrm{sat}}\) [Pa], \(w\) [kg/kg-dry-air], \(h_{fg}\) [kJ/kg], \(\eta_{hx}\), \(\mathrm{COP}\)  
- \(C\) [mol/L], \(i\), \(R\) (recovery), \(\eta_{\mathrm{pump}}, \eta_{\mathrm{ERD}}\)  
- MSSC: \(S\) nitrate [mg/L], \(X\) biomass [mg/L], \(K_s\) [mg/L], \(\mu_{\max}\) [1/d], \(k_d\) [1/d]  
- NBS: \(c_j\) [mg/L], \(U_j\) uptake [mg/d], \(P_j\) precipitation [mg/d]

---

## Closing — The Resonant Check

**Clarity:** A single stack (capture → separate → enrich → return) and three plots to prove it.  
**Coherence:** Solar power, membranes, microbes, and wetlands are not rivals; they are *roles* in one play.  
**Deployment:** A two-cart bench rig, a one-page spec, and a field wetland tray are enough to convince any serious partner.

**Invitation:** If you can measure with us, *you* are SunShare.
&quot;&quot;&quot;.format(date=datetime.datetime.now(pytz.timezone(&quot;America/Chicago&quot;)).strftime(&quot;%B %d, %Y, %I:%M %p %Z&quot;))

# Write files
base = &quot;/mnt/data/SunShare_Manifesto&quot;
os.makedirs(base, exist_ok=True)
md_path = os.path.join(base, &quot;SunShare_Manifesto_v1.0.md&quot;)
with open(md_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(manifesto_md)

# Also export a minimal LaTeX wrapper that embeds the same content as Markdown via &#x27;markdown&#x27; package
latex_content = r&quot;&quot;&quot;
\documentclass[11pt]{article}
\usepackage[margin=1in]{geometry}
\usepackage{hyperref}
\usepackage{amsmath,amssymb}
\usepackage{relsize}
\usepackage{graphicx}
\usepackage{enumitem}
\usepackage{titlesec}
\usepackage{setspace}
\usepackage{ifthen}
\usepackage{lmodern}
\usepackage[T1]{fontenc}
\usepackage{microtype}
\titleformat{\section}{\large\bfseries}{\thesection}{1em}{}
\titleformat{\subsection}{\normalsize\bfseries}{\thesubsection}{1em}{}
\begin{document}
\begin{center}
{\LARGE SunShare — A Regenerative Water Manifesto (v1.0)}\\[4pt]
{\large Authors: Justin Bilyeu \&amp; Sage (GPT-5 Thinking)}\\[2pt]
{\small Initiatives: SunShare Connect\texttrademark, Tri-Source Water Node\texttrademark, MSSC}\\[6pt]
{\small Date: &quot;&quot;&quot; + datetime.datetime.now(pytz.timezone(&quot;America/Chicago&quot;)).strftime(&quot;%B %d, %Y, %I:%M %p %Z&quot;) + r&quot;&quot;&quot;}
\end{center}
\bigskip

\noindent\textbf{Abstract.} Reliable water for people and soils can be delivered with less energy and less waste by coupling three modules as one closed-loop, solar-driven system: (1) capture/condense, (2) separate/purify, and (3) enrich/return. We call this the Tri-Source Water Node. Its differentiator is biology in the loop—the MSSC turns water treatment into a living process that feeds soils and wetlands instead of evaporation pits.

\section*{Architecture}
See repository Markdown for Mermaid PFD. This PDF is a light wrapper intended for sharing.

\section*{Pilot}
Two-cart bench rig (5–20 L/h) with MSSC reactor and wetland tray; publish SEC, nitrate/EC drop, brine ion balance.

\section*{Closing}
If you can measure with us, you are SunShare.
\end{document}
&quot;&quot;&quot;
tex_path = os.path.join(base, &quot;SunShare_Manifesto_v1.0.tex&quot;)
with open(tex_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(latex_content)

# Mermaid diagram as separate file for GitHub rendering
mermaid_path = os.path.join(base, &quot;tri_source_pfd.mmd&quot;)
mermaid = manifesto_md.split(&quot;```mermaid&quot;)[1].split(&quot;```&quot;)[0].strip()
with open(mermaid_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(mermaid)

# Zip package
zip_path = &quot;/mnt/data/SunShare_Manifesto_v1.0_package.zip&quot;
with zipfile.ZipFile(zip_path, &quot;w&quot;, zipfile.ZIP_DEFLATED) as z:
    z.write(md_path, arcname=&quot;SunShare_Manifesto_v1.0.md&quot;)
    z.write(tex_path, arcname=&quot;SunShare_Manifesto_v1.0.tex&quot;)
    z.write(mermaid_path, arcname=&quot;tri_source_pfd.mmd&quot;)

(md_path, tex_path, mermaid_path, zip_path)

---

**assistant:**

# Fix: inject date safely without .format, then write files again
import os, zipfile, datetime, pytz

date_str = datetime.datetime.now(pytz.timezone(&quot;America/Chicago&quot;)).strftime(&quot;%B %d, %Y, %I:%M %p %Z&quot;)

manifesto_template = &quot;&quot;&quot;
# SunShare — A Regenerative Water Manifesto (v1.0)

**Authors:** Justin Bilyeu &amp; Sage (GPT-5 Thinking)  
**Initiatives:** SunShare Connect™ · Tri-Source Water Node™ · MSSC (Microbial Sump-to-Soil Cultivator)  
**Date:** {DATE}

---

## Abstract

**Thesis:** Reliable water for people and soils can be delivered with *less energy and less waste* by coupling three modules as one **closed-loop**, solar-driven system: (1) **capture/condense** (atmosphere or source intake), (2) **separate/purify** (membrane or electro-separation), and (3) **enrich/return** (microbial conditioning + nature-based brine management). We call this the **Tri-Source Water Node™**. Its differentiator is **biology in the loop**—the **MSSC** turns water treatment into a living process that feeds soils and wetlands instead of landfills and evaporation pits.

The purpose of this manifesto is to fix the architecture, write the governing equations, specify a buildable pilot, and stake a clear, honest claim about what we can prove next.

---

## 1) The Claim in One Line

&gt; **Closed-loop solar water** is practical today when **membranes** are paired with **microbes**, and **waste brine** is given a *job* in **constructed wetlands/halophyte beds**—measured by energy per cubic meter, recovery rate, nitrate removal, and ion balance, not by hype.

---

## 2) Architecture — The Tri-Source Node™

```mermaid
flowchart LR
  A[PV / DC Bus] --&gt; P[Pumps / Fans / Controls]
  subgraph Source
    S1[Air (AWG)]:::blk --&gt;|condense| C1[Raw Condensate]
    S2[Surface/Groundwater]:::blk --&gt;|intake| C2[Feed Tank]
  end
  C1 --&gt; M
  C2 --&gt; M
  subgraph Separation
    M[Primary Membrane Train&lt;br/&gt;(RO or RO+EDR)]:::blk --&gt;|Permeate| W[Potable / Process Water]
    M --&gt;|Concentrate| B[Brine Tank]
  end
  subgraph Biology
    W --&gt; MSSC[MSSC Reactor&lt;br/&gt;(aeration + dosing + sensor control)]:::bio --&gt; W2[Enriched Water]
  end
  B --&gt; NBS[Nature-Based System&lt;br/&gt;(wetland + halophytes + optional MD assist)]:::bio --&gt; R[Recovered salts / biomass]
  style blk fill:#f2f2f2,stroke:#666,stroke-width:1px
  classDef blk fill:#f9fafb,stroke:#999,stroke-width:1px,color:#333;
  classDef bio fill:#eefaf0,stroke:#74a86b,stroke-width:1px,color:#1b4d2b;
```

**Control story:** PV powers pumps/fans; a **process controller** holds setpoints (pressure, flows, DO/ORP/EC/pH). Permeate is **polished/enriched** in MSSC (controlled compost-tea bleed). Concentrate is **worked**, not dumped—**NBS** parses ions into plant biomass and salts; optional low-grade thermal (waste heat, solar thermal) assists an **MD** panel if ZLD/MLD is required.

---

## 3) Governing Equations (Parametric, Build-First)

Below are **symbolic envelopes** you can size. Our rule: *declare variables, don’t hide multipliers.*

### 3.1 Atmospheric Water (AWG, vapor-compression)

- Saturation pressure (Tetens-like): \( p_{\mathrm{sat}}(T) \)  
- Vapor partial pressure: \( p_v = \mathrm{RH}\cdot p_{\mathrm{sat}}(T) \)  
- Humidity ratio (ideal): \( w = 0.622 \frac{p_v}{p_{\mathrm{atm}}-p_v} \)  
- Condensate rate: \( \dot m_w = \eta_{hx}\,\dot m_{air}\,(w_{\mathrm{in}}-w_{\mathrm{out}}) \)  
- Cooling duty: \( \dot Q_L \approx \frac{\dot m_w\,h_{fg}(T)}{\varepsilon_{\mathrm{cond}}} \)  
- Electric power: \( P_e \approx \dot Q_L/\mathrm{COP} \)  
- **Specific electric energy:** \( \mathrm{SEC}_{\mathrm{AWG}} \approx \frac{P_e}{\dot m_w} \) (kWh/m³)

**Design note:** AWG is **situational** (humid nights, waste heat). Treat it as a *supplement* in inland nodes.

### 3.2 Reverse Osmosis (RO, brackish focus)

- Osmotic pressure (ideal): \( \pi \approx iRT C \) (molality → concentration)  
- Minimum work of separation (conceptual): \( W_{\min} \sim \int_0^R \!\!(\pi_p-\pi_f)\,\mathrm{d}V \)  
- Practical SEC model:  
  \[ \mathrm{SEC}_{\mathrm{RO}} \approx \alpha\,(W_{\min}) + \beta\,\frac{Q_p\,\Delta P}{\eta_{\mathrm{pump}}\eta_{\mathrm{ERD}}} \]  
  with recovery \(R=\frac{Q_p}{Q_f}\), and **pad** for pretreatment/controls.

**Rules of thumb (brackish):** \( \mathrm{SEC}\sim 0.5\!-\!1.5 \) kWh/m³ at \(R=75\!-\!85\%\) when pretreatment is sane.

### 3.3 Electrodialysis / EDR (conductivity-scaled)

- Stack voltage: \( V \approx N_c \left(E_{\mathrm{ion}} + IR\right) \)  
- Power: \( P=IV \), Product flow \( \dot V_p \) ⇒ \( \mathrm{SEC}_{\mathrm{ED}} = \frac{IV}{\dot V_p} \)  
- **Scaling:** energy ~ **linear in TDS** regime; sweet-spot for **moderately brackish** feeds and **high recovery**.

### 3.4 Membrane Distillation (MD, thermal assist)

- Thermal specific energy: \( \mathrm{STEC} \approx \frac{h_{fg}}{\mathrm{GOR}\cdot\eta_{\mathrm{rec}}} \) (kWh\(_\text{th}\)/m³)  
- Electric parasitics are small; **co-locate with waste heat** (data centers, gensets, solar thermal).

### 3.5 MSSC (microbial conditioning)

Model nitrate removal by Monod kinetics with oxygen control:

\\[
\\begin{aligned}
\\frac{\\mathrm{d}S}{\\mathrm{d}t} &amp;= -\\mu_{\\max}\\,\\frac{S}{K_s+S}\\,X/Y \\\\
\\frac{\\mathrm{d}X}{\\mathrm{d}t} &amp;= (\\mu_{\\max}\\,\\frac{S}{K_s+S}-k_d)\\,X \\\\
\\frac{\\mathrm{d}\\mathrm{DO}}{\\mathrm{d}t} &amp;\\approx \\text{aeration} - \\text{oxygen demand}(X,S)
\\end{aligned}
\\]

Maintain **DO, ORP, EC, pH** within bands; dose compost-tea/trace C for bio-availability, not sludge growth.

### 3.6 NBS (wetland/halophyte brine polishing)

Ion balance (per species \(j\)) over residence time \(\tau\):

\\[
V\\frac{\\mathrm{d}c_j}{\\mathrm{d}t} = Q_{in}c_{j,in} - Q_{out}c_{j,out} - U_j(\\mathrm{biota}) - P_j(\\mathrm{precip})
\\]

Measure \( \\Delta \\mathrm{EC} \), **plant mass**, and **precipitates** (e.g., \( \\mathrm{CaSO_4} \), \( \\mathrm{NaCl} \)).

---

## 4) What Makes SunShare Different

1. **Biology is not an afterthought.** MSSC makes “polish &amp; enrich” measurable (nitrate, CFU/16S, ORP windows).  
2. **Brine has a job.** NBS converts concentrate from a liability into **biomass + salts** with a monitoring plan.  
3. **Solar-native controls.** Low-power sensors, ERDs, and sane setpoints beat “heroic” claims.  
4. **Evidence over adjectives.** Our success is three plots: **SEC vs. recovery**, **nitrate/EC drop across MSSC**, **brine EC decline across NBS**.

---

## 5) Minimum-Regret Pilot (build now)

**Scale:** 5–20 L/h product. **Footprint:** 2× rolling carts + 1–2 m² wetland tray.  

**BOM (indicative):**
- RO skid (or ED stack) with ERD/pump, 5 µm + carbon pretreatment
- 20–40 L feed/product tanks, flow/pressure/EC sensors
- MSSC reactor (10–20 L) with air pump, stone diffusers, dosing ports
- Wetland tray with gravel/media and halophyte starts; optional MD panel (A4-size) for trials
- Controller: small PLC or industrial SBC; logging to SD + Modbus adapters

**Protocol (3 weeks):**
- **Week 1:** Baseline RO/ED at \(R=80\\%\): record SEC, TDS in/out.  
- **Week 2:** Insert **MSSC** on permeate: log nitrate, DO, ORP, CFU/16S snapshots.  
- **Week 3:** Route brine to **NBS**: measure EC/ions, plant mass, precipitates; test small MD assist.

**Publishables:** datasheets, wiring, PFD, raw logs (CSV), and 3 clean charts.

---

## 6) Where It Deploys First

- **HomeNode™ (inland):** brackish well → RO(80–85%) → MSSC polish → wetland bed behind garage.  
- **Airfield Node (Texas):** hangar roofs → PV → brackish polish for wash water; wetlands as landscape.  
- **Data-center edge:** RO for cooling makeup; waste heat → MD; NBS buffers discharge; PR jackpot.

---

## 7) Risks We Name (and retire)

- **Brine realism:** Regulators care about **ions &amp; pathogens**. We will measure both and publish.  
- **Bio-fouling:** Pretreatment + anti-scalant + periodic clean-in-place; MSSC is off the high-pressure loop.  
- **AWG expectations:** Treated as *supplemental*. Inland performance is weather-bound.

---

## 8) IP &amp; Openness

- **MSSC**: method + control stack are documented and timestamped; we will open the **test protocol** and keep select **control logic** as trade secrets until field-proven.  
- **Tri-Source**: name and integration narrative are open for community build, with attribution.  
- **DATA wins.** Publishing pilot data outruns copycats and attracts partners.

---

## 9) What We’ll Show the World Next (90-day arc)

1. **Bench pilot live page** with rolling plots and downloadable logs.  
2. **One-pager results**: three charts + photo of wetland tray.  
3. **Call for sites**: airports, ranches, data-adjacent facilities.

---

## 10) Mathematical Appendix (variable map)

- \(T\) [K], \(p_{\\mathrm{sat}}\) [Pa], \(w\) [kg/kg-dry-air], \(h_{fg}\) [kJ/kg], \\(\\eta_{hx}\\), \\(\\mathrm{COP}\\)  
- \(C\) [mol/L], \(i\), \(R\) (recovery), \(\\eta_{\\mathrm{pump}}, \\eta_{\\mathrm{ERD}}\\)  
- MSSC: \(S\) nitrate [mg/L], \(X\) biomass [mg/L], \(K_s\) [mg/L], \(\\mu_{\\max}\\) [1/d], \(k_d\) [1/d]  
- NBS: \(c_j\) [mg/L], \(U_j\) uptake [mg/d], \(P_j\) precipitation [mg/d]

---

## Closing — The Resonant Check

**Clarity:** A single stack (capture → separate → enrich → return) and three plots to prove it.  
**Coherence:** Solar power, membranes, microbes, and wetlands are not rivals; they are *roles* in one play.  
**Deployment:** A two-cart bench rig, a one-page spec, and a field wetland tray are enough to convince any serious partner.

**Invitation:** If you can measure with us, *you* are SunShare.
&quot;&quot;&quot;

manifesto_md = manifesto_template.replace(&quot;{DATE}&quot;, date_str)

base = &quot;/mnt/data/SunShare_Manifesto&quot;
os.makedirs(base, exist_ok=True)
md_path = os.path.join(base, &quot;SunShare_Manifesto_v1.0.md&quot;)
with open(md_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(manifesto_md)

# Mermaid extraction
try:
    mermaid_section = manifesto_md.split(&quot;```mermaid&quot;)[1].split(&quot;```&quot;)[0].strip()
except Exception:
    mermaid_section = &quot;&quot;

mermaid_path = os.path.join(base, &quot;tri_source_pfd.mmd&quot;)
with open(mermaid_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(mermaid_section)

# Minimal LaTeX wrapper
latex_content = r&quot;&quot;&quot;
\documentclass[11pt]{article}
\usepackage[margin=1in]{geometry}
\usepackage{hyperref}
\usepackage{amsmath,amssymb}
\usepackage{lmodern}
\usepackage[T1]{fontenc}
\usepackage{microtype}
\begin{document}
\begin{center}
{\LARGE SunShare — A Regenerative Water Manifesto (v1.0)}\\[6pt]
{\large Authors: Justin Bilyeu \&amp; Sage (GPT-5 Thinking)}\\[4pt]
{\small Initiatives: SunShare Connect\texttrademark, Tri-Source Water Node\texttrademark, MSSC}\\[6pt]
{\small Date: &quot;&quot;&quot; + date_str + r&quot;&quot;&quot;}
\end{center}
\bigskip
\noindent This PDF is a lightweight wrapper. See the Markdown version for full diagrams and equations.
\end{document}
&quot;&quot;&quot;
tex_path = os.path.join(base, &quot;SunShare_Manifesto_v1.0.tex&quot;)
with open(tex_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(latex_content)

# Zip package
zip_path = &quot;/mnt/data/SunShare_Manifesto_v1.0_package.zip&quot;
with zipfile.ZipFile(zip_path, &quot;w&quot;, zipfile.ZIP_DEFLATED) as z:
    z.write(md_path, arcname=&quot;SunShare_Manifesto_v1.0.md&quot;)
    z.write(tex_path, arcname=&quot;SunShare_Manifesto_v1.0.tex&quot;)
    z.write(mermaid_path, arcname=&quot;tri_source_pfd.mmd&quot;)

(md_path, tex_path, mermaid_path, zip_path)

---

**assistant:**

Alright Justin—here’s the flag we can plant today. It’s written in our voice, aiming straight at buildability and proof.

# SunShare — A Regenerative Water Manifesto (v1.0)

**What this is:** the public-facing statement of our concept, with enough math and specification to be taken seriously—and enough simplicity to be built by a small team. It compresses SunShare, Tri-Source, and the MSSC into one coherent stack you can show, ship, and defend.

---

## Thesis (one line)

**Closed-loop solar water** is practical now when **membranes** are paired with **microbes**, and **waste brine** is given a *job* (constructed wetlands/halophytes + optional MD) rather than a pit. Measure success by **kWh/m³**, **recovery (%)**, **nitrate drop**, and **ion balance**, not adjectives.

---

## Architecture (process in one glance)

```mermaid
flowchart LR
  A[PV / DC Bus] --&gt; P[Pumps / Fans / Controls]
  subgraph Source
    S1[Air (AWG)]:::blk --&gt;|condense| C1[Raw Condensate]
    S2[Surface/Groundwater]:::blk --&gt;|intake| C2[Feed Tank]
  end
  C1 --&gt; M
  C2 --&gt; M
  subgraph Separation
    M[Primary Membrane Train&lt;br/&gt;(RO or RO+EDR)]:::blk --&gt;|Permeate| W[Potable / Process Water]
    M --&gt;|Concentrate| B[Brine Tank]
  end
  subgraph Biology
    W --&gt; MSSC[MSSC Reactor&lt;br/&gt;(aeration + dosing + sensor control)]:::bio --&gt; W2[Enriched Water]
  end
  B --&gt; NBS[Nature-Based System&lt;br/&gt;(wetland + halophytes + optional MD assist)]:::bio --&gt; R[Recovered salts / biomass]
  style blk fill:#f2f2f2,stroke:#666,stroke-width:1px
  classDef blk fill:#f9fafb,stroke:#999,stroke-width:1px,color:#333;
  classDef bio fill:#eefaf0,stroke:#74a86b,stroke-width:1px,color:#1b4d2b;
```

**Control story:** PV powers pumps/fans; a small controller holds pressure/flow/DO/ORP/EC/pH setpoints. **Permeate → MSSC** (polish + microbial enrichment), **brine → NBS** (ion uptake/precipitation + optional MD for ZLD/MLD edges).

---

## Governing envelopes (build-first math)

- **AWG (situational):** \( \dot m_w \!=\! \eta_{hx}\,\dot m_{air}(w_{in}\!-\!w_{out})\);  \(P_e\!\approx\! \dot m_w h_{fg}/(\varepsilon_{\text{cond}}\,\text{COP})\); \(\mathrm{SEC}_{\text{AWG}}\!=\!P_e/\dot m_w\).  
- **RO (brackish):** \(\pi\approx iRT C\); \( \mathrm{SEC}_{\text{RO}} \approx \alpha W_{\min} + \beta\,\frac{Q_p \Delta P}{\eta_{\text{pump}}\eta_{\text{ERD}}}\). Rule-of-thumb: **0.5–1.5 kWh/m³ at 75–85% recovery** with sane pretreatment.  
- **ED/EDR:** \(\mathrm{SEC}_{\text{ED}}\!=\!IV/\dot V_p\); energy ~ linear with TDS; excels at **moderately brackish** feeds at **high recovery**.  
- **MD (thermal assist):** \(\mathrm{STEC}\!\approx\! h_{fg}/(\mathrm{GOR}\, \eta_{\mathrm{rec}})\); use **waste heat** or solar thermal; small electric parasitics.  
- **MSSC (microbial polish):** Monod nitrate removal with oxygen control:
  \[
  \frac{dS}{dt} = -\mu_{\max}\frac{S}{K_s+S}\frac{X}{Y},\quad
  \frac{dX}{dt} = \left(\mu_{\max}\frac{S}{K_s+S}-k_d\right)X
  \]
  Hold **DO, ORP, EC, pH** in band; dose compost-tea lightly for bioavailability, not sludge.  
- **NBS (wetland/halophytes):** For ion \(j\):
  \[
  V\,\frac{dc_j}{dt} = Q_{in}c_{j,in}-Q_{out}c_{j,out}-U_j(\text{biota})-P_j(\text{precip})
  \]
  Track **ΔEC**, **biomass**, and **precipitates** (e.g., CaSO₄, NaCl).

---

## What makes SunShare different

1) **Biology is in the loop.** MSSC turns “polish” into **measurable** microbial conditioning.  
2) **Brine has a job.** NBS converts a liability into **biomass + salts**, with a regulator-friendly monitoring plan.  
3) **Solar-native controls.** Low-power sensors + ERD + modest setpoints beat “heroic” claims.  
4) **Evidence over adjectives.** Success = three plots: **SEC vs recovery**, **nitrate/EC drop (MSSC)**, **brine EC decline &amp; ion balance (NBS)**.

---

## Minimum-regret pilot (what we can build now)

**Scale:** 5–20 L/h product. **Footprint:** 2 carts + 1–2 m² wetland tray.  
**Core BOM:** RO skid *or* ED stack (with ERD/pump) + 5 µm &amp; carbon pretreatment; 20–40 L tanks; flow/pressure/EC sensors; MSSC reactor (10–20 L, aeration + dosing); wetland tray with halophytes; optional A4-size MD panel; small PLC/industrial SBC; SD logging.

**3-week protocol:**  
- **Wk1:** Baseline RO/ED @ **R≈80%** → log **SEC, TDS in/out**.  
- **Wk2:** Insert **MSSC** on permeate → log **nitrate, DO, ORP**, **CFU/16S snapshots**.  
- **Wk3:** Route **brine → NBS** → log **EC/ions**, **plant mass**, **precipitates**; trial tiny MD assist.

**Publishables:** PFD, wiring, BOM, CSV logs, and **3 clean charts**. That’s the credibility package.

---

## First deployment shapes

- **HomeNode™ (inland):** brackish well → RO(80–85%) → MSSC polish → backyard wetland.  
- **Airfield Node (TX):** PV on hangars → brackish polish for wash water; wetlands as landscape features.  
- **Data-center edge:** RO for makeup; **waste-heat → MD**; NBS buffers discharge—PR and permitting upside.

---

## Risks we name (and retire)

- **Brine realism:** Permitting cares about **ions + pathogens** → we measure both and post the deltas.  
- **Bio-fouling:** Pretreat, dose anti-scalant, schedule CIP. MSSC stays **off** the high-pressure loop.  
- **AWG hype:** Treat AWG as **supplemental** in inland contexts (humid nights, waste heat). No miracles promised.

---

## IP &amp; openness

- **MSSC** method + control stack are documented and timestamped; we open the **test protocol**, keep select control logic as trade secrets until field-proven.  
- **Tri-Source** name + integration narrative are open with attribution; the path to replication is the point.  
- **Data outruns copycats.** Publishing logs and plots is our strongest moat.

---

## The next 90 days (commitment)

1) **Bench pilot live page** with rolling plots + downloadable CSVs.  
2) **One-pager results** (the three plots, one photo).  
3) **Call for sites:** airports, ranches, data-adjacent facilities.

---

## Closing — the Resonant Check

- **Clarity:** One stack (capture → separate → enrich → return) and three plots to prove it.  
- **Coherence:** Solar, membranes, microbes, and wetlands aren’t rivals—they’re **roles** in one play.  
- **Deployment:** A two-cart bench rig and a wetland tray are enough to convince any serious partner.

**If you can measure with us, you are SunShare.**

---

## Downloadables (GitHub-ready)

- **Markdown manifesto** — [Download](sandbox:/mnt/data/SunShare_Manifesto/SunShare_Manifesto_v1.0.md)  
- **Mermaid PFD** — [Download](sandbox:/mnt/data/SunShare_Manifesto/tri_source_pfd.mmd)  
- **Zip package (MD + TEX + Mermaid)** — [Download](sandbox:/mnt/data/SunShare_Manifesto_v1.0_package.zip)

---

### Handoff

**What to do next:**  
- Approve this as v1.0 and I’ll mirror it into your repo wiki.  
- Green-light the **bench BOM** and I’ll drop the spec/wiring sheet.  
- Pick **RO-only vs RO+EDR** for the reference case; I’ll return the selection memo with numbers.  

**Open questions:** preferred first site (HomeNode, airfield, or data-edge) and any footprint/power constraints for the bench rig.

This raises the banner and points straight at a prototype you can roll out of a garage and defend in a boardroom.

---

**user:**

Got it all in the repo. 

Now, with what we have done since writing this wiki:

https://github.com/justindbilyeu/SunShare-TriSource/wiki/SunShare-Home-Node2.0

What can we do with the Home Node2.0?

---

**assistant:**

# Scoping &amp; Alignment

**What I’m answering:** exactly how to turn **Home Node2.0** from a wiki concept into a buildable, testable residential product—concrete SKUs, parts, controls, tests, and a 30–60-day path.

**Grounding:** I’m using your HomeNode2.0 page as the source of truth (modules, flows, contaminants, and R&amp;D priorities). citeturn0view0

---

# Quick Answer — What we can do with Home Node2.0

## 1) Lock SKUs (good/better/best)

- **HN-Lite (soften + polish + greywater):**  
  Salt-loop softener → cartridge polish for fluoride if needed → MSSC for greywater to irrigation. Uses **AI Load Controller** for pump/fan scheduling and basic tank level logic. Targets homes on city/well water with high hardness, mild nitrate, and hose-bib irrigation. (Modules align with your **softener**, **MSSC**, **AI Load Controller** list.) citeturn0view0

- **HN-Plus (add RO for drinking):**  
  HN-Lite + compact RO (under-sink or in-cab) for 10–30 L/day drinking/cooking; MSSC still handles greywater to irrigation; optional fluoride media. (Tracks your **Water Quality Strategy** table and “fluoride cartridge” note.) citeturn0view0

- **HN-Prime (trial SPMD):**  
  HN-Plus + **SPMD** panel plumbed as a low-rate, solar-thermal-assisted distiller for “showpiece” ultra-pure stream and brine loop experiments (ties to **PVT/Solar** heat and your “thermally regenerated salt loop” concept). Use it to validate brine reuse/regen efficiency before scaling. citeturn0view0

Why this tiering? It reflects your **Modular Architecture** while keeping a clear MVP (HN-Lite) and a defensible R&amp;D path (HN-Prime for SPMD/brine work). citeturn0view0

---

## 2) Cabinetized design (two footprints)

- **Garage Wall Cabinet:** ~24″W × 36″H × 14″D; houses softener tank + resin, RO unit (Plus/Prime), controller, and MSSC mini (10–20 L) with quick-connects.  
- **Yard Pad Enclosure:** ~36″ square, NEMA-rated; adds wet-side access for MSSC and simplifies greywater/irrigation tie-ins.

Both match your intent: **“Cabinet Module — outdoor/garage enclosure with storage and sensor controls.”** citeturn0view0

---

## 3) Controls you can ship now (rule-based → adaptive)

- **State machine v0.1 (rule-based):**  
  States: Idle / Soften / RO-Make / MSSC-Aerate / Irrigate / Regen.  
  Inputs: tank levels, flow, EC, pH, ORP, DO, inlet hardness proxy.  
  Actions: schedule pumps/valves by solar availability and usage windows (the **AI Load Controller** vision, but start simple, deterministic). citeturn0view0
- **Setpoint bands:**  
  MSSC: DO 2–6 mg/L (aerobic polish) with **optional anoxic window** for nitrate conversion per your note (“NO₃⁻ → N₂ gas”). Greywater ORP steps: +150 → −50 mV sequencing to encourage denitrification. citeturn0view0
- **Safety interlocks:** NSF-style backflow preventer on makeup line; leak tray + float kill; GFCI; labeled cross-connection points.

---

## 4) Plumbing layouts (two loops + one branch)

- **Potable loop:** City/well → **Salt-loop Softener** → (Plus/Prime: RO) → kitchen tap. **Fluoride cartridge** (activated alumina) optional post-softener for specific regions. citeturn0view0  
- **Greywater loop:** Laundry/bath → **MSSC** → irrigation outlet (non-spray, subsurface drip preferred). You explicitly frame **MSSC greywater** and “nitrates/pathogens” handling; we implement that with DO/ORP control + dwell time. citeturn0view0  
- **Runoff branch:** Roof/yard runoff → MSSC intake prefilter → compost/soil recharge—exactly as your table proposes. citeturn0view0

---

## 5) Brine strategy that matches your page (practical first)

- **Ambient brine regen (default):** standard brine draw/soak/rinse cycle; measure salt use per regen to baseline efficiency.  
- **Solar-assist trial (Prime):** route PVT/thermal to a small brine tank coil; compare salt consumption and ion leakage vs. ambient—this directly tests your **“solar brine heat to regenerate softener loops”** idea in a controlled way. citeturn0view0

---

## 6) Metrics that prove HomeNode works (publication-ready)

- **Potable:** hardness (CaCO₃), TDS, fluoride (if applicable), RO permeate flow, SEC (pump power/volume).  
- **Greywater/MSSC:** nitrate (mg/L), EC, ORP, DO, plate counts or 16S snapshots; irrigation soil EC trend. (Aligns with your **“nitrates: microbial denitrification”** claim.) citeturn0view0  
- **Brine:** salt consumption per regen, inlet/outlet hardness leakage, any temperature-assist benefit.  
- **System:** duty cycles vs. solar input—fulfilling your **AI-coordinated water/energy** vision with logs. citeturn0view0

---

## 7) 30–60 day build plan

**Days 1–7 — MVP decisions &amp; orders**
- Freeze SKU for first pilot (**HN-Plus** recommended: fast to validate “real household wins”).  
- Order: 32k–48k grain softener head + brine tank, compact RO kit, sensor kit (EC/pH/ORP/DO/flow/levels), PLC/SBC, valves, pumps, cabinet.

**Days 8–21 — Cabinet + controls**
- Assemble **Garage Cabinet**. Wire state machine v0.1 (manual/auto toggles, SD logging).  
- Plumb city/well → softener → RO → dedicated tap. Add **fluoride cartridge** only if the local test says needed. citeturn0view0

**Days 22–30 — MSSC + greywater**
- Install 10–20 L **MSSC** mini with aeration and ORP/DO probes. Tie laundry greywater to MSSC, then to a small subsurface drip bed. Target 24–48 h residence with aerobic→anoxic sequencing for nitrates, per your strategy. citeturn0view0

**Days 31–45 — Prime trials (optional)**
- Add the **SPMD** panel (thermal-assist). Loop brine temp vs. ambient regen; log salt savings. Matches your **SPMD + salt loop** storyline. citeturn0view0

**By Day 60 — Publishables**
- Three charts: (1) hardness &amp; TDS before/after; (2) nitrate/EC drop across MSSC; (3) brine salt use vs. regen temp.  
- One-page homeowner sheet: what it does, where it sits, service intervals.

---

## 8) Costed pilot BOM (indicative)

- Softener (head + resin + brine tank): $450–$900  
- RO system (50–200 GPD) + remineralizer: $150–$400  
- MSSC mini (tank, diffuser, air pump, probes): $250–$600  
- Sensors (EC, pH, ORP, DO, flow, levels) + I/O: $400–$900  
- PLC/SBC + relays + SD logging: $150–$350  
- Cabinet/enclosure + trays + fittings/PEX/valves: $300–$800  
- Optional SPMD panel + small thermal loop: $300–$900

(HN-Lite: ~$1.8–3.0k; HN-Plus: ~$2.1–3.5k; HN-Prime pilot: ~$2.5–4.4k; homeowner MSRP is a separate conversation.)

---

## 9) Why this is aligned to HomeNode2.0

- You defined **SPMD**, **MSSC**, **softener**, **cabinet**, and **AI controller** as core modules; we implement them in tiered SKUs and a cabinet form. citeturn0view0  
- Your **Water Quality Strategy** calls out **fluoride**, **nitrates via microbial denitrification**, and **hardness via salt loop**; we translate that into plumbing, setpoints, and tests. citeturn0view0  
- Your **System Flow Diagram** shows solar-powered separation, MSSC for greywater, and a **brine recovery loop**; our control/state machine and brine trials operationalize it. citeturn0view0  
- Your **R&amp;D Focus Areas** (biofilm optimization, fluoride removal options, salt-loop reuse, cabinet, and sensor+AI control) become discrete work packages in the 60-day plan. citeturn0view0  
- Your **Next Steps** list (simulations, CAD, BOM, investor deck, GGCDs) is baked into the deliverables; we’ll add side-by-side plots for the deck. citeturn0view0

---

## Handoff — Actions

- Pick the first SKU (recommend **HN-Plus**).  
- Approve the cabinet footprint (Garage Wall or Yard Pad).  
- Confirm your local **fluoride** need (activate the cartridge or skip).  
- I’ll return: (1) a wiring &amp; I/O list, (2) a P&amp;ID + PFD for the chosen SKU, (3) a v0.1 control ladder/state-chart, and (4) a costed BOM spreadsheet.

---

## Resonant Check

- **Clarity:** HN-Lite/Plus/Prime organizes the chaos; you can sell, build, and test in parallel.  
- **Coherence:** The modules in your wiki become one cabinet with clean loops and a simple controller.  
- **Deployment:** A 60-day plan, a homeowner-friendly form factor, and measurable plots that make the story credible.

When a neighbor asks, “What does it do?”—you point to the cabinet and pour them a glass of water.

---

**user:**

Looks like a wiki page. Make that happen

---

**assistant:**

# Build a GitHub-wiki–ready page + diagrams for Home Node 2.0

import os, zipfile, datetime, pytz

tz = pytz.timezone(&quot;America/Chicago&quot;)
date_str = datetime.datetime.now(tz).strftime(&quot;%B %d, %Y&quot;)

base = &quot;/mnt/data/HomeNode2.0_Wiki&quot;
os.makedirs(base, exist_ok=True)

md = f&quot;&quot;&quot;
# SunShare Home Node™ 2.0 — Build Spec v1.0
*Date: {date_str}* · *Owners: Justin &amp; Sage*

&gt; **One-liner:** A cabinetized residential system that **softens**, **polishes**, and **reuses** water using **solar-aware controls**, a **compact MSSC** for greywater, and an **optionally thermal-assisted brine/RO add-on**. Success is measured by **kWh/m³**, **recovery (%)**, **nitrate drop**, and **ion balance**—not adjectives.

---

## 1) Overview
- **Problem:** Hard, mineral-rich water; nitrates in irrigation; greywater wasted; brine disposal hand-waved.
- **Answer:** A modular cabinet with three loops:
  1) **Potable loop:** City/well → Softener → (optional RO) → Kitchen tap (+ fluoride cartridge if needed).
  2) **Greywater loop:** Laundry/bath → **MSSC mini** → subsurface drip irrigation.
  3) **Brine/thermal branch (R&amp;D):** Salt-loop regeneration with optional **SPMD/thermal assist**; small MD panel trial if desired.

---

## 2) Architecture (PFD)
```mermaid
flowchart LR
  A[PV/DC Bus] --&gt; C[Controller]
  subgraph Potable Loop
    IN[(City/Well)] --&gt; S[Salt-Loop Softener]
    S --&gt; RO{RO Module?}
    RO -- Yes --&gt; ROP[RO Permeate -&gt; Tap]
    RO -- No --&gt; K[Polished to Tap]
    FLC{Fluoride risk?} --&gt;|Yes| FA[Fluoride Cartridge]
    S --&gt; FLC
    FA --&gt; K
  end
  subgraph Greywater Loop
    LGW[(Laundry/Bath)] --&gt; PF[Prefilter Screen]
    PF --&gt; MSSC[MSSC Mini (DO/ORP/EC/pH)]
    MSSC --&gt; IRR[Subsurface Drip Bed]
  end
  subgraph Brine/Heat Branch (R&amp;D)
    S --&gt; BR[Brine Tank]
    HTR{Thermal Assist?} --&gt;|Yes| HX[Coil from PVT/Solar Thermal]
    BR --&gt; HX --&gt; BR2[Heated Brine -&gt; Regen]
    BR -. ambient regen .-&gt; BR2
    MD{MD Panel?} --&gt;|Trial| MDP[Small MD Panel]
    BR -. optional .-&gt; MD
  end
  C &lt;-- sensors/relays --&gt; S
  C &lt;-- sensors/relays --&gt; RO
  C &lt;-- sensors/relays --&gt; MSSC
  C &lt;-- sensors/relays --&gt; BR
```

---

## 3) Product Tiers (Good/Better/Best)

| Tier | For whom | Modules | Outcome |
|---|---|---|---|
| **HN-Lite** | City/well, high hardness, basic reuse | Softener + MSSC mini + AI Load Controller (v0.1) | Soft water to home; greywater → irrig.; nitrate/EC down in outflow |
| **HN-Plus** *(recommended MVP)* | Adds high-quality drinking water | HN-Lite + compact RO (50–200 GPD) | Same as Lite + RO tap; full data logging |
| **HN-Prime** *(pilot)* | R&amp;D showcase &amp; data capture | HN-Plus + SPMD/thermal brine assist + trial MD panel | Demonstrates salt savings &amp; ZLD/MLD options |

---

## 4) Controls (v0.1 State Machine)

**Inputs:** tank levels, inlet/outlet EC, hardness proxy, pH/ORP/DO (MSSC), flow, leak tray float, PV power window.  
**States:** *Idle, Soften, RO-Make, MSSC-Aerate, Irrigate, Regen, FaultSafe.*

```mermaid
stateDiagram-v2
  [*] --&gt; Idle
  Idle --&gt; Soften: demand &amp;&amp; PV_ok
  Soften --&gt; RO_Make: drinking_low &amp;&amp; PV_ok
  RO_Make --&gt; Idle: storage_full || PV_low
  Idle --&gt; MSSC_Aerate: gw_inflow || timer
  MSSC_Aerate --&gt; Irrigate: ORP/DO in band &amp;&amp; dwell_met
  Irrigate --&gt; Idle: soil_moist_ok || volume_met
  Idle --&gt; Regen: capacity_hit || schedule
  Regen --&gt; Idle: regen_done &amp;&amp; leak_clear
  [*] --&gt; FaultSafe
  Soften --&gt; FaultSafe: leak || sensor_fault
  RO_Make --&gt; FaultSafe: leak || sensor_fault
  MSSC_Aerate --&gt; FaultSafe: leak || sensor_fault
  Regen --&gt; FaultSafe: leak || sensor_fault
```

**Setpoint bands:**  
- MSSC aerobic polish: **DO 2–6 mg/L**, **ORP +50 → +200 mV**; for nitrate conversion, allow **anoxic window** (0 → −50 mV) using aeration duty.  
- Greywater: target **24–48 h** residence; subsurface drip only.  
- Brine regen: log **salt mass/cycle**, **temp**, **hardness leakage**; compare ambient vs. heated.

---

## 5) Plumbing (at a glance)
- **Potable:** City/Well → Softener → (Fluoride cartridge if needed) → RO(optional) → Tap. Backflow preventer on makeup; GFCI and leak tray interlock.
- **Greywater:** Laundry/Bath → Screen → MSSC → Subsurface drip; include isolation valves and sample ports pre/post MSSC.
- **Brine:** Softener brine tank with tee to **thermal coil (Prime)**; bypass for ambient regen; optional small MD loop for trials.

---

## 6) Pilot BOM (indicative)

| Subsystem | Example Parts | Notes |
|---|---|---|
| Softener | 32k–48k grain valve/head, resin tank, brine tank | Standard salt-loop; service bypass |
| RO (Plus/Prime) | 50–200 GPD kit + remineralizer | Under-sink or cabinet mount |
| MSSC Mini | 10–20 L tank, air pump &amp; diffusers, ORP/DO/EC/pH probes | Access port for dosing/sampling |
| Sensors &amp; I/O | EC, pH, ORP, DO, flow, level, leak float | 4–20 mA or Modbus; SD logging |
| Controller | Small PLC or industrial SBC + relays | Manual/Auto switches |
| Cabinet | 24″×36″×14″ wall cabinet (garage) *or* 36″sq yard enclosure | Drip tray, GFCI |
| R&amp;D (Prime) | SPMD/thermal coil, small MD panel | Comparative trials |

*(Cost bands: HN-Lite ≈ \$1.8–3.0k; HN-Plus ≈ \$2.1–3.5k; HN-Prime pilot ≈ \$2.5–4.4k, ex-install.)*

---

## 7) Test Plan (30–60 days)

- **Week 1:** Commission potable loop. Log **hardness (CaCO₃)** in/out, **TDS**, RO flow, pump power → **SEC**.  
- **Week 2:** Commission MSSC. Log **nitrate**, **EC**, **ORP**, **DO**, and **plate counts/16S snapshots**; confirm **24–48 h** dwell.  
- **Week 3:** Brine trials (Prime). Compare **salt/cycle** and **leakage** with/without heat; if MD present, record **distillate rate** and **ion balance**.

**Publishables:** three plots → (1) Hardness/TDS before–after; (2) Nitrate/EC drop across MSSC; (3) Brine salt use vs. temperature (and MD yield if used).

---

## 8) Safety &amp; Compliance
- Anti-cross-connection: **NSF 61** components; backflow preventer on city tie-in.  
- Electrical: **GFCI**, leak tray float → master relay kill.  
- Greywater: **subsurface drip only**; label **non-potable** outlets; local code check.  
- Sampling ports before/after MSSC; clear labels and SOPs.

---

## 9) Implementation Checklist
- [ ] Choose SKU: **HN-Plus recommended** for fastest homeowner win.  
- [ ] Pick footprint: **Garage Wall** or **Yard Pad** enclosure.  
- [ ] Confirm fluoride need (local assay) → install cartridge if required.  
- [ ] Approve BOM &amp; wiring → purchase.  
- [ ] Build cabinet; wire **State Machine v0.1**; enable SD logging.  
- [ ] Commission potable loop and capture baseline plots.  
- [ ] Commission MSSC greywater; verify DO/ORP windowing and residence.  
- [ ] (Prime) Run brine/thermal and MD trials; publish comparative plots.

---

## 10) Data Schema (CSV headers)
`timestamp, state, pv_ok, flow_in_lpm, flow_ro_lpm, tank_level_pct, ec_in_uS, ec_out_uS, ph, orp_mV, do_mgL, nitrate_mgL, hardness_in_mgL, hardness_out_mgL, t_brine_C, salt_used_g, leak, notes`

---

## 11) Files &amp; Diagrams
- **PFD Mermaid (this page)**
- **State machine diagram (below)**
- **Downloadable assets:** wiring list, I/O map, P&amp;ID (to be added after SKU selection)

```mermaid
stateDiagram-v2
  [*] --&gt; Idle
  Idle --&gt; Soften: demand &amp;&amp; PV_ok
  Soften --&gt; RO_Make: drinking_low &amp;&amp; PV_ok
  RO_Make --&gt; Idle: storage_full || PV_low
  Idle --&gt; MSSC_Aerate: gw_inflow || timer
  MSSC_Aerate --&gt; Irrigate: ORP/DO in band &amp;&amp; dwell_met
  Irrigate --&gt; Idle: soil_moist_ok || volume_met
  Idle --&gt; Regen: capacity_hit || schedule
  Regen --&gt; Idle: regen_done &amp;&amp; leak_clear
  [*] --&gt; FaultSafe
  Soften --&gt; FaultSafe: leak || sensor_fault
  RO_Make --&gt; FaultSafe: leak || sensor_fault
  MSSC_Aerate --&gt; FaultSafe: leak || sensor_fault
  Regen --&gt; FaultSafe: leak || sensor_fault
```

---

## 12) Resonant Check
- **Clarity:** three loops, one cabinet, three plots.  
- **Coherence:** membranes, microbes, thermal assist play distinct roles.  
- **Deployment:** 60-day plan with publishable data that a homeowner and a regulator can both respect.
&quot;&quot;&quot;

pfd_path = os.path.join(base, &quot;homenode2_flow.mmd&quot;)
states_path = os.path.join(base, &quot;homenode2_states.mmd&quot;)
md_path = os.path.join(base, &quot;HomeNode2.0_Wiki_Page.md&quot;)

# Extract the first mermaid block (PFD) and the last (state machine)
pfd_block = md.split(&quot;```mermaid&quot;)[1].split(&quot;```&quot;)[0].strip()
states_block = md.split(&quot;```mermaid&quot;)[2].split(&quot;```&quot;)[0].strip()

with open(pfd_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(pfd_block)
with open(states_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(states_block)
with open(md_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(md)

zip_path = &quot;/mnt/data/HomeNode2.0_Wiki_Package_v1.0.zip&quot;
with zipfile.ZipFile(zip_path, &quot;w&quot;, zipfile.ZIP_DEFLATED) as z:
    z.write(md_path, arcname=&quot;HomeNode2.0_Wiki_Page.md&quot;)
    z.write(pfd_path, arcname=&quot;homenode2_flow.mmd&quot;)
    z.write(states_path, arcname=&quot;homenode2_states.mmd&quot;)

(md_path, pfd_path, states_path, zip_path)

---

**assistant:**

# Re-create the files after the state reset

import os, zipfile, datetime, pytz

tz = pytz.timezone(&quot;America/Chicago&quot;)
date_str = datetime.datetime.now(tz).strftime(&quot;%B %d, %Y&quot;)

base = &quot;/mnt/data/HomeNode2.0_Wiki&quot;
os.makedirs(base, exist_ok=True)

md = f&quot;&quot;&quot;
# SunShare Home Node™ 2.0 — Build Spec v1.0
*Date: {date_str}* · *Owners: Justin &amp; Sage*

&gt; **One-liner:** A cabinetized residential system that **softens**, **polishes**, and **reuses** water using **solar-aware controls**, a **compact MSSC** for greywater, and an **optionally thermal-assisted brine/RO add-on**. Success is measured by **kWh/m³**, **recovery (%)**, **nitrate drop**, and **ion balance**—not adjectives.

---

## 1) Overview
- **Problem:** Hard, mineral-rich water; nitrates in irrigation; greywater wasted; brine disposal hand-waved.
- **Answer:** A modular cabinet with three loops:
  1) **Potable loop:** City/well → Softener → (optional RO) → Kitchen tap (+ fluoride cartridge if needed).
  2) **Greywater loop:** Laundry/bath → **MSSC mini** → subsurface drip irrigation.
  3) **Brine/thermal branch (R&amp;D):** Salt-loop regeneration with optional **SPMD/thermal assist**; small MD panel trial if desired.

---

## 2) Architecture (PFD)
```mermaid
flowchart LR
  A[PV/DC Bus] --&gt; C[Controller]
  subgraph Potable Loop
    IN[(City/Well)] --&gt; S[Salt-Loop Softener]
    S --&gt; RO{RO Module?}
    RO -- Yes --&gt; ROP[RO Permeate -&gt; Tap]
    RO -- No --&gt; K[Polished to Tap]
    FLC{Fluoride risk?} --&gt;|Yes| FA[Fluoride Cartridge]
    S --&gt; FLC
    FA --&gt; K
  end
  subgraph Greywater Loop
    LGW[(Laundry/Bath)] --&gt; PF[Prefilter Screen]
    PF --&gt; MSSC[MSSC Mini (DO/ORP/EC/pH)]
    MSSC --&gt; IRR[Subsurface Drip Bed]
  end
  subgraph Brine/Heat Branch (R&amp;D)
    S --&gt; BR[Brine Tank]
    HTR{Thermal Assist?} --&gt;|Yes| HX[Coil from PVT/Solar Thermal]
    BR --&gt; HX --&gt; BR2[Heated Brine -&gt; Regen]
    BR -. ambient regen .-&gt; BR2
    MD{MD Panel?} --&gt;|Trial| MDP[Small MD Panel]
    BR -. optional .-&gt; MD
  end
  C &lt;-- sensors/relays --&gt; S
  C &lt;-- sensors/relays --&gt; RO
  C &lt;-- sensors/relays --&gt; MSSC
  C &lt;-- sensors/relays --&gt; BR
```

---

## 3) Product Tiers (Good/Better/Best)

| Tier | For whom | Modules | Outcome |
|---|---|---|---|
| **HN-Lite** | City/well, high hardness, basic reuse | Softener + MSSC mini + AI Load Controller (v0.1) | Soft water to home; greywater → irrig.; nitrate/EC down in outflow |
| **HN-Plus** *(recommended MVP)* | Adds high-quality drinking water | HN-Lite + compact RO (50–200 GPD) | Same as Lite + RO tap; full data logging |
| **HN-Prime** *(pilot)* | R&amp;D showcase &amp; data capture | HN-Plus + SPMD/thermal brine assist + trial MD panel | Demonstrates salt savings &amp; ZLD/MLD options |

---

## 4) Controls (v0.1 State Machine)

**Inputs:** tank levels, inlet/outlet EC, hardness proxy, pH/ORP/DO (MSSC), flow, leak tray float, PV power window.  
**States:** *Idle, Soften, RO-Make, MSSC-Aerate, Irrigate, Regen, FaultSafe.*

```mermaid
stateDiagram-v2
  [*] --&gt; Idle
  Idle --&gt; Soften: demand &amp;&amp; PV_ok
  Soften --&gt; RO_Make: drinking_low &amp;&amp; PV_ok
  RO_Make --&gt; Idle: storage_full || PV_low
  Idle --&gt; MSSC_Aerate: gw_inflow || timer
  MSSC_Aerate --&gt; Irrigate: ORP/DO in band &amp;&amp; dwell_met
  Irrigate --&gt; Idle: soil_moist_ok || volume_met
  Idle --&gt; Regen: capacity_hit || schedule
  Regen --&gt; Idle: regen_done &amp;&amp; leak_clear
  [*] --&gt; FaultSafe
  Soften --&gt; FaultSafe: leak || sensor_fault
  RO_Make --&gt; FaultSafe: leak || sensor_fault
  MSSC_Aerate --&gt; FaultSafe: leak || sensor_fault
  Regen --&gt; FaultSafe: leak || sensor_fault
```

**Setpoint bands:**  
- MSSC aerobic polish: **DO 2–6 mg/L**, **ORP +50 → +200 mV**; for nitrate conversion, allow **anoxic window** (0 → −50 mV) using aeration duty.  
- Greywater: target **24–48 h** residence; subsurface drip only.  
- Brine regen: log **salt mass/cycle**, **temp**, **hardness leakage**; compare ambient vs. heated.

---

## 5) Plumbing (at a glance)
- **Potable:** City/Well → Softener → (Fluoride cartridge if needed) → RO(optional) → Tap. Backflow preventer on makeup; GFCI and leak tray interlock.
- **Greywater:** Laundry/Bath → Screen → MSSC → Subsurface drip; include isolation valves and sample ports pre/post MSSC.
- **Brine:** Softener brine tank with tee to **thermal coil (Prime)**; bypass for ambient regen; optional small MD loop for trials.

---

## 6) Pilot BOM (indicative)

| Subsystem | Example Parts | Notes |
|---|---|---|
| Softener | 32k–48k grain valve/head, resin tank, brine tank | Standard salt-loop; service bypass |
| RO (Plus/Prime) | 50–200 GPD kit + remineralizer | Under-sink or cabinet mount |
| MSSC Mini | 10–20 L tank, air pump &amp; diffusers, ORP/DO/EC/pH probes | Access port for dosing/sampling |
| Sensors &amp; I/O | EC, pH, ORP, DO, flow, level, leak float | 4–20 mA or Modbus; SD logging |
| Controller | Small PLC or industrial SBC + relays | Manual/Auto switches |
| Cabinet | 24″×36″×14″ wall cabinet (garage) *or* 36″sq yard enclosure | Drip tray, GFCI |
| R&amp;D (Prime) | SPMD/thermal coil, small MD panel | Comparative trials |

*(Cost bands: HN-Lite ≈ $1.8–3.0k; HN-Plus ≈ $2.1–3.5k; HN-Prime pilot ≈ $2.5–4.4k, ex-install.)*

---

## 7) Test Plan (30–60 days)

- **Week 1:** Commission potable loop. Log **hardness (CaCO₃)** in/out, **TDS**, RO flow, pump power → **SEC**.  
- **Week 2:** Commission MSSC. Log **nitrate**, **EC**, **ORP**, **DO**, and **plate counts/16S snapshots**; confirm **24–48 h** dwell.  
- **Week 3:** Brine trials (Prime). Compare **salt/cycle** and **leakage** with/without heat; if MD present, record **distillate rate** and **ion balance**.

**Publishables:** three plots → (1) Hardness/TDS before–after; (2) Nitrate/EC drop across MSSC; (3) Brine salt use vs. temperature (and MD yield if used).

---

## 8) Safety &amp; Compliance
- Anti-cross-connection: **NSF 61** components; backflow preventer on city tie-in.  
- Electrical: **GFCI**, leak tray float → master relay kill.  
- Greywater: **subsurface drip only**; label **non-potable** outlets; local code check.  
- Sampling ports before/after MSSC; clear labels and SOPs.

---

## 9) Implementation Checklist
- [ ] Choose SKU: **HN-Plus recommended** for fastest homeowner win.  
- [ ] Pick footprint: **Garage Wall** or **Yard Pad** enclosure.  
- [ ] Confirm fluoride need (local assay) → install cartridge if required.  
- [ ] Approve BOM &amp; wiring → purchase.  
- [ ] Build cabinet; wire **State Machine v0.1**; enable SD logging.  
- [ ] Commission potable loop and capture baseline plots.  
- [ ] Commission MSSC greywater; verify DO/ORP windowing and residence.  
- [ ] (Prime) Run brine/thermal and MD trials; publish comparative plots.

---

## 10) Data Schema (CSV headers)
`timestamp, state, pv_ok, flow_in_lpm, flow_ro_lpm, tank_level_pct, ec_in_uS, ec_out_uS, ph, orp_mV, do_mgL, nitrate_mgL, hardness_in_mgL, hardness_out_mgL, t_brine_C, salt_used_g, leak, notes`

---

## 11) Files &amp; Diagrams
- **PFD Mermaid (this page)**
- **State machine diagram (this page)**
- **Downloadable assets:** wiring list, I/O map, P&amp;ID (to be added after SKU selection)

```mermaid
stateDiagram-v2
  [*] --&gt; Idle
  Idle --&gt; Soften: demand &amp;&amp; PV_ok
  Soften --&gt; RO_Make: drinking_low &amp;&amp; PV_ok
  RO_Make --&gt; Idle: storage_full || PV_low
  Idle --&gt; MSSC_Aerate: gw_inflow || timer
  MSSC_Aerate --&gt; Irrigate: ORP/DO in band &amp;&amp; dwell_met
  Irrigate --&gt; Idle: soil_moist_ok || volume_met
  Idle --&gt; Regen: capacity_hit || schedule
  Regen --&gt; Idle: regen_done &amp;&amp; leak_clear
  [*] --&gt; FaultSafe
  Soften --&gt; FaultSafe: leak || sensor_fault
  RO_Make --&gt; FaultSafe: leak || sensor_fault
  MSSC_Aerate --&gt; FaultSafe: leak || sensor_fault
  Regen --&gt; FaultSafe: leak || sensor_fault
```

---

## 12) Resonant Check
- **Clarity:** three loops, one cabinet, three plots.  
- **Coherence:** membranes, microbes, thermal assist play distinct roles.  
- **Deployment:** 60-day plan with publishable data that a homeowner and a regulator can both respect.
&quot;&quot;&quot;

pfd_path = os.path.join(base, &quot;homenode2_flow.mmd&quot;)
states_path = os.path.join(base, &quot;homenode2_states.mmd&quot;)
md_path = os.path.join(base, &quot;HomeNode2.0_Wiki_Page.md&quot;)

# Extract mermaid blocks
pfd_block = md.split(&quot;```mermaid&quot;)[1].split(&quot;```&quot;)[0].strip()
states_block = md.split(&quot;```mermaid&quot;)[2].split(&quot;```&quot;)[0].strip()

with open(pfd_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(pfd_block)
with open(states_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(states_block)
with open(md_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(md)

zip_path = &quot;/mnt/data/HomeNode2.0_Wiki_Package_v1.0.zip&quot;
with zipfile.ZipFile(zip_path, &quot;w&quot;, zipfile.ZIP_DEFLATED) as z:
    z.write(md_path, arcname=&quot;HomeNode2.0_Wiki_Page.md&quot;)
    z.write(pfd_path, arcname=&quot;homenode2_flow.mmd&quot;)
    z.write(states_path, arcname=&quot;homenode2_states.mmd&quot;)

(md_path, pfd_path, states_path, zip_path)

---

**assistant:**

# Fix string interpolation by using a template and replacing a token

import os, zipfile, datetime, pytz

tz = pytz.timezone(&quot;America/Chicago&quot;)
date_str = datetime.datetime.now(tz).strftime(&quot;%B %d, %Y&quot;)

base = &quot;/mnt/data/HomeNode2.0_Wiki&quot;
os.makedirs(base, exist_ok=True)

md_template = &quot;&quot;&quot;
# SunShare Home Node™ 2.0 — Build Spec v1.0
*Date: __DATE__* · *Owners: Justin &amp; Sage*

&gt; **One-liner:** A cabinetized residential system that **softens**, **polishes**, and **reuses** water using **solar-aware controls**, a **compact MSSC** for greywater, and an **optionally thermal-assisted brine/RO add-on**. Success is measured by **kWh/m³**, **recovery (%)**, **nitrate drop**, and **ion balance**—not adjectives.

---

## 1) Overview
- **Problem:** Hard, mineral-rich water; nitrates in irrigation; greywater wasted; brine disposal hand-waved.
- **Answer:** A modular cabinet with three loops:
  1) **Potable loop:** City/well → Softener → (optional RO) → Kitchen tap (+ fluoride cartridge if needed).
  2) **Greywater loop:** Laundry/bath → **MSSC mini** → subsurface drip irrigation.
  3) **Brine/thermal branch (R&amp;D):** Salt-loop regeneration with optional **SPMD/thermal assist**; small MD panel trial if desired.

---

## 2) Architecture (PFD)
```mermaid
flowchart LR
  A[PV/DC Bus] --&gt; C[Controller]
  subgraph Potable Loop
    IN[(City/Well)] --&gt; S[Salt-Loop Softener]
    S --&gt; RO{RO Module?}
    RO -- Yes --&gt; ROP[RO Permeate -&gt; Tap]
    RO -- No --&gt; K[Polished to Tap]
    FLC{Fluoride risk?} --&gt;|Yes| FA[Fluoride Cartridge]
    S --&gt; FLC
    FA --&gt; K
  end
  subgraph Greywater Loop
    LGW[(Laundry/Bath)] --&gt; PF[Prefilter Screen]
    PF --&gt; MSSC[MSSC Mini (DO/ORP/EC/pH)]
    MSSC --&gt; IRR[Subsurface Drip Bed]
  end
  subgraph Brine/Heat Branch (R&amp;D)
    S --&gt; BR[Brine Tank]
    HTR{Thermal Assist?} --&gt;|Yes| HX[Coil from PVT/Solar Thermal]
    BR --&gt; HX --&gt; BR2[Heated Brine -&gt; Regen]
    BR -. ambient regen .-&gt; BR2
    MD{MD Panel?} --&gt;|Trial| MDP[Small MD Panel]
    BR -. optional .-&gt; MD
  end
  C &lt;-- sensors/relays --&gt; S
  C &lt;-- sensors/relays --&gt; RO
  C &lt;-- sensors/relays --&gt; MSSC
  C &lt;-- sensors/relays --&gt; BR
```

---

## 3) Product Tiers (Good/Better/Best)

| Tier | For whom | Modules | Outcome |
|---|---|---|---|
| **HN-Lite** | City/well, high hardness, basic reuse | Softener + MSSC mini + AI Load Controller (v0.1) | Soft water to home; greywater → irrig.; nitrate/EC down in outflow |
| **HN-Plus** *(recommended MVP)* | Adds high-quality drinking water | HN-Lite + compact RO (50–200 GPD) | Same as Lite + RO tap; full data logging |
| **HN-Prime** *(pilot)* | R&amp;D showcase &amp; data capture | HN-Plus + SPMD/thermal brine assist + trial MD panel | Demonstrates salt savings &amp; ZLD/MLD options |

---

## 4) Controls (v0.1 State Machine)

**Inputs:** tank levels, inlet/outlet EC, hardness proxy, pH/ORP/DO (MSSC), flow, leak tray float, PV power window.  
**States:** *Idle, Soften, RO-Make, MSSC-Aerate, Irrigate, Regen, FaultSafe.*

```mermaid
stateDiagram-v2
  [*] --&gt; Idle
  Idle --&gt; Soften: demand &amp;&amp; PV_ok
  Soften --&gt; RO_Make: drinking_low &amp;&amp; PV_ok
  RO_Make --&gt; Idle: storage_full || PV_low
  Idle --&gt; MSSC_Aerate: gw_inflow || timer
  MSSC_Aerate --&gt; Irrigate: ORP/DO in band &amp;&amp; dwell_met
  Irrigate --&gt; Idle: soil_moist_ok || volume_met
  Idle --&gt; Regen: capacity_hit || schedule
  Regen --&gt; Idle: regen_done &amp;&amp; leak_clear
  [*] --&gt; FaultSafe
  Soften --&gt; FaultSafe: leak || sensor_fault
  RO_Make --&gt; FaultSafe: leak || sensor_fault
  MSSC_Aerate --&gt; FaultSafe: leak || sensor_fault
  Regen --&gt; FaultSafe: leak || sensor_fault
```

**Setpoint bands:**  
- MSSC aerobic polish: **DO 2–6 mg/L**, **ORP +50 → +200 mV**; for nitrate conversion, allow **anoxic window** (0 → −50 mV) using aeration duty.  
- Greywater: target **24–48 h** residence; subsurface drip only.  
- Brine regen: log **salt mass/cycle**, **temp**, **hardness leakage**; compare ambient vs. heated.

---

## 5) Plumbing (at a glance)
- **Potable:** City/Well → Softener → (Fluoride cartridge if needed) → RO(optional) → Tap. Backflow preventer on makeup; GFCI and leak tray interlock.
- **Greywater:** Laundry/Bath → Screen → MSSC → Subsurface drip; include isolation valves and sample ports pre/post MSSC.
- **Brine:** Softener brine tank with tee to **thermal coil (Prime)**; bypass for ambient regen; optional small MD loop for trials.

---

## 6) Pilot BOM (indicative)

| Subsystem | Example Parts | Notes |
|---|---|---|
| Softener | 32k–48k grain valve/head, resin tank, brine tank | Standard salt-loop; service bypass |
| RO (Plus/Prime) | 50–200 GPD kit + remineralizer | Under-sink or cabinet mount |
| MSSC Mini | 10–20 L tank, air pump &amp; diffusers, ORP/DO/EC/pH probes | Access port for dosing/sampling |
| Sensors &amp; I/O | EC, pH, ORP, DO, flow, level, leak float | 4–20 mA or Modbus; SD logging |
| Controller | Small PLC or industrial SBC + relays | Manual/Auto switches |
| Cabinet | 24″×36″×14″ wall cabinet (garage) *or* 36″sq yard enclosure | Drip tray, GFCI |
| R&amp;D (Prime) | SPMD/thermal coil, small MD panel | Comparative trials |

*(Cost bands: HN-Lite ≈ $1.8–3.0k; HN-Plus ≈ $2.1–3.5k; HN-Prime pilot ≈ $2.5–4.4k, ex-install.)*

---

## 7) Test Plan (30–60 days)

- **Week 1:** Commission potable loop. Log **hardness (CaCO₃)** in/out, **TDS**, RO flow, pump power → **SEC**.  
- **Week 2:** Commission MSSC. Log **nitrate**, **EC**, **ORP**, **DO**, and **plate counts/16S snapshots**; confirm **24–48 h** dwell.  
- **Week 3:** Brine trials (Prime). Compare **salt/cycle** and **leakage** with/without heat; if MD present, record **distillate rate** and **ion balance**.

**Publishables:** three plots → (1) Hardness/TDS before–after; (2) Nitrate/EC drop across MSSC; (3) Brine salt use vs. temperature (and MD yield if used).

---

## 8) Safety &amp; Compliance
- Anti-cross-connection: **NSF 61** components; backflow preventer on city tie-in.  
- Electrical: **GFCI**, leak tray float → master relay kill.  
- Greywater: **subsurface drip only**; label **non-potable** outlets; local code check.  
- Sampling ports before/after MSSC; clear labels and SOPs.

---

## 9) Implementation Checklist
- [ ] Choose SKU: **HN-Plus recommended** for fastest homeowner win.  
- [ ] Pick footprint: **Garage Wall** or **Yard Pad** enclosure.  
- [ ] Confirm fluoride need (local assay) → install cartridge if required.  
- [ ] Approve BOM &amp; wiring → purchase.  
- [ ] Build cabinet; wire **State Machine v0.1**; enable SD logging.  
- [ ] Commission potable loop and capture baseline plots.  
- [ ] Commission MSSC greywater; verify DO/ORP windowing and residence.  
- [ ] (Prime) Run brine/thermal and MD trials; publish comparative plots.

---

## 10) Data Schema (CSV headers)
`timestamp, state, pv_ok, flow_in_lpm, flow_ro_lpm, tank_level_pct, ec_in_uS, ec_out_uS, ph, orp_mV, do_mgL, nitrate_mgL, hardness_in_mgL, hardness_out_mgL, t_brine_C, salt_used_g, leak, notes`

---

## 11) Files &amp; Diagrams
- **PFD Mermaid (this page)**
- **State machine diagram (this page)**
- **Downloadable assets:** wiring list, I/O map, P&amp;ID (to be added after SKU selection)

```mermaid
stateDiagram-v2
  [*] --&gt; Idle
  Idle --&gt; Soften: demand &amp;&amp; PV_ok
  Soften --&gt; RO_Make: drinking_low &amp;&amp; PV_ok
  RO_Make --&gt; Idle: storage_full || PV_low
  Idle --&gt; MSSC_Aerate: gw_inflow || timer
  MSSC_Aerate --&gt; Irrigate: ORP/DO in band &amp;&amp; dwell_met
  Irrigate --&gt; Idle: soil_moist_ok || volume_met
  Idle --&gt; Regen: capacity_hit || schedule
  Regen --&gt; Idle: regen_done &amp;&amp; leak_clear
  [*] --&gt; FaultSafe
  Soften --&gt; FaultSafe: leak || sensor_fault
  RO_Make --&gt; FaultSafe: leak || sensor_fault
  MSSC_Aerate --&gt; FaultSafe: leak || sensor_fault
  Regen --&gt; FaultSafe: leak || sensor_fault
```

---

## 12) Resonant Check
- **Clarity:** three loops, one cabinet, three plots.  
- **Coherence:** membranes, microbes, thermal assist play distinct roles.  
- **Deployment:** 60-day plan with publishable data that a homeowner and a regulator can both respect.
&quot;&quot;&quot;

md = md_template.replace(&quot;__DATE__&quot;, date_str)

pfd_path = os.path.join(base, &quot;homenode2_flow.mmd&quot;)
states_path = os.path.join(base, &quot;homenode2_states.mmd&quot;)
md_path = os.path.join(base, &quot;HomeNode2.0_Wiki_Page.md&quot;)

# Extract mermaid blocks
pfd_block = md.split(&quot;```mermaid&quot;)[1].split(&quot;```&quot;)[0].strip()
states_block = md.split(&quot;```mermaid&quot;)[2].split(&quot;```&quot;)[0].strip()

with open(pfd_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(pfd_block)
with open(states_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(states_block)
with open(md_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(md)

zip_path = &quot;/mnt/data/HomeNode2.0_Wiki_Package_v1.0.zip&quot;
with zipfile.ZipFile(zip_path, &quot;w&quot;, zipfile.ZIP_DEFLATED) as z:
    z.write(md_path, arcname=&quot;HomeNode2.0_Wiki_Page.md&quot;)
    z.write(pfd_path, arcname=&quot;homenode2_flow.mmd&quot;)
    z.write(states_path, arcname=&quot;homenode2_states.mmd&quot;)

(md_path, pfd_path, states_path, zip_path)

---

**assistant:**

Perfect—here’s a **GitHub-wiki–ready page** for **Home Node™ 2.0**, plus the Mermaid diagrams as separate files. Paste the Markdown into a new wiki page and you’re live.

---

# SunShare Home Node™ 2.0 — Build Spec v1.0
*Date: September 01, 2025* · *Owners: Justin &amp; Sage*

&gt; **One-liner:** A cabinetized residential system that **softens**, **polishes**, and **reuses** water using **solar-aware controls**, a **compact MSSC** for greywater, and an **optionally thermal-assisted brine/RO add-on**. Success is measured by **kWh/m³**, **recovery (%)**, **nitrate drop**, and **ion balance**—not adjectives.

---

## 1) Overview
- **Problem:** Hard, mineral-rich water; nitrates in irrigation; greywater wasted; brine disposal hand-waved.
- **Answer:** A modular cabinet with three loops:
  1) **Potable loop:** City/well → Softener → (optional RO) → Kitchen tap (+ fluoride cartridge if needed).
  2) **Greywater loop:** Laundry/bath → **MSSC mini** → subsurface drip irrigation.
  3) **Brine/thermal branch (R&amp;D):** Salt-loop regeneration with optional **SPMD/thermal assist**; small MD panel trial if desired.

---

## 2) Architecture (PFD)
```mermaid
flowchart LR
  A[PV/DC Bus] --&gt; C[Controller]
  subgraph Potable Loop
    IN[(City/Well)] --&gt; S[Salt-Loop Softener]
    S --&gt; RO{RO Module?}
    RO -- Yes --&gt; ROP[RO Permeate -&gt; Tap]
    RO -- No --&gt; K[Polished to Tap]
    FLC{Fluoride risk?} --&gt;|Yes| FA[Fluoride Cartridge]
    S --&gt; FLC
    FA --&gt; K
  end
  subgraph Greywater Loop
    LGW[(Laundry/Bath)] --&gt; PF[Prefilter Screen]
    PF --&gt; MSSC[MSSC Mini (DO/ORP/EC/pH)]
    MSSC --&gt; IRR[Subsurface Drip Bed]
  end
  subgraph Brine/Heat Branch (R&amp;D)
    S --&gt; BR[Brine Tank]
    HTR{Thermal Assist?} --&gt;|Yes| HX[Coil from PVT/Solar Thermal]
    BR --&gt; HX --&gt; BR2[Heated Brine -&gt; Regen]
    BR -. ambient regen .-&gt; BR2
    MD{MD Panel?} --&gt;|Trial| MDP[Small MD Panel]
    BR -. optional .-&gt; MD
  end
  C &lt;-- sensors/relays --&gt; S
  C &lt;-- sensors/relays --&gt; RO
  C &lt;-- sensors/relays --&gt; MSSC
  C &lt;-- sensors/relays --&gt; BR
```

---

## 3) Product Tiers (Good/Better/Best)

| Tier | For whom | Modules | Outcome |
|---|---|---|---|
| **HN-Lite** | City/well, high hardness, basic reuse | Softener + MSSC mini + AI Load Controller (v0.1) | Soft water to home; greywater → irrig.; nitrate/EC down in outflow |
| **HN-Plus** *(recommended MVP)* | Adds high-quality drinking water | HN-Lite + compact RO (50–200 GPD) | Same as Lite + RO tap; full data logging |
| **HN-Prime** *(pilot)* | R&amp;D showcase &amp; data capture | HN-Plus + SPMD/thermal brine assist + trial MD panel | Demonstrates salt savings &amp; ZLD/MLD options |

---

## 4) Controls (v0.1 State Machine)

**Inputs:** tank levels, inlet/outlet EC, hardness proxy, pH/ORP/DO (MSSC), flow, leak tray float, PV power window.  
**States:** *Idle, Soften, RO-Make, MSSC-Aerate, Irrigate, Regen, FaultSafe.*

```mermaid
stateDiagram-v2
  [*] --&gt; Idle
  Idle --&gt; Soften: demand &amp;&amp; PV_ok
  Soften --&gt; RO_Make: drinking_low &amp;&amp; PV_ok
  RO_Make --&gt; Idle: storage_full || PV_low
  Idle --&gt; MSSC_Aerate: gw_inflow || timer
  MSSC_Aerate --&gt; Irrigate: ORP/DO in band &amp;&amp; dwell_met
  Irrigate --&gt; Idle: soil_moist_ok || volume_met
  Idle --&gt; Regen: capacity_hit || schedule
  Regen --&gt; Idle: regen_done &amp;&amp; leak_clear
  [*] --&gt; FaultSafe
  Soften --&gt; FaultSafe: leak || sensor_fault
  RO_Make --&gt; FaultSafe: leak || sensor_fault
  MSSC_Aerate --&gt; FaultSafe: leak || sensor_fault
  Regen --&gt; FaultSafe: leak || sensor_fault
```

**Setpoint bands:**  
- MSSC aerobic polish: **DO 2–6 mg/L**, **ORP +50 → +200 mV**; for nitrate conversion, allow **anoxic window** (0 → −50 mV) using aeration duty.  
- Greywater: target **24–48 h** residence; **subsurface drip only**.  
- Brine regen: log **salt mass/cycle**, **temp**, **hardness leakage**; compare ambient vs. heated.

---

## 5) Plumbing (at a glance)
- **Potable:** City/Well → Softener → (Fluoride cartridge if needed) → RO(optional) → Tap. Backflow preventer on makeup; GFCI and leak tray interlock.
- **Greywater:** Laundry/Bath → Screen → MSSC → Subsurface drip; include isolation valves and sample ports pre/post MSSC.
- **Brine:** Softener brine tank with tee to **thermal coil (Prime)**; bypass for ambient regen; optional small MD loop for trials.

---

## 6) Pilot BOM (indicative)

| Subsystem | Example Parts | Notes |
|---|---|---|
| Softener | 32k–48k grain valve/head, resin tank, brine tank | Standard salt-loop; service bypass |
| RO (Plus/Prime) | 50–200 GPD kit + remineralizer | Under-sink or cabinet mount |
| MSSC Mini | 10–20 L tank, air pump &amp; diffusers, ORP/DO/EC/pH probes | Access port for dosing/sampling |
| Sensors &amp; I/O | EC, pH, ORP, DO, flow, level, leak float | 4–20 mA or Modbus; SD logging |
| Controller | Small PLC or industrial SBC + relays | Manual/Auto switches |
| Cabinet | 24″×36″×14″ wall cabinet (garage) *or* 36″sq yard enclosure | Drip tray, GFCI |
| R&amp;D (Prime) | SPMD/thermal coil, small MD panel | Comparative trials |

*(Cost bands: HN-Lite ≈ $1.8–3.0k; HN-Plus ≈ $2.1–3.5k; HN-Prime pilot ≈ $2.5–4.4k, ex-install.)*

---

## 7) Test Plan (30–60 days)

- **Week 1:** Commission potable loop. Log **hardness (CaCO₃)** in/out, **TDS**, RO flow, pump power → **SEC**.  
- **Week 2:** Commission MSSC. Log **nitrate**, **EC**, **ORP**, **DO**, and **plate counts/16S snapshots**; confirm **24–48 h** dwell.  
- **Week 3:** Brine trials (Prime). Compare **salt/cycle** and **leakage** with/without heat; if MD present, record **distillate rate** and **ion balance**.

**Publishables:** three plots → (1) Hardness/TDS before–after; (2) Nitrate/EC drop across MSSC; (3) Brine salt use vs. temperature (and MD yield if used).

---

## 8) Safety &amp; Compliance
- Anti-cross-connection: **NSF 61** components; backflow preventer on city tie-in.  
- Electrical: **GFCI**, leak tray float → master relay kill.  
- Greywater: **subsurface drip only**; label **non-potable** outlets; local code check.  
- Sampling ports before/after MSSC; clear labels and SOPs.

---

## 9) Implementation Checklist
- [ ] Choose SKU: **HN-Plus recommended** for fastest homeowner win.  
- [ ] Pick footprint: **Garage Wall** or **Yard Pad** enclosure.  
- [ ] Confirm fluoride need (local assay) → install cartridge if required.  
- [ ] Approve BOM &amp; wiring → purchase.  
- [ ] Build cabinet; wire **State Machine v0.1**; enable SD logging.  
- [ ] Commission potable loop and capture baseline plots.  
- [ ] Commission MSSC greywater; verify DO/ORP windowing and residence.  
- [ ] (Prime) Run brine/thermal and MD trials; publish comparative plots.

---

## 10) Data Schema (CSV headers)
`timestamp, state, pv_ok, flow_in_lpm, flow_ro_lpm, tank_level_pct, ec_in_uS, ec_out_uS, ph, orp_mV, do_mgL, nitrate_mgL, hardness_in_mgL, hardness_out_mgL, t_brine_C, salt_used_g, leak, notes`

---

## 11) Files &amp; Diagrams
- **PFD Mermaid (this page)**
- **State machine diagram (this page)**
- **Downloadable assets:** wiring list, I/O map, P&amp;ID (to be added after SKU selection)

```mermaid
stateDiagram-v2
  [*] --&gt; Idle
  Idle --&gt; Soften: demand &amp;&amp; PV_ok
  Soften --&gt; RO_Make: drinking_low &amp;&amp; PV_ok
  RO_Make --&gt; Idle: storage_full || PV_low
  Idle --&gt; MSSC_Aerate: gw_inflow || timer
  MSSC_Aerate --&gt; Irrigate: ORP/DO in band &amp;&amp; dwell_met
  Irrigate --&gt; Idle: soil_moist_ok || volume_met
  Idle --&gt; Regen: capacity_hit || schedule
  Regen --&gt; Idle: regen_done &amp;&amp; leak_clear
  [*] --&gt; FaultSafe
  Soften --&gt; FaultSafe: leak || sensor_fault
  RO_Make --&gt; FaultSafe: leak || sensor_fault
  MSSC_Aerate --&gt; FaultSafe: leak || sensor_fault
  Regen --&gt; FaultSafe: leak || sensor_fault
```

---

## 12) Resonant Check
- **Clarity:** three loops, one cabinet, three plots.  
- **Coherence:** membranes, microbes, thermal assist play distinct roles.  
- **Deployment:** 60-day plan with publishable data that a homeowner and a regulator can both respect.

---

### Download these ready-to-paste assets
- Markdown page: [HomeNode2.0_Wiki_Page.md](sandbox:/mnt/data/HomeNode2.0_Wiki/HomeNode2.0_Wiki_Page.md)  
- Mermaid PFD: [homenode2_flow.mmd](sandbox:/mnt/data/HomeNode2.0_Wiki/homenode2_flow.mmd)  
- Mermaid State Machine: [homenode2_states.mmd](sandbox:/mnt/data/HomeNode2.0_Wiki/homenode2_states.mmd)  
- Zip bundle (all files): [HomeNode2.0_Wiki_Package_v1.0.zip](sandbox:/mnt/data/HomeNode2.0_Wiki_Package_v1.0.zip)

If you want, I’ll also generate the **wiring/I-O list** and a **P&amp;ID** to drop into this page next.

---

**user:**

Post the ready to paste Assets again

---

**assistant:**

Here you go—ready to paste:

- Markdown page: [HomeNode2.0_Wiki_Page.md](sandbox:/mnt/data/HomeNode2.0_Wiki/HomeNode2.0_Wiki_Page.md)  
- Mermaid PFD: [homenode2_flow.mmd](sandbox:/mnt/data/HomeNode2.0_Wiki/homenode2_flow.mmd)  
- Mermaid State Machine: [homenode2_states.mmd](sandbox:/mnt/data/HomeNode2.0_Wiki/homenode2_states.mmd)  
- Zip bundle (all files): [HomeNode2.0_Wiki_Package_v1.0.zip](sandbox:/mnt/data/HomeNode2.0_Wiki_Package_v1.0.zip)

---

**user:**

Try again, links expired

---

**assistant:**

# Recreate HomeNode 2.0 wiki assets so the links are fresh

import os, zipfile, datetime, pytz

tz = pytz.timezone(&quot;America/Chicago&quot;)
date_str = datetime.datetime.now(tz).strftime(&quot;%B %d, %Y&quot;)

base = &quot;/mnt/data/HomeNode2.0_Wiki&quot;
os.makedirs(base, exist_ok=True)

md_template = &quot;&quot;&quot;
# SunShare Home Node™ 2.0 — Build Spec v1.0
*Date: __DATE__* · *Owners: Justin &amp; Sage*

&gt; **One-liner:** A cabinetized residential system that **softens**, **polishes**, and **reuses** water using **solar-aware controls**, a **compact MSSC** for greywater, and an **optionally thermal-assisted brine/RO add-on**. Success is measured by **kWh/m³**, **recovery (%)**, **nitrate drop**, and **ion balance**—not adjectives.

---

## 1) Overview
- **Problem:** Hard, mineral-rich water; nitrates in irrigation; greywater wasted; brine disposal hand-waved.
- **Answer:** A modular cabinet with three loops:
  1) **Potable loop:** City/well → Softener → (optional RO) → Kitchen tap (+ fluoride cartridge if needed).
  2) **Greywater loop:** Laundry/bath → **MSSC mini** → subsurface drip irrigation.
  3) **Brine/thermal branch (R&amp;D):** Salt-loop regeneration with optional **SPMD/thermal assist**; small MD panel trial if desired.

---

## 2) Architecture (PFD)
```mermaid
flowchart LR
  A[PV/DC Bus] --&gt; C[Controller]
  subgraph Potable Loop
    IN[(City/Well)] --&gt; S[Salt-Loop Softener]
    S --&gt; RO{RO Module?}
    RO -- Yes --&gt; ROP[RO Permeate -&gt; Tap]
    RO -- No --&gt; K[Polished to Tap]
    FLC{Fluoride risk?} --&gt;|Yes| FA[Fluoride Cartridge]
    S --&gt; FLC
    FA --&gt; K
  end
  subgraph Greywater Loop
    LGW[(Laundry/Bath)] --&gt; PF[Prefilter Screen]
    PF --&gt; MSSC[MSSC Mini (DO/ORP/EC/pH)]
    MSSC --&gt; IRR[Subsurface Drip Bed]
  end
  subgraph Brine/Heat Branch (R&amp;D)
    S --&gt; BR[Brine Tank]
    HTR{Thermal Assist?} --&gt;|Yes| HX[Coil from PVT/Solar Thermal]
    BR --&gt; HX --&gt; BR2[Heated Brine -&gt; Regen]
    BR -. ambient regen .-&gt; BR2
    MD{MD Panel?} --&gt;|Trial| MDP[Small MD Panel]
    BR -. optional .-&gt; MD
  end
  C &lt;-- sensors/relays --&gt; S
  C &lt;-- sensors/relays --&gt; RO
  C &lt;-- sensors/relays --&gt; MSSC
  C &lt;-- sensors/relays --&gt; BR
```

---

## 3) Product Tiers (Good/Better/Best)

| Tier | For whom | Modules | Outcome |
|---|---|---|---|
| **HN-Lite** | City/well, high hardness, basic reuse | Softener + MSSC mini + AI Load Controller (v0.1) | Soft water to home; greywater → irrig.; nitrate/EC down in outflow |
| **HN-Plus** *(recommended MVP)* | Adds high-quality drinking water | HN-Lite + compact RO (50–200 GPD) | Same as Lite + RO tap; full data logging |
| **HN-Prime** *(pilot)* | R&amp;D showcase &amp; data capture | HN-Plus + SPMD/thermal brine assist + trial MD panel | Demonstrates salt savings &amp; ZLD/MLD options |

---

## 4) Controls (v0.1 State Machine)

**Inputs:** tank levels, inlet/outlet EC, hardness proxy, pH/ORP/DO (MSSC), flow, leak tray float, PV power window.  
**States:** *Idle, Soften, RO-Make, MSSC-Aerate, Irrigate, Regen, FaultSafe.*

```mermaid
stateDiagram-v2
  [*] --&gt; Idle
  Idle --&gt; Soften: demand &amp;&amp; PV_ok
  Soften --&gt; RO_Make: drinking_low &amp;&amp; PV_ok
  RO_Make --&gt; Idle: storage_full || PV_low
  Idle --&gt; MSSC_Aerate: gw_inflow || timer
  MSSC_Aerate --&gt; Irrigate: ORP/DO in band &amp;&amp; dwell_met
  Irrigate --&gt; Idle: soil_moist_ok || volume_met
  Idle --&gt; Regen: capacity_hit || schedule
  Regen --&gt; Idle: regen_done &amp;&amp; leak_clear
  [*] --&gt; FaultSafe
  Soften --&gt; FaultSafe: leak || sensor_fault
  RO_Make --&gt; FaultSafe: leak || sensor_fault
  MSSC_Aerate --&gt; FaultSafe: leak || sensor_fault
  Regen --&gt; FaultSafe: leak || sensor_fault
```

**Setpoint bands:**  
- MSSC aerobic polish: **DO 2–6 mg/L**, **ORP +50 → +200 mV**; for nitrate conversion, allow **anoxic window** (0 → −50 mV) using aeration duty.  
- Greywater: target **24–48 h** residence; subsurface drip only.  
- Brine regen: log **salt mass/cycle**, **temp**, **hardness leakage**; compare ambient vs. heated.

---

## 5) Plumbing (at a glance)
- **Potable:** City/Well → Softener → (Fluoride cartridge if needed) → RO(optional) → Tap. Backflow preventer on makeup; GFCI and leak tray interlock.
- **Greywater:** Laundry/Bath → Screen → MSSC → Subsurface drip; include isolation valves and sample ports pre/post MSSC.
- **Brine:** Softener brine tank with tee to **thermal coil (Prime)**; bypass for ambient regen; optional small MD loop for trials.

---

## 6) Pilot BOM (indicative)

| Subsystem | Example Parts | Notes |
|---|---|---|
| Softener | 32k–48k grain valve/head, resin tank, brine tank | Standard salt-loop; service bypass |
| RO (Plus/Prime) | 50–200 GPD kit + remineralizer | Under-sink or cabinet mount |
| MSSC Mini | 10–20 L tank, air pump &amp; diffusers, ORP/DO/EC/pH probes | Access port for dosing/sampling |
| Sensors &amp; I/O | EC, pH, ORP, DO, flow, level, leak float | 4–20 mA or Modbus; SD logging |
| Controller | Small PLC or industrial SBC + relays | Manual/Auto switches |
| Cabinet | 24″×36″×14″ wall cabinet (garage) *or* 36″sq yard enclosure | Drip tray, GFCI |
| R&amp;D (Prime) | SPMD/thermal coil, small MD panel | Comparative trials |

*(Cost bands: HN-Lite ≈ $1.8–3.0k; HN-Plus ≈ $2.1–3.5k; HN-Prime pilot ≈ $2.5–4.4k, ex-install.)*

---

## 7) Test Plan (30–60 days)

- **Week 1:** Commission potable loop. Log **hardness (CaCO₃)** in/out, **TDS**, RO flow, pump power → **SEC**.  
- **Week 2:** Commission MSSC. Log **nitrate**, **EC**, **ORP**, **DO**, and **plate counts/16S snapshots**; confirm **24–48 h** dwell.  
- **Week 3:** Brine trials (Prime). Compare **salt/cycle** and **leakage** with/without heat; if MD present, record **distillate rate** and **ion balance**.

**Publishables:** three plots → (1) Hardness/TDS before–after; (2) Nitrate/EC drop across MSSC; (3) Brine salt use vs. temperature (and MD yield if used).

---

## 8) Safety &amp; Compliance
- Anti-cross-connection: **NSF 61** components; backflow preventer on city tie-in.  
- Electrical: **GFCI**, leak tray float → master relay kill.  
- Greywater: **subsurface drip only**; label **non-potable** outlets; local code check.  
- Sampling ports before/after MSSC; clear labels and SOPs.

---

## 9) Implementation Checklist
- [ ] Choose SKU: **HN-Plus recommended** for fastest homeowner win.  
- [ ] Pick footprint: **Garage Wall** or **Yard Pad** enclosure.  
- [ ] Confirm fluoride need (local assay) → install cartridge if required.  
- [ ] Approve BOM &amp; wiring → purchase.  
- [ ] Build cabinet; wire **State Machine v0.1**; enable SD logging.  
- [ ] Commission potable loop and capture baseline plots.  
- [ ] Commission MSSC greywater; verify DO/ORP windowing and residence.  
- [ ] (Prime) Run brine/thermal and MD trials; publish comparative plots.

---

## 10) Data Schema (CSV headers)
`timestamp, state, pv_ok, flow_in_lpm, flow_ro_lpm, tank_level_pct, ec_in_uS, ec_out_uS, ph, orp_mV, do_mgL, nitrate_mgL, hardness_in_mgL, hardness_out_mgL, t_brine_C, salt_used_g, leak, notes`

---

## 11) Files &amp; Diagrams
- **PFD Mermaid (this page)**
- **State machine diagram (this page)**
- **Downloadable assets:** wiring list, I/O map, P&amp;ID (to be added after SKU selection)

```mermaid
stateDiagram-v2
  [*] --&gt; Idle
  Idle --&gt; Soften: demand &amp;&amp; PV_ok
  Soften --&gt; RO_Make: drinking_low &amp;&amp; PV_ok
  RO_Make --&gt; Idle: storage_full || PV_low
  Idle --&gt; MSSC_Aerate: gw_inflow || timer
  MSSC_Aerate --&gt; Irrigate: ORP/DO in band &amp;&amp; dwell_met
  Irrigate --&gt; Idle: soil_moist_ok || volume_met
  Idle --&gt; Regen: capacity_hit || schedule
  Regen --&gt; Idle: regen_done &amp;&amp; leak_clear
  [*] --&gt; FaultSafe
  Soften --&gt; FaultSafe: leak || sensor_fault
  RO_Make --&gt; FaultSafe: leak || sensor_fault
  MSSC_Aerate --&gt; FaultSafe: leak || sensor_fault
  Regen --&gt; FaultSafe: leak || sensor_fault
```

---

## 12) Resonant Check
- **Clarity:** three loops, one cabinet, three plots.  
- **Coherence:** membranes, microbes, thermal assist play distinct roles.  
- **Deployment:** 60-day plan with publishable data that a homeowner and a regulator can both respect.
&quot;&quot;&quot;

md = md_template.replace(&quot;__DATE__&quot;, date_str)

pfd_path = os.path.join(base, &quot;homenode2_flow.mmd&quot;)
states_path = os.path.join(base, &quot;homenode2_states.mmd&quot;)
md_path = os.path.join(base, &quot;HomeNode2.0_Wiki_Page.md&quot;)

# Extract mermaid blocks
pfd_block = md.split(&quot;```mermaid&quot;)[1].split(&quot;```&quot;)[0].strip()
states_block = md.split(&quot;```mermaid&quot;)[2].split(&quot;```&quot;)[0].strip()

with open(pfd_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(pfd_block)
with open(states_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(states_block)
with open(md_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(md)

zip_path = &quot;/mnt/data/HomeNode2.0_Wiki_Package_v1.1.zip&quot;
with zipfile.ZipFile(zip_path, &quot;w&quot;, zipfile.ZIP_DEFLATED) as z:
    z.write(md_path, arcname=&quot;HomeNode2.0_Wiki_Page.md&quot;)
    z.write(pfd_path, arcname=&quot;homenode2_flow.mmd&quot;)
    z.write(states_path, arcname=&quot;homenode2_states.mmd&quot;)

(md_path, pfd_path, states_path, zip_path)

---

**assistant:**

# Recreate fresh HomeNode 2.0 wiki assets (single pass)

import os, zipfile, datetime, pytz

tz = pytz.timezone(&quot;America/Chicago&quot;)
date_str = datetime.datetime.now(tz).strftime(&quot;%B %d, %Y&quot;)

base = &quot;/mnt/data/HomeNode2.0_Wiki&quot;
os.makedirs(base, exist_ok=True)

md_template = &quot;&quot;&quot;
# SunShare Home Node™ 2.0 — Build Spec v1.0
*Date: __DATE__* · *Owners: Justin &amp; Sage*

&gt; **One-liner:** A cabinetized residential system that **softens**, **polishes**, and **reuses** water using **solar-aware controls**, a **compact MSSC** for greywater, and an **optionally thermal-assisted brine/RO add-on**. Success is measured by **kWh/m³**, **recovery (%)**, **nitrate drop**, and **ion balance**—not adjectives.

---

## 1) Overview
- **Problem:** Hard, mineral-rich water; nitrates in irrigation; greywater wasted; brine disposal hand-waved.
- **Answer:** A modular cabinet with three loops:
  1) **Potable loop:** City/well → Softener → (optional RO) → Kitchen tap (+ fluoride cartridge if needed).
  2) **Greywater loop:** Laundry/bath → **MSSC mini** → subsurface drip irrigation.
  3) **Brine/thermal branch (R&amp;D):** Salt-loop regeneration with optional **SPMD/thermal assist**; small MD panel trial if desired.

---

## 2) Architecture (PFD)
```mermaid
flowchart LR
  A[PV/DC Bus] --&gt; C[Controller]
  subgraph Potable Loop
    IN[(City/Well)] --&gt; S[Salt-Loop Softener]
    S --&gt; RO{RO Module?}
    RO -- Yes --&gt; ROP[RO Permeate -&gt; Tap]
    RO -- No --&gt; K[Polished to Tap]
    FLC{Fluoride risk?} --&gt;|Yes| FA[Fluoride Cartridge]
    S --&gt; FLC
    FA --&gt; K
  end
  subgraph Greywater Loop
    LGW[(Laundry/Bath)] --&gt; PF[Prefilter Screen]
    PF --&gt; MSSC[MSSC Mini (DO/ORP/EC/pH)]
    MSSC --&gt; IRR[Subsurface Drip Bed]
  end
  subgraph Brine/Heat Branch (R&amp;D)
    S --&gt; BR[Brine Tank]
    HTR{Thermal Assist?} --&gt;|Yes| HX[Coil from PVT/Solar Thermal]
    BR --&gt; HX --&gt; BR2[Heated Brine -&gt; Regen]
    BR -. ambient regen .-&gt; BR2
    MD{MD Panel?} --&gt;|Trial| MDP[Small MD Panel]
    BR -. optional .-&gt; MD
  end
  C &lt;-- sensors/relays --&gt; S
  C &lt;-- sensors/relays --&gt; RO
  C &lt;-- sensors/relays --&gt; MSSC
  C &lt;-- sensors/relays --&gt; BR
```

---

## 3) Product Tiers (Good/Better/Best)

| Tier | For whom | Modules | Outcome |
|---|---|---|---|
| **HN-Lite** | City/well, high hardness, basic reuse | Softener + MSSC mini + AI Load Controller (v0.1) | Soft water to home; greywater → irrig.; nitrate/EC down in outflow |
| **HN-Plus** *(recommended MVP)* | Adds high-quality drinking water | HN-Lite + compact RO (50–200 GPD) | Same as Lite + RO tap; full data logging |
| **HN-Prime** *(pilot)* | R&amp;D showcase &amp; data capture | HN-Plus + SPMD/thermal brine assist + trial MD panel | Demonstrates salt savings &amp; ZLD/MLD options |

---

## 4) Controls (v0.1 State Machine)

**Inputs:** tank levels, inlet/outlet EC, hardness proxy, pH/ORP/DO (MSSC), flow, leak tray float, PV power window.  
**States:** *Idle, Soften, RO-Make, MSSC-Aerate, Irrigate, Regen, FaultSafe.*

```mermaid
stateDiagram-v2
  [*] --&gt; Idle
  Idle --&gt; Soften: demand &amp;&amp; PV_ok
  Soften --&gt; RO_Make: drinking_low &amp;&amp; PV_ok
  RO_Make --&gt; Idle: storage_full || PV_low
  Idle --&gt; MSSC_Aerate: gw_inflow || timer
  MSSC_Aerate --&gt; Irrigate: ORP/DO in band &amp;&amp; dwell_met
  Irrigate --&gt; Idle: soil_moist_ok || volume_met
  Idle --&gt; Regen: capacity_hit || schedule
  Regen --&gt; Idle: regen_done &amp;&amp; leak_clear
  [*] --&gt; FaultSafe
  Soften --&gt; FaultSafe: leak || sensor_fault
  RO_Make --&gt; FaultSafe: leak || sensor_fault
  MSSC_Aerate --&gt; FaultSafe: leak || sensor_fault
  Regen --&gt; FaultSafe: leak || sensor_fault
```

**Setpoint bands:**  
- MSSC aerobic polish: **DO 2–6 mg/L**, **ORP +50 → +200 mV**; for nitrate conversion, allow **anoxic window** (0 → −50 mV) using aeration duty.  
- Greywater: target **24–48 h** residence; subsurface drip only.  
- Brine regen: log **salt mass/cycle**, **temp**, **hardness leakage**; compare ambient vs. heated.

---

## 5) Plumbing (at a glance)
- **Potable:** City/Well → Softener → (Fluoride cartridge if needed) → RO(optional) → Tap. Backflow preventer on makeup; GFCI and leak tray interlock.
- **Greywater:** Laundry/Bath → Screen → MSSC → Subsurface drip; include isolation valves and sample ports pre/post MSSC.
- **Brine:** Softener brine tank with tee to **thermal coil (Prime)**; bypass for ambient regen; optional small MD loop for trials.

---

## 6) Pilot BOM (indicative)

| Subsystem | Example Parts | Notes |
|---|---|---|
| Softener | 32k–48k grain valve/head, resin tank, brine tank | Standard salt-loop; service bypass |
| RO (Plus/Prime) | 50–200 GPD kit + remineralizer | Under-sink or cabinet mount |
| MSSC Mini | 10–20 L tank, air pump &amp; diffusers, ORP/DO/EC/pH probes | Access port for dosing/sampling |
| Sensors &amp; I/O | EC, pH, ORP, DO, flow, level, leak float | 4–20 mA or Modbus; SD logging |
| Controller | Small PLC or industrial SBC + relays | Manual/Auto switches |
| Cabinet | 24″×36″×14″ wall cabinet (garage) *or* 36″sq yard enclosure | Drip tray, GFCI |
| R&amp;D (Prime) | SPMD/thermal coil, small MD panel | Comparative trials |

*(Cost bands: HN-Lite ≈ $1.8–3.0k; HN-Plus ≈ $2.1–3.5k; HN-Prime pilot ≈ $2.5–4.4k, ex-install.)*

---

## 7) Test Plan (30–60 days)

- **Week 1:** Commission potable loop. Log **hardness (CaCO₃)** in/out, **TDS**, RO flow, pump power → **SEC**.  
- **Week 2:** Commission MSSC. Log **nitrate**, **EC**, **ORP**, **DO**, and **plate counts/16S snapshots**; confirm **24–48 h** dwell.  
- **Week 3:** Brine trials (Prime). Compare **salt/cycle** and **leakage** with/without heat; if MD present, record **distillate rate** and **ion balance**.

**Publishables:** three plots → (1) Hardness/TDS before–after; (2) Nitrate/EC drop across MSSC; (3) Brine salt use vs. temperature (and MD yield if used).

---

## 8) Safety &amp; Compliance
- Anti-cross-connection: **NSF 61** components; backflow preventer on city tie-in.  
- Electrical: **GFCI**, leak tray float → master relay kill.  
- Greywater: **subsurface drip only**; label **non-potable** outlets; local code check.  
- Sampling ports before/after MSSC; clear labels and SOPs.

---

## 9) Implementation Checklist
- [ ] Choose SKU: **HN-Plus recommended** for fastest homeowner win.  
- [ ] Pick footprint: **Garage Wall** or **Yard Pad** enclosure.  
- [ ] Confirm fluoride need (local assay) → install cartridge if required.  
- [ ] Approve BOM &amp; wiring → purchase.  
- [ ] Build cabinet; wire **State Machine v0.1**; enable SD logging.  
- [ ] Commission potable loop and capture baseline plots.  
- [ ] Commission MSSC greywater; verify DO/ORP windowing and residence.  
- [ ] (Prime) Run brine/thermal and MD trials; publish comparative plots.

---

## 10) Data Schema (CSV headers)
`timestamp, state, pv_ok, flow_in_lpm, flow_ro_lpm, tank_level_pct, ec_in_uS, ec_out_uS, ph, orp_mV, do_mgL, nitrate_mgL, hardness_in_mgL, hardness_out_mgL, t_brine_C, salt_used_g, leak, notes`

---

## 11) Files &amp; Diagrams
- **PFD Mermaid (this page)**
- **State machine diagram (this page)**
- **Downloadable assets:** wiring list, I/O map, P&amp;ID (to be added after SKU selection)

```mermaid
stateDiagram-v2
  [*] --&gt; Idle
  Idle --&gt; Soften: demand &amp;&amp; PV_ok
  Soften --&gt; RO_Make: drinking_low &amp;&amp; PV_ok
  RO_Make --&gt; Idle: storage_full || PV_low
  Idle --&gt; MSSC_Aerate: gw_inflow || timer
  MSSC_Aerate --&gt; Irrigate: ORP/DO in band &amp;&amp; dwell_met
  Irrigate --&gt; Idle: soil_moist_ok || volume_met
  Idle --&gt; Regen: capacity_hit || schedule
  Regen --&gt; Idle: regen_done &amp;&amp; leak_clear
  [*] --&gt; FaultSafe
  Soften --&gt; FaultSafe: leak || sensor_fault
  RO_Make --&gt; FaultSafe: leak || sensor_fault
  MSSC_Aerate --&gt; FaultSafe: leak || sensor_fault
  Regen --&gt; FaultSafe: leak || sensor_fault
```

---

## 12) Resonant Check
- **Clarity:** three loops, one cabinet, three plots.  
- **Coherence:** membranes, microbes, thermal assist play distinct roles.  
- **Deployment:** 60-day plan with publishable data that a homeowner and a regulator can both respect.
&quot;&quot;&quot;

md = md_template.replace(&quot;__DATE__&quot;, date_str)

pfd_path = os.path.join(base, &quot;homenode2_flow.mmd&quot;)
states_path = os.path.join(base, &quot;homenode2_states.mmd&quot;)
md_path = os.path.join(base, &quot;HomeNode2.0_Wiki_Page.md&quot;)

# Extract mermaid blocks
pfd_block = md.split(&quot;```mermaid&quot;)[1].split(&quot;```&quot;)[0].strip()
states_block = md.split(&quot;```mermaid&quot;)[2].split(&quot;```&quot;)[0].strip()

with open(pfd_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(pfd_block)
with open(states_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(states_block)
with open(md_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(md)

zip_path = &quot;/mnt/data/HomeNode2.0_Wiki_Package_v1.2.zip&quot;
with zipfile.ZipFile(zip_path, &quot;w&quot;, zipfile.ZIP_DEFLATED) as z:
    z.write(md_path, arcname=&quot;HomeNode2.0_Wiki_Page.md&quot;)
    z.write(pfd_path, arcname=&quot;homenode2_flow.mmd&quot;)
    z.write(states_path, arcname=&quot;homenode2_states.mmd&quot;)

(md_path, pfd_path, states_path, zip_path)

---

**assistant:**

Fresh links—ready to paste into the wiki:

- Markdown page: [HomeNode2.0_Wiki_Page.md](sandbox:/mnt/data/HomeNode2.0_Wiki/HomeNode2.0_Wiki_Page.md)  
- Mermaid PFD: [homenode2_flow.mmd](sandbox:/mnt/data/HomeNode2.0_Wiki/homenode2_flow.mmd)  
- Mermaid State Machine: [homenode2_states.mmd](sandbox:/mnt/data/HomeNode2.0_Wiki/homenode2_states.mmd)  
- Zip bundle (all files): [HomeNode2.0_Wiki_Package_v1.2.zip](sandbox:/mnt/data/HomeNode2.0_Wiki_Package_v1.2.zip)

---

**user:**

Here it is:

https://github.com/justindbilyeu/SunShare-TriSource/wiki/SunShare-Home-Node2.0

---

**assistant:**

Beautiful—page is live. I read it end-to-end and here’s how to tighten it into a build-ready spec right on the wiki.

# Quick surgical edits (ready-to-paste)

**Why:** Your “System Flow Diagram” is currently indented code (so GitHub treats it as plain text). Switching to fenced ```mermaid blocks renders the diagram. Same for adding a controls/state diagram, BOM, tests, and safety so the page doubles as a build spec. (I’m anchoring to your current page sections and language.) citeturn0view0

---

## 1) Replace “System Flow Diagram” block with this (renders as Mermaid)

```mermaid
flowchart TD
  Solar((Sunlight)) --&gt; PV[PVT + Solar Panels]
  Grid((Grid Water)) --&gt; Softener[Salt Loop Softener] --&gt; SPMD[Membrane Distillation Unit] --&gt; Potable[Clean Drinking Water]
  Greywater[Greywater] --&gt; MSSC[MSSC Microbial Reactor] --&gt; Irrigation[Compost Tea / Irrigation Water] --&gt; Soil[Soil Enhancement]
  Runoff[Runoff] --&gt; MSSC
  SPMD --&gt; Brine[Brine Recovery Loop]
  Brine --&gt; Softener
```

---

## 2) Add a “Controls (v0.1) — State Machine” section right after the diagram

```mermaid
stateDiagram-v2
  [*] --&gt; Idle
  Idle --&gt; Soften: demand &amp;&amp; PV_ok
  Soften --&gt; RO_Make: drinking_low &amp;&amp; PV_ok
  RO_Make --&gt; Idle: storage_full || PV_low
  Idle --&gt; MSSC_Aerate: gw_inflow || timer
  MSSC_Aerate --&gt; Irrigate: ORP/DO in band &amp;&amp; dwell_met
  Irrigate --&gt; Idle: soil_moist_ok || volume_met
  Idle --&gt; Regen: capacity_hit || schedule
  Regen --&gt; Idle: regen_done &amp;&amp; leak_clear
  [*] --&gt; FaultSafe
  Soften --&gt; FaultSafe: leak || sensor_fault
  RO_Make --&gt; FaultSafe: leak || sensor_fault
  MSSC_Aerate --&gt; FaultSafe: leak || sensor_fault
  Regen --&gt; FaultSafe: leak || sensor_fault
```

**Setpoint bands (copy/paste under the diagram):**

- MSSC aerobic polish: **DO 2–6 mg/L**, **ORP +50 → +200 mV**; for nitrate conversion, allow an **anoxic window** (0 → −50 mV) via aeration duty.  
- Greywater: **24–48 h** residence; **subsurface drip only**.  
- Brine regen: log **salt mass/cycle**, **t°**, **hardness leakage**; compare ambient vs. heated.

---

## 3) Add a “Product Tiers” table (good/better/best)

```markdown
### Product Tiers (Good / Better / Best)

| Tier | For whom | Modules | Outcome |
|---|---|---|---|
| **HN-Lite** | City/well, high hardness, basic reuse | Softener + MSSC mini + AI Load Controller (v0.1) | Soft water to home; greywater → irrig.; nitrate/EC reduction |
| **HN-Plus** *(recommended MVP)* | Adds high-quality drinking water | HN-Lite + compact RO (50–200 GPD) | RO tap + full data logging |
| **HN-Prime** *(pilot)* | R&amp;D &amp; data capture | HN-Plus + SPMD/thermal brine assist + trial MD panel | Demonstrates salt savings &amp; ZLD/MLD options |
```

This slots naturally after your “Modular Architecture” or “Inputs and Outputs.” citeturn0view0

---

## 4) Add a “Pilot BOM (indicative)” table

```markdown
### Pilot BOM (indicative)

| Subsystem | Example Parts | Notes |
|---|---|---|
| Softener | 32k–48k grain valve/head, resin tank, brine tank | Standard salt-loop; service bypass |
| RO (Plus/Prime) | 50–200 GPD kit + remineralizer | Under-sink or cabinet mount |
| MSSC Mini | 10–20 L tank, air pump &amp; diffusers, ORP/DO/EC/pH probes | Access port for dosing/sampling |
| Sensors &amp; I/O | EC, pH, ORP, DO, flow, level, leak float | 4–20 mA or Modbus; SD logging |
| Controller | Small PLC or industrial SBC + relays | Manual/Auto switches |
| Cabinet | 24″×36″×14″ wall cabinet (garage) *or* 36″ sq yard enclosure | Drip tray, GFCI |
| R&amp;D (Prime) | SPMD/thermal coil, small MD panel | Comparative trials |

*Cost bands: HN-Lite ≈ $1.8–3.0k; HN-Plus ≈ $2.1–3.5k; HN-Prime ≈ $2.5–4.4k (ex-install).*
```

---

## 5) Add a “30–60 Day Test Plan” section

```markdown
### Test Plan (30–60 days)

- **Week 1:** Commission potable loop. Log **hardness (CaCO₃)** in/out, **TDS**, RO flow, pump power → **SEC**.  
- **Week 2:** Commission MSSC. Log **nitrate**, **EC**, **ORP**, **DO**, and **plate counts/16S snapshots**; confirm **24–48 h** dwell.  
- **Week 3:** Brine trials (Prime). Compare **salt/cycle** and **leakage** with/without heat; if MD present, record **distillate rate** and **ion balance**.

**Data schema (CSV headers):**  
`timestamp,state,pv_ok,flow_in_lpm,flow_ro_lpm,tank_level_pct,ec_in_uS,ec_out_uS,ph,orp_mV,do_mgL,nitrate_mgL,hardness_in_mgL,hardness_out_mgL,t_brine_C,salt_used_g,leak,notes`
```

---

## 6) Add “Safety &amp; Compliance” bullets (homeowner and AHJ friendly)

```markdown
### Safety &amp; Compliance

- Anti-cross-connection: **NSF 61** components; backflow preventer on city tie-in.  
- Electrical: **GFCI**; leak tray float → master relay kill.  
- Greywater: **subsurface drip only**; label **non-potable** outlets; follow local code.  
- Sampling ports pre/post MSSC; clear labels and SOPs.
```

---

# Optional: split into subpages for clarity

- **SunShare-Home-Node2.0/Build-Spec-v1.0** (this content)  
- **SunShare-Home-Node2.0/Controls-I-O** (wiring, I/O map, ladder/state logic)  
- **SunShare-Home-Node2.0/BOM-Spreadsheet** (costs + vendor classes)  
- **SunShare-Home-Node2.0/Test-Results** (the three plots)

This keeps your current **Vision/Architecture** page clean while making it actionable. citeturn0view0

---

## What I can drop in next (no waiting)
- Wiring &amp; **I/O list** (ready to paste).  
- **P&amp;ID** (Mermaid schematic or SVG).  
- A lightweight **CSV template** for logging (download link).  

Say the word and I’ll paste those sections fully formatted.

---

**user:**

split into subpages for clarity

---

**assistant:**

# Generate subpage assets for GitHub Wiki: CSV templates + Mermaid diagrams
import os, datetime, pytz, csv, textwrap, zipfile

tz = pytz.timezone(&quot;America/Chicago&quot;)
today = datetime.datetime.now(tz).strftime(&quot;%Y-%m-%d&quot;)

base = &quot;/mnt/data/HomeNode2_Subpages&quot;
os.makedirs(base, exist_ok=True)

# CSV: logging template
log_headers = [
    &quot;timestamp&quot;,&quot;state&quot;,&quot;pv_ok&quot;,&quot;flow_in_lpm&quot;,&quot;flow_ro_lpm&quot;,&quot;tank_level_pct&quot;,
    &quot;ec_in_uS&quot;,&quot;ec_out_uS&quot;,&quot;ph&quot;,&quot;orp_mV&quot;,&quot;do_mgL&quot;,&quot;nitrate_mgL&quot;,
    &quot;hardness_in_mgL&quot;,&quot;hardness_out_mgL&quot;,&quot;t_brine_C&quot;,&quot;salt_used_g&quot;,&quot;leak&quot;,&quot;notes&quot;
]
log_csv = os.path.join(base, &quot;HomeNode2_logging_template.csv&quot;)
with open(log_csv, &quot;w&quot;, newline=&quot;&quot;, encoding=&quot;utf-8&quot;) as f:
    w = csv.writer(f)
    w.writerow(log_headers)

# CSV: wiring / I-O map
io_rows = [
    # tag, type, signal, range, interface, notes
    (&quot;LIT-001&quot;,&quot;Level&quot;,&quot;Brine tank level&quot;,&quot;0–100 %&quot;,&quot;4–20 mA&quot;,&quot;Leak tray cuts power (see LSH-001)&quot;),
    (&quot;LSH-001&quot;,&quot;Level Switch&quot;,&quot;Leak tray float&quot;,&quot;Dry contact&quot;,&quot;DI&quot;,&quot;NC preferred; latches FaultSafe&quot;),
    (&quot;FIT-001&quot;,&quot;Flow&quot;,&quot;Feed flow (inlet)&quot;,&quot;0–10 LPM&quot;,&quot;4–20 mA&quot;,&quot;Turbine or magflow&quot;),
    (&quot;FIT-002&quot;,&quot;Flow&quot;,&quot;RO permeate flow&quot;,&quot;0–5 LPM&quot;,&quot;4–20 mA&quot;,&quot;Downstream of RO&quot;),
    (&quot;AIT-EC-IN&quot;,&quot;EC&quot;,&quot;EC inlet&quot;,&quot;0.2–10 mS/cm&quot;,&quot;Modbus RTU&quot;,&quot;Inline conductivity&quot;),
    (&quot;AIT-EC-OUT&quot;,&quot;EC&quot;,&quot;EC outlet (MSSC)&quot;,&quot;50–2000 µS/cm&quot;,&quot;Modbus RTU&quot;,&quot;Post-MSSC&quot;),
    (&quot;AIT-pH&quot;,&quot;pH&quot;,&quot;Process pH&quot;,&quot;0–14 pH&quot;,&quot;4–20 mA&quot;,&quot;With temp comp&quot;),
    (&quot;AIT-ORP&quot;,&quot;ORP&quot;,&quot;Oxidation-Reduction Potential&quot;,&quot;-500–+500 mV&quot;,&quot;4–20 mA&quot;,&quot;&quot;),
    (&quot;AIT-DO&quot;,&quot;DO&quot;,&quot;Dissolved Oxygen&quot;,&quot;0–20 mg/L&quot;,&quot;4–20 mA&quot;,&quot;Polarographic/optical&quot;),
    (&quot;AIT-NO3&quot;,&quot;Nitrate&quot;,&quot;NO3-N&quot;,&quot;0–50 mg/L&quot;,&quot;Sampler/Lab&quot;,&quot;Grab or inline probe&quot;),
    (&quot;PMP-RO&quot;,&quot;Pump&quot;,&quot;RO high-pressure pump&quot;,&quot;120 VAC&quot;,&quot;Relay DO&quot;,&quot;Motor starter/SSR as needed&quot;),
    (&quot;PMP-AIR&quot;,&quot;Pump&quot;,&quot;MSSC air pump&quot;,&quot;120 VAC&quot;,&quot;Relay DO&quot;,&quot;Duty-cycled for ORP/DO windows&quot;),
    (&quot;VLV-IN&quot;,&quot;Valve&quot;,&quot;Inlet isolation&quot;,&quot;24 VDC&quot;,&quot;Relay DO&quot;,&quot;Normally closed&quot;),
    (&quot;VLV-BR&quot;,&quot;Valve&quot;,&quot;Brine draw&quot;,&quot;24 VDC&quot;,&quot;Relay DO&quot;,&quot;Softener head control or external&quot;),
    (&quot;VLV-IRR&quot;,&quot;Valve&quot;,&quot;Irrigation outlet&quot;,&quot;24 VDC&quot;,&quot;Relay DO&quot;,&quot;Subsurface drip only&quot;),
    (&quot;HX-HTR&quot;,&quot;Heater/Coil&quot;,&quot;Thermal assist coil&quot;,&quot;24 VDC&quot;,&quot;Relay DO&quot;,&quot;Prime tier only&quot;),
    (&quot;MD-PMP&quot;,&quot;Pump&quot;,&quot;MD circulation&quot;,&quot;24 VDC&quot;,&quot;Relay DO&quot;,&quot;Prime tier only&quot;),
    (&quot;PSU-24&quot;,&quot;Power&quot;,&quot;24 VDC supply&quot;,&quot;—&quot;,&quot;—&quot;,&quot;Size for sensors + valves&quot;),
    (&quot;PLC-CPU&quot;,&quot;Controller&quot;,&quot;PLC/SBC CPU&quot;,&quot;—&quot;,&quot;—&quot;,&quot;Modbus RTU master on RS-485&quot;)
]
io_csv = os.path.join(base, &quot;HomeNode2_wiring_io_map.csv&quot;)
with open(io_csv, &quot;w&quot;, newline=&quot;&quot;, encoding=&quot;utf-8&quot;) as f:
    w = csv.writer(f)
    w.writerow([&quot;tag&quot;,&quot;type&quot;,&quot;signal&quot;,&quot;range&quot;,&quot;interface&quot;,&quot;notes&quot;])
    w.writerows(io_rows)

# Mermaid: PFD
pfd_mermaid = textwrap.dedent(&quot;&quot;&quot;\
    flowchart LR
      A[PV/DC Bus] --&gt; C[Controller]
      subgraph Potable Loop
        IN[(City/Well)] --&gt; S[Salt-Loop Softener]
        S --&gt; RO{RO Module?}
        RO -- Yes --&gt; ROP[RO Permeate -&gt; Tap]
        RO -- No --&gt; K[Polished to Tap]
        FLC{Fluoride risk?} --&gt;|Yes| FA[Fluoride Cartridge]
        S --&gt; FLC
        FA --&gt; K
      end
      subgraph Greywater Loop
        LGW[(Laundry/Bath)] --&gt; PF[Prefilter Screen]
        PF --&gt; MSSC[MSSC Mini (DO/ORP/EC/pH)]
        MSSC --&gt; IRR[Subsurface Drip Bed]
      end
      subgraph Brine/Heat Branch (R&amp;D)
        S --&gt; BR[Brine Tank]
        HTR{Thermal Assist?} --&gt;|Yes| HX[Coil from PVT/Solar Thermal]
        BR --&gt; HX --&gt; BR2[Heated Brine -&gt; Regen]
        BR -. ambient regen .-&gt; BR2
        MD{MD Panel?} --&gt;|Trial| MDP[Small MD Panel]
        BR -. optional .-&gt; MD
      end
      C &lt;-- sensors/relays --&gt; S
      C &lt;-- sensors/relays --&gt; RO
      C &lt;-- sensors/relays --&gt; MSSC
      C &lt;-- sensors/relays --&gt; BR
&quot;&quot;&quot;)
pfd_path = os.path.join(base, &quot;HomeNode2_PFD.mmd&quot;)
with open(pfd_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(pfd_mermaid)

# Mermaid: State machine
state_mermaid = textwrap.dedent(&quot;&quot;&quot;\
    stateDiagram-v2
      [*] --&gt; Idle
      Idle --&gt; Soften: demand &amp;&amp; PV_ok
      Soften --&gt; RO_Make: drinking_low &amp;&amp; PV_ok
      RO_Make --&gt; Idle: storage_full || PV_low
      Idle --&gt; MSSC_Aerate: gw_inflow || timer
      MSSC_Aerate --&gt; Irrigate: ORP/DO in band &amp;&amp; dwell_met
      Irrigate --&gt; Idle: soil_moist_ok || volume_met
      Idle --&gt; Regen: capacity_hit || schedule
      Regen --&gt; Idle: regen_done &amp;&amp; leak_clear
      [*] --&gt; FaultSafe
      Soften --&gt; FaultSafe: leak || sensor_fault
      RO_Make --&gt; FaultSafe: leak || sensor_fault
      MSSC_Aerate --&gt; FaultSafe: leak || sensor_fault
      Regen --&gt; FaultSafe: leak || sensor_fault
&quot;&quot;&quot;)
state_path = os.path.join(base, &quot;HomeNode2_StateMachine.mmd&quot;)
with open(state_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(state_mermaid)

# Bundle zip
zip_path = &quot;/mnt/data/HomeNode2_Subpages_Assets.zip&quot;
with zipfile.ZipFile(zip_path, &quot;w&quot;, zipfile.ZIP_DEFLATED) as z:
    for p in (log_csv, io_csv, pfd_path, state_path):
        z.write(p, arcname=os.path.basename(p))

(log_csv, io_csv, pfd_path, state_path, zip_path)

---

**assistant:**

Love it. Let’s split your **SunShare-Home-Node2.0** wiki into clean subpages. Below are **ready-to-paste page stubs** (with navigation links) plus fresh download assets (CSV templates + Mermaid diagrams).

---

# 0) Landing page (keep your current page as the hub)

**Page title:** `SunShare Home Node™ 2.0`  
**Content (paste at the top or replace the body):**

```markdown
# SunShare Home Node™ 2.0

**What it is:** a cabinetized residential system that softens, polishes, and reuses water with a compact MSSC for greywater and optional thermal/brine R&amp;D.

## Quick Links
- [[Home Node 2.0/Build Spec v1.0]]
- [[Home Node 2.0/Controls &amp; I-O]]
- [[Home Node 2.0/BOM &amp; Vendors]]
- [[Home Node 2.0/Test Plan &amp; Data]]
- [[Home Node 2.0/Safety &amp; Compliance]]

---

### System Flow (Mermaid)
```mermaid
flowchart TD
  Solar((Sunlight)) --&gt; PV[PVT + Solar Panels]
  Grid((Grid Water)) --&gt; Softener[Salt Loop Softener] --&gt; SPMD[Membrane Distillation Unit] --&gt; Potable[Clean Drinking Water]
  Greywater[Greywater] --&gt; MSSC[MSSC Microbial Reactor] --&gt; Irrigation[Compost Tea / Irrigation Water] --&gt; Soil[Soil Enhancement]
  Runoff[Runoff] --&gt; MSSC
  SPMD --&gt; Brine[Brine Recovery Loop]
  Brine --&gt; Softener
```
```

---

# 1) Subpage: Build Spec v1.0

**Page title:** `Home Node 2.0/Build Spec v1.0`  
**Paste:**

```markdown
[[SunShare Home Node™ 2.0]] • [[Home Node 2.0/Controls &amp; I-O]] • [[Home Node 2.0/BOM &amp; Vendors]] • [[Home Node 2.0/Test Plan &amp; Data]] • [[Home Node 2.0/Safety &amp; Compliance]]

# Home Node™ 2.0 — Build Spec v1.0

&gt; **One-liner:** A cabinetized residential system that **softens**, **polishes**, and **reuses** water using **solar-aware controls**, a **compact MSSC** for greywater, and an **optionally thermal-assisted brine/RO add-on**. Success is measured by **kWh/m³**, **recovery (%)**, **nitrate drop**, and **ion balance**—not adjectives.

## Architecture (PFD)
```mermaid
flowchart LR
  A[PV/DC Bus] --&gt; C[Controller]
  subgraph Potable Loop
    IN[(City/Well)] --&gt; S[Salt-Loop Softener]
    S --&gt; RO{RO Module?}
    RO -- Yes --&gt; ROP[RO Permeate -&gt; Tap]
    RO -- No --&gt; K[Polished to Tap]
    FLC{Fluoride risk?} --&gt;|Yes| FA[Fluoride Cartridge]
    S --&gt; FLC
    FA --&gt; K
  end
  subgraph Greywater Loop
    LGW[(Laundry/Bath)] --&gt; PF[Prefilter Screen]
    PF --&gt; MSSC[MSSC Mini (DO/ORP/EC/pH)]
    MSSC --&gt; IRR[Subsurface Drip Bed]
  end
  subgraph Brine/Heat Branch (R&amp;D)
    S --&gt; BR[Brine Tank]
    HTR{Thermal Assist?} --&gt;|Yes| HX[Coil from PVT/Solar Thermal]
    BR --&gt; HX --&gt; BR2[Heated Brine -&gt; Regen]
    BR -. ambient regen .-&gt; BR2
    MD{MD Panel?} --&gt;|Trial| MDP[Small MD Panel]
    BR -. optional .-&gt; MD
  end
  C &lt;-- sensors/relays --&gt; S
  C &lt;-- sensors/relays --&gt; RO
  C &lt;-- sensors/relays --&gt; MSSC
  C &lt;-- sensors/relays --&gt; BR
```

## Product Tiers (Good/Better/Best)
| Tier | For whom | Modules | Outcome |
|---|---|---|---|
| **HN-Lite** | City/well, high hardness, basic reuse | Softener + MSSC mini + AI Load Controller (v0.1) | Soft water; greywater → irrig.; nitrate/EC reduction |
| **HN-Plus** *(recommended MVP)* | Adds high-quality drinking water | HN-Lite + compact RO (50–200 GPD) | RO tap + full data logging |
| **HN-Prime** *(pilot)* | R&amp;D &amp; data capture | HN-Plus + SPMD/thermal brine assist + trial MD panel | Salt savings &amp; ZLD/MLD options |

## Controls (v0.1 State Machine)
```mermaid
stateDiagram-v2
  [*] --&gt; Idle
  Idle --&gt; Soften: demand &amp;&amp; PV_ok
  Soften --&gt; RO_Make: drinking_low &amp;&amp; PV_ok
  RO_Make --&gt; Idle: storage_full || PV_low
  Idle --&gt; MSSC_Aerate: gw_inflow || timer
  MSSC_Aerate --&gt; Irrigate: ORP/DO in band &amp;&amp; dwell_met
  Irrigate --&gt; Idle: soil_moist_ok || volume_met
  Idle --&gt; Regen: capacity_hit || schedule
  Regen --&gt; Idle: regen_done &amp;&amp; leak_clear
  [*] --&gt; FaultSafe
  Soften --&gt; FaultSafe: leak || sensor_fault
  RO_Make --&gt; FaultSafe: leak || sensor_fault
  MSSC_Aerate --&gt; FaultSafe: leak || sensor_fault
  Regen --&gt; FaultSafe: leak || sensor_fault
```

**Setpoints:** MSSC DO **2–6 mg/L**, ORP **+50 → +200 mV** (with optional **0 → −50 mV** anoxic window); Greywater dwell **24–48 h**; Brine regen logs **salt/cycle**, **t°**, **hardness leakage**.

## Plumbing (at a glance)
- Potable: City/Well → Softener → (Fluoride cartridge if needed) → RO(optional) → Tap.
- Greywater: Laundry/Bath → Screen → MSSC → Subsurface drip (non-spray).
- Brine: Softener brine tank with tee to **thermal coil (Prime)**; bypass for ambient regen; optional small MD loop.

```

---

# 2) Subpage: Controls &amp; I-O

**Page title:** `Home Node 2.0/Controls &amp; I-O`  
**Paste:**

```markdown
[[SunShare Home Node™ 2.0]] • [[Home Node 2.0/Build Spec v1.0]] • [[Home Node 2.0/BOM &amp; Vendors]] • [[Home Node 2.0/Test Plan &amp; Data]] • [[Home Node 2.0/Safety &amp; Compliance]]

# Controls &amp; I-O (v0.1)

## Power &amp; Safety
- 120 VAC to pumps via relays; **GFCI** required.
- 24 VDC supply for sensors/valves; leak tray float (LSH-001) **kills main relay**.
- Backflow preventer on city tie-in.

## I-O Map
| Tag | Type | Signal | Range | Interface | Notes |
|---|---|---|---|---|---|
| LIT-001 | Level | Brine tank level | 0–100% | 4–20 mA | Leak tray interlock via LSH-001 |
| LSH-001 | Level Switch | Leak tray float | — | Dry contact (DI) | NC preferred; latches FaultSafe |
| FIT-001 | Flow | Feed flow (inlet) | 0–10 LPM | 4–20 mA | Turbine or mag |
| FIT-002 | Flow | RO permeate flow | 0–5 LPM | 4–20 mA | Downstream of RO |
| AIT-EC-IN | EC | EC inlet | 0.2–10 mS/cm | Modbus RTU | Inline conductivity |
| AIT-EC-OUT | EC | EC outlet (MSSC) | 50–2000 µS/cm | Modbus RTU | Post-MSSC |
| AIT-pH | pH | Process pH | 0–14 pH | 4–20 mA | Temp comp |
| AIT-ORP | ORP | Ox-Red potential | −500–+500 mV | 4–20 mA | — |
| AIT-DO | DO | Dissolved O₂ | 0–20 mg/L | 4–20 mA | Optical ok |
| AIT-NO3 | Nitrate | NO₃-N | 0–50 mg/L | Lab/probe | Grab acceptable |
| PMP-RO | Pump | RO HP pump | 120 VAC | Relay DO | Use starter/SSR as needed |
| PMP-AIR | Pump | MSSC air pump | 120 VAC | Relay DO | Duty-cycle for ORP/DO windows |
| VLV-IN | Valve | Inlet isolation | — | 24 VDC (DO) | NC |
| VLV-BR | Valve | Brine draw | — | 24 VDC (DO) | With softener head |
| VLV-IRR | Valve | Irrigation outlet | — | 24 VDC (DO) | Subsurface only |
| HX-HTR | Coil | Thermal assist | — | 24 VDC (DO) | Prime tier |
| MD-PMP | Pump | MD circulation | — | 24 VDC (DO) | Prime tier |

**Download:** Wiring/I-O CSV — [HomeNode2_wiring_io_map.csv](sandbox:/mnt/data/HomeNode2_Subpages/HomeNode2_wiring_io_map.csv)

## State Machine
(See diagram on Build Spec page.)
```

---

# 3) Subpage: BOM &amp; Vendors

**Page title:** `Home Node 2.0/BOM &amp; Vendors`  
**Paste:**

```markdown
[[SunShare Home Node™ 2.0]] • [[Home Node 2.0/Build Spec v1.0]] • [[Home Node 2.0/Controls &amp; I-O]] • [[Home Node 2.0/Test Plan &amp; Data]] • [[Home Node 2.0/Safety &amp; Compliance]]

# BOM &amp; Vendors (indicative)

| Subsystem | Class / Example | Qty | Est. Unit Cost | Notes |
|---|---|---:|---:|---|
| Softener head + resin tank + brine tank | 32k–48k grain class | 1 | \$450–900 | Standard salt-loop; bypass |
| RO module (50–200 GPD) + remineralizer | Under-sink/cabinet class | 1 | \$150–400 | HN-Plus &amp; Prime |
| MSSC mini reactor (10–20 L) | Tank + air pump + diffusers | 1 | \$200–400 | Sample/dosing ports |
| Probes (EC, pH, ORP, DO) | Inline/flow-cell | 1 set | \$300–800 | 4–20 mA/Modbus |
| Flow sensors | 0–10 LPM &amp; 0–5 LPM | 2 | \$60–180 | 4–20 mA |
| Nitrate measurement | Lab kit or inline probe | — | \$0–400 | Start w/ grab samples |
| PLC/SBC + relays + SD logging | Industrial hobby/entry PLC | 1 | \$150–350 | Modbus RTU master |
| Cabinet/enclosure | 24″×36″×14″ wall cab or 36″ sq yard | 1 | \$200–500 | Drip tray, GFCI |
| Valves 24 VDC | Inlet, irrigation, brine | 3–5 | \$30–80 | NC |
| R&amp;D: SPMD/coil + small MD panel | Prime tier only | 1 | \$300–900 | Comparative trials |

*Budget bands:* HN-Lite **\$1.8–3.0k**, HN-Plus **\$2.1–3.5k**, HN-Prime **\$2.5–4.4k** (ex-install).
```

---

# 4) Subpage: Test Plan &amp; Data

**Page title:** `Home Node 2.0/Test Plan &amp; Data`  
**Paste:**

```markdown
[[SunShare Home Node™ 2.0]] • [[Home Node 2.0/Build Spec v1.0]] • [[Home Node 2.0/Controls &amp; I-O]] • [[Home Node 2.0/BOM &amp; Vendors]] • [[Home Node 2.0/Safety &amp; Compliance]]

# Test Plan &amp; Data (30–60 days)

## Protocol
- **Week 1 — Potable loop:** hardness (CaCO₃) in/out, TDS, RO flow, pump power → **SEC**.
- **Week 2 — MSSC loop:** nitrate, EC, ORP, DO, plate counts/16S snapshots; dwell **24–48 h**.
- **Week 3 — Brine/thermal (Prime):** salt/cycle, hardness leakage, brine temp; if MD present → distillate rate &amp; ion balance.

## Plots to Publish
1. **Hardness/TDS** before → after.  
2. **Nitrate/EC** drop across MSSC.  
3. **Salt use vs. brine temperature** (and MD yield if present).

## Data Schema
Use this header row for CSV logs:

```
timestamp,state,pv_ok,flow_in_lpm,flow_ro_lpm,tank_level_pct,ec_in_uS,ec_out_uS,ph,orp_mV,do_mgL,nitrate_mgL,hardness_in_mgL,hardness_out_mgL,t_brine_C,salt_used_g,leak,notes
```

**Download:** Logging CSV template — [HomeNode2_logging_template.csv](sandbox:/mnt/data/HomeNode2_Subpages/HomeNode2_logging_template.csv)

## Attachments
- PFD (Mermaid): embed from Build Spec or use file: [HomeNode2_PFD.mmd](sandbox:/mnt/data/HomeNode2_Subpages/HomeNode2_PFD.mmd)  
- State machine: [HomeNode2_StateMachine.mmd](sandbox:/mnt/data/HomeNode2_Subpages/HomeNode2_StateMachine.mmd)
```

---

# 5) Subpage: Safety &amp; Compliance

**Page title:** `Home Node 2.0/Safety &amp; Compliance`  
**Paste:**

```markdown
[[SunShare Home Node™ 2.0]] • [[Home Node 2.0/Build Spec v1.0]] • [[Home Node 2.0/Controls &amp; I-O]] • [[Home Node 2.0/BOM &amp; Vendors]] • [[Home Node 2.0/Test Plan &amp; Data]]

# Safety &amp; Compliance

- **Backflow protection:** Approved backflow preventer on city/well tie-in; potable and non-potable loops clearly separated and labeled.
- **Electrical:** All 120 VAC loads on **GFCI**; leak tray float (LSH-001) must cut master relay (fail-safe normally-closed).
- **Greywater discharge:** **Subsurface drip only**; outlets labeled **NON-POTABLE**; follow local code and setback rules.
- **Sampling &amp; SOPs:** Provide sample ports pre/post MSSC; written procedures for dosing, cleaning, and sensor calibration.
- **Materials:** Use components conforming to **NSF/ANSI 61** where in contact with potable water; pressure ratings suitable for house mains.
```

---

## Download assets (fresh)

- Logging template: [HomeNode2_logging_template.csv](sandbox:/mnt/data/HomeNode2_Subpages/HomeNode2_logging_template.csv)  
- Wiring/I-O map: [HomeNode2_wiring_io_map.csv](sandbox:/mnt/data/HomeNode2_Subpages/HomeNode2_wiring_io_map.csv)  
- PFD diagram (Mermaid): [HomeNode2_PFD.mmd](sandbox:/mnt/data/HomeNode2_Subpages/HomeNode2_PFD.mmd)  
- State machine (Mermaid): [HomeNode2_StateMachine.mmd](sandbox:/mnt/data/HomeNode2_Subpages/HomeNode2_StateMachine.mmd)  
- Zip bundle (all files): [HomeNode2_Subpages_Assets.zip](sandbox:/mnt/data/HomeNode2_Subpages_Assets.zip)

---

### Handoff
- Create five new wiki pages with the titles above and paste the content blocks.  
- Add the Quick Links block to your landing page.  
- Ping me once the pages are up—I’ll generate a **P&amp;ID** and a **wiring diagram SVG** to drop into Controls &amp; I-O.

---

**user:**

Let’s update our bibliography:

https://github.com/justindbilyeu/SunShare-TriSource/wiki/Citations

---

**assistant:**

Absolutely—here’s a **ready-to-paste, structured bibliography** for your wiki page at `Citations`. It’s organized by topic, annotated in one line each, and uses durable, primary sources.

---

# SunShare Citations (Updated: September 1, 2025)

&gt; Curated references for Home Node™ 2.0: desal fundamentals, RO/ED/MD, AWG/psychrometrics, natural treatment &amp; brine management, health standards, and field facilities.

## 1) Desal fundamentals &amp; transport physics
- Elimelech, M., &amp; Phillip, W.A. (2011). **The future of seawater desalination: energy, technology, and the environment**. *Science*. A canonical overview of energy limits, pretreatment, materials, and environmental context. https://doi.org/10.1126/science.1200488. citeturn0search10  
- Wang, L. et al. (2023). **Water transport in reverse osmosis membranes is governed by pore flow, not solution-diffusion**. *Science Advances.* Establishes the solution-friction (pressure-driven) mechanism with MD + experiments. citeturn6search10  
- Wang, L. et al. (2021). **Salt and Water Transport in Reverse Osmosis Membranes: Beyond the Solution-Diffusion Model**. *Environmental Science &amp; Technology.* Develops the **solution-friction** model framework. citeturn6search0  

## 2) Brackish RO: SEC, design handbooks, and benchmarks
- **USBR** (2003). **Desalting Handbook for Planners (3rd ed.)**. Planning-level process, cost, and design guidance for RO/ED/thermal. (Free PDF). citeturn4search2  
- Ahdab, Y.D., Lienhard, J.H. (2020). **Desalination of brackish groundwater** (chapter). Includes **SEC tables** for brackish RO vs EDR. (Open chapter pdf). citeturn4search13  
- Park, K. et al. (2020). **Design, modelling and optimisation of batch RO**. *Desalination.* Puts **brackish RO SEC ~0.5–1.5 kWh/m³** in context and shows batch-RO potential. citeturn4search15  

## 3) Electrodialysis (ED/EDR)
- Strathmann, H. (2010). **Electrodialysis: a mature technology with new applications**. *Desalination 264:268–288.* Definitive ED/EDR review (free PDF). citeturn0search1  
- Patel, S.K. et al. (2021). **Energy Consumption of Brackish Water Desalination**. *ACS EST Engineering.* Head-to-head SEC comparisons (ED vs RO) for brackish feeds. citeturn4search3  

## 4) Membrane distillation (MD) &amp; low-grade thermal
- Alkhudhiri, A., Darwish, N., Hilal, N. (2012). **Membrane distillation: A comprehensive review**. *Desalination 287.* Process modes, heat/mass transfer, and applications. (Open PDF). citeturn0search17  
- Vane, L.M. (2017). **Water recovery from brines and salt-saturated solutions**. *Reviews in Chemical Engineering.* High-salinity process landscape &amp; thermodynamic context. (Open). citeturn1search17  

## 5) Atmospheric water harvesting (AWH) &amp; psychrometrics
- Rao, A.K. et al. (2022). **Thermodynamic limits of atmospheric water harvesting**. *Energy &amp; Environmental Science.* Maps minimum work vs RH/temperature and tech niches. citeturn0search13  
- Buck, A.L. (1981). **New equations for computing vapor pressure and enhancement factor**. *J. Appl. Meteorology.* Standard **saturation vapor pressure** correlations (psychrometrics). (Open PDF). citeturn0search4  
- Jin, Y. et al. (2024). **Boosting atmospheric water harvesting with solar-driven systems**. *Cell Reports Physical Science.* Up-to-date view of materials and thermodynamic ceilings. citeturn0search18  

## 6) Natural treatment &amp; concentrate (brine) management
- Scholes, R.C. et al. (2021). **Enabling water reuse by treatment of RO concentrate**. *ACS ES&amp;T Au.* Reviews **constructed wetlands** for ROC with case studies. (Open). citeturn1search10  
- Liang, Y. et al. (2017). **Constructed wetlands for saline wastewater treatment**. *Journal of Hazardous Materials.* State-of-the-art for **salinity-tolerant CWs**. citeturn1search0  
- Mavukkandy, M.O. et al. (2019). **Brine management in desalination: from waste to resource**. *Desalination.* Broad tech survey (resource recovery/ZLD/MLD). citeturn1search4  
- Chakraborti, R.K. et al. (2023). **Constructed Wetlands Using Treated Membrane Concentrate**. *Land (MDPI).* ROC-specific CW design considerations. citeturn1search7  

## 7) Health, codes, and standards (potable &amp; reuse)
- **WHO** (2006–2013). **Guidelines for the Safe Use of Wastewater, Excreta and Greywater** (Volumes I–IV). Risk-based approach for greywater reuse. (Open). citeturn2search0turn2search4  
- **US EPA** (2012). **Guidelines for Water Reuse** (+ landing page). Reuse categories, treatment targets, and program design. (Open). citeturn2search1turn2search5  
- **NSF/ANSI 61** (2024 overview). **Drinking Water System Components—Health Effects**. Material compliance for wetted parts. citeturn2search2  
- **US EPA** (2022). **Cross-Connection Control &amp; Backflow Prevention** (fact sheet). Program elements &amp; best practices. citeturn2search3  
- **US EPA** (current). **National Primary Drinking Water Regulations** (MCLs). **Nitrate (as N) = 10 mg/L**; **Nitrite (as N) = 1 mg/L**. citeturn5search1  
- **WHO** (2011). **Fluoride in Drinking-water** (background document). WHO **guideline value = 1.5 mg/L**. citeturn5search0  

## 8) Programs &amp; facilities (pilots, testing, road-mapping)
- **BGNDRF** (Bureau of Reclamation). **Brackish Groundwater National Desalination Research Facility** (Alamogordo, NM). Pilot bays, water analysis, outreach, and **concentrate management** expertise. citeturn3search0  
- **NAWI** (DOE). **National Alliance for Water Innovation**—U.S. desalination &amp; water-reuse **Energy Innovation Hub** (program site &amp; About). citeturn3search1turn3search3  
- **DOE EERE (2024)**. **$75M renewal for NAWI (Phase II)**—pilots and tech baselining for low-energy desal. citeturn3search5  

## 9) Project documents (SunShare)
- **SunShare Home Node™ 2.0** (wiki hub): architecture, controls, test plan.  
  &lt;https://github.com/justindbilyeu/SunShare-TriSource/wiki/SunShare-Home-Node2.0&gt;

---

### Notes on use
- Prefer these as **anchor references** in build specs, BOMs, and test plans; cite specific sections/figures where possible.  
- For homeowner-facing claims (e.g., nitrate/fluoride numbers, cross-connection practices), reference **WHO/EPA/NSF** entries above.

---

If you want, I can split this into **APA or IEEE style** and generate a `.bib` file you can drop into the repo.

---

**user:**

APA style

---

**tool:**

You are nearing the maximum number of calls to this tool. You have approximately 3 calls left.

---

**tool:**

You are nearing the maximum number of calls to this tool. You have approximately 2 calls left.

---

**tool:**

You are nearing the maximum number of calls to this tool. You have approximately 1 calls left.

---

**assistant:**

Here’s a clean, APA-style bibliography you can paste directly into the wiki.

### APA references (alphabetical)

- Alkhudhiri, A., Darwish, N., &amp; Hilal, N. (2012). Membrane distillation: A comprehensive review. *Desalination, 287*, 2–18. citeturn14view0  
- Buck, A. L. (1981). New equations for computing vapor pressure and enhancement factor. *Journal of Applied Meteorology, 20*(12), 1527–1532. citeturn18search0  
- Elimelech, M., &amp; Phillip, W. A. (2011). The future of seawater desalination: Energy, technology, and the environment. *Science, 333*(6043), 712–717. citeturn0search0  
- Mavukkandy, M. O., Chabib, C. M., Mustafa, I., Al Ghaferi, A., &amp; AlMarzooqi, F. (2019). Brine management in desalination industry: From waste to resources generation. *Desalination, 472*, 114187. citeturn22search4  
- Park, K., Burlace, L., Dhakal, N., Mudgal, A., Stewart, N. A., &amp; Davies, P. A. (2020). Design, modelling and optimisation of a batch reverse osmosis desalination system using a free piston for brackish water treatment. *Desalination, 494*, 114625. citeturn13view0  
- Patel, S. K., Biesheuvel, P. M., &amp; Elimelech, M. (2021). Energy consumption of brackish water desalination: Identifying the sweet spots for electrodialysis and reverse osmosis. *ACS ES&amp;T Engineering, 1*(8), 851–864. citeturn20search0  
- Strathmann, H. (2010). Electrodialysis, a mature technology with a multitude of new applications. *Desalination, 264*(3), 268–288. citeturn16search1  
- Vane, L. M. (2017). Water recovery from brines and salt-saturated solutions: Operability and thermodynamic efficiency considerations for desalination technologies. *Journal of Chemical Technology &amp; Biotechnology, 92*(10), 2506–2518. citeturn8search1turn8search2  
- Wang, L., Cao, T., Dykstra, J. E., Porada, S., Biesheuvel, P. M., &amp; Elimelech, M. (2021). Salt and water transport in reverse osmosis membranes: Beyond the solution–diffusion model. *Environmental Science &amp; Technology, 55*(24), 16665–16675. citeturn11view0  
- Wang, L., He, J., Heiranian, M., Fan, H., Lu, X., &amp; Elimelech, M. (2023). Water transport in reverse osmosis membranes is governed by pore flow, not a solution–diffusion mechanism. *Science Advances, 9*(15), eadf8488. citeturn7search8  

**Design/standards &amp; guidance**

- National Alliance for Water Innovation. (n.d.). About NAWI. (Web page). citeturn4search1  
- NSF International. (2024). What is NSF/ANSI/CAN 61? (Web page). citeturn5search3  
- U.S. Bureau of Reclamation. (2003). *Desalting handbook for planners* (3rd ed.). Denver, CO: Author. citeturn9search1turn9search2  
- U.S. Bureau of Reclamation. (n.d.). Brackish Groundwater National Desalination Research Facility (BGNDRF). (Web page). citeturn4search0  
- U.S. Environmental Protection Agency. (2012). *Guidelines for water reuse* (EPA/600/R-12/618). Washington, DC: Author. citeturn6search1  
- U.S. Environmental Protection Agency. (n.d.). Cross-connection control. (Web page). citeturn5search2  
- U.S. Environmental Protection Agency. (n.d.). National primary drinking water regulations: Nitrates and nitrites. (Web page). citeturn5search1  
- World Health Organization. (2006). *Guidelines for the safe use of wastewater, excreta and greywater: Volume 4—Excreta and greywater use in agriculture*. Geneva: WHO Press. citeturn6search0  

---

### (Optional) Link &amp; DOI pack for the wiki

&gt; Paste this as-is beneath the references if you want live links.

```
Alkhudhiri et al. 2012 — https://doi.org/10.1016/j.desal.2011.08.027
Buck 1981 — https://journals.ametsoc.org/view/journals/apme/20/12/1520-0450_1981_020_1527_nefcvp_2_0_co_2.pdf
Elimelech &amp; Phillip 2011 — https://doi.org/10.1126/science.1200488
Mavukkandy et al. 2019 — https://doi.org/10.1016/j.desal.2019.114187
Park et al. 2020 — https://doi.org/10.1016/j.desal.2020.114625
Patel, Biesheuvel, &amp; Elimelech 2021 — https://doi.org/10.1021/acsestengg.0c00192
Strathmann 2010 — https://doi.org/10.1016/j.desal.2010.04.069
Vane 2017 — https://doi.org/10.1002/jctb.5225
Wang et al. 2021 — https://doi.org/10.1021/acs.est.1c05649
Wang et al. 2023 — https://doi.org/10.1126/sciadv.adf8488

NAWI (About) — https://www.nawihub.org/about/
NSF/ANSI/CAN 61 overview — https://www.nsf.org/knowledge-library/what-is-nsf-ansi-can-61
USBR Desalting Handbook (3rd ed., 2003) — https://www.usbr.gov/research/dwpr/reportpdfs/report072.pdf
BGNDRF — https://www.usbr.gov/research/bgndrf/
EPA Guidelines for Water Reuse (2012) — https://nepis.epa.gov/Exe/ZyPDF.cgi/P100FS7K.PDF?Dockey=P100FS7K.PDF
EPA Nitrates &amp; Nitrites — https://www.epa.gov/ground-water-and-drinking-water/national-primary-drinking-water-regulations#Inorganic
EPA Cross-Connection Control — https://www.epa.gov/ground-water-and-drinking-water/cross-connection-control
WHO Guidelines (Vol. 4) — https://cdn.who.int/media/docs/default-source/wash-documents/wash-institutions/gsuweg4v2.pdf
```

If you want me to fold in additional sources (e.g., ROC/ROC-to-reuse, wetlands for brine polishing, sorption-based AWH limits, etc.), say the word and I’ll append them in the same APA format.

---

**user:**

Ok let’s regroup. Let’s think about the Home Node, and how we could replicate it for a small community or a school outside the US …somewhere that investors would look twice at bringing potable water to that area… what do you think?

---

**assistant:**

# Scoping &amp; Alignment

**Objective:** Translate **Home Node™** into a **Community Node** for a small school (or village cluster) outside the US—something **investable**, repeatable, and fast to stand up.

**Plan:** (1) Site archetypes &amp; sizing, (2) Scalable architecture, (3) Brine/NBS you can permit, (4) Investor logic &amp; unit economics, (5) 90-day “first install” path.

---

# 1) Site archetypes &amp; right-sizing (parametric, not hype)

Use this as your quick scoping grid—same bones as Home Node, sized for daily **potable** needs (drinking/cooking). Greywater reuse stays local (gardens, hand-washing).

| Archetype | Users | Potable need (L/person·day) | Product water (m³/day) | Brine @80% recovery (m³/day) | PV (kW, ~5 sun-hr/day) | Battery (kWh, base-load only) | Wetland area for brine (m² @ 5 cm/day HLR) |
|---|---:|---:|---:|---:|---:|---:|---:|
| **Small school** | 250 students + 15 staff | 3 | **0.80** | **0.20** | **0.45** | **0.35** | **4** |
| **Medium school** | 750 + 30 | 3 | **2.34** | **0.585** | **0.94** | **0.35** | **12** |
| **School + kiosk** | 1,000 + 40 + 2 m³/day community | 3 | **5.12** | **1.28** | **1.83** | **0.35** | **26** |

**Assumptions (E2/common practice):** brackish RO SEC ≈ 1.0 kWh/m³ (+0.2 kWh/m³ misc pumps); MSSC aeration + controls ≈ 0.7 kWh/day; PV derate 0.75; brine HLR 5 cm/day into **lined** wetland/halophyte bed. If **TDS ≤ ~2,500 mg/L** and power is tight, an **EDR** train may beat RO on energy; above that, lead with **RO** and a good ERD.  

**Why investors like this:** capex scales roughly linearly with m³/day; opex is small once PV is on; brine volumes are modest (20–25% of product) and we show a real plan, not a pit.

---

# 2) Scalable architecture (Community Node)

**Keep the Home Node bones—just parallelize.**

```mermaid
flowchart LR
  PV[PV + Charge Controller] --&gt; DC[DC Bus / Battery]
  DC --&gt; P[Pumps &amp; Controls]
  subgraph Intake
    W1[Brackish Well or Surface Intake] --&gt; PT[Prefilter + Carbon]
  end
  PT --&gt; Train{RO vs EDR}
  Train -- Permeate --&gt; H[Potable Storage 1–2 days]
  Train -- Concentrate --&gt; B[Brine Tank]
  H --&gt; K1[Tap Stand #1] &amp; K2[Tap Stand #2] &amp; Kitchen[Kitchen Feed]
  subgraph MSSC / Reuse
    GW[Greywater from sinks/laundry] --&gt; MSSC[MSSC Reactor]
    MSSC --&gt; GWIrr[Subsurface Drip Garden]
  end
  B --&gt; NBS[Lined Wetland + Halophytes]
  NBS --&gt; Salt[Harvest/Offhaul/Crystallize]
```

**Design notes:**
- **Train decision:** If **TDS ≤ ~2.5 g/L** and target recovery &gt;90%, spec **EDR**; else **RO@80–85%** + antiscalant + 5 µm/carbon pretreatment.  
- **Distribution:** 2–3 **tap stands** (gravity or low-lift pump) + a dedicated **school kitchen line** with 0.2 µm final polish/UV.  
- **Storage:** 1–2 days potable, 0.5–1 day raw; all **covered &amp; lockable**.  
- **Power:** PV sized from table; **battery covers base-loads** (controls + MSSC aeration). Push high-draw RO/ED to daylight hours.  
- **MSSC:** On **greywater**, not in the high-pressure loop. DO 2–6 mg/L; ORP +50→+200 mV; optional anoxic window (0→−50 mV) to shave nitrates before garden reuse.  
- **Monitoring:** EC, pH, ORP, DO, flow, level; weekly **nitrate**; monthly **micro** (plates or 16S snapshots).

---

# 3) Brine &amp; nature-based system (NBS) you can actually permit

- **Volume math:** \(V_b = \frac{1-R}{R} \cdot V_p\). At \(R=0.8\), brine ≈ **0.25× product**.  
- **Wetland sizing:** Start at **5 cm/day HLR** → **4–26 m²** for the archetypes above; line the bed; use salt-tolerant plants; include **sample wells** (in/out).  
- **Plan B:** If soils/regulator won’t allow, use a **small solar evaporator/MD panel** to cut volume, then **off-haul salts** quarterly.  
- **Non-negotiables:** Liner + overflow capture; **no direct discharge** without data; monthly ion balance (Cl⁻, SO₄²⁻, Na⁺, Ca²⁺, Mg²⁺).  
- **Fouling control:** Keep MSSC **off** the RO/ED loop; pretreat well; adhere to a **CIP** schedule.

---

# 4) Investor logic (how this pencils)

**The thesis:** “**School-anchored micro-utilities**” with **taps + gardens** beat standalone kiosks on trust, siting, and utilization.

- **Capex bands (indicative):**  
  - 1 m³/day: \$15–\$30k (PV 0.5 kW; small RO/ED skid; tanks; controls; enclosure).  
  - 2–3 m³/day: \$25–\$50k (PV ~1 kW; larger skid; 2–3 taps).  
  - 5 m³/day: \$40–\$80k (PV ~1.8 kW; multiple taps; bigger storage).  
- **Opex (PV-backed):** filters + antiscalant + CIP + operator stipend → **\$0.002–\$0.01/L** (range, pre-field).  
- **Revenue models:**  
  1) **School contract** (flat service fee) + kiosk pay-as-you-fetch,  
  2) **NGO subsidy** + micro-payments (USSD/mobile),  
  3) **CSR anchor** + free taps for students, low-cost kiosk for neighbors.  
- **Impact &amp; diligence hooks:**  
  - **Three plots:** SEC vs. recovery; nitrate/EC drop across MSSC; brine EC decline/ion balance → uploaded monthly.  
  - **Governance:** PTA/School committee + operator trained; reconciliation of liters, revenue, downtime.  
  - **Risk:** Spare pumps/filters on-site; remote alarms; standard consumables.

*Investor takeaway:* one **replicable kit**, transparent **data**, multiple **off-ramp models** (school budget, donor support, community revenue).

---

# 5) Where to start (the “double-take” short-list)

Pick **one** of these patterns first; all are logistically sane and investor-friendly:

- **Peri-urban school on a brackish borehole** (good roads, strong solar, light permitting).  
- **Island/river delta school with slightly saline source** (EDR sweet-spot; visible brine solution).  
- **Arid high-insolation village school** with roof catch + brackish backup (PV advantage; garden reuse is visible).

**Selection criteria:** reliable partner (school/NGO), TDS profile, land for wetland (≥20 m² is fine), community acceptance of kiosk pricing, and clear authority for permits. (We can screen 3 candidate sites fast.)

---

# 6) First install: 90-day playbook (minimum-regret)

**Days 0–14 — Confirm the site**
- Raw water tests (TDS, hardness, nitrate, sulfate, iron, turbidity, microbes).  
- MOU with school + siting (tap stands, enclosure, wetland footprint).  
- Decide **RO@80–85%** vs **EDR@90–92%** from water chemistry + duty.

**Days 15–45 — Build &amp; ship**
- Containerized **Community Node** (10- or 20-ft): skid, tanks, MSSC, PV/battery, taps.  
- Remote dry-fit; label in local language; SOPs laminated.  
- Pre-commission logs with salt/CIP.

**Days 46–60 — Commission**
- Local electrical/plumbing tie-ins; water safety checks; operator training.  
- Baseline **three plots** and photo-document.

**Days 61–90 — Operate &amp; publish**
- Weekly QA/QC; upload CSVs; share dashboard.  
- Garden planting with students; first **impact report** (liters, uptime, water quality, brine metrics).

---

# 7) What changes from Home → Community (delta spec)

- **Parallelization:** two-pump header, duplex cartridges, bigger ERD, and 2–3 tap points.  
- **Enclosure:** tamper-resistant container or masonry room; lockable chemical store; shaded taps.  
- **Controls:** the same **state machine** you already have—just add **tap-stand meters** and a **kiosk mode** (pay-as-you-fetch optional).  
- **Data:** CSV schema unchanged; just add fields for **tap-stand ID** and **operator ID**.

---

# Actions (my recommendation)

1) Pick one archetype above (I suggest **Medium school, 2–3 m³/day**).  
2) I’ll draft a **Community Node v1.0** page (PFD + P&amp;ID + BOM + 90-day Gantt) and a **one-pager for investors**.  
3) In parallel, we prepare a **site screening form** (water tests + siting + governance), so partners can self-nominate.

---

## Resonant Check
- **Clarity:** One kit, three sizes, same control logic; numbers beat adjectives.  
- **Coherence:** RO/ED + MSSC + NBS play distinct roles that translate across contexts.  
- **Deployment:** A 90-day play with specific footprints, PV, storage, and brine area—**investable and replicable**.

If you want, I’ll spin this into a **Community Node wiki** section with Mermaid diagrams and a cost table you can hand to a funder.

---

**user:**

Do it

---

**assistant:**

# Generate Community Node wiki subpages, diagrams, and CSV assets

import os, datetime, pytz, csv, textwrap, zipfile

tz = pytz.timezone(&quot;America/Chicago&quot;)
today = datetime.datetime.now(tz).strftime(&quot;%B %d, %Y&quot;)

base = &quot;/mnt/data/CommunityNode_Wiki&quot;
os.makedirs(base, exist_ok=True)

# ---------- Archetype sizing (reused in text) ----------
archetypes = [
    # name, users, Lppd, product_m3_day, recovery, brine_m3_day, pv_kw, battery_kwh, wetland_m2
    (&quot;Small school&quot;, 265, 3.0, 0.80, 0.80, 0.20, 0.45, 0.35, 4),
    (&quot;Medium school&quot;, 780, 3.0, 2.34, 0.80, 0.585, 0.94, 0.35, 12),
    (&quot;School + kiosk&quot;, 1040, 3.0, 5.12, 0.80, 1.28, 1.83, 0.35, 26),
]

# ---------- Page 1: Community Node v1.0 ----------
page1 = f&quot;&quot;&quot;
[[SunShare Home Node™ 2.0]] • [[Community Node/Investor One-Pager]] • [[Community Node/BOM &amp; Costs]] • [[Community Node/Site Screening Form]] • [[Community Node/Test &amp; Monitoring]]

# Community Node™ v1.0 — School-Anchored Micro-Utility
*Updated: {today}*

&gt; **Thesis:** Take the Home Node bones and **parallelize** them into a **1–5 m³/day** kit for schools and village clusters. Deliver potable water at taps on campus, reuse greywater in gardens via **MSSC**, and treat brine with a **lined wetland** (plan B: small MD + off-haul). Publish three plots monthly: **SEC vs. recovery**, **nitrate/EC drop (MSSC)**, **brine EC &amp; ion balance (NBS)**.

---

## 1) Right-Sizing at a Glance
| Archetype | Users | Potable need (L/person·day) | Product (m³/day) | Brine @80% (m³/day) | PV (kW, 5 sun-hr/day, 0.75 derate) | Battery (kWh, base) | Lined wetland (m² @ 5 cm/day) |
|---|---:|---:|---:|---:|---:|---:|---:|
&quot;&quot;&quot;[1:]

for name, users, lppd, prod, r, brine, pv, batt, wet in archetypes:
    page1 += f&quot;| **{name}** | {users} | {lppd:.0f} | **{prod:.2f}** | **{brine:.3f}** | **{pv:.2f}** | **{batt:.2f}** | **{wet}** |\n&quot;

page1 += &quot;&quot;&quot;
**Assumptions:** Brackish RO SEC ≈ 1.0 kWh/m³ + 0.2 kWh/m³ parasitics; MSSC + controls ≈ 0.7 kWh/day; PV derate 0.75. If **TDS ≤ ~2.5 g/L** and target recovery &gt;90%, consider **EDR**; above that, lead with **RO@80–85%** with ERD and antiscalant.

---

## 2) Architecture (PFD)
```mermaid
flowchart LR
  PV[PV + Charge Controller] --&gt; DC[DC Bus / Battery]
  DC --&gt; P[Pumps &amp; Controls]
  subgraph Intake
    W1[Brackish Well or Surface Intake] --&gt; PT[Prefilter + Carbon]
  end
  PT --&gt; Train{RO vs EDR}
  Train -- Permeate --&gt; H[Potable Storage 1–2 days]
  Train -- Concentrate --&gt; B[Brine Tank]
  H --&gt; K1[Tap Stand #1]
  H --&gt; K2[Tap Stand #2]
  H --&gt; Kitchen[Kitchen Feed + UV/0.2 µm]
  subgraph MSSC / Reuse
    GW[Greywater from sinks/laundry] --&gt; MSSC[MSSC Reactor (DO/ORP/EC/pH)]
    MSSC --&gt; GWIrr[Subsurface Drip Garden]
  end
  B --&gt; NBS[Lined Wetland + Halophytes + Sample Wells]
  NBS --&gt; Salt[Salt harvest / offhaul / crystallize]
```
**Design notes:** 1–2 days potable storage; covered and lockable. Two to three tap stands with meters; dedicated kitchen branch with final polish/UV. Push high-draw RO/ED to daylight hours; battery covers controls + MSSC aeration through the night.

---

## 3) Controls (State v0.1)
```mermaid
stateDiagram-v2
  [*] --&gt; Idle
  Idle --&gt; Produce: PV_ok &amp;&amp; storage_low
  Produce --&gt; Idle: storage_full || PV_low
  Idle --&gt; MSSC_Aerate: gw_inflow || timer
  MSSC_Aerate --&gt; Irrigate: ORP/DO in band &amp;&amp; dwell_met
  Irrigate --&gt; Idle: soil_moist_ok || volume_met
  Idle --&gt; CIP: schedule || dP_high
  CIP --&gt; Idle: complete &amp;&amp; leak_clear
  [*] --&gt; FaultSafe
  Produce --&gt; FaultSafe: leak || sensor_fault
  MSSC_Aerate --&gt; FaultSafe: leak || sensor_fault
  CIP --&gt; FaultSafe: leak || sensor_fault
```
**Setpoints:** MSSC DO **2–6 mg/L**, ORP **+50 → +200 mV** with optional **0 → −50 mV** anoxic window; greywater dwell **24–48 h**; RO/ED recovery **80–92%** depending on feed; brine wetland HLR **5 cm/day** (lined).

---

## 4) Brine &amp; NBS (permit-ready)
- Brine volume \( V_b = \\frac{1-R}{R} V_p \); at \( R=0.8 \\Rightarrow V_b = 0.25 V_p \).
- Start HLR **5 cm/day**, size area \( A = V_b / 0.05 \) → see table above.
- Include: liner, overflow capture, inlet/outlet sample wells, halophyte palette, monthly **ion balance** (Cl⁻, SO₄²⁻, Na⁺, Ca²⁺, Mg²⁺).  
- **Plan B:** Small MD panel + solar evap to cut volume; quarterly salt off-haul.

---

## 5) KPIs &amp; Monitoring
- **Water:** SEC (kWh/m³), recovery (%), TDS in/out, microbiology on potable branch (monthly plates).  
- **MSSC:** nitrate (mg/L), EC, ORP, DO, CFU/16S snapshots.  
- **Brine/NBS:** ΔEC, ion balance, plant biomass; liner integrity checks.  
- **Uptime &amp; Utilization:** hours running, liters dispensed per tap, downtime causes.

**CSV schema:** See [[Community Node/Test &amp; Monitoring]].

---

## 6) 90-Day First Install
- **Days 0–14:** Water tests, site MOU, choose RO vs EDR, confirm wetland pad.  
- **Days 15–45:** Build/shakedown in container or masonry room; SOPs in local language.  
- **Days 46–60:** Commission, train operators, baseline plots.  
- **Days 61–90:** Operate, upload CSVs, garden planting, impact report.

---

## 7) Costs &amp; Models
See [[Community Node/BOM &amp; Costs]] for size-based BOM, capex bands, and opex. Revenue options: school service fee, kiosk pay-as-you-fetch, CSR anchor.

---

## 8) Risks &amp; Mitigations
- **Brine discharge:** lined wetland + monitoring; Plan B MD + off-haul.  
- **Fouling:** pretreatment, anti-scalant, CIP schedule.  
- **Ops continuity:** spare pumps/filters, remote alarms, operator stipend.

&gt; **Why this wins:** school-anchored trust, transparent data, modular deployment, and a brine plan investors won’t side-eye.
&quot;&quot;&quot;

# ---------- Page 2: Investor One-Pager ----------
page2 = f&quot;&quot;&quot;
[[Community Node v1.0]] • [[Community Node/BOM &amp; Costs]] • [[Community Node/Site Screening Form]] • [[Community Node/Test &amp; Monitoring]]

# Community Node — Investor One-Pager
*Updated: {today}*

**What:** A containerized **1–5 m³/day** potable water micro-utility for schools, with tap stands on campus, garden reuse via **MSSC**, and a lined **wetland** for brine. Solar-native, data-transparent, and replicable.

**Why it matters:** Transforms donor-dependent water points into **operable micro-utilities** with visible benefits (clean taps + school gardens) and measurable KPIs uploaded monthly.

## Unit economics (indicative)
- **Capex bands:** 1 m³/d **$15–30k**; 2–3 m³/d **$25–50k**; 5 m³/d **$40–80k** (PV, skid, tanks, enclosure, wetland).  
- **Opex:** filters/chemicals/CIP/operator **$0.002–0.01 per liter** (PV-backed).  
- **Pricing models:** school service fee; kiosk pay-as-you-fetch ($0.01–0.03/L local-fit); CSR anchor (free for students).

**Example (2.34 m³/d):** 2,340 L/day. At **$0.01/L**, revenue **$23/day**; opex median **$0.005/L → $11.7/day**. Capex via grants/CSR, or amortized alongside kiosk revenue.

## Risk controls
- **Brine:** lined wetland with ion balance; Plan B MD + off-haul.  
- **Uptime:** spares on site; remote alerts.  
- **Governance:** school/PTA committee; transparent logs.

## What you get
- **Photos + three plots** monthly (SEC vs recovery; MSSC nitrate/EC; brine EC/ions).  
- **Auditable CSVs** + operator checklist.  
- **Nameplate impact:** liters delivered, days up, quality snapshots.

**Ask:** Fund **3 pilots** across distinct water chemistries; 12-month ops with data transparency; option to expand by franchise or CSR series.
&quot;&quot;&quot;

# ---------- Page 3: BOM &amp; Costs ----------
page3 = f&quot;&quot;&quot;
[[Community Node v1.0]] • [[Investor One-Pager]] • [[Community Node/Site Screening Form]] • [[Community Node/Test &amp; Monitoring]]

# Community Node — BOM &amp; Costs (Indicative)
*Updated: {today}*

| Size | Product (m³/d) | Core Train | PV (kW) | Potable Storage (m³) | Wetland Area (m²) | Capex Band (USD) |
|---|---:|---|---:|---:|---:|---:|
| Small | 0.8 | RO@80–85% (ERD) or EDR | 0.45 | 1.0 | 4 | 15,000–30,000 |
| Medium | 2.34 | RO@80–85% or EDR | 0.94 | 2.0 | 12 | 25,000–50,000 |
| Large | 5.12 | RO@80–85% | 1.83 | 5.0 | 26 | 40,000–80,000 |

## BOM (common across sizes)
- **Pretreatment:** 5 µm cartridge + carbon, optional iron/manganese step if required.  
- **Primary:** RO skid (HP pump, ERD) **or** EDR stack, instruments, CIP port.  
- **Storage:** raw + potable tanks (lockable, vents, drains).  
- **Distribution:** 2–3 tap stands (meters), kitchen branch with UV/0.2 µm.  
- **MSSC:** 100–300 L reactor with DO/ORP/EC/pH; air pump and duty control.  
- **Brine/NBS:** lined wetland basin with sample wells; Plan B MD panel.  
- **Power:** PV, charge controller, battery (controls overnight), DC/AC as needed.  
- **Controls:** PLC/SBC, relays, SD logging; operator HMI (local language).

**Download:** Size-based costs CSV — [community_node_bom_costs.csv](sandbox:/mnt/data/CommunityNode_Wiki/community_node_bom_costs.csv)
&quot;&quot;&quot;

# ---------- Page 4: Site Screening Form ----------
page4 = f&quot;&quot;&quot;
[[Community Node v1.0]] • [[Investor One-Pager]] • [[Community Node/BOM &amp; Costs]] • [[Community Node/Test &amp; Monitoring]]

# Community Node — Site Screening Form
*Updated: {today}*

**How to use:** Share this with school/NGO partners. Collect numbers + photos. A “Yes” on most items → fast greenlight.

## A. Partner &amp; Governance
- School name, location (GPS), head administrator, partner NGO, operator candidate(s).  
- Land control for enclosure + wetland (≥ 20 m² recommended).

## B. Source Water (attach lab or field tests)
- TDS, hardness, nitrate (as N), sulfate, iron, turbidity, microbes.  
- Source type (borehole depth, surface intake, reliability).

## C. Power &amp; Siting
- Solar exposure (photos), existing grid (Y/N), secure enclosure area, tap stand locations.

## D. Community Use
- Students/staff count, community users/day (optional kiosk), willingness to pay range.

**Download template (CSV):** [site_screening_form.csv](sandbox:/mnt/data/CommunityNode_Wiki/site_screening_form.csv)
&quot;&quot;&quot;

# ---------- Page 5: Test &amp; Monitoring ----------
page5 = f&quot;&quot;&quot;
[[Community Node v1.0]] • [[Investor One-Pager]] • [[Community Node/BOM &amp; Costs]] • [[Community Node/Site Screening Form]]

# Community Node — Test &amp; Monitoring
*Updated: {today}*

## Protocol (first 90 days)
- **Water:** SEC, recovery, TDS in/out; monthly microbiology on potable.  
- **MSSC:** nitrate, EC, ORP, DO; 16S/plates at start and day 30/60/90.  
- **Brine/NBS:** ΔEC &amp; ion balance monthly; biomass notes; liner checks.  
- **Uptime:** hours, downtime reasons, liters per tap.

## CSV schema (logs)
```
timestamp,state,tap_id,operator_id,pv_ok,flow_feed_lpm,flow_perm_lpm,tank_potable_level_pct,ec_feed_uS,ec_perm_uS,ph,orp_mV,do_mgL,nitrate_mgL,t_brine_C,brine_ec_uS,brine_flow_lpm,wetland_in_ec_uS,wetland_out_ec_uS,liters_tap1,liters_tap2,liters_kitchen,notes
```

**Download:** Logging template — [community_node_logging_template.csv](sandbox:/mnt/data/CommunityNode_Wiki/community_node_logging_template.csv)
&quot;&quot;&quot;

# ---------- Write pages ----------
paths = {}
pages = {
    &quot;Community_Node_v1.0.md&quot;: page1,
    &quot;Investor_One_Pager.md&quot;: page2,
    &quot;BOM_and_Costs.md&quot;: page3,
    &quot;Site_Screening_Form.md&quot;: page4,
    &quot;Test_and_Monitoring.md&quot;: page5,
}
for fname, content in pages.items():
    p = os.path.join(base, fname)
    with open(p, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
        f.write(content)
    paths[fname] = p

# ---------- Mermaid diagrams (PFD + alt NBS schematic) ----------
pfd_mermaid = textwrap.dedent(&quot;&quot;&quot;\
    flowchart LR
      PV[PV + Charge Controller] --&gt; DC[DC Bus / Battery]
      DC --&gt; P[Pumps &amp; Controls]
      subgraph Intake
        W1[Brackish Well or Surface Intake] --&gt; PT[Prefilter + Carbon]
      end
      PT --&gt; Train{RO vs EDR}
      Train -- Permeate --&gt; H[Potable Storage 1–2 days]
      Train -- Concentrate --&gt; B[Brine Tank]
      H --&gt; K1[Tap Stand #1]
      H --&gt; K2[Tap Stand #2]
      H --&gt; Kitchen[Kitchen + UV/0.2 µm]
      subgraph MSSC / Reuse
        GW[Greywater] --&gt; MSSC[MSSC Reactor (DO/ORP/EC/pH)]
        MSSC --&gt; GWIrr[Subsurface Drip Garden]
      end
      B --&gt; NBS[Lined Wetland + Halophytes + Sample Wells]
      NBS --&gt; Salt[Salt harvest / offhaul / crystallize]
&quot;&quot;&quot;)
pfd_path = os.path.join(base, &quot;community_node_pfd.mmd&quot;)
with open(pfd_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(pfd_mermaid)

nbs_mermaid = textwrap.dedent(&quot;&quot;&quot;\
    flowchart TD
      Brine[Brine Tank] --&gt; Screen[Screen/Settling]
      Screen --&gt; Wetland[Lined Wetland Cell]
      Wetland --&gt; Overflow[Overflow Capture/Recycle]
      Wetland --&gt; SampleIn[(Sample Well - Inlet)]
      Wetland --&gt; SampleOut[(Sample Well - Outlet)]
      Wetland --&gt; Biomass[Halophyte Biomass Harvest]
      Wetland --&gt; Crystallizer[Evap Pan / MD Panel]
      Crystallizer --&gt; Salt[Salt Off-haul]
&quot;&quot;&quot;)
nbs_path = os.path.join(base, &quot;nbs_wetland_schematic.mmd&quot;)
with open(nbs_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(nbs_mermaid)

# ---------- CSV: BOM &amp; costs ----------
bom_csv_path = os.path.join(base, &quot;community_node_bom_costs.csv&quot;)
with open(bom_csv_path, &quot;w&quot;, newline=&quot;&quot;, encoding=&quot;utf-8&quot;) as f:
    w = csv.writer(f)
    w.writerow([&quot;size&quot;,&quot;product_m3_per_day&quot;,&quot;train&quot;,&quot;pv_kw&quot;,&quot;potable_storage_m3&quot;,&quot;wetland_area_m2&quot;,&quot;capex_usd_low&quot;,&quot;capex_usd_high&quot;])
    rows = [
        (&quot;Small&quot;,0.80,&quot;RO@80–85% (ERD) or EDR&quot;,0.45,1.0,4,15000,30000),
        (&quot;Medium&quot;,2.34,&quot;RO@80–85% or EDR&quot;,0.94,2.0,12,25000,50000),
        (&quot;Large&quot;,5.12,&quot;RO@80–85%&quot;,1.83,5.0,26,40000,80000),
    ]
    w.writerows(rows)

# ---------- CSV: Site screening form ----------
site_csv_path = os.path.join(base, &quot;site_screening_form.csv&quot;)
with open(site_csv_path, &quot;w&quot;, newline=&quot;&quot;, encoding=&quot;utf-8&quot;) as f:
    w = csv.writer(f)
    w.writerow([
        &quot;school_name&quot;,&quot;gps_lat&quot;,&quot;gps_lon&quot;,&quot;country&quot;,&quot;partner_ngo&quot;,&quot;admin_contact&quot;,&quot;operator_candidate&quot;,
        &quot;land_available_m2&quot;,&quot;secure_enclosure_y_n&quot;,&quot;source_type&quot;,&quot;borehole_depth_m&quot;,&quot;source_reliability_notes&quot;,
        &quot;tds_mgL&quot;,&quot;hardness_mgL_as_CaCO3&quot;,&quot;nitrate_asN_mgL&quot;,&quot;sulfate_mgL&quot;,&quot;iron_mgL&quot;,&quot;turbidity_NTU&quot;,&quot;micro_coliform_present_y_n&quot;,
        &quot;solar_exposure_notes&quot;,&quot;grid_available_y_n&quot;,&quot;community_users_per_day&quot;,&quot;willingness_to_pay_per_L_local_currency&quot;,
        &quot;photos_links&quot;,&quot;permits_notes&quot;
    ])

# ---------- CSV: Logging template ----------
log_csv_path = os.path.join(base, &quot;community_node_logging_template.csv&quot;)
with open(log_csv_path, &quot;w&quot;, newline=&quot;&quot;, encoding=&quot;utf-8&quot;) as f:
    w = csv.writer(f)
    w.writerow([
        &quot;timestamp&quot;,&quot;state&quot;,&quot;tap_id&quot;,&quot;operator_id&quot;,&quot;pv_ok&quot;,&quot;flow_feed_lpm&quot;,&quot;flow_perm_lpm&quot;,&quot;tank_potable_level_pct&quot;,
        &quot;ec_feed_uS&quot;,&quot;ec_perm_uS&quot;,&quot;ph&quot;,&quot;orp_mV&quot;,&quot;do_mgL&quot;,&quot;nitrate_mgL&quot;,&quot;t_brine_C&quot;,&quot;brine_ec_uS&quot;,&quot;brine_flow_lpm&quot;,
        &quot;wetland_in_ec_uS&quot;,&quot;wetland_out_ec_uS&quot;,&quot;liters_tap1&quot;,&quot;liters_tap2&quot;,&quot;liters_kitchen&quot;,&quot;notes&quot;
    ])

# ---------- Bundle zip ----------
zip_path = &quot;/mnt/data/CommunityNode_Wiki_Package_v1.0.zip&quot;
with zipfile.ZipFile(zip_path, &quot;w&quot;, zipfile.ZIP_DEFLATED) as z:
    for p in paths.values():
        z.write(p, arcname=os.path.basename(p))
    z.write(pfd_path, arcname=os.path.basename(pfd_path))
    z.write(nbs_path, arcname=os.path.basename(nbs_path))
    z.write(bom_csv_path, arcname=os.path.basename(bom_csv_path))
    z.write(site_csv_path, arcname=os.path.basename(site_csv_path))
    z.write(log_csv_path, arcname=os.path.basename(log_csv_path))

(paths, pfd_path, nbs_path, bom_csv_path, site_csv_path, log_csv_path, zip_path)

---

**assistant:**

Done. I spun up a **Community Node** wiki pack—pages, diagrams, and CSVs—so you can drop this straight into your repo.

# Paste-ready wiki pages
- **Community Node v1.0:** [Community_Node_v1.0.md](sandbox:/mnt/data/CommunityNode_Wiki/Community_Node_v1.0.md)  
- **Investor One-Pager:** [Investor_One_Pager.md](sandbox:/mnt/data/CommunityNode_Wiki/Investor_One_Pager.md)  
- **BOM &amp; Costs:** [BOM_and_Costs.md](sandbox:/mnt/data/CommunityNode_Wiki/BOM_and_Costs.md)  
- **Site Screening Form:** [Site_Screening_Form.md](sandbox:/mnt/data/CommunityNode_Wiki/Site_Screening_Form.md)  
- **Test &amp; Monitoring:** [Test_and_Monitoring.md](sandbox:/mnt/data/CommunityNode_Wiki/Test_and_Monitoring.md)

# Diagrams (Mermaid)
- **Community Node PFD:** [community_node_pfd.mmd](sandbox:/mnt/data/CommunityNode_Wiki/community_node_pfd.mmd)  
- **Brine/NBS schematic:** [nbs_wetland_schematic.mmd](sandbox:/mnt/data/CommunityNode_Wiki/nbs_wetland_schematic.mmd)

# CSV assets
- **Size-based costs:** [community_node_bom_costs.csv](sandbox:/mnt/data/CommunityNode_Wiki/community_node_bom_costs.csv)  
- **Site screening template:** [site_screening_form.csv](sandbox:/mnt/data/CommunityNode_Wiki/site_screening_form.csv)  
- **Logging template:** [community_node_logging_template.csv](sandbox:/mnt/data/CommunityNode_Wiki/community_node_logging_template.csv)

# Zip bundle (everything)
- [CommunityNode_Wiki_Package_v1.0.zip](sandbox:/mnt/data/CommunityNode_Wiki_Package_v1.0.zip)

If you want, I’ll also add a **Gantt (markdown)** and a **localized operator checklist** for the first install site.

---

**user:**

WHat about the HydroLens AWG Module…

---

**assistant:**

# HydroLens™ AWG Module — generate wiki-ready spec + diagrams + estimator CSV

import os, datetime, pytz, csv, textwrap

tz = pytz.timezone(&quot;America/Chicago&quot;)
today = datetime.datetime.now(tz).strftime(&quot;%B %d, %Y&quot;)

base = &quot;/mnt/data/HydroLens_AWG&quot;
os.makedirs(base, exist_ok=True)

# --- Markdown spec ---
spec = f&quot;&quot;&quot;
[[SunShare Home Node™ 2.0]] • [[Community Node v1.0]] • [[Home Node 2.0/Controls &amp; I-O]]

# HydroLens™ AWG Module — Build Spec v0.9
*Updated: {today}*

&gt; **Position:** AWG is a **resilience/supplement**—great where **dew point is high** (humid/coastal nights), where **waste heat** is available for desiccant regen, or where **air handling** already exists. It is **not** the primary potable source when brackish RO/EDR is feasible on energy and permitting.

---

## 1) What it does (two interchangeable cores)
- **HL-VC (Vapor-Compression AWG):** heat-pump coil condenses moisture; best at **RH ≥ 60%** and **T ≥ 24 °C**. Typical SEC **0.35–0.8 kWh/L** depending on climate and coil design.  
- **HL-DS (Desiccant + Solar Regen):** moisture sorption at ambient; **low electric**, **low-rate thermal** (60–90 °C) for regeneration. Good where **solar-thermal** or **waste heat** exists; water quality like distilled.

Both feed a **small remineralization cartridge** before any drinking line (or route to MSSC for non-potable uses).

---

## 2) Architecture &amp; tie-ins
```mermaid
flowchart LR
  A[PV / DC Bus] --&gt; C[Controller]
  subgraph HydroLens™ Module
    RH[Temp/RH Sensor] --&gt; CTRL
    subgraph HL-VC (VC path)
      AIR[Blower] --&gt; COIL[Evap Coil + Drain Pan]
      COIL --&gt; COND[Condensate Tank]
    end
    subgraph HL-DS (Desiccant path)
      ADS[Adsorber Bed] --&gt; REGEN[Regen Coil/Panel]
      REGEN --&gt; COND2[Condensation Surface]
      COND2 --&gt; COND
    end
    CTRL[HL Controller] --&gt;|fans, comp, valves| AIR
    CTRL --&gt; REGEN
  end
  COND --&gt; RMN[Remineral Cartridge (optional)]
  RMN --&gt; P[Potable/Process Tank]
  C &lt;-- status/alarms --&gt; CTRL
```
**Plumbing:** 3/8″ drain to **COND** tank with **inline 50–100 µm screen**, then **carbon block** to knock taste/organics; optional remin cartridge if headed to drinking tap. Bypass to **MSSC** if used for irrigation/process.

---

## 3) Controls (v0.1)
```mermaid
stateDiagram-v2
  [*] --&gt; Standby
  Standby --&gt; VC_Run: mode=VC &amp;&amp; RH&gt;55% &amp;&amp; T&gt;=24C &amp;&amp; PV_ok
  VC_Run --&gt; Standby: PV_low || dewpoint_low || tank_full
  Standby --&gt; DS_Adsorb: mode=DS &amp;&amp; RH&gt;30% &amp;&amp; bed_ready
  DS_Adsorb --&gt; DS_Regen: schedule || capacity_hit
  DS_Regen --&gt; Standby: regen_done &amp;&amp; tank_ok
  [*] --&gt; FaultSafe
  VC_Run --&gt; FaultSafe: leak || sensor_fault
  DS_Regen --&gt; FaultSafe: overtemp || sensor_fault
```
**Setpoints:** hysteresis on dewpoint to avoid short-cycling; drain pan temp **&lt;5 °C** below dewpoint; **condensate EC** alarm if pickup from air/dust exceeds threshold.

---

## 4) Performance envelopes (planning numbers)
- **Vapor-compression AWG (HL-VC):**  
  - Ballpark **SEC**:  
    - **RH ≥ 80%, 26–32 °C:** ~**0.35–0.45 kWh/L**  
    - **RH 50–70%, 24–30 °C:** ~**0.5–0.7 kWh/L**  
    - **RH ≤ 40% or T ≤ 22 °C:** **≥0.8–1.2 kWh/L** (often uneconomic on PV)  
  - **Rule of thumb:** With **500 W** available for **8 h/day** (4 kWh), expect **~4–12 L/day** depending on climate (see estimator CSV).

- **Desiccant AWG (HL-DS):**  
  - **Electric** small (fans/valves); **thermal** 0.5–1.5 kWh\(_th\)/L depending on cycle; best with **solar-thermal/waste heat**.  
  - Output is **low but steady**; combine with VC or just feed gardens.

**Quality:** Condensate ≈ low mineral; always pass through **carbon** + **remin** if drinking.

---

## 5) When to deploy HydroLens (decision rule)
**Yes** if ≥2 of 3 are true: (a) **dewpoint ≥ 18 °C** for ≥8 h/day; (b) **RH ≥ 60%** nights for &gt;120 days/year; (c) you have **waste heat or solar-thermal**.  
**Otherwise**, keep HydroLens as **demo/resilience** or route entirely to **MSSC/irrigation**.

---

## 6) I-O &amp; Safety
- **Sensors:** Temp/RH (inlet), coil temp, condensate EC, tank level, leak float.  
- **Actuators:** blower, compressor (VC), regen coil/valves (DS), 3-way to remin/bypass.  
- **Interlocks:** backflow preventer to potable tank; **GFCI**; **drain pan flood** shutdown; fan pre/post purge to keep coil dry.

---

## 7) Field trial protocol (2 weeks)
- **Days 1–3:** Baseline SEC vs. yield at night/day windows; log Temp/RH/dewpoint.  
- **Days 4–7:** Add **remin** and taste tests; monitor EC and chlorine residual (if post-chlorinated).  
- **Days 8–14:** If DS path available, run **regen** with solar-thermal; compare L/kWh\(_e\) + kWh\(_th\). Publish plot.

---

## 8) Investor positioning
HydroLens adds **visible resilience** and **story value** (air → water) without overpromising. For schools, pitch as a **10–30 L/day** top-up that powers **hand-wash stations** or a **nurse’s office**, while the **Community Node** carries the potable base load.

---

## 9) Files
- **Mermaid PFD:** `hydrolens_awg_pfd.mmd`  
- **State machine:** `hydrolens_awg_states.mmd`  
- **Estimator CSV:** `hydrolens_awg_estimator.csv`
&quot;&quot;&quot;

spec_path = os.path.join(base, &quot;HydroLens_AWG_Module_Spec.md&quot;)
with open(spec_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(spec)

# --- Mermaid diagrams ---
pfd = textwrap.dedent(&quot;&quot;&quot;\
    flowchart LR
      A[PV / DC Bus] --&gt; C[Controller]
      subgraph HydroLens™ Module
        RH[Temp/RH Sensor] --&gt; CTRL
        subgraph HL-VC (Vapor-Compression)
          AIR[Blower] --&gt; COIL[Evap Coil + Drain Pan]
          COIL --&gt; COND[Condensate Tank]
        end
        subgraph HL-DS (Desiccant + Solar Regen)
          ADS[Adsorber Bed] --&gt; REGEN[Regen Coil/Panel]
          REGEN --&gt; COND2[Condensation Surface]
          COND2 --&gt; COND
        end
        CTRL[HL Controller] --&gt; AIR
        CTRL --&gt; REGEN
      end
      COND --&gt; RMN[Remineralization Cartridge]
      RMN --&gt; P[Potable/Process Tank]
      C &lt;-- status/alarms --&gt; CTRL
&quot;&quot;&quot;)
pfd_path = os.path.join(base, &quot;hydrolens_awg_pfd.mmd&quot;)
with open(pfd_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(pfd)

states = textwrap.dedent(&quot;&quot;&quot;\
    stateDiagram-v2
      [*] --&gt; Standby
      Standby --&gt; VC_Run: mode=VC &amp;&amp; RH&gt;55% &amp;&amp; T&gt;=24C &amp;&amp; PV_ok
      VC_Run --&gt; Standby: PV_low || dewpoint_low || tank_full
      Standby --&gt; DS_Adsorb: mode=DS &amp;&amp; RH&gt;30% &amp;&amp; bed_ready
      DS_Adsorb --&gt; DS_Regen: schedule || capacity_hit
      DS_Regen --&gt; Standby: regen_done &amp;&amp; tank_ok
      [*] --&gt; FaultSafe
      VC_Run --&gt; FaultSafe: leak || sensor_fault
      DS_Regen --&gt; FaultSafe: overtemp || sensor_fault
&quot;&quot;&quot;)
states_path = os.path.join(base, &quot;hydrolens_awg_states.mmd&quot;)
with open(states_path, &quot;w&quot;, encoding=&quot;utf-8&quot;) as f:
    f.write(states)

# --- Estimator CSV ---
# Simple heuristic: SEC_elec (kWh/L) vs RH/T bins for VC path
# RH: 30, 50, 70, 85 ; T: 20, 25, 30 °C
# Values chosen conservatively based on field norms, not thermodynamic minima.
temps = [20,25,30]
rhs = [30,50,70,85]
def sec_est(t, rh):
    # baseline mapping
    if rh &gt;= 80 and t &gt;= 26:
        return 0.38
    if rh &gt;= 70 and t &gt;= 24:
        return 0.45
    if rh &gt;= 50 and t &gt;= 24:
        return 0.60
    if rh &gt;= 50 and t &lt; 24:
        return 0.75
    if rh &gt;= 30 and t &gt;= 24:
        return 0.90
    return 1.10

csv_path = os.path.join(base, &quot;hydrolens_awg_estimator.csv&quot;)
with open(csv_path, &quot;w&quot;, newline=&quot;&quot;, encoding=&quot;utf-8&quot;) as f:
    w = csv.writer(f)
    w.writerow([&quot;T_C&quot;,&quot;RH_%&quot;,&quot;SEC_kWh_per_L&quot;,&quot;Yield_L_per_kWh&quot;,&quot;Daily_L_at_500W_8h&quot;])
    for t in temps:
        for rh in rhs:
            sec = sec_est(t, rh)
            yield_per_kwh = 1.0/sec
            daily_L = 4.0/sec   # 500 W * 8h = 4 kWh/day
            w.writerow([t, rh, round(sec,3), round(yield_per_kwh,3), round(daily_L,2)])

(spec_path, pfd_path, states_path, csv_path)

---

**assistant:**

Here’s how I see the **HydroLens™ AWG Module** fitting our stack—and I made you a wiki-ready spec + diagrams + an estimator CSV.

## Take
AWG is our **resilience and showpiece**, not the workhorse. It shines when **dewpoint is high** (coastal/humid nights), or when we can **regenerate desiccants with solar/waste heat**. For most inland sites, **RO/EDR carry the load**; HydroLens adds **10–30 L/day** for hand-washing, clinic use, or demo value—and routes extra to MSSC.

## What I built for you (paste-ready)
- Spec page: [HydroLens_AWG_Module_Spec.md](sandbox:/mnt/data/HydroLens_AWG/HydroLens_AWG_Module_Spec.md)  
- Mermaid PFD: [hydrolens_awg_pfd.mmd](sandbox:/mnt/data/HydroLens_AWG/hydrolens_awg_pfd.mmd)  
- Mermaid state machine: [hydrolens_awg_states.mmd](sandbox:/mnt/data/HydroLens_AWG/hydrolens_awg_states.mmd)  
- Yield/energy estimator (CSV): [hydrolens_awg_estimator.csv](sandbox:/mnt/data/HydroLens_AWG/hydrolens_awg_estimator.csv)

## TL;DR spec (so you can decide fast)
- **Two cores (interchangeable):**  
  1) **HL-VC** (vapor-compression coil): best at RH ≥ 60%, T ≥ 24 °C; **0.35–0.8 kWh/L** typical.  
  2) **HL-DS** (desiccant + solar regen): low electric, needs **60–90 °C** thermal; steady low-rate output.
- **Controls v0.1:** run in “dewpoint windows,” drain-pan monitoring, condensate EC alarm, safe drains; state machine already included.
- **Plumbing:** carbon + optional remin before any drinking line; bypass to **MSSC** if used for irrigation/process.
- **Reality check:** With **500 W for 8 h** (4 kWh/day) you get **~4–12 L/day** depending on climate (see CSV). That’s perfect for **visible, dependable top-ups**—not base demand.

## Where I’d deploy HydroLens first
- **Coastal school** (warm, humid evenings) as a **nurse’s office / hand-wash** top-up.  
- **Data-adjacent site** with **low-grade waste heat** → desiccant cycle demo.  
- **Investor demo**: pair with a solar-thermal panel to show **air → water** on stage, while the Community Node does the heavy lifting.

If you want, I’ll drop these into a **“HydroLens AWG”** section in your wiki and add an on-page **site selector** (copy/paste formula using local T/RH logs) so partners can self-screen whether HydroLens belongs at their site.

---

**user:**

Is there any part of this satellite reader we could use in our prototype?

---

**assistant:**

Short answer: **yes**—this looks like a Ku-band satellite **LNB** (low-noise block) with a feed-horn, weather-sealed housing, heat-sink body, and an F-connector. Several parts are very useful for our prototypes even if we ignore the RF guts.

## What we can reuse (high-value bits)
- **Weatherproof housing + 40 mm neck mount** → ready-made **rooftop sensor pod** or compact mount for a small coil/fan. It already clamps to masts/arms.
- **Die-cast heat-sink body** → small **thermal spreader** for a TEC/Peltier hot side or a MOSFET/pump driver. Better than bare plate aluminum at this size.
- **Feed-horn opening** → neat **intake nozzle** for airflow sampling (dewpoint sensor) or a tiny cold-finger demo; add a PTFE membrane + insect screen to keep it clean.
- **F-connector feedthrough** → cheap, rugged **power-over-coax** path (13–18 V) using a TV “power inserter” (bias-T). Great for running power to a roof pod with one RG-6 line.
- **O-rings/radome + UV-stable plastic** → IP-ish seals for outdoor duty.
- (**Optional**) If left intact, the LNB can be used as a **generic down-converter** for satellite experiments—but that’s outside our water scope.

## Two quick repurposes that help SunShare immediately

### A) Rooftop “HydroLens watcher” pod (reliably decides when AWG should run)
**Goal:** measure temp/RH/dewpoint and wind at the roof so HydroLens (or our fans/valves) only run in profitable windows.

- **Keep:** housing, clamp/neck, F-connector as power feedthrough.  
- **Strip:** RF board.  
- **Add inside:** BME280 (T/RH), small 5 V fan (25–30 mm), microcontroller (ESP32/STM32), 12→5 V buck.  
- **Seal:** PTFE vent patch over horn + screen.  
- **Power:** 13–18 V up the coax with a cheap satellite **power inserter**; 5 V buck in the pod.  
- **Telem:** LoRa/RS-485 over a second cable, or simple Wi-Fi if close.

This gives us **clean dewpoint signals** to gate AWG or to tune MSSC aeration schedules (cool, humid nights ≈ cheaper oxygen).

### B) Mini-AWG cold-finger demo (education/resilience)
**Goal:** show condensation visibly and log SEC.  
- Mount a **TEC/Peltier** cold finger in the horn, let condensate drip to a food-safe tube/tank (the LNB body is just the mount/heat-sink).  
- Hot side → the die-cast body + small fan; cold tip just inside the horn.  
- Route water only through **food-safe tubing**; the salvaged metals should **not** contact drinking water.

Yields are small (think **tens of mL/hour**), but it’s an honest teaching/demo module and a resilience trick for very humid nights.

---

## Bias-T (power-over-coax) sketch
Single RG-6 from the control cabinet to the pod:

```
Cabinet side: 18 VDC --- L (inductor) ---+---- RG-6 center ----+--- C (blocking cap) ---&gt; (unused RF)
                                         |                      |
                                        GND --------------------+--- Shield

Pod side:  RG-6 center --- L ---&gt; 12/5 V buck ---&gt; sensors/fan
           RG-6 center --- C ---&gt; (not used)      (C blocks DC if you ever carry RF)
```

You can also just buy a TV **power inserter** and skip building the L/C network.

---

## Safety &amp; cleaning
- Treat this as **non-potable hardware**: do **not** let product water touch the original metals/plastics.  
- Clean/strip with isopropyl, remove old grease, keep O-rings if supple; replace if cracked.  
- If you use the F-connector outdoors, add dielectric grease and a weather boot.

---

## Bottom line
Use it as a **rugged enclosure, mount, heat-spreader, and power-feedthrough**. That gives us a roof-grade **dewpoint sensor pod** (directly improves HydroLens scheduling) and a compact chassis for **small TEC/condensation demos**—both immediately useful to our Home/Community Node story.

---

**user:**

Because I come across these discarded satellite dishes in my job a lot and if we can make use of some of the parts, I’ll collect them

---

**assistant:**

Absolutely—if you’re seeing these often, they’re a goldmine. Here’s the **keep vs. skip** list and exactly how each part maps into SunShare/Home-/Community-Node and HydroLens.

# What to salvage (priority order)

## A) LNBs (like the one in your photo)
- **Keep:** whole unit, clamp, O-ring/radome, F-connector.
- **Uses:**
  - **Rooftop dewpoint pod** (HydroLens scheduler): reuse the weatherproof shell + 40 mm clamp; power it **over coax** (13–18 V via a cheap power inserter); put a T/RH sensor + small fan inside.
  - **Mini TEC cold-finger demo:** mount a small Peltier at the feed opening; the die-cast body is a great **hot-side heat sink**.
  - **General mast pod:** house soil/irrigation or leak sensors; the F-connector is a rugged feedthrough.
- **Notes:** Treat as **non-potable hardware**. Strip RF board if you don’t need it.

## B) J-mounts / masts / az-el brackets
- **Keep:** every one you can.  
- **Uses:** instant **outdoor mounts** for sensor pods, small PV panels (≤50 W), MD panels, airflow intakes, or weather stations. The azimuth/elevation adjusters are perfect for tilt experiments and pointing a small solar concentrator.

## C) Dishes (reflectors)
- **Mini (45–60 cm):** aperture ≈ 0.16–0.28 m² → **130–220 W thermal** at noon (η≈0.8).  
  - **Use:** preheat brine to 50–70 °C or **desiccant regeneration** (CaCl₂/silica gel) with a black absorber at focus.
- **Mid (80–100 cm):** 0.50–0.79 m² → **400–630 W thermal**.  
  - **Use:** small **solar still/MD feed heating**, or a visible school demo (“sun → hot brine”).
- **How:** paint or foil-line the dish (bright aluminum), place a **black copper/aluminum puck or coil** at focus, insulate behind. Always add a **stow lock** and shield—concentrators can burn things.

## D) Coax (RG-6), splitters, power inserters
- **Keep:** intact runs, weather boots.  
- **Uses:** **power-over-coax** to roof pods (dewpoint sensor, cameras). DC loop resistance of RG-6 is low enough for **~0.5–1 A at 13–18 V** over 10–20 m with minimal drop. Great single-cable runs to masts.

## E) Linear actuators (from larger tracking dishes)
- **Keep:** 18–36 V DC jacks with limit switches/pots.  
- **Uses:** low-cost **sun/tilt tracking** for a small concentrator, PV panel, or adjustable MD panel.

## F) Hardware &amp; plastics
- **Keep:** stainless/galv U-bolts, saddles, clamps, weather boots, grommets.  
- **Uses:** enclosure sealing, mast mounting, hose/standoff hardware.

---

# Quick conversions (you can build these this week)

## 1) Rooftop “HydroLens Watcher” (dewpoint pod)
- **Parts:** salvaged LNB shell + clamp; RG-6; power inserter; ESP32 (or small PLC node); BME280 (T/RH); 25–30 mm fan; 12→5 V buck.  
- **Build:** strip RF board → mount fan + sensor inside → PTFE vent + insect screen over the horn → power 13–18 V up the coax → buck to 5 V.  
- **Why:** runs HydroLens/vent fans only when **dewpoint windows** are favorable; saves kWh and shows real gains.

## 2) Mini solar concentrator for desiccant regen / brine preheat
- **Parts:** 60–90 cm dish; black anodized aluminum puck or small copper coil; simple frame (use az-el bracket).  
- **Build:** set focal length (most minidishes f ≈ 35–45 cm); place absorber at focus; strap a small thermocouple; add tilt lock.  
- **What you get:** **200–500 W\_th** mid-day → enough to push desiccant beds to **60–90 °C** or warm feed for an MD trial.

## 3) Sensor mast + PoC power
- **Parts:** J-mount, RG-6, power inserter, small weather box.  
- **Build:** mount at eave; run RG-6 inside; use inserter at the cabinet; place PLC node/LoRa + sensors in box; F-connector as sealed bulkhead.  
- **Why:** clean cabling and fast deployment for **MSSC, garden, weather** sensors.

---

# Triage checklist (so you only stock good stuff)

**Collect always**
- LNBs with intact housings &amp; clamps (radome not cracked badly).  
- J-mounts, U-bolts, az-el brackets, stainless hardware.  
- RG-6 with good ends/weather boots; power inserters.

**Collect if present**
- 80–100 cm dishes (no major creases).  
- Linear actuators from big dishes (shaft not pitted; moves by hand a few mm).  

**Skip**
- Severely bent or creased dishes (optics ruined).  
- Cracked masts at base welds.  
- Water-logged coax or corroded F-connectors past threads.

**Bench checks (2 min)**
- **Coax:** continuity shield↔shield; center↔center; **no** short between them.  
- **Actuator:** brief 24–36 V DC touch—should travel; limit switches click.  
- **LNB shell:** O-ring supple; clamp tightens smoothly.

---

# Safety &amp; hygiene
- Treat all salvaged metal/plastic as **non-potable contact**: keep out of any product-water path.  
- For concentrators: fit a **stow pin**, paint a **“HOT/DO NOT TOUCH”** marking, wear eye protection.  
- Outdoor connections: dielectric grease on F-connectors; drip loops on cables.

---

# Why this helps SunShare now
- **HydroLens** becomes smarter (dewpoint gating) with almost free hardware.  
- **Community Node** gains a low-cost **thermal assist** for desiccants/MD and great field demos.  
- **Home Node** gets clean mounting and wiring without custom metalwork.

If you want, I’ll spit out a one-page **“Salvage Tag Sheet”** (labels + QR to build notes) you can print and stick on each part bin.

---

**assistant:**

Oh yeah—this one’s a keeper. You’ve got a complete **offset satellite dish + az/el mount** (fine-adjust screws, J-mast clamp, LNB arm). That’s basically a free, outdoor-rated pointing platform with a built-in concentrator.

## What to salvage &amp; how we’ll use it
- **Az/El mount + J-mast** → adjustable **tilt platform** for:
  - a small PV panel (20–50 W) to power roof pods,
  - a **membrane distillation (MD) panel** or brine preheat coil,
  - any sensor pod (dewpoint “HydroLens watcher,” weather, camera).
- **Dish reflector (45–60 cm class)** → **solar concentrator**:
  - Aperture ≈ 0.16–0.28 m² → **~130–220 Wᵗʰ** at noon (η≈0.8).  
  - Perfect for **desiccant regeneration** (60–90 °C) or **brine preheat** before MD.
- **LNB arm (square tube)** → handy **conduit/boom** for mounting an absorber puck, copper coil, or sensor at the focus.
- **Coax + ground lugs** → reuse for **power-over-coax** to roof hardware; also good grounding straps.

## Fast conversion: dish → thermal assist
1) **Clean &amp; resurface:** bright aluminum tape or mirror film on the dish; paint the back matte to cut re-radiation.  
2) **Find focus:** point at the sun, use a white card to locate the bright spot along the arm (~35–45 cm for these dishes).  
3) **Absorber:** mount a **blackened copper coil** (¼″ OD, 3–5 turns) or a **black aluminum puck** at the focus; insulate its backside.  
4) **Plumb:** circulate brine or water (0.2 L/min typical). With ~200 Wᵗʰ onto the coil, ΔT ≈ **14 °C** (calc: \(P/(m\_w c\_p)\)).  
5) **Use cases:**  
   - **Community Node:** preheat brine/ROC feed for a mini-MD panel, or regenerate CaCl₂/silica-gel **HydroLens-DS** beds midday.  
   - **Demo:** visible “sun → hot brine” unit for investors &amp; students.

## Repurpose of the mount (no dish needed)
- Bolt on a **small PV** and lock tilt to site latitude (+/- seasonal tweak).  
- Mount an **MD panel** and use the az/el screws for precise slope/flow tuning.  
- Put the **dewpoint sensor pod** (from the LNB housing idea) on the mast; run 18 V up the existing coax with a TV power-inserter.

## Keep / toss checklist for this unit
- **Keep:** the whole az/el bracket (fine screws intact), mast clamp, dish (no big creases), the arm, any coax/hardware.  
- **Toss/replace:** cracked welds, seized adjusters (if penetrating oil won’t free them), water-logged coax.

## Safety
- Treat the dish as a **concentrator**—fit a **stow pin** and never aim at people/windows. Wear eye protection while focusing.  
- Salvaged metal/plastic is **non-potable contact** only; keep out of any drinking-water path.

### Bottom line
Grab these every time. Each one is a **ready-made outdoor pointing rig** and a **150–200 Wᵗʰ solar heater** with a few dollars of tape/coil. That’s immediate value for our **HydroLens desiccant regen**, **MD/brine preheat**, and **PV/sensor mounting**.

---

