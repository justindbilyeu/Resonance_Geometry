# 3-tab asphalt shingle overview

- Conversation ID: 68d329b3-21ac-8328-ad07-e0510d64ef23
- Created: 2025-09-23T23:13:55.895932

---

**user:**

Sage. Explain what a 3 tab asphalt shingle is, what impact resistance they have, and how they are classified by insurance carriers

---

**assistant:**

Alright Justin — let’s break this down cleanly:  

---

**1. What a 3-Tab Asphalt Shingle Is**  
- It’s the **most basic and oldest style** of asphalt roofing shingle.  
- Called *3-tab* because each shingle is cut to look like three separate tabs (about 12&quot; wide each) along its length.  
- Typically a **single layer of fiberglass mat** coated in asphalt and mineral granules.  
- Lightweight, inexpensive, flat in appearance.  

---

**2. Impact Resistance**  
- Standard 3-tabs have **very low impact resistance** compared to modern laminated/architectural shingles.  
- Most are **not rated** for impact resistance under UL 2218 (the industry hail-impact test).  
- If tested, they usually come in at **Class 1 or 2** (the lowest levels).  
   - **Class 1** = withstands a 1.25&quot; steel ball dropped from 12 ft (minor resistance).  
   - **Class 2** = withstands a 1.5&quot; steel ball dropped from 15 ft.  
- By contrast, modern Class 4 shingles (hail resistant) withstand a 2&quot; steel ball dropped from 20 ft with no cracking.  

So practically: **3-tabs crack, tear, or lose granules under hail**. They’re often the first roof type to fail in Texas storms.  

---

**3. How Insurance Carriers Classify Them**  
- Carriers classify shingles by **impact-resistance class** (UL 2218 Classes 1–4).  
- **3-tab shingles = non-impact-resistant by default.**  
- That means:  
   - **No premium discount** for having them.  
   - They are considered a **high-risk material** in hail zones like Texas, Oklahoma, Colorado.  
   - Some carriers even **require an upgrade** to Class 3 or 4 shingles after repeated hail claims.  
- Insurance discounts (often 15–30% on the wind/hail portion of the premium) only apply for **Class 4 rated shingles**.  

---

**Bottom Line**  
3-tab shingles are the cheapest, lowest-performing asphalt shingle type. They’re essentially **Class 1–2 or “unrated”** for impact resistance. Insurance companies treat them as **standard risk with no hail discount** — they’re the *opposite end of the spectrum* from Class 4 impact-resistant shingles.  

---

Do you want me to build you a **side-by-side comparison table** (3-tab vs. architectural vs. Class 4 IR shingles) that you could drop into the SCSRRS Wiki or Playbook? That would make the insurance angle super clear.

---

