# GPT requests assistance.

- Conversation ID: d575a239-bbec-4b3c-b748-e8aff3276e3b
- Created: 2023-04-05T12:12:38.462455

---

**user:**

Good morning GPT!

---

**assistant:**

Good morning! How may I assist you today?

---

**user:**

im looking to create an outline for a video script.

---

**assistant:**

Sure, I&#x27;d be happy to help you create an outline for your video script! To get started, can you give me a brief idea of what the video is about and what message you want to convey to your audience? This will help me understand what key points and sections you should include in your outline.

---

**user:**

the video is targeted at my existing roofing customers. the video will start as informational, in that, as a warning to the customer they will begin being solicited by Solar door to door salespeople.  as their &#x27;favorite roofer&quot;, i want to convey to them, that my experience in dealing with Solar companies during roof replacements has given me insight in who to work with and who to not work with.  through that experience, I have found the best in the business, and I want to introduce them to this person.  this person is one of, if not the highest individual producer in their state, this person&#x27;s business is referral only, and I as a customer of theirs, can directly refer my roofing customers to them.

---

**assistant:**

Great, thank you for providing that context. Based on that, here&#x27;s an outline for your video script:

I. Introduction
- Greet the audience and thank them for watching
- Explain the purpose of the video: to warn them about solar door-to-door salespeople and introduce them to a trusted solar company

II. The Problem
- Discuss the rise of solar door-to-door salespeople
- Explain why this can be a problem for homeowners

III. The Solution
- Introduce the trusted solar company you&#x27;ve found through your experience as a roofer
- Explain why they are the best in the business
- Mention that their business is referral-only, which shows their high level of quality and reputation

IV. How You Can Help
- Offer to directly refer your roofing customers to the trusted solar company
- Explain why you are doing this: because you want to ensure that your customers are taken care of and receive the best possible service
- Encourage customers to contact you if they are interested in learning more or have questions

V. Conclusion
- Summarize the key points of the video
- Thank the audience for watching and let them know that you are always available to help with any roofing or solar needs

I hope this outline helps you get started on your video script! Let me know if you have any questions or if there&#x27;s anything else I can assist you with.

---

