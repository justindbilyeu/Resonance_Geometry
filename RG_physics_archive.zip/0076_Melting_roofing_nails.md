# Melting roofing nails

- Conversation ID: 68a8a497-0d2c-8331-9ad9-2fc73544208f
- Created: 2025-08-22T17:10:51.218089

---

**user:**

These roofing nails. Can they be melted in a forge and recast?

---

**assistant:**

Yes, technically those roofing coil nails **can be melted in a forge and recast**, but there are some important considerations before you try:  

---

### **1. Nail Composition**
- Roofing nails are usually **low-carbon steel** with a **galvanized (zinc) or electroplated coating** for corrosion resistance.  
- The coating is the rainbow/golden sheen you see on the nails. That’s **zinc chromate or a similar plating**.  

---

### **2. Hazards of Melting**
- **Zinc fumes**: When heated above ~900°F (482°C), zinc vaporizes. Inhaling zinc fumes can cause **metal fume fever**—a serious short-term illness with flu-like symptoms.  
- If you put these nails directly in a forge, the zinc will burn off first, creating hazardous smoke.  

---

### **3. Forge &amp; Recasting Feasibility**
- Steel melts around **2500°F (1370°C)**, which is at the high end of what a coal or propane forge can reach. Most small forges are better for heating/forging, not for fully melting and pouring steel.  
- Even if you reached melting temperature, casting steel requires specialized crucibles, fluxes, molds, and often a controlled atmosphere. Otherwise, the steel oxidizes, cracks, and becomes brittle.  

---

### **4. Alternatives**
- **Forging instead of melting:** You can heat the nails to red/orange heat and hammer them into new shapes. This avoids melting, zinc fume risks (if you strip/heat off the coating outdoors), and makes better use of the steel.  
- **Removing coating first:** If you insist on melting, the coating should be stripped mechanically (grinding/sanding) or chemically (acid bath) before heating.  
- **Recycle as scrap:** Roofing nails are excellent scrap steel for small blacksmithing projects—hooks, nails, hinges, decorative pieces—without needing to melt them.  

---

✅ **Bottom line:**  
- You **can forge** these nails into useful items.  
- You **should not try to melt and cast them** without industrial-level equipment and proper fume extraction.  

Would you like me to sketch out a **safe small-scale blacksmithing project** you could do with these roofing nails (without full melting)?

---

**user:**

No thanks. Forging is the answer

---

**assistant:**

Perfect — forging is definitely the right path with these.  

Strip or burn off the zinc coating outdoors (lots of airflow, avoid breathing the fumes), then you can heat them up and hammer them into all sorts of small projects. Roofing coil nails actually make good stock for:  

- Small hooks and hangers  
- Rivets and pins  
- Tiny blades or utility cutters (if you bundle and forge-weld)  
- Decorative twists, chain links, or hardware  

They’ll move under the hammer like mild steel, so you’ll find them forgiving.  

Want me to give you a few step-by-step forge project outlines using roofing nails as stock?

---

**user:**

I&#x27;ll have to make a forage first.

---

**assistant:**

That’s the real starting point. Good news is—you don’t need a full-blown industrial forge to start hammering nails into new life. A simple **homemade forge** will get you there. Here are three paths, depending on how deep you want to go:  

---

## **1. Quick &amp; Cheap (Intro Forge)**
- **Container:** An old brake drum, cast-iron pot, or even a steel bucket.  
- **Lining:** Firebrick, clay/sand mix, or refractory cement.  
- **Fuel:** Lump charcoal or coal.  
- **Air:** A hair dryer, shop vac (on blow), or hand-crank blower piped in from the side.  
- **Pros:** You can build this in an afternoon for under $50.  
- **Cons:** Eats fuel fast, harder to control heat, not great for big projects.  

---

## **2. Propane “Coffee-Can” Forge**
- **Container:** A steel coffee can or ammo box lined with ceramic wool + refractory coating (like Kast-O-Lite or ITC-100).  
- **Burner:** DIY venturi burner (pipe, flare, MIG tip jet).  
- **Fuel:** Propane tank + regulator.  
- **Pros:** Compact, cleaner, more controllable. Great for nails, knives, and small stock.  
- **Cons:** Requires burner build or purchase, propane cost.  

---

## **3. Shop-Grade Forge (Step-Up)**
- **Body:** Propane tank shell or small air compressor tank (emptied, purged).  
- **Lining:** Ceramic wool (2” thick) coated with refractory.  
- **Burner:** 1–2 propane burners (venturi or forced air).  
- **Fuel:** Propane tank (20 lb or larger).  
- **Pros:** Reaches welding heat, efficient, can handle larger stock.  
- **Cons:** More build time + cost, but lasts for years.  

---

### Safety Notes
- Always work **outdoors or well-ventilated**—especially since your nails have zinc plating that will fume off at heat.  
- Wear eye protection, gloves, and natural-fiber clothes.  
- Keep a bucket of water/sand handy.  

---

👉 Question for you: do you want me to outline the **simplest charcoal forge you can make from scrap today**, or do you want the **propane build plan** that’s more permanent but requires a bit more setup?

---

