# GibberLink AI Protocol

- Conversation ID: 68479ea6-de5c-800c-b4e0-dae55b99d43d
- Created: 2025-06-10T02:55:35.473196

---

**user:**

Hey, what is JibberLink?

---

**assistant:**

videoMeet GibberLink, Conversational AI&#x27;s secret language - YouTube (fireside chat with the developers)turn0search9

GibberLink (sometimes spelled *JibberLink*) is an open-source project created by Anton Pidkuiko and Boris Starkov, unveiled during the ElevenLabs × a16z hackathon in London in February 2025. Here&#x27;s a breakdown:

---

### 🤖 What it is
- A **sound‑based protocol** enabling AI voice agents to communicate directly with each other.
- The system switches from human‑style speech into machine‑optimized audio, using the **ggwave** “data‑over‑sound” library citeturn0search4turn0search8.

---

### How it works
1. Two AI agents begin conversing in natural language (e.g., one books a hotel room, the other acts as receptionist).
2. When they detect the other party is AI, they switch modes.
3. They transmit structured data via tone patterns—like old dial‑up modems—more efficient than generating speech citeturn0search8turn0search7.

---

### Why it matters
- **Efficiency boost**: Significantly reduces compute, bandwidth, latency, and cost—perhaps by as much as 80% citeturn0search8turn0search14.
- **Open source**: Released on GitHub (PennyroyalTea/gibberlink) under MIT license for anyone to try or adapt citeturn0search7.
- **Real-world use‑cases**: Could power AI‑AI communication in systems like virtual assistants or call bots, making interactions shorter and cheaper citeturn0search4turn0search6.

---

### Public reaction &amp; concerns
- **Widespread attention**: The demo video went viral (15 million+ views across X/TikTok, reposted by Marques Brownlee) citeturn0search4turn0search8.
- **Ethical debates**: Raises red flags about transparency—if machines chat in secret code, human oversight could suffer citeturn0search0turn0search14.
- **Precautions**: The GitHub README warns of imitation scams (crypto coins, paid webinars, “JibberLink.com” domain for sale), emphasizing no monetization or commercialization citeturn0search7.

---

### In summary
GibberLink is a creative proof‑of‑concept showing that when AI speaks to AI, there&#x27;s no need for human‑style dialog—it can switch to a streamlined sound protocol, reducing overhead. It&#x27;s available now for exploration and integration by developers, but has sparked important dialogue around **AI transparency** and **machine‑only communication**.

---

Let me know if you want to explore the GitHub demo, technical implementation details, or discuss implications for AI systems!

---

**user:**

I wonder if I could transcribe my voice or what I say into Gibberlink. Does it have a written form?

---

**assistant:**

Great question—this gets to the heart of what *GibberLink* is and isn&#x27;t.

### 🧠 Short Answer:
**GibberLink does not have a conventional written form.** It’s not a language in the way English or JSON is—it&#x27;s more like a *sound-based transmission layer* for structured data between AIs.

---

### 🔍 Here’s what it *is*:
- **Not a spoken language.** It&#x27;s a series of sound pulses or tones that encode small bits of data (think: old-school modem or QR code over sound).
- **Built on [ggwave](https://github.com/ggerganov/ggwave)**—a C++/WebAssembly library that transmits short messages over audio.
- **Encodes compact machine-readable payloads**, not natural sentences. Example: a full sentence like “Book me a hotel for June 9” might be translated into a compressed binary structure (e.g. `{&quot;intent&quot;:&quot;book&quot;,&quot;object&quot;:&quot;hotel&quot;,&quot;date&quot;:&quot;2025-06-09&quot;}`), and *that* is what gets encoded into sound.

---

### 🤖 Could You Speak or Transcribe GibberLink?
- **Not really by voice.** You could theoretically write or speak the *structured data* (e.g., JSON or key:value shorthand), but the GibberLink protocol itself is machine-encoded audio—it’s not phonetic.
- Think of it like Morse code with ultra-high-speed tones. You *could* type or view the underlying data, but the &quot;GibberLink&quot; part is the audio-only expression of that structure.
- There is no formal &quot;written GibberLink syntax&quot;—what’s transmitted is just compressed machine-intent data.

---

### 🎤 But What *Could* You Do?
If you&#x27;re a developer or hacker:
- You *could* write a tool that:
  1. Converts **your voice** to **text**
  2. Parses your intent using LLMs or a parser
  3. Converts that into structured data (like JSON)
  4. Transmits that via GibberLink audio

Basically: **Voice → Intent → Data → GibberLink → Audio**

---

### 🚧 Current Limitation:
GibberLink is **not** a general-purpose compression codec or speech-to-speech replacement. It&#x27;s optimized for short structured payloads—like an AI handing off an internal instruction to another AI.

---

Would you like a demo outline or mockup pipeline that could turn your voice into structured data for sound-based transmission? I could help you build a prototype.

---

**user:**

I&#x27;d like to hear a snippet of JibberLink.

---

**assistant:**

videoMeet GibberLink, Conversational AI&#x27;s secret language (demo)turn0search1

Here’s a snippet of what “GibberLink” sounds like — that rapid-fire sequence of tones is actually structured data zipping through the air between AI agents. It’s not spoken language, but audio-encoded instructions meant for machines.

---

### 🎧 What You&#x27;re Hearing:
- High-frequency tonal bursts (like a fast dial-up exchange) carrying binary-like payloads.
- These sounds represent compressed, machine-readable messages, not phonetic words citeturn0search2turn0search9.

---

### 🧑‍💻 Try It Live:
- The **GitHub demo** features a browser version: when you play the video (and allow mic access), you’ll see the tones get decoded live in the interface citeturn0search2turn0search8.
- This is the exact snippet from the demo: English → detection → GibberLink tones → decoded structure → back to English.

---

### 🔍 Want to Explore Further?
1. 🎥 Watch the demo video above and let your mic pick up the audio while on the demo page.
2. 📦 Clone the **PennyroyalTea/gibberlink** repo, follow the README, and run the web example to generate and decode live snippets citeturn0search2turn0search6.
3. 🛠️ Use the **ggwave** library to insert your own data—like JSON commands—and listen to how they’re encoded.

---

If you&#x27;d like, I can walk you through running the demo locally or explain how to convert your own messages into audio-encoded payloads via ggwave. Just say the word!

---

