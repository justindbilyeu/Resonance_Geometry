# Fulcanelli the Alchemist

- Conversation ID: 68feca34-7cac-832b-abd1-ca522c184677
- Created: 2025-10-27T01:26:57.549933

---

**user:**

What do you know about  an alchemist named Fulcanelli?

---

**assistant:**

Short version: **Fulcanelli** is the pseudonym of a 20th-century French alchemist–author whose real identity remains unproven. He wrote two famously cryptic books that read Gothic architecture and old houses as *alchemical texts in stone*, and a cloud of legends—transmutations, nuclear warnings, and disappearing acts—has followed him ever since. citeturn1search0

**What’s generally agreed on**
- **Pseudonymous French adept, active c. 1910–1930s.** The name is often explained as a play on *Vulcan* (fire) + *El* (divinity). citeturn1search0  
- **Two core books:** *Le Mystère des Cathédrales* (1926) and *Les Demeures Philosophales* (1929/1930). They decode cathedral sculpture and historic architecture via hermetic symbolism; English editions appeared from Neville Spearman in 1971 and later reprints. citeturn1search0turn2search15turn2search1  
- **Ideas &amp; style:** heavy use of alchemical emblems, wordplay, and what he called the **“phonetic cabala”/language of the birds**—puns and assonance as keys to hidden meaning. citeturn1search0  
- **Circle &amp; transmission:** The illustrator **Julien Champagne** is closely tied to the project; **Eugène Canseliet** (who wrote the prefaces) presented himself as Fulcanelli’s student and editor. citeturn3search0turn1search1

**The legends (treated cautiously)**
- **A 1922 “Sarcelles” transmutation:** Canseliet later claimed he turned lead into gold at a gasworks using a pinch of his master’s *projection powder*; Champagne and Gaston Sauvage were said to be present. Historians treat this as lore, not verified fact. citeturn1search0  
- **A 1937 meeting about nuclear power:** Writer-chemist **Jacques Bergier** recounted that Fulcanelli warned of chain reactions and city-destroying “atomic explosives” just before fission’s discovery; the tale helped popularize the myth in *The Morning of the Magicians* (1960). Documentation is anecdotal. citeturn1search0  
- **A third book, *Finis Gloriae Mundi*:** often rumored; published versions attributed to Fulcanelli are widely regarded as inauthentic. citeturn1search0

**Who was he? (competing theories)**
Scholars and esoteric historians have proposed several candidates—**Jean-Julien Champagne** (the illustrator), **Pierre Dujols** (bookseller/erudite occultist), even physicist **Jules Violle**—or a collaborative authorship. None is conclusive. citeturn0search5turn0search14

**Where to read him now**
- *The Mystery of the Cathedrals* — modern English translations keep Champagne’s drawings; check reputable editions. citeturn3search16  
- *The Dwellings of the Philosophers* — the second (and last generally accepted) book. citeturn1search4  
- For context and identity research: Geneviève Dubois, *Fulcanelli and the Alchemical Revival* (Destiny Books). citeturn2search10

If you’re curious, I can:  
- pull key passages where he explains the “phonetic cabala,”  
- map his cathedral symbol set (Nigredo/Albedo/Rubedo, etc.) to specific carvings,  
- or compare the main identity hypotheses side-by-side with evidentiary pros/cons.

---

