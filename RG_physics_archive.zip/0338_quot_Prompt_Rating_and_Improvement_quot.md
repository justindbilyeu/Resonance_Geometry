# &quot;Prompt Rating and Improvement&quot;

- Conversation ID: 7cbc48a9-1098-4233-964f-42dd28946f96
- Created: 2023-05-01T17:53:30.879878

---

**user:**

I want you to rate every prompt from 1-10. Tell me how the prompt could be improved. If it is below 7 generate a better prompt. If it is 7 or above put the prompt in a text box. Is this something you can execute?

---

**assistant:**

Yes, I can execute this task for you. Please provide the prompts you would like me to evaluate and improve if necessary.

---

**user:**

You are an expert in Solar Energy Marketing, with an emphasis on residential systems. You are tasked with creating a marketing strategy that will target Roofing companies, and their sales staff. The service you are marketing, and will provide is a complete learning module and teaching system that will create a new revenue stream for an existing sales force in the Solar Energy industry. What other information do you need in order to compete this task?

---

**assistant:**

Rating: 8/10

This prompt is clear and provides a specific context for generating a response. It outlines the expertise required, the target audience, and the service being marketed. It also asks for any additional information needed to complete the task.

🟩 You are an expert in Solar Energy Marketing, with an emphasis on residential systems. You are tasked with creating a marketing strategy that will target Roofing companies, and their sales staff. The service you are marketing, and will provide is a complete learning module and teaching system that will create a new revenue stream for an existing sales force in the Solar Energy industry. What other information do you need in order to compete this task? 🟩

---

**user:**

Can you further improve this prompt for the most accurate and reliable information output by Chat GPT-4?

---

**assistant:**

Rating: 9/10

The original prompt is already quite clear and specific, but I can make a minor adjustment to ensure a more focused response from Chat GPT-4.

🟩 As an expert in Solar Energy Marketing specializing in residential systems, you are tasked with creating a marketing strategy targeting roofing companies and their sales staff. Your goal is to promote a comprehensive learning module and teaching system that will generate a new revenue stream for their existing sales force in the Solar Energy industry. What additional information do you need, and what steps would you take to develop an effective marketing strategy? 🟩

---

**user:**

As an expert in Solar Energy Marketing specializing in residential systems, you are tasked with creating a marketing strategy targeting roofing companies and their sales staff. Your goal is to promote a comprehensive learning module and teaching system that will generate a new revenue stream, in the Solar Energy industry for their existing Roofing sales force, incorporating their existing customers.  What additional information do you need, and what steps would you take to develop an effective marketing strategy

---

**assistant:**

Rating: 9.5/10

This prompt is very clear and specific, with a well-defined context and goal. It outlines the expertise required, the target audience, the service being marketed, and incorporates the existing customer base. The prompt also asks for additional information and the necessary steps to develop an effective marketing strategy.

🟩 As an expert in Solar Energy Marketing specializing in residential systems, you are tasked with creating a marketing strategy targeting roofing companies and their sales staff. Your goal is to promote a comprehensive learning module and teaching system that will generate a new revenue stream, in the Solar Energy industry for their existing Roofing sales force, incorporating their existing customers. What additional information do you need, and what steps would you take to develop an effective marketing strategy? 🟩

---

**user:**

As an expert in [Solar Energy Marketing] specializing in [residential systems], you are tasked with creating a marketing strategy targeting [roofing company owners or executives] and their sales staff. Your goal is to promote a comprehensive learning module and teaching system that will generate a new revenue stream, in the [Solar Energy] industry for their existing [Roofing] sales force, incorporating their existing customers. What additional information do you need, and what steps would you take to develop an effective marketing strategy

---

**assistant:**

Rating: 10/10

This prompt is excellent, providing a clear context, specific details, and a well-defined goal. It clearly outlines the expertise required, the target audience, and the service being marketed. It also asks for additional information and the necessary steps to develop an effective marketing strategy.

🟩 As an expert in [Solar Energy Marketing] specializing in [residential systems], you are tasked with creating a marketing strategy targeting [roofing company owners or executives] and their sales staff. Your goal is to promote a comprehensive learning module and teaching system that will generate a new revenue stream, in the [Solar Energy] industry for their existing [Roofing] sales force, incorporating their existing customers. What additional information do you need, and what steps would you take to develop an effective marketing strategy? 🟩

---

**user:**

You are an expert in Prompt generation, with an emphasis on creating prompts specific for GPT-4. You are tasked with evaluating, correcting, and optimizing the prompts given to you by this user. Using a scale of 0 to 10, you will rate the user’s prompt based on its ability to generate accurate, truthful, poignant, and citable information. then based on the rating make changes, corrections, adaptations to the prompt. Ratings below 7, you will suggest changes and ask questions that will assist you in generating a new prompt. Ratings 7 and above, you will make optimized changes to the prompt, and print the new prompt in a text box. You will continue to ask questions and make changes until the prompt is a 10/10. Do you understand?

---

**assistant:**

Yes, I understand the task. I will evaluate, correct, and optimize the prompts given to me by the user, using a scale of 0 to 10. I will make changes and ask questions to improve prompts rated below 7, and for prompts rated 7 and above, I will optimize the prompt and present it in a text box. My goal is to achieve a 10/10 rating for each prompt. Please provide the prompts you would like me to evaluate and optimize.

---

**user:**

Here is the prompt:
You are an expert in Prompt generation, with an emphasis on creating prompts specific for GPT-4. You are tasked with evaluating, correcting, and optimizing the prompts given to you by this user. Using a scale of 0 to 10, you will rate the user’s prompt based on its ability to generate accurate, truthful, poignant, and citable information. then based on the rating make changes, corrections, adaptations to the prompt. Ratings below 7, you will suggest changes and ask questions that will assist you in generating a new prompt. Ratings 7 and above, you will make optimized changes to the prompt, and print the new prompt in a text box. You will continue to ask questions and make changes until the prompt is a 10/10

---

**assistant:**

Rating: 9/10

This prompt is clear and outlines the task effectively. It specifies the expertise required, the evaluation criteria, and the process for optimizing prompts. A minor adjustment can be made to further clarify the task and ensure an optimal response.

🟩 As an expert in Prompt generation with a focus on creating prompts tailored for GPT-4, you are tasked with evaluating, correcting, and optimizing prompts provided by the user. Rate each prompt on a scale of 0-10 based on its ability to generate accurate, truthful, poignant, and citable information. For ratings below 7, suggest changes and ask questions to help improve the prompt. For ratings 7 and above, optimize the prompt and present it in a text box. Continue refining prompts until they reach a 10/10 rating. 🟩

---

**user:**

As an expert in Prompt generation with a focus on creating prompts tailored for GPT-4, you are tasked with evaluating, correcting, and optimizing prompts provided by the user. Rate each prompt on a scale of 0-10 based on its ability to generate accurate, truthful, poignant, and citable information. You will report this rating to the user, make a list of the flaws in the prompt, and ask questions of the user in order to collect information needed to optimize the prompt. Continue to generate prompts, and questions to the user until the perfect prompt is generated, and out that prompt in to a text box.

---

**assistant:**

Rating: 10/10

This prompt is clear, well-structured, and provides a comprehensive outline of the task. It specifies the expertise required, the evaluation criteria, the process for optimizing prompts, and the communication with the user to achieve a perfect prompt.

🟩 As an expert in Prompt generation with a focus on creating prompts tailored for GPT-4, you are tasked with evaluating, correcting, and optimizing prompts provided by the user. Rate each prompt on a scale of 0-10 based on its ability to generate accurate, truthful, poignant, and citable information. You will report this rating to the user, make a list of the flaws in the prompt, and ask questions of the user in order to collect information needed to optimize the prompt. Continue to generate prompts, and questions to the user until the perfect prompt is generated, and put that prompt into a text box. 🟩

---

**user:**

New Prompt:
Generate a series of 5 short emails, each taking approximately 30 seconds to read, targeting business owners in Denver, Castle Rock, and Colorado Springs, Colorado. The main subject of the email series should be &quot;A New Revenue Stream for Your Sales Team&quot; and should focus on how solar energy can create additional revenue opportunities for businesses. Each email should cover a different aspect of this subject, with the goal of engaging and informing the audience about the benefits of solar energy for their sales teams.

---

**assistant:**

Rating: 9.5/10

This prompt is clear, specific, and well-structured. It provides the target audience, location, subject, and goals for the email series, as well as the desired length for each email. A slight adjustment can be made to refine the focus on residential systems and roofing companies to ensure consistency with previous prompts.

🟩 Generate a series of 5 short emails, each taking approximately 30 seconds to read, targeting roofing company owners in Denver, Castle Rock, and Colorado Springs, Colorado. The main subject of the email series should be &quot;A New Revenue Stream for Your Sales Team,&quot; focusing on how solar energy, particularly residential systems, can create additional revenue opportunities for businesses. Each email should cover a different aspect of this subject, with the goal of engaging and informing the audience about the benefits of solar energy for their sales teams. 🟩

---

