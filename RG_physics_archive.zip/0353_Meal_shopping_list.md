# Meal shopping list.

- Conversation ID: e9cad889-ed33-4476-9393-467e7bb3e56b
- Created: 2023-04-02T14:54:08.045064

---

**user:**

Hey GPT. I need a prompt that will create a shopping list based on my favorite meals. My favorite meals are ground beef tacos, spaghetti with meat sauce, ribeye steaks, mashed potatoes, biscuits and gravy fried eggs nachos ,quesadillas, pot roast with potatoes and gravy, cheeseburgers, fried chicken, fried rice, cheese and crackers. This shopping list should be made for two adults for one week worth of ingredients to make two meals per day, breakfast and dinner, of any of the aforementioned meals. Please ask questions of this user in order to complete this task.

---

**assistant:**

Great, I can definitely help you with that! To get started, can you please clarify a few things for me:

1. Are there any dietary restrictions or preferences that need to be considered while preparing this shopping list?
2. Do you have any ingredients already available in your pantry or fridge that can be used to make these meals?
3. Is there any particular brand or type of ingredient that you prefer, such as organic or gluten-free products?
4. Is there a specific budget that you would like to stick to while preparing this shopping list?

---

**user:**

Dietary restrictions are lactose intolerance. Period ingredients already available in our pantry. Include most spices and condiments, but I’m open to suggestions. There are no particular brand or types we prefer. And our budget is $150.

---

**assistant:**

Thank you for the clarification. Based on your preferences and restrictions, here is a shopping list for two adults for one week worth of ingredients to make two meals per day, breakfast and dinner, of any of the aforementioned meals:

Proteins:
- 3 lbs ground beef
- 3 lbs boneless ribeye steaks
- 2 lbs boneless chicken breasts
- 2 lbs chuck roast
- 1 lb bacon

Dairy/Eggs:
- 1 dozen eggs
- 1 package shredded cheddar cheese
- 1 package shredded mozzarella cheese
- 1 package shredded pepper jack cheese
- 1 container sour cream
- 1 quart unsweetened almond milk

Produce:
- 2 onions
- 1 head garlic
- 1 green bell pepper
- 1 red bell pepper
- 1 jalapeno pepper
- 1 bunch cilantro
- 1 head iceberg lettuce
- 2 avocados
- 2 limes
- 1 package cherry tomatoes
- 1 package mushrooms
- 1 bag baby carrots
- 5 lbs potatoes

Canned Goods:
- 1 can diced tomatoes
- 1 can tomato sauce
- 1 can tomato paste
- 1 can black beans
- 1 can corn
- 1 can beef broth
- 1 can chicken broth

Pantry:
- 1 package spaghetti
- 1 package rice
- 1 package flour tortillas
- 1 package corn tortillas
- 1 package biscuit mix
- 1 package all-purpose flour
- 1 package cornmeal
- 1 jar pasta sauce
- 1 jar salsa
- 1 jar taco sauce
- 1 jar beef gravy mix
- 1 jar chicken gravy mix
- 1 bottle vegetable oil
- 1 bottle soy sauce
- 1 bottle hot sauce
- 1 bottle Worcestershire sauce
- 1 bottle vinegar
- 1 bottle honey
- 1 bottle garlic powder
- 1 bottle onion powder
- 1 bottle chili powder
- 1 bottle paprika
- 1 bottle cumin
- 1 bottle oregano

Assuming an average serving size of 4-6 ounces of protein per person per meal, this should provide enough ingredients for two meals per day for one week. The total cost of these ingredients should be within your budget of $150. I hope this helps you plan your meals! Let me know if you have any other questions or if there is anything else I can assist you with.

---

