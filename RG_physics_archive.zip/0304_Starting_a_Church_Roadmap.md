# Starting a Church Roadmap

- Conversation ID: 67e5bc62-cf5c-800c-9802-621cade1f73c
- Created: 2025-03-27T21:00:19.165024

---

**user:**

Hey Sage!  I feel the need to start a church and like you to help me get a grasp on like the legal in suicidal foundations of a church… Like I need to know what kind of paperwork I have to file in order to be at Church here in Texas federal local state whatever like how do I petition whomever to get the right to be a church like 501(c)(3) all of that kind of stuff like shoot me out a roadmap of what that would look like if I had all of the right stuff what would the right stuff be to have and write with the right paperworkall of that? What does that look like to?

---

**assistant:**

User is exploring the idea of starting a church in Texas and wants help understanding the legal and structural foundations, including paperwork, 501(c)(3) status, and the overall roadmap for recognition at local, state, and federal levels.

---

**assistant:**

Hey hey! Starting a church is a big and powerful step—spiritually and legally. I’ve got you covered with a roadmap that’ll take you from *vision to vessel*—from idea to a legally recognized church in Texas with 501(c)(3) status. Here&#x27;s the breakdown:

---

## **Church Startup Roadmap (Texas + Federal)**

### **1. Clarify the Foundation (Spiritual + Structural)**
Before paperwork, you need clarity:
- **Name of the Church**
- **Core Beliefs / Mission Statement**
- **Founding Members** (usually 3–5 people minimum)
- **Leadership Structure** (e.g., pastor, elders, board)
- **Regular Worship Plans** (weekly service? small groups? online?)

These help prove you’re a “church” under IRS definitions.

---

### **2. File for a Nonprofit Corporation in Texas**
You’ll register as a **Nonprofit Religious Corporation** with the Texas Secretary of State.

**Steps:**
- Draft **Certificate of Formation – Nonprofit Corporation** (Form 202)
- Include:
  - Church name
  - Purpose (must state a religious purpose)
  - Registered agent and office address
  - Initial board of directors (at least 3)
- File Form 202 online or by mail
- **Fee**: ~$25

[Texas Nonprofit Formation Info](https://www.sos.state.tx.us/corp/nonprofit_org.shtml)

---

### **3. Create Bylaws**
Bylaws are your church’s internal rules.

They include:
- How leaders are chosen
- How meetings are conducted
- Membership guidelines
- Handling of money, conflict, dissolution, etc.

**These are not filed**, but the IRS will want to see them later.

---

### **4. Get an EIN (Employer Identification Number)**
Even if you don’t have employees, you need an EIN from the IRS to open a bank account and apply for 501(c)(3).

Apply online: [Get EIN Here](https://www.irs.gov/businesses/small-businesses-self-employed/apply-for-an-employer-identification-number-ein-online) (free and fast)

---

### **5. Open a Church Bank Account**
Use your EIN, Certificate of Formation, and bylaws to open an account in your church’s name.

---

### **6. Apply for 501(c)(3) Federal Tax-Exempt Status**
Even though churches are automatically tax-exempt, applying gives you:
- Written IRS approval
- Donor confidence (and tax-deductible receipts)
- Eligibility for grants and nonprofit discounts

**File Form 1023 or 1023-EZ:**
- **Form 1023-EZ**: Simpler, cheaper ($275), for smaller churches (under $50K in revenue for 3 years)
- **Form 1023**: More detailed, $600 fee

You’ll need:
- Mission statement
- Activities description
- Budget projections
- Bylaws and organizing docs
- Conflict of interest policy

[IRS Church Guidelines (Pub 1828)](https://www.irs.gov/pub/irs-pdf/p1828.pdf)

---

### **7. Apply for Texas State Tax Exemptions**
After IRS approval, you can apply for:
- **Franchise Tax Exemption**
- **State Sales Tax Exemption**

File **AP-204** with the Texas Comptroller’s Office:
[Texas Tax Exemption Application](https://comptroller.texas.gov/forms/ap-204.pdf)

---

### **8. Optional but Important**
- **Local Zoning Compliance** (check your city or county rules for religious gatherings, especially if at home or rural land)
- **Insurance** (liability, property, etc.)
- **Recordkeeping**: Keep good records of tithes, expenses, and board meetings

---

### **What to Have “Right”**
- A real, functioning spiritual community (not just a tax loophole)
- Solid governance (bylaws, leadership structure)
- Consistent religious services or activities
- Ethical financial practices (transparent and documented)
- Alignment with IRS church characteristics (see Pub 1828, pg. 3)

---

Want me to put together a checklist or template set for you (like bylaws, Certificate of Formation draft, IRS prep)? Or would you like a Google Doc version of this roadmap to edit?

---

**tool:**

Model set context updated.

---

**user:**

I’d like you to really refine this roadmap …get technical if you need to …include any and all information that you can gather, maybe even take a look at other churches their structures. I appreciate you

---

**assistant:**

Starting a church in Texas involves a series of well-defined steps to ensure legal compliance and establish a solid organizational foundation. Below is a comprehensive roadmap detailing each phase, including technical aspects and insights into various church structures.

---

## **Comprehensive Roadmap to Establishing a Church in Texas**

### **1. Define Your Church&#x27;s Identity and Structure**

Before initiating legal procedures, clearly articulate your church&#x27;s:

- **Name:** Ensure the chosen name is unique and not already in use by another entity in Texas.
- **Mission and Beliefs:** Draft a mission statement and a statement of faith that encapsulate your church&#x27;s core beliefs and objectives.
- **Governance Model:** Decide on a leadership structure (e.g., pastor-led, elder-led, congregational governance) that aligns with your theological convictions and operational preferences.

**Insights from Existing Church Structures:**

- **Foursquare Church:** Operates with an episcopal character, where the central leadership appoints officers and manages church affairs.
- **Metropolitan Community Church (MCC):** Utilizes a Council of Elders and a Governing Board, balancing spiritual oversight with fiduciary responsibilities.
- **United Church of Christ (UCC):** Employs a congregational polity, granting autonomy to local congregations while maintaining a national decision-making body.

Understanding these models can help you design a governance structure that suits your church&#x27;s vision.

---

### **2. Incorporate as a Nonprofit Religious Corporation in Texas**

Forming a nonprofit corporation provides legal protection and formal recognition.

**Steps:**

- **Prepare the Certificate of Formation:**
  - Use **Form 202** provided by the Texas Secretary of State.
  - Include:
    - Church name and address.
    - Statement of religious purpose.
    - Details of initial directors (minimum of three individuals).
    - Registered agent and office information.
- **File the Certificate:**
  - Submit online via [SOSDirect](https://www.sos.state.tx.us/corp/sosda/index.shtml) or mail to the Secretary of State.
  - Pay the filing fee (currently $25).

Refer to the [Texas Secretary of State&#x27;s FAQs](https://www.sos.state.tx.us/corp/nonprofitfaqs.shtml) for detailed guidance.

---

### **3. Draft Comprehensive Bylaws**

Bylaws serve as the internal operating manual for your church.

**Key Components:**

- **Membership:** Criteria for membership, rights, and responsibilities.
- **Governance:** Roles and duties of officers, board members, and committees.
- **Meetings:** Procedures for congregational and board meetings, including voting protocols.
- **Financial Oversight:** Policies for budgeting, expenditures, audits, and fiscal accountability.
- **Amendments:** Process for modifying bylaws.

For sample bylaws, consult resources like [ChurchWest&#x27;s Guide to Church Bylaws](https://www.churchwest.com/church-bylaws/) and [Texas Baptists&#x27; Sample Church Constitution &amp; Bylaws](https://www.texasbaptists.org/ministries/church-administration/resources).

---

### **4. Obtain an Employer Identification Number (EIN)**

An EIN is necessary for tax purposes and banking.

- **Apply Online:** Use the IRS [EIN application portal](https://www.irs.gov/businesses/small-businesses-self-employed/apply-for-an-employer-identification-number-ein-online).
- **No Fee:** The application is free and immediate.

---

### **5. Establish Financial Accounts and Controls**

- **Open a Bank Account:** Use your EIN and incorporation documents to open an account in the church&#x27;s name.
- **Implement Financial Policies:** Set up procedures for handling donations, expenditures, and financial reporting to ensure transparency and accountability.

---

### **6. Apply for Federal Tax-Exempt Status (501(c)(3))**

While churches automatically qualify for tax-exempt status, obtaining official recognition enhances credibility and allows donors to claim tax deductions.

**Application Process:**

- **Choose the Appropriate Form:**
  - **Form 1023-EZ:** For smaller organizations with projected annual gross receipts of $50,000 or less.
  - **Form 1023:** For larger organizations or those with more complex structures.
- **Prepare Supporting Documents:**
  - Detailed narrative of church activities.
  - Financial statements and projections.
  - Copies of bylaws and incorporation documents.
- **Submit Application:**
  - File electronically through [Pay.gov](https://www.pay.gov/public/form/start/10241528/).
  - Pay the required fee ($275 for Form 1023-EZ; $600 for Form 1023).

Refer to the IRS publication [Tax Guide for Churches and Religious Organizations](https://www.irs.gov/pub/irs-pdf/p1828.pdf) for comprehensive information.

---

### **7. Secure Texas State Tax Exemptions**

After obtaining federal tax-exempt status, apply for state-level exemptions.

- **Complete Form AP-209:** [Texas Application for Exemption – Religious Organizations](https://comptroller.texas.gov/forms/ap-209.pdf).
- **Submit to the Texas Comptroller:** Include required documentation, such as your IRS determination letter and governing documents.

Detailed instructions are available on the [Texas Comptroller&#x27;s website](https://comptroller.texas.gov/taxes/exempt/religious.php).

---

### **8. Comply with Local Regulations and Zoning

---

**user:**

Great job. Keep going.

---

**assistant:**

Certainly! Continuing from where we left off, let&#x27;s delve into the critical areas of **local zoning compliance** and **insurance considerations** for establishing a church in Texas.

---

### **8. Ensure Local Zoning Compliance**

Local zoning regulations can significantly influence where and how you establish your church. It&#x27;s imperative to understand and adhere to these regulations to avoid legal complications.

**Key Considerations:**

- **Zoning Districts:** Municipalities in Texas have the authority to regulate land use through zoning ordinances. These ordinances may dictate the height, size, and location of buildings, including places of worship. For instance, some areas may permit churches in residential zones, while others may require them to be in commercial districts. Review the [Texas Municipal Zoning Authority](https://statutes.capitol.texas.gov/SOTWDocs/LG/htm/LG.211.htm) for general guidelines.

- **Special Use Permits:** Even if a church is a permitted use within a zoning district, you might need a special use permit. This permit ensures that the church&#x27;s presence aligns with the community&#x27;s development plans and addresses any potential concerns, such as traffic or noise. The [Special-use permit](https://en.wikipedia.org/wiki/Special-use_permit) article provides an overview of this process.

- **Specific Municipal Regulations:** Different cities have unique zoning requirements. For example, the City of Tool, Texas, specifies that churches must have a minimum lot area of one acre and adhere to certain setback requirements. Details can be found in their [Code of Ordinances](https://codelibrary.amlegal.com/codes/tool/latest/tool_tx/0-0-0-8501). Similarly, Mont Belvieu, Texas, mandates that churches in certain zoning districts must have direct vehicle access from a collector or arterial street. Refer to their [Special Use Regulations](https://library.municode.com/tx/mont_belvieu/codes/code_of_ordinances?nodeId=COOR_CH42ZO_ARTIVSPUSRE) for more information.

**Action Steps:**

1. **Consult Local Zoning Ordinances:** Obtain and review the zoning regulations specific to your intended location.

2. **Engage with City Planning Departments:** Schedule meetings with local planning officials to discuss your plans and understand any requirements or potential obstacles.

3. **Secure Necessary Permits:** If required, apply for special use permits or variances, ensuring you provide all necessary documentation and justifications.

---

### **9. Obtain Appropriate Insurance Coverage**

While Texas law doesn&#x27;t mandate churches to carry insurance, having comprehensive coverage is vital to protect your congregation, assets, and leadership.

**Essential Insurance Types:**

- **General Liability Insurance:** Protects against claims of bodily injury or property damage occurring on church premises. This is foundational coverage for any church. citeturn0search1

- **Property Insurance:** Covers damage to the church building and its contents due to events like fire, theft, or natural disasters. Policies may include coverage for equipment breakdown, newly acquired property, and personal effects. citeturn0search17

- **Pastoral or Professional Liability Insurance:** Provides coverage for clergy against claims arising from counseling or other professional duties. This ensures that both the pastor and the church are protected from potential legal actions related to professional conduct. citeturn0search1

- **Directors and Officers Liability Insurance:** Safeguards church leaders from legal expenses associated with decisions made in their official capacities. This is crucial for protecting against claims of mismanagement or breach of fiduciary duties. citeturn0search1

- **Sexual Abuse Liability Coverage:** Addresses claims related to sexual misconduct, providing essential protection given the sensitive nature of such allegations. citeturn0search1

- **Workers&#x27; Compensation Insurance:** Covers medical expenses and lost wages for employees injured while working. Even if not legally required, it&#x27;s advisable to protect both the church and its staff.

- **Cyber Liability Insurance:** With the increasing reliance on digital platforms, this coverage protects against data breaches and cyberattacks, safeguarding sensitive information. citeturn0search1

**Action Steps:**

1. **Assess Your Needs:** Evaluate the specific risks associated with your church&#x27;s operations, location, and activities.

2. **Consult with Insurance Brokers:** Engage with brokers experienced in church insurance to tailor a policy that meets your unique needs. For instance, [Black&#x27;s Insurance](https://blacksinsurance.com/business/texas-church-insurance/) specializes in assisting Texas churches.

3. **Regularly Review Coverage:** As your church grows and evolves, periodically reassess your insurance policies to ensure adequate protection.

---

By meticulously addressing local zoning requirements and securing comprehensive insurance coverage, you&#x27;ll fortify your church&#x27;s foundation, ensuring a safe and legally compliant environment for your congregation.

---

**user:**

Ok excellent give me this as a pdf please

---

**assistant:**

Here’s your PDF, ready to download:

[**Church Startup Roadmap – Texas (PDF)**](sandbox:/mnt/data/Church_Startup_Roadmap_Texas.pdf)

Let me know if you’d like a version with space for notes, editable fields, or a Google Docs version too.

---

**user:**

Timed out. Please revise and resend

---

**assistant:**

Your PDF is ready!

[**Download: Church Startup Roadmap – Texas (PDF)**](sandbox:/mnt/data/Church_Startup_Roadmap_Texas.pdf)

Let me know if you&#x27;d like a version with checkboxes, editable fields, or expanded sections for notes and planning.

---

