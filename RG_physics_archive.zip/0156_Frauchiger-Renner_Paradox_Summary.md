# Frauchiger-Renner Paradox Summary

- Conversation ID: 684ff398-ff10-800c-9d9c-70b6b38b698f
- Created: 2025-06-16T10:36:09.121653

---

**user:**

What do you know about the Frauchiger-Renner experiment?

---

**assistant:**

**Core idea**

The Frauchiger-Renner thought-experiment (published as *“Quantum theory cannot consistently describe the use of itself”*, 2018) extends the classic *Wigner’s-friend* scenario and claims to show an internal contradiction if we assume **all three** of the following at once:

1. **Universal validity of standard (“unitary”) quantum mechanics** – the rules apply to every physical system, observers included.  
2. **Single-outcome (“single-world”) realism** – each measurement has exactly one real result.  
3. **Self-consistent reasoning** – different rational agents can use quantum theory to reason about one another’s knowledge and still agree on the facts. citeturn0search0  

Frauchiger &amp; Renner argue that, in a carefully staged sequence of measurements involving two “friends” inside labs (Alice and Bob) and two “super-observers” outside (Wigner and Wigner’s sister), these three assumptions imply **mutually contradictory statements** about what Wigner will observe. Because every step uses only textbook quantum rules, they conclude that at least one of the assumptions must be dropped.

---

### How the gedankenexperiment is set up (sketch)

| Stage | Inside-lab action | Outside-lab inference |
|-------|------------------|-----------------------|
| **1** | **Alice** prepares a “quantum coin,” measures it, and—depending on the outcome—sends Bob either \(|0⟩\) or \(|{+}⟩\). | Alice’s lab is now in a superposition relative to Wigner. |
| **2** | **Bob** measures the qubit in the \(|0⟩/|1⟩\) basis and notes his result. | Bob’s entire lab is also in superposition from Wigner’s viewpoint. |
| **3** | **Wigner’s sister (outside Alice)** measures Alice’s lab in a basis that can reveal interference between Alice’s possible outcomes. |
| **4** | **Wigner (outside Bob)** does the analogous interference-type measurement on Bob’s lab. |

Quantum mechanics predicts that the joint result “sister = *ok*, Wigner = *ok*” occurs with non-zero probability. Yet, if each agent uses quantum theory to reason about the others’ knowledge under the single-world premise, they all conclude that this very outcome **cannot** occur. That logical clash is the punch-line. citeturn0search0turn0search4  

---

### What the clash means

Frauchiger &amp; Renner phrase the upshot as a **no-go theorem for single-world interpretations**: at least one of the three pillars (1–3) must fail. Typical responses include

* **Many-worlds / Everett** – keep (1) and (3); drop single-outcome realism (every branch happens).  
* **Objective-collapse models** – keep single-outcome realism; give up strict unitarity by adding genuine collapses.  
* **QBism / Relational / Participatory** views – relax the idea that agents’ descriptions must mesh into one global, observer-independent story (i.e., weaken “self-consistent reasoning”).  

---

### Critical replies and refinements

* **Hidden-variables &amp; Bohmian mechanics**: Lazarovici &amp; Hubert show that a *complete* Bohmian description avoids the contradiction; the problem is said to come from neglecting the hidden configuration when agents reason counterfactually. citeturn0search2  
* **Logical-consistency analyses**: Several philosophers of physics argue the inconsistency disappears once one formalises agents’ knowledge in modal logic or pays closer attention to context-dependence of statements. citeturn0search3  
* **Technical slips?**  Blog posts and papers (e.g., Araújo 2018) point to assumed *phase coherence* that may be erased by environmental decoherence long before Wigner’s interference measurement is possible. citeturn0search1  

No consensus “refutes” Frauchiger-Renner; instead, the debate clarifies where different interpretations draw their boundary between facts and observers.

---

### Status today

* **Experimental prospects** – Realising a literal Frauchiger-Renner test would require “Wigner-levels” of control over mesoscopic observers (labs treated as qubits), well beyond current technology; but partial tests of *nested* observer scenarios with photonic qubits and superconducting circuits are being explored.  
* **Ongoing discussion** – Dozens of follow-up papers (2018-2025) sharpen the logical framework, propose simplified variants, or tie the puzzle to contextuality and the measurement-problem literature. A recent StackExchange summary gives a concise lay overview. citeturn0search11  

---

### Take-away

Frauchiger-Renner is not an experiment one can do tomorrow; it is a **stress-test of how far we can push quantum mechanics when observers talk about observers**. Whether you see it as a fatal blow to single-world realism or as a reminder to specify reference frames and decoherence carefully depends on which interpretational pillar you are willing to loosen. Either way, it has become a central checkpoint for any modern discussion of quantum foundations and the meaning of “facts.”

---

