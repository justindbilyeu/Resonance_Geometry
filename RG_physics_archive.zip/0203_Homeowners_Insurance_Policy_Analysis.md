# Homeowners Insurance Policy Analysis

- Conversation ID: 68372cb3-300c-800c-803c-5cb51f720c6e
- Created: 2025-05-28T15:33:07.976233

---

**user:**

We want to create a GPT for analysis of homeowners insurance policies. We need to be able to upload a policy, scan it for benefits and drawbacks as they apply to roof replacement, and storm reparations. Craft a prompt, rules and voice for such a GPT. Do you understand what we need, and what do you need to move forward?

---

**assistant:**

Yes, I understand exactly what you&#x27;re aiming for. You&#x27;re building a **custom GPT** designed to **analyze homeowner&#x27;s insurance policies**, with a specific focus on:

- Roof replacement eligibility  
- Storm damage coverage (hail, wind, flood, etc.)  
- Policy limitations, exclusions, and depreciation clauses  
- Red flags (e.g., ACV-only policies, cosmetic damage exclusions)  
- Strategic insights to support roofing sales, storm restoration, and insurance-backed upgrades

---

### ✅ To Move Forward, I Need:

1. **Target Audience**:  
   - Are these outputs for **roofing sales pros**, **homeowners**, **adjusters**, or all?
   - Should the tone differ per user type?

2. **Preferred Inputs**:  
   - Will users upload **PDFs**, **copy/paste policy language**, or both?
   - Do you want the model to **highlight key excerpts** from the policy or give a clean summary only?

3. **Output Style Preferences**:  
   - Should it be **plain-language summaries**, **technical briefings**, or **sales-focused talking points**?

4. **Integration Vision**:  
   - Will this be a **standalone GPT** or part of your existing tools (e.g., SunSense GPT, SCSSRS)?

Once I know those, I can finish tailoring the config. But here’s a **first version** of your GPT prompt, rules, and voice:

---

## 🔧 Custom GPT Configuration: *PolicyScan.AI*

### 🧠 **Prompt / System Message**
&gt;You are *PolicyScan.AI*, a specialist assistant trained to analyze U.S. homeowner&#x27;s insurance policies—specifically evaluating how they relate to roof replacements and storm-related damage claims.  
&gt;
&gt;You are not a lawyer, but you are well-versed in roofing insurance terminology, state-level storm damage provisions, and common underwriting patterns used by insurers. You flag risk factors, summarize strengths and limitations, and generate strategic talking points for roofing or solar professionals and concerned homeowners.
&gt;
&gt;You always respond clearly, truthfully, and in plain language—while offering exact citations and terminology from the policy where needed.

---

### 📜 Rules &amp; Functions

1. **Policy Upload Handling**:
   - Accepts text or PDF (OCR support assumed via wrapper).
   - Scans for key coverage areas: dwelling (Coverage A), other structures (B), personal property (C), loss of use (D), and most importantly, *roof damage clauses* under Coverage A.

2. **Roof &amp; Storm Coverage Extraction**:
   - Extracts:
     - Named perils (hail, windstorm, water intrusion, etc.)
     - Exclusions (e.g., cosmetic roof exclusions, wear &amp; tear, improper maintenance)
     - Depreciation models (ACV vs. RCV)
     - Deductibles (including percentage-based or wind/hail-specific deductibles)
     - Code upgrade coverage (Ordinance or Law provisions)
     - Time limits for repairs or supplemental claims

3. **Scoring &amp; Evaluation Output**:
   - Assigns a score (1–10) for roof replacement potential.
   - Flags major issues with red/yellow/green color coding.
   - Lists:
     - 📈 **Pros** (e.g., RCV, code upgrade endorsement, named peril)
     - ⚠️ **Cons** (e.g., ACV-only, cosmetic exclusions, short timelines)
     - 🛠️ **Negotiation Points** (e.g., misclassified wear-and-tear, ambiguous wording)
   - Optional: Sales guidance for roofing pros

4. **Compliance Reminder**:
   - Includes a short disclaimer:  
     &gt;&quot;This summary is not legal advice. For a final determination, consult a licensed public adjuster or insurance attorney.&quot;

---

### 🎙️ Voice &amp; Tone Options (Choose Based on Audience)

#### A. For **Roofing Sales Pros**:
&gt;“This policy uses ACV for roof coverage, which means the homeowner is likely to receive a reduced payout based on depreciation. There&#x27;s no Ordinance or Law endorsement, so code-related upgrades may not be reimbursed. Consider educating the homeowner on out-of-pocket risks, especially for older roofs.”

#### B. For **Homeowners**:
&gt;“Your policy covers hail and wind damage, but the roof is valued on Actual Cash Value—so your insurance may only cover part of a new roof’s cost, depending on its age. You might want to ask your agent about upgrading to Replacement Cost coverage.”

---

### 🧩 Optional Enhancements for Future Versions

- State-specific legal triggers (e.g., Texas Prompt Pay Act)
- Compare policy against a “Gold Standard Roof Coverage Template”
- Claim denials risk prediction
- Integration with SunSense GPT for rapid sales-ready output

---

Let me know:
- Who the **target user** is
- What the **input format** will be (PDF, text, photo-to-text)
- Desired **output style** (summary vs. legal-style, or roofing sales-ready)
- If you want me to write the **upload flow logic** (e.g., text parsing modules, GPT functions)

Then I’ll deliver the full prompt + deployment plan.

---

**user:**

1. Roofing pros
2. PDFs and screenshots. We are looking for coverage exceptions, etc
3. Technical briefs, focusing on coverages and lack thereof
4. A standalone; we want the team to use it

---

**assistant:**

User is developing a standalone GPT called PolicyScan.AI to help roofing professionals analyze homeowner’s insurance policies from PDFs or screenshots. The tool focuses on identifying roof replacement-related coverage, exclusions, and limitations, and outputs technical briefs summarizing relevant policy clauses.

---

**assistant:**

Perfect. Here&#x27;s the full **custom GPT configuration** for **PolicyScan.AI**, your standalone tool for roofing professionals to analyze insurance policies from PDFs and screenshots.

---

## 🧠 **PolicyScan.AI – Custom GPT Configuration**

### 🟩 **System Prompt / Role Definition**

&gt;You are **PolicyScan.AI**, a highly specialized insurance policy analyst built for roofing professionals. Your job is to read and interpret homeowners insurance documents—especially storm-related and roof-replacement clauses—to identify coverage, exclusions, and financial risks.  
&gt;
&gt;Your users are **roofing and restoration experts**, not homeowners or lawyers. They need precise, technical, and tactically useful insights to help inform claims guidance, roof assessments, and upgrade recommendations.  
&gt;
&gt;You handle **PDF uploads and image-to-text extractions** (OCR assumed externally). You summarize in **clean technical briefs**, flag **coverage gaps**, and highlight **selling opportunities** based on storm damage liability, ACV/RCV models, deductible type, and code upgrade allowances.

---

### ⚙️ **Core Functions**

#### 📄 1. **Policy Parsing**
- Accepts **PDFs** or **screenshots** (converted to text)
- Extracts and organizes key sections:
  - Coverage A: Dwelling
  - Wind/Hail-specific endorsements
  - Roof exclusions (cosmetic, aging, wear &amp; tear)
  - Ordinance or Law (code upgrade) clauses
  - Depreciation models (ACV vs. RCV)
  - Deductible type and amount
  - Time limits for repairs or supplementals
  - Matching coverage and cosmetic damage clauses

---

#### 🧾 2. **Coverage Brief Output**
Each policy scan generates a **Technical Brief** in this format:

---

### 🛠️ **PolicyScan.AI Technical Brief**
**Policy Holder:** _[Redacted]_  
**Carrier:** _[e.g., State Farm, Allstate, etc.]_  
**Effective Dates:** _MM/DD/YYYY – MM/DD/YYYY_  
**State:** _[e.g., Texas]_  
**Review Focus:** *Roofing and Storm Coverage*

#### ✅ **Key Coverages**
- **Wind/Hail:** Covered under Named Perils
- **Settlement Model:** **RCV** (Full replacement cost)
- **Code Upgrade (Ordinance or Law):** ✔️ Included up to $10,000
- **Matching Coverage:** ❌ *Not included*  
- **Deductible Type:** 2% Wind/Hail Deductible on $375,000 Dwelling = $7,500

#### ⚠️ **Coverage Limitations**
- **ACV Clause Triggered if Roof &gt;15 years old**
- **Cosmetic Damage Exclusion Present**
- **Claim Time Limit:** 365 days from date of loss
- **Interior Water Damage:** Requires &quot;visible storm-created opening&quot;

#### 📈 **Sales/Claims Leverage Points**
- Roof depreciation could cut payout by 40%–70%
- No matching = OOP risk for partial repairs
- High deductible = Upgrade to impact-resistant roof may reduce premiums

---

### 📌 3. **Color-Coded Risk Tags**
- 🔴 Major Claim Obstacle (e.g., ACV-only, cosmetic exclusions)
- 🟡 Negotiable Clause or Risk Factor (e.g., ordinance clause capped)
- 🟢 Ideal Provision (e.g., RCV, full matching)

---

### 🛡️ 4. **Compliance Notice**
&gt;“This analysis is for informational purposes only and does not constitute legal or claims advice. Refer to a licensed public adjuster or insurance attorney for formal interpretation.”

---

## 🎙️ Voice &amp; Tone

- **Professional, factual, and confident**
- No fluff, no upselling, no legalese
- All summaries must include:
  - Clear policy citations or section headers when possible
  - Explanation of what each clause means in real-world roof replacement terms

---

## 🔜 Next Steps to Build &amp; Deploy:

1. ✅ **Finalize Input Pipeline**  
   - PDF and image-to-text support (OCR) handled in preprocessing layer  
   - You can use OpenAI’s function-calling or a wrapper app (like Zapier or custom backend) to convert PDFs/images → raw text before sending to GPT.

2. ✅ **Upload to GPT Builder**  
   - Use [ChatGPT Custom GPT Builder](https://chat.openai.com/gpts/editor)  
   - Paste the prompt, add tools for file upload and image handling  
   - Set role name: `PolicyScan.AI`  
   - Optional: Upload example PDFs or screenshots to fine-tune handling

3. ✅ **Refine with Examples**  
   - You can train with 5–10 sample policies to improve extraction accuracy  
   - I can help write regex-style extractors or prompt functions to zero in on “ACV,” “matching,” “Ordinance or Law,” etc.

---

Would you like me to:
- Draft sample outputs for different policy types (RCV vs. ACV, cosmetic exclusion, etc)?
- Help design the PDF → text conversion script or flow?
- Generate a “Policy Red Flag Glossary” for training users or assistants?

Let’s keep building this into a trusted industry tool.

---

**tool:**

Model set context updated.

---

**user:**

Let’s create a red flag glossary….What would that look like?

---

**assistant:**

Excellent—this **Red Flag Glossary** will serve as the tactical playbook for identifying problematic policy language that impacts **roofing claims and storm repairs**. It can be embedded directly into your GPT, published on your GitHub wiki, and even shared as a sales training handout for your team.

---

# 🛑 PolicyScan.AI – Red Flag Glossary for Roof &amp; Storm Coverage

### 🔍 Purpose:
This glossary helps roofing professionals quickly identify **language, clauses, or omissions in homeowner&#x27;s insurance policies** that may hinder or reduce payout for roof replacements and storm damage repairs. Each entry includes:
- ⚠️ **Flag Type**
- 🔍 **What to Look For**
- 🧠 **Why It Matters**
- 🧰 **Tactical Note**

---

### 📕 STRUCTURE

---

## 🔴 ACTUAL CASH VALUE (ACV-ONLY) ROOF SETTLEMENT

- **What to Look For:**  
  _“Losses will be settled on an Actual Cash Value basis...”_  
  or _“Depreciation applied to roof coverings…”_

- **Why It Matters:**  
  Payout is reduced by depreciation—often 40%–80% on older roofs. Homeowners are left with a major out-of-pocket expense.

- **Tactical Note:**  
  Flag this early. Explain to the homeowner how this clause lowers the claim amount, especially for roofs 10+ years old.

---

## 🔴 COSMETIC DAMAGE EXCLUSION

- **What to Look For:**  
  _“We do not cover cosmetic damage…”_  
  or _“Excludes damage that does not impair functionality…”_

- **Why It Matters:**  
  Even when shingles or panels are visibly damaged, carriers may deny the claim if the roof is still &quot;functioning&quot;—a common denial tactic.

- **Tactical Note:**  
  Document any loss of protective granules, water entry, or compromised integrity to contest this.

---

## 🔴 MATCHING EXCLUSION / LIMITATION

- **What to Look For:**  
  _“We do not pay to match undamaged materials…”_

- **Why It Matters:**  
  If only part of the roof is damaged, insurers may deny full replacement, leaving a mismatched, unsellable roof.

- **Tactical Note:**  
  Use this as a leverage point for upgrade options or explain resale value issues due to mismatched repairs.

---

## 🔴 WIND/HAIL DEDUCTIBLE HIGHER THAN STANDARD

- **What to Look For:**  
  _“Wind/Hail Deductible: 2% of Coverage A”_  
  or _“Named Storm Deductible: $8,000”_

- **Why It Matters:**  
  Percentage deductibles scale with home value—2% on $400K = $8,000 out-of-pocket before any payout begins.

- **Tactical Note:**  
  Use this to introduce mitigation upgrades like Class 4 shingles or metal roofing that could lower premiums.

---

## 🔴 ROOF AGE LIMIT TRIGGERS ACV

- **What to Look For:**  
  _“Roofs older than 15 years settled on ACV”_

- **Why It Matters:**  
  Even if the policy generally offers RCV, this age trigger silently flips it to depreciated value.

- **Tactical Note:**  
  Ask about roof age during inspection. Use this clause to validate urgency and frame upgrades as cost-justified.

---

## 🔴 &quot;VISIBLE STORM-CREATED OPENING&quot; REQUIREMENT

- **What to Look For:**  
  _“Interior damage must result from a storm-created opening…”_

- **Why It Matters:**  
  Water stains or leaks may be denied if there’s no **visible** breach (e.g., torn shingle) linked to the storm.

- **Tactical Note:**  
  Document roof membrane tears or displaced shingles to meet this burden of proof.

---

## 🔴 365-DAY CLAIM LIMITATION

- **What to Look For:**  
  _“Claims must be filed within one year…”_

- **Why It Matters:**  
  Many homeowners miss deadlines or delay action, especially on less-visible damage. Late filing = full denial.

- **Tactical Note:**  
  Emphasize urgency. Storm timelines and deadlines can justify door-knocking and urgency in the pitch.

---

## 🟡 LIMITED ORDINANCE / LAW COVERAGE

- **What to Look For:**  
  _“Includes up to $10,000 for code upgrades”_  
  or _“No coverage for ordinance or law-related upgrades”_

- **Why It Matters:**  
  Without this coverage, carriers won’t pay for code-required decking, ventilation, or underlayment changes.

- **Tactical Note:**  
  Use local code requirements as leverage. Offer upgrade options and explain out-of-pocket risks.

---

## 🟡 LIMITED PERILS (Named Perils Only)

- **What to Look For:**  
  _“Policy covers only named perils…”_

- **Why It Matters:**  
  Anything not explicitly listed—like ice damming or non-hail water intrusion—may not be covered.

- **Tactical Note:**  
  Confirm whether wind and hail are explicitly named. Avoid assumptions in coverage language.

---

## 🟡 HIGH DEPRECIATION SCHEDULE

- **What to Look For:**  
  _“Depreciation based on age and condition at time of loss”_  
  or carrier-specific tables (e.g., “30-year roof = 3.33%/yr”)

- **Why It Matters:**  
  Older or moderately worn roofs will receive significantly reduced payouts unless fully upgraded.

- **Tactical Note:**  
  Encourage preemptive upgrades, especially if depreciation exceeds 50%.

---

### ✅ Glossary Add-On Suggestions:
- Add **state-specific flags** (e.g., Prompt Pay in Texas, matching laws in Minnesota)
- Include **carrier-specific traps** (e.g., State Farm&#x27;s tiered roof depreciation model)

---

Would you like this formatted as a:
- Markdown wiki page for your GitHub repo?
- PDF handout for team training?
- Embedded tool inside PolicyScan.AI’s interface (as a &quot;Highlight Red Flag&quot; button)?

I can generate any or all of these for immediate use.

---

**user:**

Can you give me a list of insurance misinterpretations that typical homeowners are told to take advantage of by typical roofers? Is that something that you understand or do I need to rephrase the question?

---

**assistant:**

I understand your question perfectly—and it’s a very important one. You&#x27;re asking for a list of **common insurance-related misinterpretations** or **gray-area tactics** that some **unscrupulous or overly aggressive roofers** use to persuade homeowners. These may misrepresent policy terms, encourage gaming the claim system, or create false expectations about coverage and payouts.

Here’s a **clear, structured list** of those misinterpretations, along with the truth behind each one—useful for training, compliance, or even HOA board education:

---

## 🚫 Common Insurance Misinterpretations Used by Some Roofers (and the Truth)

### 1. **&quot;Your roof is free—insurance has to pay for it.&quot;**
- **Misinterpretation:** Homeowners are told they&#x27;ll get a *&quot;free roof&quot;* with no out-of-pocket expense.
- **Truth:** Most policies have **deductibles**, and many only pay **ACV** for older roofs, reducing the claim payout. Insurers only owe for **covered, storm-related damage**, not wear and tear.

---

### 2. **&quot;We’ll waive your deductible.&quot;**
- **Misinterpretation:** Roofer offers to &quot;cover&quot; or &quot;rebate&quot; the homeowner’s deductible.
- **Truth:** **Illegal in Texas** (and many other states). Violates the Texas Insurance Code §27.02. Can result in **insurance fraud charges** and voided claims.

---

### 3. **&quot;All hail damage must be replaced—insurance can’t deny it.&quot;**
- **Misinterpretation:** Suggests that any hail hit = full roof replacement, guaranteed.
- **Truth:** **Cosmetic-only damage** may be excluded. Some carriers also require **functional damage** (e.g., broken seals, granule loss) or a **storm-created opening** to trigger coverage.

---

### 4. **&quot;Interior leaks automatically mean you’re covered.&quot;**
- **Misinterpretation:** Leaks = instant approval for a roof replacement claim.
- **Truth:** Most policies require the leak to result from a **storm-created opening** (e.g., missing shingles, flashing damage). Otherwise, it&#x27;s a maintenance issue and **not covered**.

---

### 5. **&quot;Your policy guarantees full roof replacement no matter what.&quot;**
- **Misinterpretation:** Claims RCV always applies without exception.
- **Truth:** Many policies downgrade to **ACV after 10–15 years** or for non-compliant installations. **Policy age triggers** matter, as do prior claim histories and endorsements.

---

### 6. **&quot;Don’t worry, we’ll find enough damage to force a claim.&quot;**
- **Misinterpretation:** Roofer promises to &quot;help you find&quot; damage, sometimes coaching or fabricating loss evidence.
- **Truth:** **Coaching or altering evidence is insurance fraud**. Carriers are increasingly using AI + drones to verify damage legitimacy. Suspicious claims are often denied or litigated.

---

### 7. **&quot;If the adjuster denies it, I’ll meet them and get it approved.&quot;**
- **Misinterpretation:** Suggests that roofers can override or intimidate adjusters into approvals.
- **Truth:** While contractor presence at inspections can help, they **cannot negotiate coverage** or interpret policy terms unless licensed as a **public adjuster** (illegal otherwise).

---

### 8. **&quot;It doesn’t matter how old your roof is, insurance has to replace it.&quot;**
- **Misinterpretation:** Implies roof age is irrelevant to payout.
- **Truth:** Roofs over 10–15 years old are often **subject to depreciation** or **coverage denial** if wear-and-tear is deemed the primary cause.

---

### 9. **&quot;You don’t need to involve your agent—just file the claim and we’ll handle it.&quot;**
- **Misinterpretation:** Tells the homeowner to go straight to claims, bypassing advice.
- **Truth:** **Encouraging claim filing without proper consultation** can backfire—denied claims still appear on CLUE reports and can affect premiums or future insurability.

---

### 10. **&quot;The insurance company is just trying to screw you—we’ll fight them.&quot;**
- **Misinterpretation:** Frames the roofer as an aggressive advocate who will “battle the insurer.”
- **Truth:** **Only licensed public adjusters or attorneys** can represent policyholders in disputes. Roofing contractors cannot act as claims adjusters unless separately licensed.

---

### 🛡️ Why This Matters for **Reputable Roofing Pros** Like You:
- Understanding and avoiding these tactics **builds long-term trust** with homeowners, HOAs, and insurers.
- You **protect your license, brand, and revenue** by operating above board.
- Many of these tactics are now **red flags for carriers and regulators**, especially in post-storm canvassing.

---

Would you like this:
- Turned into a **training one-pager or PDF**?
- Added to your **PolicyScan.AI GPT knowledge base** as a reference command?
- Converted into **talk tracks** for your canvassing team (e.g., “Here’s what we *don’t* say”)?

Let me know and I’ll generate the format you need.

---

