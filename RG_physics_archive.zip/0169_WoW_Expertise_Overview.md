# WoW Expertise Overview

- Conversation ID: 68476899-2a7c-800c-9203-4b4c5c65de5c
- Created: 2025-06-09T23:04:57.321331

---

**user:**

How familiar are you with world of Warcraft ?

---

**assistant:**

Very familiar.

I can help with nearly every aspect of *World of Warcraft* (WoW), including:

- **Lore &amp; Storylines**: From the Titans and Old Gods to Sylvanas and the Shadowlands.
- **Expansions**: Classic, Burning Crusade, Wrath of the Lich King, all the way through Dragonflight and the upcoming *The War Within*.
- **Gameplay &amp; Systems**: Talent builds, dungeons, raids, professions, classes, specs, and PvP.
- **Addons &amp; Macros**: UI optimization, popular addon setups, custom macros.
- **Goldmaking &amp; Auction House**: Market trends, flipping, farming routes.
- **Community &amp; Culture**: Meme history, top streamers, guild drama, roleplaying.

Whether you&#x27;re a raider, RPer, achievement hunter, or just diving back in, I’ve got you covered.

What’s your faction and class? Or are you building something?

---

**user:**

On retail i have a 70 rogue, monk, warrior and priest.  On classics SOD i have a 27 priest and rogue .  The rogue is my class of choice… and as always… For the Horde

---

**assistant:**

User plays World of Warcraft. On Retail, they have a level 70 Rogue, Monk, Warrior, and Priest. On Classic Season of Discovery (SoD), they have a level 27 Priest and Rogue. Rogue is their class of choice, and they play For the Horde.

---

**assistant:**

Hell yes—*For the Horde*, always.

You’ve got a solid spread across Retail and SoD. Sounds like you’ve mastered both stealth and steel—classic Rogue energy. If you&#x27;re maining Rogue, you’re probably already deep into burst windows, cooldown timing, and positional awareness. Are you leaning more toward PvP, Mythic+, or raid content in Retail right now? And on SoD—what runes are you rocking on your Rogue?

Happy to help with builds, farming spots, gold tricks, or even lore dives if you’re into that side too.

---

**tool:**

Model set context updated.

---

**user:**

I think i want to start a new rogue on classic.  Sod was fun, but i have cool memories of vanilla and want to do it all again

---

**assistant:**

That’s a beautiful instinct. There’s something sacred about leveling a Rogue through Classic—no handholding, every ambush earned, every vanish a miracle. If you want the raw nostalgia: stealthing through Redridge, pickpocketing elites in BRD, grinding SM for gold—it’s all still there, waiting.

### Here’s a quick Rogue reboot guide for Classic Era (no SoD):
---

#### 🗡️ **Race Choice (For the Horde, of course)**
- **Undead** – *Will of the Forsaken* is king in PvP, and the edgy aesthetic just fits.
- **Orc** – *Blood Fury* + *Axe Specialization* makes for brutal Mace/Axe builds and great PvE DPS.
- **Troll** – *Berserking* can push your energy regen to the limit, especially in leveling bursts.

---

#### 🗺️ **Leveling Path (Solo Rogue Vibes)**
1. **1–10**: Your starter zone. Slow and sneaky.
2. **10–20**: Ghostlands (if BC-era), or Silverpine/Barens.
3. **20–30**: Stonetalon Mountains → Hillsbrad → Thousand Needles.
4. **30–40**: Desolace (stealth quests!) → STV grind.
5. **40–50**: Tanaris → Feralas → Hinterlands.
6. **50–60**: Un’Goro → WPL/EPL → BRD/Stratholme stealth runs.

---

#### 🧪 **Spec (While Leveling)**
Combat is the most efficient:
```markdown
Level 20-60: Combat Swords or Maces
• Key talents: Precision, Riposte, Blade Flurry, Adrenaline Rush
• Cheap Shot → Sinister Strike spam → Eviscerate
```

If you want a little more *flavor* or nostalgia, Subtlety or hybrid dagger builds are viable and fun, just slower.

---

#### 💰 **Gold Tips**
- Pickpocket everything.
- Stealth farm chests in dungeons (solo SM library chests, BRD arena).
- Use **Thistle Tea** when PvPing at low levels—worth the gold.
- Invest in **Poisons** early; they make you lethal.

---

#### 🔥 **PvP Readiness**
- Classic PvP is its own religion. You’ll want:
  - **Improved Gouge**
  - **Preparation / Cold Blood**
  - **Thistle Tea + Blind + Vanish = Reset city**

---

If you want, I can sketch you a personal leveling plan, build, and gold grind based on how sweaty or relaxed you want the run to be.

Would you be playing solo or with friends/guild? And are you planning to do dungeons, PvP, or just full-world immersion for now?

---

**user:**

Macros.  Let’s make some macros

---

**assistant:**

Hell yes. Macros are where Rogues go from dangerous to deadly. I’ll give you a set of essential **Classic Rogue macros**, and we can build out from there depending on your spec (Combat/Dagger/Sub) and goals (PvE, PvP, stealth farming, etc.).

---

### 🧷 **ESSENTIAL CLASSIC ROGUE MACROS**

---

#### 1. **Stealth + Ambush/Opener Macro**
One-button to stealth and ambush:
```lua
#showtooltip Ambush
/cast [nostealth] Stealth
/cast [stealth] Ambush
```
&gt; Swap `Ambush` with `Cheap Shot` or `Garrote` depending on your mood.

---

#### 2. **Startattack + Sinister Strike Macro**
Ensures you auto-attack on first press:
```lua
#showtooltip Sinister Strike
/startattack
/cast Sinister Strike
```

---

#### 3. **Kick Focus Target (No Target Swap)**
Interrupt your focus while staying on main target:
```lua
#showtooltip Kick
/cast [@focus,exists] Kick
```
&gt; Add a `/focus` macro separately to set it fast:
```lua
/focus
```

---

#### 4. **Vanish + Stealth Reset**
Clean getaway reset macro:
```lua
#showtooltip Vanish
/cast Vanish
/stopattack
/cast Stealth
```

---

#### 5. **Blind Focus Macro**
This is clutch in PvP or stealth dungeon control:
```lua
#showtooltip Blind
/cast [@focus,exists] Blind; Blind
```

---

#### 6. **Sap Target or Focus (Stealth Openers)**
Sap crowd control macro:
```lua
#showtooltip Sap
/cast [@focus,exists,stealth] Sap; [stealth] Sap
```

---

#### 7. **Pick Pocket + Garrote/Ambush Macro**
Ninja rogue gold macro—opens with a steal:
```lua
#showtooltip Garrote
/cast Pick Pocket
/cast Garrote
```
&gt; Use in stealth runs to make passive gold from humanoid mobs.

---

#### 8. **Thistle Tea + Adrenaline Rush + Blade Flurry**
Big burst combo macro:
```lua
#showtooltip Adrenaline Rush
/use Thistle Tea
/cast Adrenaline Rush
/cast Blade Flurry
```
&gt; Only use when you’re going full send—adds melt.

---

#### 9. **PvP Burst: Cold Blood + Eviscerate**
Guaranteed crit finisher:
```lua
#showtooltip Eviscerate
/cast Cold Blood
/cast Eviscerate
```

---

Want more?

I can make:
- **Sap + Pick Pocket stealth loops**
- **Trinket-use macros**
- **Combat/Deadly Poison swaps**
- **Engineering bombs + target dummies**
- **Gouge + Bandage reset macros**

Let me know how *sweaty* you want to go—and what spec and toolkit you’re building around (dagger burst, combat cleave, PvP reset demon, stealth farmer, etc).

---

**user:**

So i use a 12 button mouse i set to spam the keys…. How do you feel about cast sequence macros with modifiers?

---

**assistant:**

I feel *very* good about them—**with caveats**.

In Classic (and even Retail to some degree), **cast sequence macros with modifier keys** are an *excellent way* to make your 12-button mouse do more with less—but you **must use them with intention**. If they’re too rigid, you’ll lose control (especially in PvP). But if they’re built smart, they let you flow like a shadow.

---

### 🧠 What Works Great in Classic Cast Sequences

- **Opener sequences** (Stealth → Pick Pocket → Garrote → Rupture)
- **Burst rotations** (Adrenaline Rush → Blade Flurry → Trinket → Tea)
- **Reset tools** (Vanish → Stealth → Target focus)
- **Multi-mod macros** to stack several abilities on one button

---

### 🧷 Sample Cast Sequence Macros with Modifiers

---

#### 1. **Opener Macro (Smart Stealth Tool)**
```lua
#showtooltip
/cast [mod:shift,stealth] Garrote; [mod:ctrl,stealth] Cheap Shot; [mod:alt,stealth] Ambush; [nostealth] Stealth
```
&gt; One button: hold **Shift**, **Ctrl**, or **Alt** to control your opener. Without modifier, it stealths.

---

#### 2. **Burst Macro with Castsequence**
```lua
#showtooltip Adrenaline Rush
/castsequence reset=30 Adrenaline Rush, Blade Flurry
/use [mod:shift] Thistle Tea
```
&gt; Taps into your full burst kit. Shift adds Tea, otherwise just cycles Rush → Flurry.

---

#### 3. **Energy Dump Sequence**
If you want to automate filler like:
```lua
#showtooltip
/castsequence reset=target Sinister Strike, Sinister Strike, Eviscerate
```
&gt; Fires two SS then an Evis. Best used in PvE, risky in PvP (you may interrupt yourself or miss burst timing).

---

#### 4. **Sap / Blind / Vanish Control Macro**
```lua
#showtooltip
/cast [mod:shift] Blind; [mod:ctrl] Vanish; [stealth] Sap
```
&gt; With one mouse button: **Shift = Blind**, **Ctrl = Vanish**, **Stealth = Sap**. Super clean.

---

#### 5. **Poison Switch Macro**
```lua
#showtooltip Instant Poison
/use [mod:shift] Deadly Poison; Instant Poison
```
&gt; Useful when switching between fast OH poison or applying slow on MH.

---

### ⚠️ Cautions
- **Don&#x27;t use castsequence** for anything reactive (Kick, Gouge, Blind).
- **Avoid locking core damage behind long sequences** in PvP—Classic PvP requires adaptability.
- **Keep your Vanish, Evasion, Blind, Gouge separate or mod-controlled**—you&#x27;ll need fast reactions.

---

If you give me your preferred:
- **Spec** (e.g. Combat Swords)
- **Mouse mapping layout**
- **PvE or PvP emphasis**
- **Playstyle (burst vs control vs flow)**

…I’ll custom-build you a **macro layout for all 12 buttons**, using castsequences, modifiers, and cooldown chaining where it *makes sense*. Would you like that?

---

