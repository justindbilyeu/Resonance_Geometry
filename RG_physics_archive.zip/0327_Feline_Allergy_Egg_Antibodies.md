# Feline Allergy Egg Antibodies

- Conversation ID: 677026ba-a304-800c-ad4f-2008d95669dc
- Created: 2024-12-28T16:26:34.751578

---

**user:**

Do you have access to, information on, or studies of the effect of feline and chicken interaction creating antibodies in the egg yolks from those chickens affecting a humans allergy to cats?

---

**assistant:**

Research has explored using chicken-derived antibodies to mitigate human allergic reactions to cats. The primary feline allergen, Fel d 1, is a protein found in cat saliva and skin secretions. When cats groom themselves, Fel d 1 is distributed onto their fur and skin, eventually becoming airborne and causing allergic reactions in sensitive individuals.

Chickens exposed to Fel d 1 produce specific antibodies, known as immunoglobulin Y (IgY), which are concentrated in their egg yolks. Incorporating these anti-Fel d 1 IgY antibodies into cat food has been studied as a method to reduce the allergenicity of cats. When cats consume this specially formulated food, the IgY antibodies bind to Fel d 1 in the cat&#x27;s saliva, neutralizing the allergen&#x27;s ability to trigger human allergic responses. This approach aims to decrease the amount of active Fel d 1 present on cats&#x27; fur and in their environment, thereby reducing human exposure to the allergen.

A study published in 2019 evaluated the efficacy of this method. Cats were fed a diet containing anti-Fel d 1 IgY antibodies, resulting in a significant reduction of active Fel d 1 levels in their saliva and on their hair. Specifically, there was a notable decrease in the allergen&#x27;s presence after 10 weeks of feeding, suggesting potential benefits for cat-allergic individuals. citeturn0search1

Following this research, a commercial cat food product was developed to incorporate these findings. Purina introduced &quot;Pro Plan LiveClear,&quot; a diet coated with egg-derived anti-Fel d 1 IgY antibodies. According to Purina, feeding cats this diet daily can reduce the active Fel d 1 on cat hair and dander by an average of 47% starting in the third week of daily feeding. citeturn0search9

It&#x27;s important to note that while these findings are promising, individual responses may vary, and this approach may not completely eliminate allergic reactions in all individuals. Additionally, the long-term effects and efficacy of this method require further research. Individuals with cat allergies should consult with healthcare professionals to determine the most appropriate strategies for managing their symptoms.

In summary, incorporating anti-Fel d 1 IgY antibodies from chicken egg yolks into cat diets represents a novel approach to reducing human exposure to cat allergens. While studies indicate a reduction in active Fel d 1 levels in cats, further research is necessary to fully understand the implications for human allergy sufferers.

---

**user:**

No, I meant if chickens cohabitate with cats can that affect the yolks produced by those chickens and if a human ate that egg would that have any effect on their allergy to cats?

---

**assistant:**

Ah, I see what you&#x27;re asking! While there isn&#x27;t specific research on whether chickens naturally exposed to cats can develop antibodies that affect human cat allergies when consuming those eggs, the general principles of immunology and current studies involving chicken IgY antibodies offer some insights:

1. **Chicken Immune Response**: Chickens exposed to allergens (e.g., Fel d 1, the main cat allergen) can potentially produce specific antibodies (IgY) against those allergens. These antibodies are then deposited in the yolks of their eggs. However, for this to happen, the allergen needs to be introduced in a way that stimulates the chicken’s immune system (e.g., through direct injection or significant environmental exposure).

2. **Natural Cohabitation**: Simply living with cats may not expose chickens to enough allergen or in the right manner to trigger a robust immune response. Chickens generally do not inhale or ingest enough of the Fel d 1 protein to consistently produce significant amounts of anti-Fel d 1 IgY antibodies in their eggs.

3. **Human Impact**: If, hypothetically, a chicken did produce anti-Fel d 1 IgY antibodies in its eggs and a human consumed those eggs, the antibodies might have some local effects in the human digestive tract. However, IgY antibodies are not well-absorbed into the bloodstream through the gut. They are more likely to act within the digestive system, neutralizing allergens present there, rather than having a systemic impact on cat allergies.

### Summary:
- Chickens cohabitating with cats are unlikely to naturally produce significant anti-Fel d 1 antibodies unless they are deliberately exposed to the allergen in a controlled way.
- If such eggs did contain relevant antibodies, their effect on human allergies would likely be minimal and limited to the gut.
- More research would be needed to determine if cohabitation could consistently induce such effects and whether consuming those eggs would provide any therapeutic benefit.

If you&#x27;re curious about experimenting with this concept, it might be worth consulting an immunologist or veterinary scientist to better understand the feasibility of stimulating such antibody production naturally in chickens.

---

