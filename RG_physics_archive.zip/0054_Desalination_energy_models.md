# Desalination energy models

- Conversation ID: 68b5b4c0-fbb8-832d-b57a-18cfb157fc33
- Created: 2025-09-01T14:59:13.923700

---

**user:**

(* ===== Constants &amp; helpers ===== *)
Rbar = 0.08314472;          (* L·bar/(mol·K) *)
MNaCl = 58.44;              (* g/mol *)
BarToKWhm3 = 1/36.;         (* 1 bar = 0.027777... kWh/m^3 *)
Fconst = 96485.33212;       (* C/mol *)
hfg_kWhth_per_m3_25C = 678.;(* latent heat ~ 2440 kJ/kg -&gt; 678 kWh_th/m^3 at ~25°C *)

(* ===== 1) Osmotic pressure (van ’t Hoff, NaCl-like brackish) ===== *)
OsmoticPressureBar[TDS_gL_, T_C_:25., i_:2.] := Module[
  {C0 = TDS_gL/MNaCl},      (* mol/L *)
  i*Rbar*(T_C + 273.15)*C0  (* bar *)
];

(* ===== 2) RO thermodynamic minimum work (per m^3 product) ===== *)
(* Wmin = (i R T C0 / r) * ln(1/(1 - r))  [bar], then convert to kWh/m^3 *)
ROMinWorkBar[TDS_gL_, r_:0.75, T_C_:25., i_:2.] := Module[
  {C0 = TDS_gL/MNaCl},
  (i*Rbar*(T_C + 273.15)*C0/r)*Log[1/(1 - r)]
];
ROMinWorkKWhm3[args___] := ROMinWorkBar[args]*BarToKWhm3;

(* ===== 3) RO practical SEC estimate with ERD (back-of-envelope) ===== *)
(* SEC ≈ Pf/(36 r) * (1/η_pump - η_ERD*(1 - r))  with Pf in bar *)
ROSECEstimateKWhm3[Pf_bar_, r_, etaPump_:0.85, etaERD_:0.90] :=
  (Pf_bar/(36.*r))*(1./etaPump - etaERD*(1. - r));

(* ===== 4) ED/EDR energy from measurements (field-friendly) ===== *)
(* If you know power and product flow directly: *)
EDSECFromPowerAndFlow[Power_kW_, Flow_m3_per_h_] := Power_kW/Flow_m3_per_h;

(* If you know current density j, membrane area A, avg cell voltage V, and product flux Jp: *)
(* Units: j [A/m^2], A [m^2], V [V], Jp [m^3/s] *)
EDSECFromJV[j_Aperm2_, Area_m2_, V_V_, Jp_m3pers_] := (j_Aperm2*Area_m2*V_V)/Jp_m3pers/3.6*10^-6;

(* ===== 5) MD thermal demand via GOR (simple envelope) ===== *)
(* Thermal_kWh_th/m^3 ≈ 678 / GOR  (678 at ~25°C; use your h_fg if known) *)
MDThermalKWhthPerM3[GOR_] := hfg_kWhth_per_m3_25C/GOR;

(* ===== 6) CDI energy (NaCl example; assumes 2 Faradays per mole of NaCl removed) ===== *)
(* ΔC in mg/L of NaCl removed; Vavg in volts; eff = coulombic efficiency *)
CDI_SEC_KWhm3_NaCl[deltaC_mgL_, Vavg_V_:1.2, zTotal_:2., eff_:0.90] := Module[
  {deltaC_molL = deltaC_mgL/1000./MNaCl},
  (Vavg_V*Fconst*zTotal*deltaC_molL*1000.)/(eff*3.6*10^6)  (* kWh/m^3 *)
];

(* ===== 7) Quick unit helpers ===== *)
BarToKWhm3Fn[p_bar_] := p_bar*BarToKWhm3;
KWhm3ToBar[e_kWhm3_] := e_kWhm3/BarToKWhm3;

(* ===== Sanity checks (expected numeric outputs in comments) ===== *)

(* Osmotic pressure at 3 g/L, 25°C (brackish): ~2.545 bar *)
OsmoticPressureBar[3]
(* -&gt; ~2.545 *)

(* RO thermodynamic minimum at 3 g/L, r = 0.75, 25°C: ~0.131 kWh/m^3 *)
ROMinWorkKWhm3[3, 0.75, 25]
(* -&gt; ~0.131 *)

(* RO practical SEC example (seawater-ish): Pf=65 bar, r=0.45, ηpump=0.85, ηERD=0.90: ~2.73 kWh/m^3 *)
ROSECEstimateKWhm3[65, 0.45, 0.85, 0.90]
(* -&gt; ~2.73 *)

(* RO practical SEC example (brackish): Pf=25 bar, r=0.80, ηpump=0.85, ηERD=0.85: ~0.874 kWh/m^3 *)
ROSECEstimateKWhm3[25, 0.80, 0.85, 0.85]
(* -&gt; ~0.874 *)

(* ED/EDR from field measurements: 12 kW plant making 10 m^3/h -&gt; 1.2 kWh/m^3 *)
EDSECFromPowerAndFlow[12, 10]
(* -&gt; 1.2 *)

(* MD thermal demand at GOR = 6: ~113 kWh_th/m^3 *)
MDThermalKWhthPerM3[6]
(* -&gt; ~113 *)

(* CDI energy for removing 1000 mg/L NaCl at 1.2 V, eff=0.9: ~1.23 kWh/m^3 *)
CDI_SEC_KWhm3_NaCl[1000, 1.2, 2, 0.90]
(* -&gt; ~1.23 *)

(* CDI for 500 mg/L removal at same conditions: ~0.61 kWh/m^3 *)
CDI_SEC_KWhm3_NaCl[500, 1.2, 2, 0.90]
(* -&gt; ~0.61 *)

---

**assistant:**

Thanks for uploading the full suite of Wolfram code, food data, and usage instructions. Here&#x27;s a quick summary of what&#x27;s included and how it all connects:

---

## ✅ Uploaded Code: Desalination &amp; Water Treatment Energy Models

Your Wolfram Language code provides modular, physically meaningful back-of-the-envelope models for water treatment processes:

### 1. **Osmotic Pressure**
```wolfram
OsmoticPressureBar[TDS_gL_, T_C_:25., i_:2.]
```
- **Units:** bar  
- Based on van ’t Hoff equation for NaCl-like salts.

---

### 2. **RO Thermodynamic Minimum Work**
```wolfram
ROMinWorkKWhm3[TDS_gL_, r_:0.75, T_C_:25., i_:2.]
```
- **Units:** kWh/m³  
- Uses ideal minimum energy equation with log term.

---

### 3. **RO SEC Estimate (with ERD)**
```wolfram
ROSECEstimateKWhm3[Pf_bar_, r_, etaPump_:0.85, etaERD_:0.90]
```
- **Units:** kWh/m³  
- Estimates real-world RO SEC given pump/ERD efficiencies.

---

### 4. **ED/EDR SEC Estimation**
```wolfram
EDSECFromPowerAndFlow[Power_kW_, Flow_m3_per_h_]
EDSECFromJV[j_Aperm2_, Area_m2_, V_V_, Jp_m3pers_]
```
- Simple field methods or detailed electrochemical input.

---

### 5. **MD (Membrane Distillation) Thermal Demand**
```wolfram
MDThermalKWhthPerM3[GOR_]
```
- **Units:** kWhₜₕ/m³  
- Uses latent heat per m³ divided by GOR.

---

### 6. **CDI (Capacitive Deionization) SEC**
```wolfram
CDI_SEC_KWhm3_NaCl[deltaC_mgL_, Vavg_V_:1.2, zTotal_:2., eff_:0.90]
```
- **Units:** kWh/m³  
- Based on Faraday’s law, assumes 2 electrons per NaCl removed.

---

### 7. **Quick Unit Conversion Helpers**
```wolfram
BarToKWhm3Fn[p_bar_]
KWhm3ToBar[e_kWhm3_]
```

---

## 🔗 What This Enables

You can now ask for:

- Energy comparisons across technologies (e.g., RO vs MD vs CDI)
- Quick desalination energy estimates given TDS, recovery, or operating pressure
- “What-if” analyses (e.g., “What happens to RO energy if ERD drops to 75%?”)
- Brackish vs seawater scenarios
- Field measurements to SEC translations (for ED/EDR)

---

## 📎 Additional Files You Uploaded

### ✅ Wolfram Food Data.txt
- Use `ResourceFunction[&quot;NutritionReport&quot;]` with `&quot;ASCIITable&quot;` for nutrition.
- Convert serving sizes to grams/mL before calling.
- Prefer `EntityProperty[...]` if specific nutrients are requested.

### ✅ getWolframCloudResults query guidelines.txt
- **Always explain** logic before writing code.
- **Only use lowercase or camelCase** for variable names.
- **No inline comments** in code sent to the API.

### ✅ getWolframAlphaResults query guidelines.txt
- Simplify to keywords (e.g. “France GDP”).
- Use **scientific notation**: `6*10^6`, not `6e6`.
- Include real units, skip counting units like “books.”

### ✅ Wolfram Entity Data.txt
- Always resolve entity/property names using:
  - `getSemanticInterpretationAPI`
  - `findEntityAPI`, `findEntityClassAPI`, `findPropertyAPI`

---

## ✅ Ready for Use

You can now ask me anything related to:

- Desalination and water treatment energy models
- Nutrition breakdowns
- Unit conversions
- Wolfram computations or visualizations

Would you like to run a test scenario with one of the models (e.g., “CDI energy for 750 mg/L NaCl removal”)? Or compare two technologies for the same feedwater?

---

**tool:**

All the files uploaded by the user have been fully loaded. Searching won&#x27;t provide additional information.

---

**user:**

1.	RO minimum work &amp; osmotic pressure
	•	Your formulas are correct for NaCl-like brackish feeds. Remember real brackish waters aren’t pure NaCl; if TDS has divalents (CaSO₄, Mg²⁺), i and activity effects make the ideal van’t Hoff estimate a little low. For our sizing: keep van’t Hoff for 3–5 g/L, but pad practical SEC via pump/ERD terms (you already do).
	2.	RO practical SEC
	•	The ROSECEstimateKWhm3 expression is a sound envelope. Note that it excludes intake/outfall pumping and pretreatment loads; when comparing to plant claims, add a margin (often +0.2–0.5 kWh/m³ for seawater intakes).
	3.	ED/EDR energy from JV
	•	Your conversion …/3.6*10^-6 is equivalent to divide by 3.6e6 J/kWh (correct). Keep it; just be sure Jp is really m³/s (not m³/h).
	4.	MD thermal accounting
	•	GOR formulation is right. Keep electric and thermal separate. Don’t convert thermal to electric unless you explicitly state an assumed COP or heat price.
	5.	CDI energy
	•	Faraday-based model is correct and scales with removal (ΔC). Typical Vavg ~1.1–1.2 V and coulombic efficiency 0.85–0.95; your default of 0.90 is reasonable. Remember CDI is for brackish, not seawater.

---

**assistant:**

Excellent — your notes are sharp and show clear domain understanding. Let’s summarize and flag key implications or options for refinement based on your annotations:

---

## ✅ 1. **RO Osmotic Pressure &amp; Minimum Work**

- **✔ Your formulas are physically valid** for NaCl-only systems using the van ’t Hoff approximation.
- **⚠ Real brackish waters** often contain divalent ions (e.g. Mg²⁺, Ca²⁺, SO₄²⁻), which:
  - Increase the **effective osmotic pressure** (due to higher van’t Hoff factor \( i &gt; 2 \))
  - Introduce **non-ideality** (activity coefficients &lt; 1)
- **🛠 Action**: For sizing &amp; back-of-envelope design:
  - *Keep van’t Hoff as-is for 3–5 g/L TDS*
  - *Pad total SEC via pump/ERD model instead of complicating \( \Pi \)*

### Optional: If needed, we could later add a correction factor for high-divalent brines, or link to activity-based osmotic estimates via Debye–Hückel or Pitzer, though that’s probably overkill for your use case.

---

## ✅ 2. **RO Practical SEC**

- Your `ROSECEstimateKWhm3` is a clean and defensible **core process energy model**.
- ⚠ **Missing: Intake, pretreatment, post-treatment**
  - These can add **+0.2–0.5 kWh/m³** in seawater RO systems.

### 🛠 Option:
If you&#x27;d like, we can add an **adjusted SEC function**:
```wolfram
ROTotalSEC[Pf_bar_, r_, etaPump_:0.85, etaERD_:0.90, intakePretreat_kWhm3_:0.3] :=
  ROSECEstimateKWhm3[Pf_bar, r, etaPump, etaERD] + intakePretreat_kWhm3
```

---

## ✅ 3. **ED/EDR Energy from JV Expression**

- ✔ Unit conversion: `... / (3.6*10^6)` is spot-on → \( \frac{\text{J}}{\text{s}} \cdot \frac{1\,\text{kWh}}{3.6\cdot10^6\,\text{J}} \)
- ⚠ **Double-check Jp input units**: Users may think in m³/h
  - Always make sure to clarify **&quot;Jp must be in m³/s&quot;** (or build a wrapper to convert units internally if needed)

---

## ✅ 4. **MD (Membrane Distillation) Thermal Demand**

- Your GOR-based model is **perfect for first-order accounting**.
- ⚠ Important: Keep thermal and electric **strictly separate**
  - Do **not convert thermal → electric** without explicitly stating a:
    - COP (e.g., if using heat pump)
    - Thermal price (e.g., waste heat vs steam)

---

## ✅ 5. **CDI (Capacitive Deionization)**

- ✔ Faraday-law energy model is conceptually solid:
  - \[
    \text{Energy} = \frac{V \cdot z \cdot F \cdot \Delta C}{\eta \cdot 3.6 \cdot 10^6}
  \]
- ⚠ Clearly brackish-only — not appropriate for seawater (TDS &gt; ~10 g/L)
- Default:
  - \( V_{\text{avg}} = 1.2\, \text{V} \)
  - \( \eta = 0.90 \)  
  are both realistic.

---

## Summary Table

| Model             | Status | Notes |
|------------------|--------|-------|
| Osmotic pressure | ✅     | Stick with van’t Hoff for ≤5 g/L |
| RO min work      | ✅     | Solid for NaCl-like TDS |
| RO SEC (core)    | ✅     | Good envelope; consider intake/pretreatment margin |
| ED/EDR SEC (JV)  | ✅     | Unit check on Jp |
| MD thermal       | ✅     | No conversion unless COP or cost given |
| CDI energy       | ✅     | Accurate Faraday-based model; brackish only |

---

Let me know if you want to:

- Add the **RO total SEC** function with optional pretreatment margin
- Add input validation or helper wrappers (e.g., for m³/h → m³/s)
- Extend any model to multi-salt, non-ideal, or cost-based versions

Or if you&#x27;re ready to run example comparisons (e.g., &quot;What’s the energy cost difference between CDI and RO for 1000 mg/L NaCl?&quot;), I can compute that for you.

---

