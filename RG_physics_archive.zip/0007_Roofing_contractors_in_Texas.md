# Roofing contractors in Texas

- Conversation ID: 690b6355-dbbc-8332-8f7a-d11f688e85f3
- Created: 2025-11-05T14:46:48.841313

---

**user:**

How many licensed roofing contractors are in the state of Texas

---

**assistant:**

Short version: Texas doesn’t have a state-issued roofing contractor license, so there isn’t a single official number to give you. 🧱

Here’s what’s going on:

1. **No state license right now**  
   Texas is one of the few big states where you can do roofing without holding a state roofing license. The Texas Department of Licensing &amp; Regulation (TDLR) doesn’t regulate roofers. citeturn0search0turn0search2turn0search7

2. **Voluntary license through RCAT**  
   The closest thing to “licensed roofing contractors in Texas” is the voluntary program run by the **Roofing Contractors Association of Texas (RCAT)**. Contractors apply, prove insurance/experience, and pass exams. But it’s optional, so it only captures a slice of the market. To get the exact count, you’d have to query RCAT’s directory. citeturn0search1turn0search3turn0search8

3. **A change has been proposed**  
   There’s been talk in the Legislature (e.g. HB 3344) about finally requiring roofers to be licensed statewide, precisely because right now *anyone with a ladder* can call themselves a roofer. But as of those 2025 writeups, that’s not law yet, so still no central list. citeturn0search4turn0search11

So, the honest answer:

- **Official statewide number:** doesn’t exist (no state license).
- **Best proxy right now:** number of RCAT-licensed roofers in their directory (voluntary, smaller than real market).
- **Real market size:** much bigger than RCAT because thousands of roofers operate unlicensed at the state level.

If you tell me *why* you want the number (market sizing for a roofing service, compliance check, sales territory planning), I can show you how to estimate the total contractor universe in Texas even without a state license list.

---

**user:**

I’d like to know how many other Roofing companies actually have their roofing contractors license because we do

---

**assistant:**

Perfect — so you’re one of the ones who actually did the RCAT route. That already puts you in the smaller, more professional bucket.

Here’s the straight answer based on how Texas is set up:

1. **Texas still doesn’t license roofers at the state level.** So there is no “all roofing companies with a Texas roofing license” master list at TDLR, because TDLR doesn’t license roofers. citeturn0search10turn0search11

2. **The only meaningful “roofing contractor license” in Texas right now is the voluntary one from RCAT.** That’s the one you have. Their own site tells homeowners to search *their* directory to find “RCAT Licensed Roofing Contractors.” citeturn0search0turn0search1turn0search2

3. **Because it’s voluntary, the number will always be way smaller than the total number of roofing companies operating in Texas.** Most roofers don’t bother, especially storm-chase outfits and small locals. So if you’re RCAT-licensed, you’re already in the top tier.

4. **RCAT doesn’t publish a single “we have X licensed contractors” number on the public page** — they make you search the directory by zip/miles/category. So the closest you can get publicly is to pull that directory and count it. If you call RCAT (they list the numbers on that page) they can usually tell you how many active licensees there are right now. citeturn0search0turn0search3

So, to your underlying question — *“how many others actually have it?”* — the answer is: **a relatively small fraction of the Texas roofing market**. You’re already differentiated.

If you want to weaponize that in sales, here’s the line you can use:

&gt; “Texas doesn’t require a roofing license, so most roofers don’t have one. We went through the RCAT licensing process anyway — background, insurance, exams — so you’re not taking a risk on a pop-up roofer.”

If you tell me what city/area you mostly work in, I can show you how to estimate *your local* RCAT competition from that directory, which is even more useful than the statewide number.

---

**user:**

Central Texas namely, the Austin area

---

**assistant:**

Nice — Austin/Central Texas is actually the easiest place to make this a sales differentiator because RCAT and the Central Texas Roofing Contractors Association are both active there. Here’s how this shakes out for you.

### 1. What we can know from public stuff
- RCAT says: Texas has **no state roofing license**, so the only way to filter for “actually licensed” is to tick the **RCAT Licensed Contractor** box in their own search tool. citeturn0search0turn0search2
- Their search is **radius-based** (ZIP + miles). It doesn’t show “there are 143 in Austin,” it just shows whoever is in range.
- Central Texas has its own regional association (CTRCA), but that’s a membership body, not a license authority. Some of those members will also be RCAT-licensed, some won’t. citeturn0search1turn0search5

So: **there isn’t a published “Austin has X licensed roofers” number.** You have to pull it from the RCAT directory.

---

### 2. How to get the real local count (the way I’d do it)
You or someone on your team can do this in 5–10 minutes:

1. Go to the RCAT search page. citeturn0search2
2. Pick an Austin ZIP (78701, 78704, 78723, 78745 — whatever is central).
3. Set **miles = 25** first, **Category = Contractor**, and **check “RCAT Licensed Contractor.”**
4. Count the results.
5. Repeat with **miles = 50** to catch Round Rock / Pflugerville / Georgetown / Kyle / Buda, because a lot of shops serve the whole metro.
6. De-duplicate (some appear in multiple searches if you change ZIPs).

That final deduped list = **your actual RCAT-licensed competitors in Greater Austin.** That’s what you want.

---

### 3. What this means for your positioning
Because RCAT licensing is voluntary, the number for Austin **will be modest** compared to how many trucks you see after a hailstorm. That’s good for you.

Use a line like:

&gt; “Most roofers in Austin aren’t RCAT-licensed because Texas doesn’t require it. We went through the RCAT licensing anyway — insurance, experience, exams — so you’re getting someone who chose the higher standard.” citeturn0search0

If you give me **one ZIP you actually operate from** (say 78641, 78660, 78745, etc.), I can write you the exact script for your office/salesperson to read off while they have the RCAT directory open, so they can tell a homeowner, “Here are the only RCAT-licensed roofers that serve your area — and we’re on it.”

---

**user:**

78703

---

**assistant:**

Perfect — 78703 puts you right in central Austin, so we can make this super concrete.

Because RCAT’s tool is radius-based and Texas doesn’t license roofers at the state level, the way to answer “who else around me actually bothered to get the roofing contractor license?” is: run the RCAT search with your ZIP, a radius, and the “RCAT Licensed Contractor” box checked. That’s the only authoritative filter right now. citeturn0search0turn0search1turn0search5

Here’s a script/workflow your office or salesperson can literally do while on the phone.

---

## Quick workflow for 78703

1. Go to the RCAT search page. (The one that says “enter miles + zip, choose Contractor, check RCAT Licensed Contractor.”) citeturn0search1
2. **Miles:** start with **25 miles**.
3. **ZIP:** `78703`
4. **Category:** `Contractor`
5. **Check:** ✅ “RCAT Licensed Contractor”
6. Hit search.
7. Count the results.
8. If it looks thin, bump to **40–50 miles** to catch Buda, Kyle, Round Rock, Georgetown, even some San Marcos shops — a lot of the names you saw in Austin-area marketing (Ja-Mar, Longhorn, Johnson Roofing) are RCAT-licensed and serve Austin but aren’t always sitting in 787xx proper. citeturn0search8turn0search9turn0search11

That number you get = **your actual, locally relevant, RCAT-licensed competition.**

---

## Phone/door script you can use

&gt; “So here’s something most people in Austin don’t realize — **Texas doesn’t require a roofing license.** Anyone can print cards after a hailstorm. We went through the **RCAT Licensed Roofing Contractor** process anyway.  
&gt;  
&gt; If you want to double-check me, RCAT has a public directory. If you put in your ZIP — 78703 — and check ‘RCAT Licensed Contractor,’ you’ll see us and just a handful of others. That list is short because most companies don’t bother.” citeturn0search0turn0search5

You can tighten it for sales:

&gt; “We’re RCAT-licensed. Most of the trucks you see in Austin are not. That’s the difference.”

---

## What this gives you

- A **verifiable** list (you can tell homeowners how to see it).
- A **small** list (so you look premium).
- A reason to price like a real company.

If you want, tell me whether you do **residential, commercial, or both**, and I’ll tweak the script so it matches the exact RCAT boxes you’d check — they let you license for residential and/or commercial.

---

**user:**

Quick aside:  I’m looking at a 6 month old Malarkey class 3 black shingle that looks melted and I can see boot prints all over it. The shingles look like they melted onto one another, and are thinner than usual. There isn’t any visible tar or adhesive leaking out or running, but the shingles do appear to have been too hot during install. Can this be proven to cause the roof to not shed water properly and warrant being replaced? The roof in question is in a house I’m thinking of buying and I wonder if I need to have it replaced?

---

**assistant:**

Short answer: **yes, it *can* be grounds for replacement—but you need to document that the hot-weather install/foot traffic caused permanent distortion or functional issues, not just cosmetic scuffing.** Here’s how to nail it down fast and negotiate from strength.

## Why this matters
- In hot weather, asphalt shingles get soft. **If they aren’t installed perfectly flat, they can “take a set” and stay distorted**, and **foot traffic can scuff/mark them**—both explicitly warned about in manufacturer/industry bulletins. citeturn1view0turn3view0  
- Manufacturers also note that **foot-traffic damage and mishandling aren’t covered by warranty**—so a roof that shows widespread boot-print scuffing or heat distortion may have **little to no warranty recourse**, which is a valid reason to ask for replacement or a price credit. citeturn4view0turn5search17

## What to look for (quick triage on that Malarkey Class 3 roof)
1. **Permanent distortion/“slumping”** (tabs not lying flat, edges fused/misaligned, “melted together” appearance). If shingles bonded while not flat, that’s a performance risk, not just cosmetic. citeturn1view0  
2. **Widespread boot-print scuffing &amp; granule loss** (not just a few paths). Extensive early granule loss accelerates aging; while some “hitchhiker” granule shedding in the first months is normal, bare asphalt or large scuffed areas are not. citeturn2view0  
3. **Seal-down/adhesive issues** (tabs over-stuck or stuck misaligned, or conversely not sealed). Hot installs can over-activate sealant; ARMA and Malarkey caution about debris/trim pieces sealing to the roof and foot-traffic scuffing in heat. citeturn3view0turn1view0

## How to *prove* it affects water shedding (and not just looks)
Do these with a reputable (ideally RCAT-licensed) roofer who documents everything:

- **Photo set**: raking-light closeups with a ruler/coin for scale showing boot prints, slumping, stuck edges, misaligned exposures.  
- **Targeted hose test**: controlled spray on suspect slopes while a spotter watches the attic/penetrations for intrusion. (Simple, persuasive for sellers/agents.)  
- **Seal check (gentle)**: after the deck is cool, randomly select tabs across each slope; note if seals are over-bonded, misaligned, or unsealed. (Stop if you risk damage.)  
- **Ventilation check**: confirm intake/exhaust and deck temps; chronic overheating worsens softening/distortion.  
- **Manufacturer field review**: Ask the seller to request a **Malarkey field/warranty rep letter** stating whether what’s observed is installation/foot-traffic damage (typically excluded) or within spec. Malarkey’s tech bulletin provides contact info for their Technical Services. citeturn1view0

&gt; If a manufacturer/tech letter or RCAT report says “installation/foot-traffic damage” or “heat-set distortion,” that’s excellent leverage for **replacement or a substantial credit** because warranty coverage is impaired. citeturn4view0turn5search17

## What to ask for before you buy
1. **Original invoice + installer info** (were they Malarkey-certified; any enhanced warranty registered?). citeturn5search2turn5search3  
2. **Written inspection** by a third party (not the seller’s roofer) documenting the three items above.  
3. **Manufacturer/tech letter** confirming whether performance/warranty is affected. citeturn1view0

## Decision rule (practical)
- **Replace / ask for big credit** if you have any TWO of the following:  
  - Widespread distortion/slumping or tabs bonded out of plane,  
  - Significant, widespread scuffing/granule loss at 6 months,  
  - Manufacturer/RCAT letter noting installation/foot-traffic damage or compromised sealant/warranty. citeturn1view0turn3view0turn4view0
- **Monitor (cosmetic)** if it’s isolated scuffing with flat, well-sealed shingles, normal early “hitchhiker” granules, and a clean letter that warranty/performance are intact. citeturn2view0

If you want, I can draft a short **email template to the listing agent** requesting the docs + manufacturer inspection, and a **one-page checklist** your RCAT inspector can use on site.

---

**user:**

Okay, so let me ask you this. I&#x27;m a roofer, obviously, and I work for a roofing company. Is that like a conflict of interest? And do I use a different roofing company to do this kind of inspection? And anything else you can think of?

---

**assistant:**

Short take: yeah, it’s a conflict (or at least looks like one) if **your own company** is the sole voice saying “this roof needs to be replaced.” Use a neutral third party for anything you’ll take to the seller/agent.

## What to do (clean + credible)
1. **Hire an independent**:
   - Pick an **RCAT-licensed roofer** *not* affiliated with your company, or a **forensic roof consultant/HAAG-certified inspector** who doesn’t do replacements (pure consulting is best).
   - If it might get contentious, add a **manufacturer field rep** (Malarkey) for a letter on install/heat/foot-traffic findings.

2. **Your role**:
   - Do a quick **pre-check** yourself (photos, straightedge/ruler shots, note where tabs are fused/misaligned).
   - **Don’t** be the one lifting tabs, cutting samples, or writing the “official” report. That keeps you out of the COI blast radius.
   - If you *must* write anything, label it “owner’s preliminary observations” and disclose you work in roofing; then defer to the third-party report.

3. **Paper to collect from the seller**:
   - **Original invoice &amp; installer info** (were they manufacturer-certified?).
   - **Warranty registration** (product + enhanced warranty, if any).
   - **Permit/final inspection** (if the city/jurisdiction required one).
   - Any **service calls** since install.

4. **COI-safe negotiation pack** (what you hand the agent):
   - Independent **RCAT/HAAG report** with photos.
   - **Manufacturer letter** (if you can get one).
   - Two **replacement quotes** from companies other than yours (or a consultant’s cost opinion).  
   - Your company can bid later if the seller asks—but don’t make *your* bid the evidence.

## Extra tips that help you win the argument
- Ask the third party to state **functional impact**, not just “looks bad”: e.g., tabs heat-set out of plane, misaligned exposure, over-bonded seals, accelerated granule loss → **compromised water shedding + impaired warranty**.  
- Keep tests **non-destructive** unless you have written permission (seller can claim you caused damage).
- If ventilation contributed (common with heat-set), have them document **intake/exhaust** and simple calcs (1:150/1:300 rules of thumb). That strengthens the “replace + fix cause” case.
- For leverage, request **credit or full replacement**; as a fallback, an **escrow holdback** that funds replacement after closing if the manufacturer/consultant deems it defective.

## One-liner you can use with the agent
&gt; “I’m in roofing, so to avoid any conflict, I hired an independent RCAT/HAAG inspector and asked Malarkey to review. Their documentation shows heat-set/foot-traffic distortion affecting water shedding and warranty. Based on that, we’re requesting replacement or a credit of $X.”

If you want, tell me whether you’d prefer an **independent consultant** or an **RCAT contractor** for the report, and I’ll draft a short email/text you can send today to book it (plus a checklist they can follow on site).

---

