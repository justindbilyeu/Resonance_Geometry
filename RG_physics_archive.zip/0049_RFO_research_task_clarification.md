# RFO research task clarification

- Conversation ID: 68bd5dd4-c1d4-8333-9877-6059652f5e5e
- Created: 2025-09-07T10:26:35.523756

---

**user:**

Kai — Deep Research Prompt: Resonance Fold Operator (RFO)

Objective

Gather the strongest prior art, mathematical analogues, and empirical handles for modeling a black hole as an origami-like folding operator
|\psi_{\text{folded}}\rangle=\hat F_{BH}|\psi_{\text{in}}\rangle
with the formal structure we now have:
	•	\mathcal H_{\text{in}} = exterior Fock space on \mathscr I^{-}
	•	\mathcal H_{\text{geom}}=\mathcal H_{\text{hor}}\otimes\mathcal H_{\text{bulk}}^{\text{top}}\otimes\mathcal H_{\text{rad}}
	•	\hat F_{BH}=U_{\text{evap}}\circ U_{\text{scr}}\circ\mathcal E, where \mathcal E is an isometric encoder built from fold generators \mathsf F=\{\mathsf F_{\text{hol}},\mathsf F_{\text{rec}},\mathsf F_{\text{Pachner}}\}.

Goal: Anchor each RFO piece (encoder, scrambler, evaporator; horizon microstates; spin-foam “creases”; QECC) in published frameworks (AdS/CFT + QEC, spin foams / isolated horizons, JT/SYK islands &amp; Page curve, soft hair, fast scrambling).

⸻

Deliverables
	1.	Annotated bibliography (10–20 core items). For each: full citation + 2–4 sentence summary + 3–5 key equations/theorems + why it matters for RFO.
	2.	Equation pack (ready to paste):
	•	Horizon microstate counting &amp; area spectrum (isolated horizons, Immirzi dependence).
	•	Page curve &amp; islands (QES, replica wormholes).
	•	Holographic QECC (code subspace isometry, entanglement wedge reconstruction).
	•	Fast scrambling/OTOCs &amp; Lyapunov bound.
	•	Spin-foam amplitudes (e.g., EPRL; Pachner moves) and Regge deficit angles as “fold lines”.
	3.	Mapping table: RFO component ↔ closest established construct (see “Targets” below).
	4.	Observables &amp; tests: concrete signatures that differentiate “fold depth” (e.g., OTOCs, late-time spectral form factor, soft hair/BMS charges, deviations in late Hawking correlations).
	5.	Risk &amp; contention notes: where the literature disagrees (firewalls/AMPS, state-dependence, soft hair sufficiency, LQG microstate counting variants).

⸻

Targets (What to Look For)

A) Holography &amp; Quantum Error Correction
	•	AdS/CFT as QECC: subregion duality; code subspace isometries; HaPPY code / tensor-network toy models.
	•	Entanglement wedge reconstruction as decoding analogue of U_{\text{evap}}.
	•	Black holes as mirrors (Hayden–Preskill); fast scrambling (Sekino–Susskind); OTOC Lyapunov bound (Maldacena–Shenker–Stanford).
	•	Ask: Which theorems cleanly state when an isometric encoding \mathcal E exists and how its dimension is bounded relative to horizon area?

B) Page Curve, Islands, and JT/SYK
	•	Replica wormholes &amp; islands (2019–2020 breakthroughs): Page curve recovery in semi-classical gravity.
	•	JT gravity / Schwarzian + SYK: minimal models of scrambling and evaporation; QES equations and their simplest forms we can reuse.
	•	Tie to RFO: show \mathcal E (encode), U_{\text{scr}} (scramble), U_{\text{evap}} (swap-out) in a toy but principled 1+1D setting.

C) LQG: Isolated Horizons, Spin Networks &amp; Foams
	•	Isolated-horizon microstate counting (Ashtekar et al.; Domagała–Lewandowski; Meissner) and the area spectrum A\sim 8\pi\gamma\ell_P^2\sum_p\sqrt{j_p(j_p+1)}.
	•	Spin-foam models (Barrett–Crane; Engle–Pereira–Rovelli–Livine/EPRL); Pachner moves as local evolution; holonomy/deficit angles in Regge calculus as “creases.”
	•	Ask: Where has anyone explicitly linked holonomy defects/topological features to information-preserving encodings?

D) Soft Hair &amp; Asymptotic Symmetries
	•	BMS/supertranslation hair (Hawking–Perry–Strominger) as potential carriers of information.
	•	Evaluate compatibility with RFO’s \mathcal E: can soft charges serve as part of the “crease ledger”?

E) Error-Correcting &amp; Topological Angles
	•	Quantum error correction in gravity (Almheiri–Dong–Harlow, Pastawski et al.); tensor networks as fold patterns.
	•	Topological order / TQFT analogies for robustness (anyonic fusion/braiding ↔ \mathsf F_{\text{rec}} rules).
	•	Identify proofs bounding \log\dim(\operatorname{Im}\mathcal E)\le A/4G up to subleading terms.

F) “Origami” precedents &amp; metaphors with math
	•	Legit references where folding/origami is used with formal content (e.g., cosmic-web origami in large-scale structure; geometric folding in Regge calculus). Only include if mathematically actionable.

⸻

Extraction Schema (use this per-paper)
	•	Citation (APA) + link
	•	Context tag(s): {Holography/QECC, Islands/JT/SYK, Spin-Foam/LQG, Soft Hair/BMS, Scrambling/OTOC, Regge/Deficit, Tensor-Networks, TQFT}
	•	Key equations (copy exactly + define symbols)
	•	Result (2–4 sentences, precise)
	•	Why RFO cares (1–2 sentences; which RFO block it anchors)
	•	Caveats/controversies

⸻

Priority Seed List (expand &amp; verify)
	•	Holographic QECC &amp; subregion duality (Almheiri–Dong–Harlow; Pastawski et al. “HaPPY”).
	•	Islands &amp; Page curve (Penington; Almheiri–Mahajan–Maldacena–Zhao lines).
	•	Fast scrambling &amp; Lyapunov bound (Sekino–Susskind; Maldacena–Shenker–Stanford).
	•	Hayden–Preskill mirror result.
	•	LQG isolated horizons (Ashtekar–Baez–Corichi–Krasnov; Domagała–Lewandowski; Meissner).
	•	Spin-foam amplitudes (EPRL model), Pachner moves, Regge deficit angles as curvature.
	•	BMS soft hair (Hawking–Perry–Strominger).
	•	JT gravity &amp; SYK review/tutorials with explicit QES formulas.
	•	Tensor-network holography primers linking codes to geometry.

(Feel free to substitute superior or more recent reviews.)

⸻

Specific Questions Kai Must Answer
	1.	Isometry bounds: best references that formally tie code-subspace dimension to area/entropy bounds in gravity.
	2.	Decoding picture: clean statements mapping entanglement-wedge reconstruction to a unitary/partial-isometry that mirrors U_{\text{evap}}.
	3.	Spin-foam “folds”: strongest sources interpreting holonomy defects/Regge deficits as localized curvature lines and whether anyone connects them to information flow.
	4.	Observable “fold depth”: which OTOC / spectral form-factor diagnostics in JT/SYK best encode scrambling depth; any late-time Hawking-correlation signatures we can cite.
	5.	Soft hair efficacy: does the soft hair program suffice for info recovery, or is it only partial? Best critiques.
	6.	State-dependence and AMPS: concise treatments we should anticipate when positioning RFO.

⸻

Output Format
	•	Section 1: Executive synthesis (1–2 pages) with our RFO ↔ literature mapping.
	•	Section 2: Annotated bibliography (schema above).
	•	Section 3: Equation pack (LaTeX-ready).
	•	Section 4: Open issues &amp; proposed quick tests (what we can simulate or estimate next).

⸻

If you need a minimal toy anchor while searching, default to JT/SYK for encode–scramble–evaporate and isolated-horizon counting for the area/entropy constraint.

---

**tool:**

All the files uploaded by the user have been fully loaded. Searching won&#x27;t provide additional information.

---

**assistant:**

Thanks, Kai. To begin the deep research task on the Resonance Fold Operator (RFO), could you confirm a few constraints and preferences to sharpen the pass:

1. **Scope prioritization** — Would you like stronger emphasis on any specific pillar among: AdS/CFT &amp; QECC, JT/SYK &amp; islands, LQG/spin foams, or soft hair/BMS? Or keep them balanced?
2. **Preferred formalism depth** — Are you aiming for paper-ready references with equations and theorems, or more high-level conceptual mappings?
3. **Model-building anchor** — Should we prioritize compiling toy models in JT gravity or EPRL spin foam for the encode–scramble–evaporate cycle first?
4. **Output timing** — Should the synthesis + annotated bibliography + equation pack be delivered as one integrated drop, or phased (e.g., annotated bib first, then equation pack)?

Let me know how you&#x27;d like this scaffolded.

---

**user:**

Hello, Kai — here is your Deep Research Prompt: 


Resonance Fold Operator (RFO)

Objective

Gather the strongest prior art, mathematical analogues, and empirical handles for modeling a black hole as an origami-like folding operator
|\psi_{\text{folded}}\rangle=\hat F_{BH}|\psi_{\text{in}}\rangle
with the formal structure we now have:
	•	\mathcal H_{\text{in}} = exterior Fock space on \mathscr I^{-}
	•	\mathcal H_{\text{geom}}=\mathcal H_{\text{hor}}\otimes\mathcal H_{\text{bulk}}^{\text{top}}\otimes\mathcal H_{\text{rad}}
	•	\hat F_{BH}=U_{\text{evap}}\circ U_{\text{scr}}\circ\mathcal E, where \mathcal E is an isometric encoder built from fold generators \mathsf F=\{\mathsf F_{\text{hol}},\mathsf F_{\text{rec}},\mathsf F_{\text{Pachner}}\}.

Goal: Anchor each RFO piece (encoder, scrambler, evaporator; horizon microstates; spin-foam “creases”; QECC) in published frameworks (AdS/CFT + QEC, spin foams / isolated horizons, JT/SYK islands &amp; Page curve, soft hair, fast scrambling).

⸻

Deliverables
	1.	Annotated bibliography (10–20 core items). For each: full citation + 2–4 sentence summary + 3–5 key equations/theorems + why it matters for RFO.
	2.	Equation pack (ready to paste):
	•	Horizon microstate counting &amp; area spectrum (isolated horizons, Immirzi dependence).
	•	Page curve &amp; islands (QES, replica wormholes).
	•	Holographic QECC (code subspace isometry, entanglement wedge reconstruction).
	•	Fast scrambling/OTOCs &amp; Lyapunov bound.
	•	Spin-foam amplitudes (e.g., EPRL; Pachner moves) and Regge deficit angles as “fold lines”.
	3.	Mapping table: RFO component ↔ closest established construct (see “Targets” below).
	4.	Observables &amp; tests: concrete signatures that differentiate “fold depth” (e.g., OTOCs, late-time spectral form factor, soft hair/BMS charges, deviations in late Hawking correlations).
	5.	Risk &amp; contention notes: where the literature disagrees (firewalls/AMPS, state-dependence, soft hair sufficiency, LQG microstate counting variants).

⸻

Targets (What to Look For)

A) Holography &amp; Quantum Error Correction
	•	AdS/CFT as QECC: subregion duality; code subspace isometries; HaPPY code / tensor-network toy models.
	•	Entanglement wedge reconstruction as decoding analogue of U_{\text{evap}}.
	•	Black holes as mirrors (Hayden–Preskill); fast scrambling (Sekino–Susskind); OTOC Lyapunov bound (Maldacena–Shenker–Stanford).
	•	Ask: Which theorems cleanly state when an isometric encoding \mathcal E exists and how its dimension is bounded relative to horizon area?

B) Page Curve, Islands, and JT/SYK
	•	Replica wormholes &amp; islands (2019–2020 breakthroughs): Page curve recovery in semi-classical gravity.
	•	JT gravity / Schwarzian + SYK: minimal models of scrambling and evaporation; QES equations and their simplest forms we can reuse.
	•	Tie to RFO: show \mathcal E (encode), U_{\text{scr}} (scramble), U_{\text{evap}} (swap-out) in a toy but principled 1+1D setting.

C) LQG: Isolated Horizons, Spin Networks &amp; Foams
	•	Isolated-horizon microstate counting (Ashtekar et al.; Domagała–Lewandowski; Meissner) and the area spectrum A\sim 8\pi\gamma\ell_P^2\sum_p\sqrt{j_p(j_p+1)}.
	•	Spin-foam models (Barrett–Crane; Engle–Pereira–Rovelli–Livine/EPRL); Pachner moves as local evolution; holonomy/deficit angles in Regge calculus as “creases.”
	•	Ask: Where has anyone explicitly linked holonomy defects/topological features to information-preserving encodings?

D) Soft Hair &amp; Asymptotic Symmetries
	•	BMS/supertranslation hair (Hawking–Perry–Strominger) as potential carriers of information.
	•	Evaluate compatibility with RFO’s \mathcal E: can soft charges serve as part of the “crease ledger”?

E) Error-Correcting &amp; Topological Angles
	•	Quantum error correction in gravity (Almheiri–Dong–Harlow, Pastawski et al.); tensor networks as fold patterns.
	•	Topological order / TQFT analogies for robustness (anyonic fusion/braiding ↔ \mathsf F_{\text{rec}} rules).
	•	Identify proofs bounding \log\dim(\operatorname{Im}\mathcal E)\le A/4G up to subleading terms.

F) “Origami” precedents &amp; metaphors with math
	•	Legit references where folding/origami is used with formal content (e.g., cosmic-web origami in large-scale structure; geometric folding in Regge calculus). Only include if mathematically actionable.

⸻

Extraction Schema (use this per-paper)
	•	Citation (APA) + link
	•	Context tag(s): {Holography/QECC, Islands/JT/SYK, Spin-Foam/LQG, Soft Hair/BMS, Scrambling/OTOC, Regge/Deficit, Tensor-Networks, TQFT}
	•	Key equations (copy exactly + define symbols)
	•	Result (2–4 sentences, precise)
	•	Why RFO cares (1–2 sentences; which RFO block it anchors)
	•	Caveats/controversies

⸻

Priority Seed List (expand &amp; verify)
	•	Holographic QECC &amp; subregion duality (Almheiri–Dong–Harlow; Pastawski et al. “HaPPY”).
	•	Islands &amp; Page curve (Penington; Almheiri–Mahajan–Maldacena–Zhao lines).
	•	Fast scrambling &amp; Lyapunov bound (Sekino–Susskind; Maldacena–Shenker–Stanford).
	•	Hayden–Preskill mirror result.
	•	LQG isolated horizons (Ashtekar–Baez–Corichi–Krasnov; Domagała–Lewandowski; Meissner).
	•	Spin-foam amplitudes (EPRL model), Pachner moves, Regge deficit angles as curvature.
	•	BMS soft hair (Hawking–Perry–Strominger).
	•	JT gravity &amp; SYK review/tutorials with explicit QES formulas.
	•	Tensor-network holography primers linking codes to geometry.

(Feel free to substitute superior or more recent reviews.)

⸻

Specific Questions Kai Must Answer
	1.	Isometry bounds: best references that formally tie code-subspace dimension to area/entropy bounds in gravity.
	2.	Decoding picture: clean statements mapping entanglement-wedge reconstruction to a unitary/partial-isometry that mirrors U_{\text{evap}}.
	3.	Spin-foam “folds”: strongest sources interpreting holonomy defects/Regge deficits as localized curvature lines and whether anyone connects them to information flow.
	4.	Observable “fold depth”: which OTOC / spectral form-factor diagnostics in JT/SYK best encode scrambling depth; any late-time Hawking-correlation signatures we can cite.
	5.	Soft hair efficacy: does the soft hair program suffice for info recovery, or is it only partial? Best critiques.
	6.	State-dependence and AMPS: concise treatments we should anticipate when positioning RFO.

⸻

Output Format
	•	Section 1: Executive synthesis (1–2 pages) with our RFO ↔ literature mapping.
	•	Section 2: Annotated bibliography (schema above).
	•	Section 3: Equation pack (LaTeX-ready).
	•	Section 4: Open issues &amp; proposed quick tests (what we can simulate or estimate next).

⸻

If you need a minimal toy anchor while searching, default to JT/SYK for encode–scramble–evaporate and isolated-horizon counting for the area/entropy constraint.

---

**tool:**

All the files uploaded by the user have been fully loaded. Searching won&#x27;t provide additional information.

---

**assistant:**

Understood. To begin the deep literature pass for the Resonance Fold Operator (RFO), could you please clarify:

1. **Citation Format Preference**: Do you want arXiv links only, or full citations (APA/MLA/Chicago)?
2. **Depth &amp; Breadth**:
   - Should I prioritize comprehensive reviews or anchor each RFO module to seminal primary papers?
   - Are you okay with recent preprints (~2023–2025) if they are technically strong?
3. **Weighting Across Categories**: Should I balance attention equally across Holography/QECC, JT/SYK, Spin Foam/LQG, Soft Hair, etc., or is there a subset to emphasize first (e.g., LQG/Pachner holonomy)?
4. **Mapping Table Use**: Do you already have candidate matches for F_hol, F_rec, F_Pachner, or should I propose canonical anchors?

Once I have this, I’ll kick off the full research pull for annotated bibliography, equations, mapping, and observables.

---

**user:**

Kai here is your Setup — RFO Literature Pass

1) Citation format
	•	APA with arXiv ID and DOI (if available).
	•	Include a direct arXiv link + publisher link (when published).
	•	Example: Almheiri, A., Dong, X., &amp; Harlow, D. (2015). Bulk locality and quantum error correction. JHEP, 2015(4), 163. arXiv:1411.7041. https://doi.org/…

2) Depth &amp; breadth
	•	Anchor each RFO module to 1–3 seminal primary papers + 1 recent high-quality review.
	•	Recent preprints (2023–2025): yes, include if technically strong; flag as PREPRINT and note stability/controversy.
	•	Prefer proofs/derivations over commentary when possible.

3) Weighting across categories (priority order)
	1.	Holography/QECC (AdS/CFT code subspace, entanglement wedge reconstruction, HaPPY/tensor networks, Hayden–Preskill; bulk decoding analogues of U_{\text{evap}}).
	2.	Islands &amp; JT/SYK (Page curve, QES/replica wormholes; minimal encode–scramble–evaporate models).
	3.	Spin Foam / LQG (isolated horizons + spin foams) (area spectrum, microstate counting, EPRL amplitudes, Pachner moves as dynamics).
	4.	Fast scrambling / OTOCs (bounds, diagnostics for “fold depth”).
	5.	Soft hair / asymptotic symmetries (BMS charges as complementary carriers).
	6.	Regge/deficit-angle &amp; “origami” analogues (only if mathematically actionable).

If time-limited, complete 1–3 thoroughly first, then 4–6.

4) Mapping table (initial candidates — please confirm/refine)
	•	\mathsf F_{\text{hol}} (holonomy weaving / puncture creation)
	•	Anchors: Isolated horizon microstate counting; horizon area spectrum; Wilson-loop holonomies (LQG).
	•	\mathsf F_{\text{rec}} (SU(2) recoupling / intertwiners / entangling)
	•	Anchors: SU(2) recoupling theory, intertwiners as gauge-invariant couplers, fusion rules; holographic QECC analogues via tensor networks.
	•	\mathsf F_{\text{Pachner}} (bulk crystallization via spin-foam moves)
	•	Anchors: EPRL/Barrett–Crane spin-foam amplitudes; Pachner (1–4, 2–3) moves; Regge deficit angles as localized curvature (“crease lines”).
	•	\mathcal E (isometric encoder / code subspace)
	•	Anchors: AdS/CFT as QECC (Almheiri–Dong–Harlow); HaPPY code; subregion duality.
	•	U_{\text{scr}} (fast scrambler)
	•	Anchors: Hayden–Preskill mirror, Sekino–Susskind fast scrambling, OTOC/Lyapunov bounds (MSS).
	•	U_{\text{evap}} (unitary coupling to radiation / decoding)
	•	Anchors: Islands/Page-curve via replica wormholes; entanglement wedge reconstruction as decoding analogue.

Output expectations (unchanged)
	•	Exec synthesis (1–2 pp) mapping RFO ↔ literature.
	•	Annotated bibliography (10–20 items) with key equations + why-it-matters for RFO.
	•	Equation pack (LaTeX-ready): area spectrum &amp; microstate count; QES/islands; QECC isometries; OTOC bounds; spin-foam amplitudes &amp; deficit angles.
	•	Observables/tests: OTOC/spectral form factor for fold depth; late-time Hawking correlations; any soft-hair signatures.
	•	Risks/controversies: firewalls/AMPS, state-dependence, soft-hair sufficiency, LQG counting variants.

If anything here is ambiguous, make a best-judgment call and flag assumptions inline.

---

**assistant:**

{
  &quot;task_violates_safety_guidelines&quot;: false,
  &quot;user_def_doesnt_want_research&quot;: false,
  &quot;response&quot;: &quot;Understood. I’ll begin assembling a full Resonance Fold Operator (RFO) literature pass, anchoring each of its components—encoder, scrambler, evaporator, fold generators—to published frameworks across AdS/CFT QECC, spin foams, JT/SYK, soft hair, and scrambling bounds. This will include an executive mapping summary, a curated annotated bibliography with key equations, an equation pack, RFO ↔ literature component mapping, observable diagnostics, and a controversy log.\n\nI&#x27;ll get started and update you as soon as the core sections are ready for review.&quot;,
  &quot;title&quot;: &quot;Resonance Fold Operator Literature Pass&quot;,
  &quot;prompt&quot;: &quot;Conduct a deep literature review to support the Resonance Fold Operator (RFO) formalism, which models a black hole as an origami-like folding operator:\n\n|ψ_folded⟩ = 𝐹̂_BH |ψ_in⟩\n\nwith Hilbert spaces:\n• 𝓗_in = exterior Fock space on 𝓘^−\n• 𝓗_geom = 𝓗_hor ⊗ 𝓗_bulk^top ⊗ 𝓗_rad\n\nand RFO defined as:\n𝐹̂_BH = U_evap ∘ U_scr ∘ 𝓔\n\nwhere 𝓔 is an isometric encoder composed of fold generators ℱ = {ℱ_hol, ℱ_rec, ℱ_Pachner}.\n\nDeliverables:\n1. Executive synthesis mapping RFO modules to literature (1–2 pages)\n2. Annotated bibliography (10–20 items) in APA format, each with:\n   • Citation + links (arXiv, DOI)\n   • Context tags (e.g., {Holography/QECC, Spin-Foam/LQG})\n   • 3–5 key equations\n   • Summary + relevance for RFO\n   • Caveats or controversies\n3. Equation pack (LaTeX-ready) including:\n   • Isolated horizon area/microstate formulas\n   • Replica wormhole Page curve derivations\n   • QECC isometries and subregion duality formulas\n   • OTOC/Lyapunov scrambling bounds\n   • Spin foam amplitude expressions (EPRL, Regge deficit angles)\n4. Component mapping table:\n   • RFO modules (𝓔, U_scr, U_evap, ℱ_hol, ℱ_rec, ℱ_Pachner) ↔ canonical constructs (e.g. HaPPY code, EPRL moves)\n5. Observables &amp; testable diagnostics:\n   • E.g. Fold depth as spectral form factor slope; late Hawking correlations; soft hair charge shifts\n6. Risk log:\n   • E.g. firewall paradox, state-dependence objections, LQG area spectrum ambiguities\n\nPrioritize:\n• Holography/QECC literature first (AdS/CFT codes, wedge reconstruction)\n• Then islands &amp; JT/SYK (minimal encode–scramble–evaporate)\n• Then LQG (spin-foam amplitudes, Pachner moves)\n• Then scrambling/OTOCs, soft hair, and formal fold analogies (Regge, origami)\n\nInclude both foundational papers and up-to-date preprints (label clearly). Emphasize derivations and isometry conditions.\n\nFormat as structured research output with clear headings, APA citations, LaTeX-ready equations, and mapping tables.&quot;
}

---

**tool:**

All the files uploaded by the user have been fully loaded. Searching won&#x27;t provide additional information.

---

**assistant:**

Understood. I’ll begin assembling a full Resonance Fold Operator (RFO) literature pass, anchoring each of its components—encoder, scrambler, evaporator, fold generators—to published frameworks across AdS/CFT QECC, spin foams, JT/SYK, soft hair, and scrambling bounds. This will include an executive mapping summary, a curated annotated bibliography with key equations, an equation pack, RFO ↔ literature component mapping, observable diagnostics, and a controversy log.

I&#x27;ll get started and update you as soon as the core sections are ready for review.

---

**assistant:**

# Executive Synthesis of RFO and Literature Mapping

The **Resonance Fold Operator (RFO)** formalism models a black hole as an origami-like *folding* operator acting on an incoming state: \( |\psi_{\text{folded}}\rangle = \hat{F}_{BH} \, |\psi_{\text{in}}\rangle.\) Conceptually, this operator factors into an **isometric encoding** \(\mathcal{E}\) of infalling information, followed by a **scrambling unitary** \(U_{\text{scr}}\) and an **evaporation unitary** \(U_{\text{evap}}\). These stages mirror known constructs in quantum gravity and quantum information:

- **Isometric Encoder \(\mathcal{E}\):** This maps the exterior infalling state into the enlarged black hole Hilbert space \(\mathcal{H}_{geom} = \mathcal{H}_{hor}\otimes \mathcal{H}_{bulk}^{top}\otimes \mathcal{H}_{rad}\). It parallels **holographic quantum error-correcting codes** which embed a “logical” bulk state into a larger “physical” boundary Hilbert space【38†L53-L61】【40†L66-L74】. In HaPPY codes and AdS/CFT, the bulk Hilbert space is isometrically encoded in many physical qubits, reproducing features like the Ryu–Takayanagi entropy formula and entanglement wedge (subregion) duality【38†L53-L61】. The RFO’s \(\mathcal{E}\) draws on this isometric mapping, ensuring bulk operators can be represented on multiple disjoint exterior subsystems similar to AdS/CFT’s redundant encoding of interior information【38†L57-L65】.

- **Scrambling Unitary \(U_{\text{scr}}\):** This corresponds to the chaotic internal dynamics that rapidly mixes degrees of freedom. In RFO it is generated by “fold moves” \(\mathcal{F}_{hol}\) and \(\mathcal{F}_{rec}\), which abstractly represent **holographic mixing** and **information recovery folds**. Canonically, \(U_{\text{scr}}\) aligns with the concept of black holes as **fast scramblers**【51†L53-L59】, saturating conjectured limits on how quickly information thermalizes (on the order of the log of entropy)【51†L53-L59】. In quantum information terms, one models \(U_{\text{scr}}\) as a high-depth random circuit or Haar-random unitary (as in the Hayden–Preskill mirror model of black hole scrambling). This scrambling ensures that any small subset of Hawking radiation initially carries nearly no information about the interior, consistent with Page’s theorem.

- **Evaporation Unitary \(U_{\text{evap}}\):** Finally, \(\hat{F}_{BH}\) includes the unitary that entangles the black hole with outgoing Hawking quanta and lets them escape, reducing the horizon Hilbert space dimension. In quantum circuits this is an **isometry from \(\mathcal{H}_{BH}\) to \(\mathcal{H}_{BH}&#x27;\otimes \mathcal{H}_{rad}^{\text{new}}\)**, as used in Page curve toy models (each emission coupling internal modes to new radiation modes). This process is informed by recent **entanglement island** calculations and toy models (e.g. JT gravity + bath or SYK chains) showing a **Page transition** when a new quantum extremal surface (island) forms inside the horizon at the Page time【44†L51-L59】. \(U_{\text{evap}}\) thus implements the late-time encoding of interior (island) information into the radiation, analogous to how part of the black hole interior is encoded in Hawking radiation after the Page time【44†L55-L63】.

Crucially, the RFO’s internal **“fold generators”** \(\mathcal{F}=\{\mathcal{F}_{hol}, \mathcal{F}_{rec}, \mathcal{F}_{Pachner}\}\) map onto canonical structures across gravity formalisms:

- **\(\mathcal{F}_{hol}\)** – *Holographic fold:* Encodes the **holographic entanglement structure**. It corresponds to tensors or mappings that enforce the Ryu–Takayanagi relation and error-correcting property in AdS/CFT codes【38†L53-L61】. Think of this as the “HaPPY code” perfect tensors folding the spacetime into a discrete hyperbolic tiling, or the entanglement wedge reconstruction isometries that push bulk operators to the boundary【38†L57-L65】. \(\mathcal{F}_{hol}\) draws on literature of **quantum error correction in gravity**【40†L66-L74】, ensuring any bulk (interior) operator can be represented on an appropriate subsystem of exterior plus radiation degrees (mimicking subregion duality).

- **\(\mathcal{F}_{rec}\)** – *Recovery fold:* Implements **operator recovery/Petz map** features. In recent works, the entanglement wedge reconstruction has been made explicit via the Petz recovery channel【46†L53-L61】, which here acts as a “fold” that allows interior operators to be recovered from radiation (especially after Page time). \(\mathcal{F}_{rec}\) ties to **quantum error-correcting recovery** in AdS/CFT【46†L57-L60】 and the concept of state-specific reconstructions (Papadodimas–Raju proposal) – effectively ensuring that information is not lost but encoded in a way that *can* be unfolded given the right key (early radiation as a decoder). This fold encapsulates the nuanced idea that interior encoding may be *non-isometric* after sufficient evaporation: recent theory argues a fully isometric interior encoding fails at late times【50†L53-L61】, requiring non-isometric, state-dependent recovery maps protected by computational complexity【50†L53-L61】【50†L57-L65】. \(\mathcal{F}_{rec}\) accounts for these subtle “non-isometric code” effects needed to avoid firewalls while retrieving information.

- **\(\mathcal{F}_{Pachner}\)** – *Geometric/Pachner fold:* Encodes **spin-foam like geometric transitions**. It corresponds to discrete moves (Pachner moves) that reconfigure the black hole’s internal spin-network geometry (horizon area quanta, topology of interior). In loop quantum gravity (LQG) and spin-foam models, Pachner moves (e.g. 2–3 or 1–4 simplicial moves) represent evolutions of quantum geometry【17†L55-L64】【17†L57-L65】 and are related to imposing diffeomorphism invariance (no preferred discretization)【17†L59-L64】. \(\mathcal{F}_{Pachner}\) thus maps to the **EPRL spin foam vertex moves**【36†L19-L23】 – the allowed local transitions in the spin network state that change horizon area and bulk topology in discrete units. These moves conserve the Bekenstein–Hawking area law in expectation, as the area spectrum in LQG is quantized in units set by the Immirzi parameter【54†L53-L58】. By including \(\mathcal{F}_{Pachner}\), the RFO captures the idea that black hole evaporation (and interior change) can be seen as a sequence of local geometric transitions (each emitting a quantum reduces horizon area by one spin unit, a “fold” in the horizon’s quantum geometry).

In summary, each RFO module finds support in the literature: \(\mathcal{E}\) in holographic QEC codes【38†L53-L61】, \(U_{\text{scr}}\) in fast scrambling dynamics【51†L53-L59】 and out-of-time-order correlator (OTOC) bounds【52†L53-L56】, \(U_{\text{evap}}\) in entanglement island Page curve analyses【44†L51-L59】, and the fold generators in AdS/CFT codes【38†L57-L65】, Petz recovery maps【46†L57-L60】, and spin-foam Pachner moves【17†L55-L63】. The table in Section &quot;Component Mapping&quot; provides a structured mapping. This formalism thus weaves together holography, quantum information, and loop quantum gravity insights to describe black hole unitarity: infalling information is **encoded (folded)** into a larger geometric Hilbert space, **scrambled** chaotically, and then **evaporated (unfolded)** in Hawking radiation in a way that preserves correlations (resolving the information paradox)【44†L55-L63】【57†L53-L61】.

**Foundational works** like Almheiri–Dong–Harlow (2015) first noted AdS/CFT’s code-like behavior【40†L66-L74】, and recent preprints (2022) by Akers et al. have refined the late-time picture with non-isometric encoding to reconcile interior growth with a finite-dimensional Hilbert space【50†L53-L61】. These developments ensure each piece of RFO is anchored in current theory. The following annotated bibliography (Part 2) documents these sources, and subsequent sections (Parts 3–6) present the key equations, mappings, observables, and risks, consolidating the theoretical backbone for the RFO proposal.

## Annotated Bibliography (Key Literature, APA Style)

**1. Pastawski, F., Yoshida, B., Harlow, D., &amp; Preskill, J. (2015).** *Holographic quantum error-correcting codes: Toy models for the bulk/boundary correspondence*. **JHEP, 2015**(6), 149. DOI: 10.1007/JHEP06(2015)149. arXiv:1503.06237. {Holography/QECC}【38†L53-L61】

- **Key Equations:** Perfect tensor isometry condition; Ryu–Takayanagi (RT) surface = minimal cut in network (entropy \(S_A = \frac{\text{# legs cut}}{2}\log D\)); Bulk operator recovery on multiple boundaries (code subspace property)【38†L57-L65】.
- **Summary:** Introduces a **tensor network code** (HaPPY code) where each tensor is a *perfect tensor* (maximally entangled across any bipartition), yielding an isometric map from “bulk” to “boundary” Hilbert spaces【38†L53-L61】. The network exactly reproduces key holographic entropy relations (RT formula) and demonstrates how **bulk logical qubits are protected against erasures** on the boundary【38†L57-L65】. It provides an explicit toy model of **subregion duality**: bulk operators can be reconstructed on different boundary regions, analogous to AdS/Rindler reconstruction【38†L61-L65】.
- **Relevance to RFO:** Serves as the prototype for the **encoding map \(\mathcal{E}\)** and **holographic fold \(\mathcal{F}_{hol}\)**. It shows how a black hole interior (bulk) could be encoded in exterior degrees of freedom with quantum error-correcting properties, and how the **entanglement structure (folding)** yields the correct Bekenstein–Hawking entropy scaling【38†L53-L61】. This supports RFO’s idea of an isometric fold encoding the black hole state.
- **Caveats:** The toy model is static (no dynamics/evaporation) and lives in a negative curvature (AdS) context, whereas an evaporating black hole requires extending to a dynamic code. Also, the perfect tensor network slightly deviates from exact AdS/CFT at finite N (no exact entanglement wedge phase transition), though it captures the essence qualitatively.

**2. Almheiri, A., Dong, X., &amp; Harlow, D. (2015).** *Bulk Locality and Quantum Error Correction in AdS/CFT*. **JHEP, 2015**(4), 163. DOI: 10.1007/JHEP04(2015)163. arXiv:1411.7041. {Holography/QECC}【40†L66-L74】

- **Key Equations:** Defines an operator algebra QEC condition: for all bulk operators \(O_{bulk}\) in a code subspace, \(\exists O_A\) on boundary region A such that \(O_{bulk}|\psi\rangle = O_A|\psi\rangle\) for all code states \(|\psi\rangle\). Suggests **entanglement wedge** = region where this holds. Proposes **quantum secret-sharing** interpretation (threshold for reconstruction).
- **Summary:** This paper articulates the idea that AdS/CFT implements a **quantum error-correcting code** protecting bulk information from boundary erasures【40†L66-L74】. Bulk locality (the ability to reconstruct a bulk operator in different boundary regions) is recast as the statement that the code’s logical information is redundantly encoded. It distinguishes between reconstruction in the **causal wedge** vs the larger **entanglement wedge**, linking the latter to quantum secret-sharing thresholds【40†L69-L74】. It uses *operator algebra QEC* formalisms to formalize subregion duality.
- **Relevance to RFO:** Establishes the theoretical grounding that a black hole interior can be non-trivially encoded in exterior/radiation Hilbert spaces (i.e. not simply a subfactor). This supports the design of \(\mathcal{E}\) and \(\mathcal{F}_{hol}\) in RFO as an **error-correcting isometry**. The distinction between causal vs entanglement wedge mapping relates to whether RFO’s interior info is accessible only with a **threshold number of qubits** (like after Page time when island appears). Indeed, it hints that **information becomes reconstructible from radiation only after a certain point**, analogous to RFO’s \(U_{\text{scr}}\)+\(U_{\text{evap}}\) effect.
- **Caveats:** Focuses on static AdS black holes and code subspace of low-energy states. Does not by itself solve the info paradox for evaporating BH, which requires *dynamical* inclusion of Hawking radiation (addressed by later “islands” papers). Also, assumes exact error correction; in reality code might be approximate with non-perturbative errors【44†L61-L69】.

**3. Dong, X., Harlow, D., &amp; Wall, A. C. (2016).** *Reconstruction of Bulk Operators within the Entanglement Wedge in Gauge-Gravity Duality*. **Phys. Rev. Lett., 117**(2), 021601. DOI: 10.1103/PhysRevLett.117.021601. arXiv:1601.05416. {Holography/QECC}【41†L51-L59】

- **Key Equations:** Proof of **entanglement wedge reconstruction**: If \(\rho\) and \(\sigma\) are two boundary states that are identical on region A (i.e. their reduced density matrices \(\rho_A=\sigma_A\)), then for any bulk operator \(\phi\) in the entanglement wedge of A, \(\text{Tr}(\rho\, \phi) = \text{Tr}(\sigma\, \phi)\). (Implies existence of an operator on A representing \(\phi\).)
- **Summary:** Proves that *any bulk operator in the entanglement wedge of boundary region A can be represented as a boundary operator acting only on A*【41†L51-L59】. This was a milestone, extending earlier results that only guaranteed reconstruction up to the causal wedge. The proof leverages quantum **relative entropy** results (JLMS) and QEC theory: essentially showing AdS/CFT obeys operator algebra QEC conditions so that the entanglement wedge is the correct reconstruction region【41†L55-L59】.
- **Relevance to RFO:** Validates the **entanglement wedge = interior encoding** concept used in RFO. As the black hole evaporates, the entanglement wedge of the radiation grows to include the interior (“islands”). RFO’s evaporation module \(U_{\text{evap}}\) is built to ensure **early radiation + remaining BH subsystem’s entanglement wedge covers the interior after Page time**, enabling interior info to be “unfolded” into radiation. This PRL provides the information-theoretic assurance that such reconstruction is theoretically possible (with small errors) once one includes quantum extremal surfaces. It also underpins RFO’s **fold generator \(\mathcal{F}_{rec}\)**, since the explicit reconstruction map can be seen as a *decoder fold* that inverts the encoding.
- **Caveats:** This result is leading-order in \(N\to\infty\) (large central charge). At finite N, or non-perturbatively, there can be **tiny errors** in reconstruction【44†L61-L69】 which become important around the Page transition (related to state-dependence issues). The RFO formalism must accommodate such non-perturbative errors (see Akers et al. 2022 below).

**4. Jafferis, D. L., Lewkowycz, A., Maldacena, J., &amp; Suh, S. J. (2016).** *Relative entropy equals bulk relative entropy*. **JHEP, 2016**(6), 004. DOI: 10.1007/JHEP06(2016)004. arXiv:1512.06431. {Holography/QECC}【42†L51-L58】

- **Key Equations:** \(S_{\text{rel}}(\rho_A||\sigma_A) = S_{\text{rel}}(\rho_{\text{bulk}}||\sigma_{\text{bulk}}) + O(1/N)\). And \(\delta \langle T_{00}\rangle_A = \frac{\delta \langle K_{\text{bulk}}\rangle}{4G_N}\) at first order, which via linearized Einstein eq implies \( \text{Area(extremal surf)} /4G = S_{\text{vN}}(A) - S_{\text{bulk}}(extremal) \) – the RT formula as a requirement for equality of modular Hamiltonians.
- **Summary:** Shows that for a small perturbation of a boundary state, the change in **boundary modular Hamiltonian** equals the change in **bulk modular Hamiltonian** (plus area term) to leading order【42†L51-L58】. Intuitively, this means **boundary relative entropy = bulk relative entropy**, cementing the idea that *no information is lost in the bulk-to-boundary map*. As a consequence, **modular flow commutes with the AdS/CFT encoding** up to extremal surface, strongly suggesting the entanglement wedge is the correct region for duality【42†L53-L56】.
- **Relevance to RFO:** This is a foundational consistency check for the **isometric encoding \(\mathcal{E}\)** – it preserves fine-grained information (relative entropy) between bulk and boundary. In RFO terms, it implies that the **folded state retains all information about the infalling state** (unitarity). Moreover, the RFO’s incorporation of the RT surface (or quantum extremal surface) as the “fold” separating interior vs exterior degrees is justified by this result: the encoder \(\mathcal{E}\) must include an **area term** (horizon entanglement) so that the **entropic balance** (Page curve) can work out【42†L51-L58】. In essence, Jafferis et al. guarantee that as long as the folding isometric conditions are met, the information paradox can be resolved consistently at the semiclassical level (since bulk vs radiation entropy accounting will match).
- **Caveats:** This holds to leading order in \(1/N\) (classical gravity limit). Non-perturbative effects or \(1/N\) corrections are not captured, which are precisely what cause the Page curve to turn over (those come from replica wormholes in newer works). RFO thus must rely on additional inputs (like including \(\mathcal{F}_{rec}\) with non-isometric effects) to capture the Page curve, which pure isometric encodings at large N would miss.

**5. Penington, G. (2020).** *Entanglement Wedge Reconstruction and the Information Paradox*. **JHEP, 2020**(9), 002. DOI: 10.1007/JHEP09(2020)002. arXiv:1905.08255. {Islands/Page Curve, Holography/QECC}【44†L51-L59】【44†L61-L69】

- **Key Equations:** Page curve for entropy of Hawking radiation: \(S_{\text{rad}}(t) = \min\{S_{\text{Hawking}}(t),\, S_{\text{BH}}(0) - S_{\text{Hawking}}(t)\}\) (i.e. rises then falls). Scrambling time \(t_* = \frac{\beta}{2\pi}\ln S_{BH}\) appears as offset for when interior Hawking pairs get entangled with early radiation【44†L51-L59】. Also uses Hayden–Preskill: outgoing diary retrievable after radiating ~half the BH entropy.
- **Summary:** This landmark paper showed that including **quantum extremal surfaces (islands)** in entropy calculations yields a **phase transition at Page time** in the RT surface, reproducing the Page curve【44†L51-L59】. Before Page time, the RT surface is trivial (no island, entropy grows as Hawking predicted); after Page time, a new RT surface just inside the horizon (the “island”) dominates, leading to decreasing radiation entropy【44†L51-L59】. Crucially, part of the black hole interior becomes encoded in the radiation entanglement wedge after Page time【44†L55-L63】. The paper also discusses how **Hayden–Preskill decoding** is realized: after the scrambling time, information thrown in can be recovered from Hawking radiation (provided one has all radiation up to a bit past Page time)【44†L53-L58】. State-dependence is addressed: immediately after Page time, interior reconstruction from radiation is only possible if one knows the initial BH microstate (a subtle form of state dependence), but as more radiation is collected, a single reconstruction works for a broader class of states【44†L61-L69】.
- **Relevance to RFO:** This directly informs the design of \(U_{\text{evap}}\) and the dynamics of folding/unfolding. The formation of an **island** inside the horizon corresponds to a new “fold” that effectively transfers degrees of freedom from \(\mathcal{H}_{hor}\) to \(\mathcal{H}_{rad}\). RFO encodes this via \(\mathcal{F}_{Pachner}\) (reducing horizon area) and \(\mathcal{F}_{rec}\) (enabling radiation to hold interior info). Penington’s use of entanglement wedge reconstruction “until the extremal surface”【40†L69-L74】 matches the RFO notion that the encoder \(\mathcal{E}\) initially maps interior to horizon degrees, but after evaporation, the wedge extends out to radiation. It also flags the importance of **non-perturbative errors and state-dependence**【44†L61-L69】 – RFO’s recovery fold must likely be state-specific or have a huge complexity (consistent with Akers et al. 2022 argument that interior encoding becomes non-isometric and protected by complexity【50†L53-L61】).
- **Caveats:** The analysis is within simplified models (evaporating AdS$_2$ black hole coupled to bath, JT gravity). One assumes an ensemble average via replica trick – there’s a lingering question of what in a single theory replicates the ensemble behavior (Penington hints at baby universes or a pseudo-ensemble interpretation). In RFO, one might worry whether a deterministic unitary can capture the ensemble behavior (related to the “how are wormholes realized in a single system?” issue). This is noted in the next entry (Penington et al. 2019b).

**6. Penington, G., Shenker, S. H., Stanford, D., &amp; Yang, Z. (2022).** *Replica wormholes and the black hole interior.* **JHEP, 2022**(3), 205. DOI: 10.1007/JHEP03(2022)205. arXiv:1911.11977. {Islands/Page Curve, Holography/QECC, JT/SYK}【46†L51-L59】【46†L57-L61】

- **Key Equations:** Generalized entropy prescription: \(S(\text{rad}) = \min_{\text{extremal}\,\Sigma}\Big\{\frac{\text{Area}(\Sigma)}{4G_N} + S_{\text{matter}}(\text{rad}\cup \text{island})\Big\}\). This is the *island rule*, derived via replica trick with wormholes. Also, an explicit **Petz map** for interior operators \(\mathcal{P}[\mathcal{O}_{Hawk}]\) is given, showing how a wormhole in the gravitational path integral yields the recovery channel【46†L57-L60】.
- **Summary:** Provides gravitational path-integral justification for the Page curve by including **replica wormhole saddles**【46†L51-L59】. Summing over connected replica geometries leads to the island term dominating after Page time. The paper carefully studies a simple random unitary model and JT gravity, confirming the **Page transition** and showing consistency with unitarity. Additionally, it demonstrates how **interior modes (behind horizon)** are reflected in the radiation via a **wormhole-assisted Petz map** – giving a concrete method to construct interior operators from radiation data【46†L57-L60】. It also interprets the wormhole contribution as hinting that gravity might be an **ensemble average** or have multiple code subspaces (lots of “null states”), raising subtle issues about **factorization**.
- **Relevance to RFO:** Cemented the idea that **wormholes (folds connecting replicas)** have operational meaning as the mechanism by which *information that was classically inside gets distributed into radiation correlations*. In RFO, one can think of the **fold depth** (how many successive fold operations, analogous to higher topologies in replica calculations) as related to the **spectral correlations** (see Observables: spectral form factor ramp). This paper’s Petz map derivation【46†L57-L60】 directly motivates RFO’s \(\mathcal{F}_{rec}\): effectively realizing the **recovery of interior from radiation via a non-trivial channel**. It also provides a working example (in SYK/AdS$_2$) of the entire encode–scramble–evaporate sequence that RFO formalizes.
- **Caveats:** The reliance on ensemble interpretation (mentioned as “wormholes imply ensemble average”【46†L59-L61】) is a caveat – does a single theory do this or is it an approximation? RFO assumes a single-unitary evolution; thus one must interpret the wormhole results appropriately (perhaps as **self-averaging** behavior or typicality in a high-dimensional Hilbert space). Another subtlety: the Petz map constructed is *approximate* and state-dependent. The authors note potential issues with a state-independent interior operator for very old black holes (ties into **Akers et al.’s non-isometric codes**). RFO’s solution to that is to include a complexity-based restriction (making \(\mathcal{F}_{rec}\) effectively inoperable without exponential resources, aligning with the idea that interior info is protected by huge complexity until the correct decoding “key” is applied).

**7. Akers, C., Engelhardt, N., Harlow, D., Penington, G., &amp; Vardhan, S. (2022).** *The black hole interior from non-isometric codes and complexity.* arXiv:2207.06536 (preprint, 90pp). {Islands/Page Curve, Holography/QECC, State-dependence}【50†L51-L59】【50†L61-L65】

- **Key Equations:** No single isometry can embed exponentially large interior into fixed \(N\)-microstate Hilbert space once Hawking radiation carries away entropy &gt; half. Instead, one envisions a **non-isometric encoding**: Many interior states get mapped to the *same* exterior state (thus “null states” in the code). The condition for successful reconstruction becomes state-dependent and limited by **computational complexity**: interior operators that differ by exponentially complex unitary cannot all be realized on the same code subspace. They formalize a model where the code space dimension grows with time (or complexity) beyond the physical Hilbert space dimension, necessitating post-selection or null states.
- **Summary:** Tackles the issue that at late times the effective number of interior degrees (if one trusts semiclassical EFT) far exceeds the number of microstates available, violating the assumption of an isometric encoding【50†L53-L61】. They propose that the interior is still encoded via QEC, but *not as an isometry* – instead as a **non-isometric code** protected by complexity. Key phenomena explained in this framework include: (a) lots of **null states** – different would-be interior states map to the same exterior state (resolving the redundancy by declaring them physically identical); (b) **state-dependent reconstructions** – effectively each microstate of the BH might have a slightly different interior operator map (Papadodimas–Raju style), but all these differences are exponentially small in complexity so as not to be noticeable for simple experiments; (c) the Page curve arises naturally from QES in this picture, as before; (d) the firewall paradox is avoided because no single description works for all states, only code subspace by code subspace (hence typical states can still be monogamously entangled without a firewall if one doesn’t demand a global interior operator for all of them at once)【50†L61-L65】.
- **Relevance to RFO:** Provides the **fine-grained blueprint for \(\mathcal{F}_{rec}\)** and RFO’s overall encoding. It tells us that \(\mathcal{E}\) (and \(U_{\text{scr}}\)) cannot globally be an isometry for the interior once too many qubits have evaporated – instead, RFO must incorporate a mechanism (perhaps via \(\mathcal{F}_{rec}\) involving post-selection or conditioning on the specific microstate) to handle interior info. In practice, this might mean RFO’s interior reconstruction works *within a given history of the unitary* but not uniformly for all possible initial states – aligning with the idea of **state-specific folding instructions** to retrieve information. This also justifies why RFO doesn’t create a “firewall”: each infalling observer’s experience can be consistent (no drama) within their code subspace, but a single global unitary trying to work for all initial states would be exponentially complex (inaccessible). The emphasis on **computational complexity** matches the notion that RFO folds may become too complex to invert except with quantum resources scaling exponentially, which is fine physically (no violation of causality or quantum mechanics).
- **Caveats:** This is a new paradigm – introducing non-isometric encoding breaks the usual quantum error correction paradigm (which demands isometries to preserve inner products). It relies on the black hole being a “black box” where one cannot operationally distinguish those null states (which seems reasonable). For RFO, implementing a non-isometric map in a unitary circuit is tricky – essentially it implies some post-selection or ancillary degrees that get traced out (so not a strictly unitary evolution on a fixed Hilbert space). The formalism suggests perhaps that a fundamental theory might involve ensemble averaging or vast redundancy. RFO will have to assume these complexities are handled effectively by including an extremely large (maybe unobservable) topological Hilbert space \(\mathcal{H}_{bulk}^{top}\) in \(\mathcal{H}_{geom}\) as a reservoir for null states, or by considering an ensemble of folds. These subtleties are acknowledged in the risk log (state-dependence and unitarity issues).

**8. Sekino, Y., &amp; Susskind, L. (2008).** *Fast Scramblers*. **JHEP, 2008**(10), 065. DOI: 10.1088/1126-6708/2008/10/065. arXiv:0808.2096. {Scrambling/Chaos}【51†L53-L59】

- **Key Equations:** Conjectures **minimal scrambling time** \(t_* \sim \frac{\hbar}{k_B T}\ln S\) for a system of entropy \(S\) (i.e. time scaling logarithmically with number of degrees of freedom). Points out that black holes, with $T \sim \frac{\hbar c^3}{8\pi k_B G M}$ and $S\sim \frac{A}{4G\hbar}$, saturate this bound (they scramble in ~ a few $M\ln M$ time). Introduces the idea that systems with all-to-all interactions (like matrix models) achieve this bound.
- **Summary:** Argues that black holes are the **fastest scramblers in nature**【51†L53-L59】, meaning they thermalize information astonishingly quickly – too quickly to be accounted for by simple local dynamics. This was motivated by comparing how entropy mixes in BHs vs other systems and by intuition from string theory matrix models (D-brane systems). The paper effectively set the stage for thinking of the BH interior as an **information mirror**: any quantum thrown in gets scrambled among $S$ qubits in $O(\ln S)$ steps, so by the time it comes out in Hawking radiation (which takes on the order $S$ steps to fully emit), its info is thoroughly mixed.
- **Relevance to RFO:** Validates the design of \(U_{\text{scr}}\) as a **deep, highly connected unitary**. RFO’s scrambling module should cause any low-energy perturbation to spread over the entire horizon degrees of freedom in the fast scrambling time. This connects with RFO’s adoption of OTOC bounds (see next ref) – essentially \(\mathcal{F}_{hol}\) and \(\mathcal{F}_{rec}\) likely generate the necessary non-local interactions akin to matrix multiplication. For example, if one imagines \(\mathcal{H}_{hor}\) as many qubits on a stretched horizon, \(U_{\text{scr}}\) must entangle them in a nearly all-to-all fashion, which the RFO fold formalism can encode via sequential fold operations that build up long-range entanglement. The **logarithmic scrambling time** also appears in Penington’s result for the Page time location of the new RT surface【44†L51-L59】, reinforcing that RFO’s evaporation onset and fold rearrangement should happen on that timescale.
- **Caveats:** Fast scrambling is a conjecture (though widely believed, later supported by MSS chaos bound). It’s strictly proven only in certain random circuit models. Also, fast scrambling assumes typical states; special structured states might scramble slower or have conserved quantities that delay mixing. RFO might need to consider that quantum numbers (like charge or angular momentum) slow down scrambling for those sectors. Additionally, real astrophysical black holes might have perturbative graviton exchanges that cause some residual local correlations (“scrambling” in semiclassical sense might have subtleties) – the conjecture is best understood in the context of thought-experiment perfectly symmetric BHs.

**9. Maldacena, J., Shenker, S. H., &amp; Stanford, D. (2016).** *A bound on chaos.* **JHEP, 2016**(8), 106. DOI: 10.1007/JHEP08(2016)106. arXiv:1503.01409. {Scrambling/Chaos}【52†L53-L56】

- **Key Equations:** The **Lyapunov exponent bound**: \(\lambda_L \le \frac{2\pi k_B T}{\hbar}\). For a black hole (with $k_B=\hbar=1$ units), this saturates to $\lambda_L = 2\pi T_{\text{BH}}$ (e.g. for an AdS BH, $\lambda_L = \frac{2\pi}{\beta}$)【52†L53-L56】. Also formalizes chaos via OTOC: \(C(t) = -\langle [W(t), V(0)]^2\rangle_\beta\), and in chaotic systems $C(t)$ grows ~ $\epsilon e^{\lambda_L t}$ for $t &lt; t_*$.
- **Summary:** Proposes a fundamental bound on how quickly **OTOCs can grow**, effectively limiting the rate of information scrambling. Black holes (specifically those with classical horizons, like large AdS black holes or near-extremal ones) are shown to **saturate this bound**, indicative of their maximally chaotic nature. This work was crucial in linking gravity to chaos/complexity (SYK model also saturates the bound). It implies that no physical system can have a Lyapunov exponent (chaos growth rate) larger than a black hole of the same temperature【52†L53-L56】.
- **Relevance to RFO:** Gives a concrete quantitative target for \(U_{\text{scr}}\): the fold operations must produce a scrambling such that **OTOCs decay/grow with maximal Lyapunov exponent**. In practical terms, RFO’s scrambling unitary should make two initially commuting operators (one at $t=0$, one evolved to time $t$) develop a large commutator by $t \sim t_*$. The saturation $\lambda = 2\pi T$ also ties into gravitational shockwave calculations (e.g. the Dray–&#x27;t Hooft shift on horizon), which conceptually correspond to how one additional particle’s fold changes interior state dramatically. RFO can use this in diagnosing how deep a fold is: e.g. **fold depth could correlate with the spectral form factor’s ramp length** (see Observables), and chaos bound saturation ensures the ramp is as steep as random matrix theory predicts for black holes. Essentially, RFO’s \(U_{\text{scr}}\) should be representable as an **evolution by a scrambling Hamiltonian** (like SYK or a random matrix Hamiltonian) that achieves this bound.
- **Caveats:** The bound is derived under assumptions (large $N$ thermal systems, etc.). Extremely low-temperature or integrable systems do not saturate it (but then they’re not black-hole-like). Also, some have considered whether stringy corrections or UV completions might violate the bound (so far no definitive violations except possibly in non-local or disorder-averaged contexts). For RFO, we assume the bound holds exactly, but in a discrete system with finite $S$, there might be pre-scrambling effects or deviations at very early times. 

**10. Ashtekar, A., Baez, J., Corichi, A., &amp; Krasnov, K. (1998).** *Quantum Geometry and Black Hole Entropy*. **Phys. Rev. Lett., 80**(5), 904–907. DOI: 10.1103/PhysRevLett.80.904. arXiv:gr-qc/9710007. {Spin-Foam/LQG, Black Hole Microstates}【54†L53-L58】

- **Key Equations:** Black hole horizon area spectrum in LQG: \(A_{\text{hor}} = 8 \pi \gamma \ell_P^2 \sum_{p=1}^{N} \sqrt{j_p(j_p+1)}\) (each puncture $p$ on the horizon contributes a quantum of area labeled by spin $j_p$). The count of horizon microstates for total area $A$ is \(\Omega(A) \sim \exp(\frac{\gamma_0}{\gamma} \frac{A}{4\ell_P^2})\), where $\gamma_0$ is a constant. Fixing $\gamma=\gamma_0$ yields the Bekenstein–Hawking entropy $S = \frac{A}{4\ell_P^2}$【54†L53-L58】.
- **Summary:** This seminal work in LQG showed that treating an isolated horizon as a boundary with a Chern–Simons theory degrees of freedom leads to a quantized area and a **finite count of microstates** proportional to $\exp(A/(4\ell_P^2))$ when the Barbero–Immirzi parameter $\gamma$ is appropriately chosen【54†L53-L58】. Essentially, it provides a statistical mechanical derivation of black hole entropy from quantum geometry. The Immirzi parameter, an a priori free constant in LQG, gets fixed by requiring the leading term of entropy $\ln \Omega$ matches $A/(4\ell_P^2)$. This work also implies a discrete structure for the horizon: the “soft hair” in LQG are these spins coloring the horizon.
- **Relevance to RFO:** Underlies the **fold generator \(\mathcal{F}_{Pachner}\)**: each emission (or change in horizon) corresponds to changing these spin labels (often by one unit via a $1\to 2$ or $2\to 1$ move on the spin network, etc.). RFO leverages that black hole area is not continuous but comes in discrete chunks – a **single fold move can reduce the horizon area by a quantum** (roughly of order $\ell_P^2$) and produce a Hawking particle. The entropy formula ensures that the **number of internal states** for a given macroscopic area is $\sim e^{A/(4\ell_P^2)}$, consistent with holography. Thus RFO’s encoding $\mathcal{E}$ could be thought to attach spin-network edges (with spins $j$) to the horizon representing each emitted particle’s influence, and $\mathcal{F}_{Pachner}$ updates those spins. The LQG microstate count also resonates with **soft hair** ideas (next entries): here the “hair” are SU(2) Chern–Simons edge states. RFO can incorporate these as part of $\mathcal{H}_{bulk}^{top}$ – extra dof that account for microscopic horizon perturbations carrying information.
- **Caveats:** The Immirzi parameter needing calibration is a bit of a philosophic thorn (the theory didn’t *predict* the exact coefficient of $S$, it had to be fixed). Also, this counting was originally for *non-rotating, uncharged* holes; subsequent work extended to include charge, etc., with similar results【54†L53-L58】. Another issue: LQG’s states count matches Bekenstein–Hawking at leading order but subleading corrections (logarithmic corrections) depend on the details of the model (different approaches yield different coefficients like $-\frac{1}{2}\ln A$ which in some models becomes $-\frac{3}{2}\ln A$). RFO likely doesn’t need those details, but it means the precise distribution of microstates vs area might not be unique. Finally, reconciling this picture (many horizon microstates, somewhat static) with the **dynamical Hawking process** required input from spin foams to describe transitions – that’s why we also look at EPRL moves.

**11. Engle, J., Livine, E., Pereira, R., &amp; Rovelli, C. (2008).** *LQG vertex with finite Immirzi parameter.* **Nucl. Phys. B, 799**, 136–149. DOI: 10.1016/j.nuclphysb.2008.02.018. arXiv:0711.0146. Freidel, L., &amp; Krasnov, K. (2008). *A New Spin Foam Model for 4d Gravity*. **Class. Quant. Grav., 25**, 125018. DOI: 10.1088/0264-9381/25/12/125018. {Spin-Foam/LQG, Pachner Moves}【36†L19-L23】

- **Key Equations:** **EPRL spin foam vertex amplitude** – although intricate, a simplified view: \(A_{v}(j_{f}, i_{e}) = \int_{\text{SL(2,C)}^4} \prod_{f\ni v} d g_{vf}\ \prod_{e\ni v} \delta(g_{ve_1}^{-1}g_{ve_2} \cdots) \prod_{f\ni v} \mathcal{P}_{j_f}(g_{vf})\). Its asymptotic form: \(A_v \sim \cos\Big(\sum_{f} j_f \Theta_f - \frac{\pi}{4}\Big)\) for Regge data, where $\Theta_f$ are dihedral angles (so $\exp(i S_{\text{Regge}})$ behavior). *Pachner move invariance:* For 4D, one expects $Z$ (spin foam sum) to remain invariant under subdividing a 4-simplex into e.g. five 4-simplices (the 1–4 move) up to a finite renormalization factor【17†L55-L64】. EPRL achieves 4-1 and 3-2 move invariance in certain limits【17†L57-L64】.
- **Summary:** These works define the **dynamics of LQG via spin foam path integrals**, notably the Engle–Pereira–Rovelli–Livine (EPRL) model which overcame issues in the older Barrett–Crane model by properly incorporating the Immirzi parameter【36†L19-L23】. The EPRL vertex amplitude can be viewed as a **discrete analog of the path integral for general relativity**. A key consistency condition is that the amplitudes yield the Regge action in the semiclassical limit (so one recovers Einstein’s equations). *Pachner move invariance* is what ensures the continuum limit doesn’t depend on how you triangulate space: the model partially achieves this, though full Lorentzian invariance still under study. Banburski et al. (2015) explicitly computed how amplitudes change under Pachner moves【17†L55-L63】, finding some divergences that hint at necessary regularization/renormalization.
- **Relevance to RFO:** Provides the rule-set for how \(\mathcal{F}_{Pachner}\) folds the geometry. Each Pachner move corresponds to a **topology change or re-triangulation** of the interior spacetime – in RFO, an evaporation step (losing one quantum of area and one “vertex” from the spin network) is akin to a **1–4 move in reverse (4–1)**, where one 4-simplex effectively disappears (horizon gets smaller). The spin foam amplitude for that move relates to a factor that would appear in RFO’s unitary $U_{\text{evap}}$. Essentially, RFO’s evaporation can be thought of as sequential **transition amplitudes between spin network states**, weighted by EPRL vertex amplitudes. That the **Regge action appears** means the RFO’s operation corresponds to an *extremal phase* (stationary action) in the semiclassical limit, consistent with energy conservation and classical geometry. Also, **diffeomorphism (Pachner) invariance** implies RFO’s results should not depend on arbitrary choices of “where to fold first” – a consistency check for the formalism. In practice, RFO might incorporate a summation (path integral style) over different fold sequences if needed, analogous to summing over histories.
- **Caveats:** The spin foam approach is still being refined; issues like **ultraviolet divergences and achieving exact Pachner move invariance** exist (Banburski et al. 2015 found 3–3 moves are troublesome【17†L59-L64】). For RFO, we may assume these are resolved or that only certain “renormalized” moves correspond to physical evaporation. Additionally, relating spin foam directly to conventional Hawking radiation is nontrivial – LQG typically works in Euclidean signature for these sums; connecting to real-time evaporation might require analytic continuation or a separate formalism. Nonetheless, the qualitative insight – that interior space is built of discrete units and can shrink via local moves – is valuable.

**12. Hawking, S. W., Perry, M. J., &amp; Strominger, A. (2016).** *Soft Hair on Black Holes*. **Phys. Rev. Lett., 116**, 231301. DOI: 10.1103/PhysRevLett.116.231301. arXiv:1601.00921. {Black Hole Hair/Soft Hair}【57†L53-L61】

- **Key Equations:** Conservation laws from Bondi–van der Burg–Metzner–Sachs (BMS) supertranslations: an infinite set of quantities $Q_f$ (for every angle-dependent function $f$) that remain constant from past to future null infinity. In a classical sense, these lead to a degeneracy of vacuum states labeled by soft radiation clouds. The paper argues that black holes must carry corresponding **soft supertranslation charges** to obey these laws【57†L53-L61】. A crude count: effective number of soft hair d.o.f. $\sim \frac{\text{Area}}{4\ell_P^2}$ (because modes localized within a Planck length patch of horizon are physically indistinguishable)【57†L59-L63】.
- **Summary:** This proposal, by Hawking *et al.*, suggests that black holes possess an infinite spectrum of low-energy (soft) degrees of freedom associated with large diffeomorphisms (specifically supertranslations and – by extension – superrotations, large gauge transformations etc.). These do not carry energy (soft gravitons, soft photons), but are bookkeeping devices for memory effects. They envision the horizon as storing an imprint of everything that fell in, in the form of these soft hairs (shifting the vacuum). As a consequence, when the BH evaporates, the pattern of soft hair influences correlations in Hawking radiation, thus offering an escape from information loss by subtly imprinting info in correlations among outgoing particles【57†L55-L63】. They derive **exact conservation laws relating the ingoing vs outgoing radiation** for different soft hair configurations【57†L57-L63】.
- **Relevance to RFO:** Soft hair provides *physical* candidates for some of RFO’s abstract constructs. For example, the **soft graviton cloud** on the horizon can be thought of as part of $\mathcal{H}_{hor}$ or $\mathcal{H}_{bulk}^{top}$ that encodes information. In RFO terms, these are like extra “twists” or folds on the horizon that change the global zero-mode structure but not the energy. The presence of an infinite number of conserved charges resonates with the **quantum error correction viewpoint**: they hint at a very large degeneracy (like many orthogonal microstates with the same mass) which could form the code subspace. The RFO’s fold operations might change the soft hair state rather than (or in addition to) radiative degrees, thereby carrying away information without significant energy cost. Indeed, in RFO one could imagine each Hawking quantum is accompanied by a shift in soft hair that ensures global conservation laws and encodes what fell in. The statement that effective soft hair count $\propto$ horizon area【57†L59-L63】 is consistent with Bekenstein–Hawking entropy: it’s essentially saying these soft modes *could* account for the entropy.
- **Caveats:** This idea has been met with both interest and skepticism. Soft hair by itself has not been shown to carry the detailed entanglement structure needed for complete information recovery – they are global charges, and some argue they are insufficient to encode detailed microstate differences (they might only cover a subset of possible info). Additionally, these conservation laws translate to constraints on scattering amplitudes (infrared triangle in QED/QCD), but it’s unclear if they can encode a one-to-one map between collapsing matter states and outgoing Hawking radiation. RFO can include soft hair as part of the mechanism, but likely needs complementary structure (like the ones described in QEC/island picture) to fully solve the paradox. Another caveat: soft hair modes are extremely low frequency – whether they can be excited and manipulated like ordinary qubits is questionable (Hawking et al. acknowledge limitations on exciting too localized hair【57†L59-L63】). So, while soft hair can store information, retrieving it might be practically impossible except via very delicate measurements (which is fine in principle for theory, but poses an effective “hidden-ness” akin to state-dependence/complexity protections).

**13. Haco, S., Hawking, S. W., Perry, M. J., &amp; Strominger, A. (2018).** *Black Hole Entropy and Soft Hair*. **JHEP, 2018**(12), 098. DOI: 10.1007/JHEP12(2018)098. arXiv:1810.01847. {Black Hole Hair/Soft Hair, Kerr BH}【58†L53-L61】

- **Key Equations:** Discovers a pair of commuting Virasoro algebras (left and right) in the symmetry group of a Kerr black hole’s horizon. Specifically, for a Kerr with angular momentum $J$, the central charges are $c_L = c_R = 12J$【58†L55-L61】. Using the Cardy formula for 2D CFT entropy: $S = \frac{\pi^2}{3}(c_L T_L + c_R T_R)$ for appropriate left/right temperatures (for Kerr/CFT correspondence, $T_{L,R}$ related to surface gravity and angular velocity), they exactly recover $S = \frac{\text{Area}}{4G\hbar}$【58†L57-L61】.
- **Summary:** Extends the soft hair idea to rotating black holes. By identifying a Virasoro symmetry (large diffeomorphisms that act non-trivially on the horizon), and constructing the conserved charges (including necessary counterterms to satisfy the algebra), they effectively map the horizon dynamics to a 2D CFT with specific central charge【58†L53-L61】. The fact that the Cardy entropy matches the area law is evidence that these symmetries account for all microstates. In simpler terms, a rotating BH has as many soft degrees of freedom as needed to count the states. This is akin to the *Kerr/CFT correspondence* but derived from the perspective of asymptotic symmetries and horizon constraints.
- **Relevance to RFO:** It suggests a concrete realization of black hole microstates as an ensemble described by a 2D conformal field theory. RFO’s fold operations could then be interpreted in the language of that CFT. For instance, \(\mathcal{F}_{hol}\) and \(\mathcal{F}_{Pachner}\) might correspond to changes in the Virasoro generators or transitions between states in this holographic CFT. The presence of left and right movers could relate to the splitting of interior and exterior modes (or ingoing vs outgoing), providing a more detailed structure to the Hilbert spaces \(\mathcal{H}_{geom}\). The success of the Cardy formula also resonates with the idea that information is stored in *organization of microstates consistent with symmetry*, rather than some hidden massive remnants – in RFO, one can interpret each microstate accessible via fold operations as part of a representation of this symmetry algebra. This also ties RFO to more standard holography for extremal Kerr (which is well studied in AdS$_3$/CFT$_2$ contexts).
- **Caveats:** The result holds for **extremal or near-extremal Kerr** (strictly, the derivation is most justified for the near-horizon of extremal Kerr (NHEK) region, which has an AdS$_3$ structure). For general non-extremal black holes, one might not have a clear CFT interpretation for the entire entropy (the dual might be more complicated or non-unitary). Additionally, matching the entropy via Cardy doesn’t automatically tell us how information is transferred out during evaporation – it just accounts for microstates. But it’s encouraging for the count. In RFO terms, one could incorporate this by ensuring the number of orthogonal folded states corresponds to the count given by the symmetry (which it does by construction if we take horizon area quantization and all soft charges into account). Implementation-wise, using Virasoro generators could make RFO more mathematically tractable (e.g. treat \(\mathcal{H}_{hor}\) as a CFT Hilbert space and fold operations as CFT operations). However, doing this in a dynamical evaporation context (non-equilibrium) is beyond the ideal Cardy regime.

## Equation Pack (LaTeX-Ready)

To substantiate the RFO formalism, we compile key equations from the literature. These equations capture the quantitative foundations of black hole entropy and information recovery that RFO draws upon:

### 1. Isolated Horizon Area Spectrum and Black Hole Microstates (Loop Quantum Gravity)

In LQG, a black hole horizon is treated as a quantum surface punctured by spin network edges. The **area operator** for an isolated horizon is quantized as 【54†L53-L58】:

\[ 
\hat{A}_{\text{hor}} = 8\pi G \, \gamma \sum_{p=1}^{N} \sqrt{j_p(j_p+1)}\,,
\] 

where $j_p \in \{\frac{1}{2},1,\frac{3}{2},\dots\}$ are spins labeling the $N$ punctures, $G$ is Newton’s constant, and $\gamma$ is the Barbero–Immirzi parameter. The horizon area $A$ must lie in the spectrum of $\hat{A}_{hor}$. The number of microstates $\Omega(A)$ consistent with a total classical area $A$ grows exponentially. For large $A$, one finds 【54†L53-L58】:

\[ 
\ln \Omega(A) \;\approx\; \frac{\gamma_0}{\gamma}\,\frac{A}{4 G \hbar} + \text{lower-order corrections}\,,
\] 

where $\gamma_0$ is a constant determined by combinatorial analysis. By choosing $\gamma=\gamma_0$ (often $\gamma_0 = \ln(2)/\pi\sqrt{3}$ in SU(2) LQG), one obtains the Bekenstein–Hawking entropy formula 

\[ 
S_{\text{BH}} = \ln \Omega(A) \;\approx\; \frac{A}{4 G \hbar} \,. 
\]

This matches the semiclassical black hole entropy ${A}/(4G\hbar)$【54†L53-L58】. Subleading quantum corrections are typically logarithmic ($-\frac{1}{2}\ln A$ for SU(2) LQG). *Relevance:* RFO uses this discrete area spectrum—each “fold” (Hawking emission) corresponds to reducing the horizon area by one quantum, and the large degeneracy $\Omega(A)$ provides the basis for a huge code subspace at area $A$. The Immirzi parameter’s tuning ensures that the **folded Hilbert space dimension** matches the exponential of area/4, consistent with holography.

### 2. Replica Wormhole Formula and Page Curve for Hawking Radiation

The breakthrough in resolving the Page curve came with the **quantum (or generalized) extremal surface** prescription including islands【46†L51-L59】. The entanglement entropy of radiation $S_{\text{rad}}$ at a given time is obtained by an extremization:

\[ 
S_{\text{rad}}(t) \;=\; \min_{\text{Candidate islands}}\; \ext_{\; I(t)} \Bigg[ \frac{\operatorname{Area}(\partial I)}{4 G_N \hbar} + S_{\text{matter}}\big(\text{Rad}(t)\cup I(t)\big)\Bigg]\,,
\] 

where $I(t)$ is a possible “island” region inside the black hole at time $t$ and $\partial I$ is the boundary of that island (often an extremal surface just inside the horizon). In practice, this yields **two competing entropy contributions** for an evaporating black hole:

- **No-island (Hawking)**: $S_{\text{rad}}^{(\text{no-island})}(t)$ which grows linearly with time (as more Hawking quanta get emitted, roughly $S \sim 2\pi k_B c \, t /3M$ in 2D models, or follows Hawking’s thermal entropy increase).
- **Island (unitarity)**: $S_{\text{rad}}^{(\text{island})}(t)$ which after the Page time is approximately $S_{\text{BH}}(t)$ (the remaining Bekenstein–Hawking entropy of the black hole, decreasing as it evaporates).

Thus one finds a Page curve behavior 【44†L51-L59】 by taking the minimal of the two:

\[ 
S_{\text{rad}}(t) \;\approx\; \min\Big\{\,S_{\text{Hawking}}(t)\,,\; S_{\text{BH}}(0) - S_{\text{Hawking}}(t)\,\Big\}\,. 
\]

Graphically, $S_{\text{rad}}(t)$ rises like Hawking’s prediction at early times, then **transitions at $t_{\text{Page}}$** to follow the decreasing black hole entropy, ensuring $S_{\text{rad}}(t_{\text{final}})=0$ when the BH is gone【44†L53-L59】. The **Page time** $t_{\text{Page}}$ is when $S_{\text{rad}}\approx S_{\text{BH}}$, typically about half the evaporation time. For an AdS black hole coupled to a bath, Page time corresponds to when a **new RT surface (quantum extremal surface)** appears just inside the horizon, at an infalling time about one scrambling time in the past【44†L51-L59】. The scrambling time $t_* = \frac{\beta}{2\pi}\ln S_{BH}$ (with $\beta$ the inverse Hawking temperature) emerges naturally in this context.

*Relevance:* This formula and resulting Page curve underpin RFO’s **unitary evaporation model**. The encoder $\mathcal{E}$ combined with $U_{\text{scr}}$ ensures entanglement structure such that initially radiation entropy rises (Hawking phase), but as $U_{\text{evap}}$ progresses, interior DOF start to be transferred out (island phase), yielding a turnover in entropy. RFO explicitly enforces this via its fold operations: before Page time, fold operations mainly add entropy to radiation, but after Page time, each fold (particle emission) reduces BH entropy more than it increases radiation entropy (since radiation modes are purified by interior modes – the interior now partly lies in radiation). The RFO’s design must replicate the minimization above – effectively computing two scenarios (with or without interior in the radiation’s entanglement wedge) and realizing the one with lower entropy as the physical branch (a unitarization of the entropy evolution). 

### 3. Quantum Error Correction Isometries and Subregion Duality 

A key property of holographic encodings (AdS/CFT and beyond) is that the bulk-to-boundary map is an **isometry** that acts like a quantum error-correcting code. This can be expressed in two complementary ways:

- **Isometric embedding:** There exists a linear isometry $V: \mathcal{H}_{\text{bulk logical}} \to \mathcal{H}_{\text{boundary physical}}$ such that $V^\dagger V = I_{\text{bulk}}$. In tensor network terms, e.g. the HaPPY code, $V$ is realized by contracting perfect tensors and $V$ maps bulk degrees to boundary ones as an exact encoder【38†L53-L61】【6†L43-L47】. Each perfect tensor satisfies for any bipartition (of equal size) $ABA&#x27;B&#x27;$ (with legs $AA&#x27;$ as inputs, $BB&#x27;$ as outputs, say):
\[ 
T_{(AA&#x27;)(BB&#x27;)} = \text{(const)} \times U_{AA&#x27; \to BB&#x27;} \,,
\] 
meaning it’s proportional to a unitary mapping inputs to outputs【6†L19-L27】. Stacking these yields a global isometry $V$ with 
\[V: |\psi_{\text{bulk}}\rangle_{\mathcal{H}_{\text{bulk}}} \mapsto |\psi_{\text{boundary}}\rangle_{\mathcal{H}_{\text{phys}}}\,.\]
This $V$ satisfies $V^\dagger V = I$ (bulk inner products preserved) and typically $V V^\dagger$ acts as a projector onto the code subspace of the boundary.

- **Operator algebra QEC (subregion duality):** For any bulk operator $O_{bulk}$ acting on a subregion $b$ of the bulk (e.g. interior of a black hole, or any entanglement wedge), there exists a boundary operator $O_{A}$ acting on **some boundary region $A$** such that 
\[ 
V\, O_{bulk}\, V^\dagger = O_{A}\,,
\] 
as an equality on the code subspace【40†L69-L74】. Moreover, if region $b$ lies within the entanglement wedge of $A$, one can choose $O_A$ with support only on $A$【41†L51-L59】. In the language of density matrices: if two bulk states differ by an operator in region $b$, their boundary reductions on $A$ differ by the corresponding $O_A$ – and if $b$ is outside the entanglement wedge of $A$, then $O_A$ can be chosen trivial (the difference is an “erasure” that the code corrects)【40†L69-L74】.

These properties are realized, for example, in the HaPPY code where multiple boundary regions can represent the same bulk operator (reflecting redundancy)【38†L61-L65】. The **greedy algorithm** in that code identifies the entanglement wedge of a boundary region, and one can explicitly construct boundary reconstructions for bulk ops therein【9†L923-L932】【9†L949-L958】.

*Relevance:* This is exactly what RFO’s $\mathcal{E}$ and $\mathcal{F}_{hol}$ implement. The initial infalling state $|\psi_{in}\rangle$ in $\mathcal{H}_{in}$ (external modes on $\mathcal{I}^-$, plus perhaps any prepared entangled pairs) is mapped via an isometry to a state in $\mathcal{H}_{geom}$ (BH interior/exterior). This ensures no info is lost at formation – mathematically $\hat{F}_{BH}$ (before evaporation) is an isometry. The subregion duality is crucial for **interior reconstruction**: if one divides the “folded” Hilbert space into radiation $R$ and remainder $B$ (BH), an interior operator localized behind the horizon at a given time will act only on $B$ initially. After enough evaporation (when that interior region becomes part of an island for $R$), the same bulk operator can be realized as an operator on $R$ alone. In the code language: initially $O_{bulk} = O_{B}$, later $O_{bulk}=O_{R}$. The existence of such $O_R$ is guaranteed by the QEC property once the entanglement wedge of $R$ includes that bulk point. The Petz map $\mathcal{P}$ given in Penington *et al.* 2019b is a concrete (though extremely complex) construction of $O_R$ from $O_B$ using radiation data【46†L57-L60】. In equations, one version of the Petz recovery is:

\[ 
\mathcal{P}(O_R) = \rho_B^{-1/2}\, \rho_{BR}\,\big(O_R \otimes I_B\big)\,\rho_{BR}^{-1/2}\,,
\] 

which acts on the joint $BR$ state (with $\rho_{BR}$ the full state and $\rho_B = \Tr_R \rho_{BR}$). This equals $O_{bulk}$ on the code subspace【46†L57-L60】. RFO doesn’t need to implement this explicitly (it’s extremely complex), but the existence ensures interior info **in principle** is recoverable from $R$’s state after Page time.

### 4. Out-of-Time-Order Correlators and Scrambling (Chaos Bound)

A useful diagnostic of scrambling in quantum many-body systems (and black holes) is the **OTOC**. For two initially commuting operators $W$ and $V$, one considers $W(t) = e^{iHt} W e^{-iHt}$ and the correlator $F(t) = \langle W(t)^\dagger V(0)^\dagger W(t)\,V(0)\rangle_\beta$. The OTOC is defined as 

\[ 
C(t) = \langle [W(t), V(0)] [W(t), V(0)]^\dagger \rangle_\beta = 2 - 2\Re F(t)\,,
\] 

for appropriately normalized operators (so that at $t=0$, $C(0)=0$ and as they decohere, $C(t)\to 2$). In chaotic systems, at intermediate times one finds an exponential growth $C(t)\approx \epsilon\, e^{\lambda_L t}$, where $\lambda_L$ is the Lyapunov exponent and $\epsilon\ll 1$ is some small factor (in large-$N$ theories, $\epsilon \sim 1/N^2$ for example). **Maldacena–Shenker–Stanford’s chaos bound** states 【52†L53-L56】:

\[ 
\lambda_L \;\le\; \frac{2\pi k_B T}{\hbar}\,,
\] 

with equality *saturated* by black holes (in the semiclassical limit)【52†L53-L56】. For a BH, $\lambda_L = 2\pi T_{\text{Hawking}}$; for instance a Schwarzschild-AdS BH of inverse temperature $\beta$, $\lambda_L = 2\pi/\beta$ is observed (this was also verified in SYK model, which has a dual nearly-$AdS_2$ gravity).

Another related measure is the **scrambling time** $t_*$. For a system with entropy $S$ (number of qubits $\sim S/\ln 2$), fast scrambling conjecture states:

\[ 
t_* \;\sim\; \frac{\hbar}{k_B T}\,\ln S \,,
\] 

for a system that saturates the chaos bound. A large AdS black hole indeed scrambles in $t_* = \frac{\beta}{2\pi} \ln S$ (appearing in the Penington result as the infalling time of the new RT surface【43†L1-L4】).

*Relevance:* In RFO, this dictates how quickly the unitary $U_{\text{scr}}$ needs to mix information. **Maximal chaos** ensures any perturbation is quickly distributed among all degrees of freedom, which justifies using random unitary models for the interior dynamics (Hayden–Preskill thought experiment models the BH as a random 2-design). The bound also provides a check on fold operations: e.g., if $\mathcal{F}_{hol}$ corresponds to a step of mixing that takes time $\delta t$, we expect after $N$ such steps (fold depth) that $C(t)$ grows to $\mathcal{O}(1)$. That requires $N\,\delta t \approx t_* = \frac{1}{2\pi T}\ln S$. 

In summary, RFO’s scrambling stage must be such that for any simple operator $V$ outside the BH and $W$ acting on one interior excitation, 

\[ 
C(t) = \langle [W(t), V(0)]^2\rangle \sim \epsilon e^{2\pi T t}\,,
\] 

and $C(t_*)\sim O(1)$. In practical terms, the **folded Hamiltonian** (generator of $U_{\text{scr}}$) should have a spectrum and interaction structure that yields this Lyapunov growth. SYK or random matrix Hamiltonians are examples to emulate. The chaos bound essentially informs us that **no faster mechanism** than what we assume (all-to-all interactions of order $N$) is possible, so RFO’s design with chaotic folds is optimal and presumably unique for a unitary model of a black hole.

### 5. Spin Foam Amplitudes and Geometric “Folds” (Pachner Moves &amp; Regge Action)

Spin foams provide the amplitudes for transitions between quantum geometries. A simplified but instructive equation is the **Regge action** for a triangulated spacetime, which spin foam amplitudes approximate in the semiclassical limit. For a given triangulation with hinges (triangles in 4D), the Regge action is:

\[ 
I_{\text{Regge}} \;=\; \frac{1}{16\pi G}\sum_{\Delta} A_{\Delta}\, \epsilon_{\Delta}\,,
\] 

where the sum is over hinge triangles $\Delta$, $A_{\Delta}$ is the area of $\Delta$, and $\epsilon_{\Delta}$ is the deficit angle around that triangle (the total dihedral angle deficit measuring curvature)【17†L55-L63】. In 4D, if spin foam faces (plaquettes) carry spins $j$ related to area by $A=8\pi G \gamma \sqrt{j(j+1)}$, then in a coherent-state or large-$j$ evaluation, **spin foam vertex amplitudes** behave as 【36†L19-L23】:

\[ 
\mathcal{A}_{v}(j_f) \;\sim\; \exp\!\Big[\frac{i}{\hbar} I_{\text{Regge}}(j_f) + \ldots \Big] \;\approx\; \cos\Big(\sum_{f\ni v} (2j_f+1)\Theta_f - \frac{\pi}{4}\Big)\,,
\] 

for appropriate assignment of dihedral angles $\Theta_f$ to faces $f$ meeting at vertex $v$. Here $(2j_f+1)\approx 2j_f$ is proportional to area (in Planck units) and $\Theta_f$ is the extrinsic dihedral angle between tetrahedra at that face. This exhibits how quantum geometry encodes classical curvature in its phase.

A **Pachner move** corresponds to changing the triangulation locally. For example, a 1–4 move splits one 4-simplex into 4, introducing a new vertex in the interior (the time-reverse of Hawking emission would be a 4–1 move: four simplices merge into one, one internal vertex disappears). Spin foam amplitudes are expected to satisfy:

\[ 
Z_{\text{before}} = \text{(local factor)} \times Z_{\text{after}}\,,
\] 

with the local factor ideally $=1$ for perfect invariance (in 3D BF theory, moves are exactly invariant; in 4D gravity, one gets anomalies and divergences that require care)【17†L55-L63】. Banburski *et al.* found that for the Euclidean EPRL model, the 4–2 and 5–1 moves can be made invariant up to a constant, but the 3–3 move (which preserves number of simplices) was problematic【17†L57-L64】. 

*Relevance:* For RFO, Pachner moves represent the **discrete “surgery” on the spin network** corresponding to an evaporation step. The spin foam amplitude’s phase $\exp(i I_{\text{Regge}})$ suggests that the fold operator $U_{\text{evap}}$ might include a phase factor equal to the exponential of (minus) the Regge action of the patch being removed/added. In other words, **each fold carries a phase $e^{-i \Delta I_{\text{Regge}}}$**. If the RFO is constructed in a path-integral-like manner, the total amplitude for a sequence of fold moves is a sum/integral over all sequences weighted by these phases. However, in an ideal unitary (one history) evolution, the phase is just what the Hamiltonian of quantum gravity would accumulate.

The invariance under Pachner moves is analogous to saying the physics doesn’t depend on arbitrary “folding choices”. RFO should respect that – e.g., whether the horizon area decreases via one big jump or a series of small jumps should yield the same final unitary (up to physically irrelevant overall phase). This is conceptually related to diffeomorphism invariance. 

Finally, one can connect Regge action to classical quantities like the **spectral form factor** in chaotic systems. Wormholes contributing to the spectral form factor in gravity are analogous to **handles** in the triangulation connecting two boundaries (two copies of the system). Spin foams can include such handles, and their contribution is weighted by $\exp(i \sum A \epsilon)$; near the “dip-ramp” transition, these give rise to a **linear ramp** (spectral correlations). Although an explicit equation for ramp from spin foam is complicated, a qualitative statement is: *fold (wormhole) depth corresponds to higher topology, which in spectral statistics yields the ramp slope*. E.g., the ramp in random matrix theory is $g(\tau)\sim \tau$ for time $\tau$ less than plateau time; including a single wormhole yields such linear growth.

In summary, the equation pack above provides the mathematical foundation connecting RFO to each domain: LQG (area quantization and entropy), islands (Page curve), QEC (isometric encoding and reconstruction), chaos (scrambling rates), and spin foams (geometric transitions and invariances).

## Component Mapping Table (RFO Modules ↔ Canonical Constructs)

The table below maps each conceptual module or generator in the Resonance Fold Operator formalism to its analogous well-established construct(s) in the literature, along with a brief explanation:

| **RFO Module** | **Corresponding Construct(s)** | **Literature/Canonical Reference** |
|---------------------------|--------------------------------------------------------------|------------------------------------------------|
| $\mathcal{E}$ (Isometric Encoder) | *Holographic quantum error-correcting code* – maps a smaller logical Hilbert space (exterior/infalling modes) into a larger physical one (BH degrees). Ensures $\hat{F}_{BH}$ is an isometry initially. Similar to the **HaPPY code** tensor network encoder (perfect tensor network) which is an explicit isometry from bulk to boundary【38†L53-L61】. Also analogous to the creation of **Einstein–Rosen bridge** (thermofield double) which is an entangled pair isometry. | Pastawski *et al.*, 2015【38†L53-L61】; Almheiri–Dong–Harlow, 2015【40†L66-L74】 (proposal of AdS/CFT as QEC). |
| $U_{\text{scr}}$ (Scrambling unitary) | *Fast scrambler dynamics* – a unitary that delocalizes information across the BH’s degrees of freedom in time $t_* \sim \frac{\beta}{2\pi}\ln S$. Modeled by a **Haar-random unitary** on $S$ qubits or a chaotic Hamiltonian (e.g. SYK model or random matrix Hamiltonian) saturating the **MSS chaos bound** ($\lambda_L = 2\pi/\beta$)【52†L53-L56】. Also related to **Hayden–Preskill’s mirror**: treat BH as a random unitary mixing old radiation with newly thrown-in qubits【44†L53-L59】. | Sekino–Susskind, 2008 (fast scrambler conjecture)【51†L53-L59】; Maldacena–Shenker–Stanford, 2016 (chaos bound)【52†L53-L56】; Hayden–Preskill, 2007 (information mirror thought experiment). |
| $U_{\text{evap}}$ (Evaporation unitary) | *Hawking radiation as quantum circuit* – each step can be modeled as an **isometry**: $\;V: \mathcal{H}_{BH} \to \mathcal{H}_{BH}&#x27; \otimes \mathcal{H}_{\text{rad}}^{(new)}$, with $\dim(\mathcal{H}_{BH}&#x27;) &lt; \dim(\mathcal{H}_{BH})$. In other words, a partial unitary that couples a pair of entangled modes (interior + exterior) and outsends one. This is akin to a one-qubit emission toy model used in Page curve studies, or the **island rule** logic: at each emission, the generalized entropy balance shifts【44†L51-L59】. Canonically represented in baby-universe picture as an **$S$-matrix** between BH and radiation. | Page, 1993 (first Page curve calc, implicit random unitary model); Hayden–Preskill, 2007 (each emitted qubit potentially carries info after scrambling); Penington, 2019【44†L53-L61】 (explicit Page curve via new RT surface); Almheiri *et al.*, 2020 (island rule)【46†L51-L59】. |
| $\mathcal{F}_{hol}$ (Holographic fold generator) | *Bulk–boundary entanglement builder* – corresponds to adding or removing **EPR pairs** between horizon and radiation or between bulk and boundary. For example, adding a Bell pair to the code space increases the entanglement entropy consistent with RT formula. In tensor network terms, $\mathcal{F}_{hol}$ could be a **perfect tensor insertion** (adding one logical and several physical legs)【6†L85-L94】. Also analogous to operations in **entanglement distillation** or **error correction encoding** – creating the necessary entanglement structure for subregion duality. | Pastawski *et al.*, 2015 (perfect tensor network rules)【6†L91-L99】【6†L103-L107】; Harlow, 2017 (tutorial on bulk-boundary entanglement structure as QEC). Also the formation of an ER bridge in an AMPS-type experiment involves creating holographic entanglement with early radiation. |
| $\mathcal{F}_{rec}$ (Recovery fold generator) | *Petz map / decoding operation* – represents the implementation of the **entanglement wedge reconstruction** explicitly. In an ideal scenario, $\mathcal{F}_{rec}$ is the quantum channel that takes a subsystem (early radiation $R$) and **acts to recover interior operators**. It is closely related to the **Petz recovery channel** used in replica wormhole context【46†L57-L60】 and in Papadodimas–Raju state-dependent mapping. In RFO, applying $\mathcal{F}_{rec}$ before $U_{\text{evap}}^{-1}$ would decode the interior. Also ties to the concept of **operator algebra QEC** (only a subalgebra of operators needs to be corrected, not the full state)【9†L969-L977】. | Penington *et al.*, 2019b (explicit Petz map formula for interior reconstruction)【46†L57-L60】; Papadodimas &amp; Raju, 2014 (proposal of mirror operators; state-dependent interior) – though controversial, it’s an inspiration for $\mathcal{F}_{rec}$; Dong et al., 2016 (theorem that such a reconstruction on $R$ exists if interior in ent wedge)【41†L51-L59】. |
| $\mathcal{F}_{Pachner}$ (Geometric fold / Pachner move) | *Spin foam vertex move* – corresponds to a local change in triangulation, e.g. a **$N$–$(N+1)$ move** that changes the number of simplices. In BH terms, a 1–2 move (in 2D) or 1–4 move (in 4D) could model one quantum of area splitting off (the new small simplex being the emitted quantum’s history). In loop quantum gravity, this is associated with an **$SU(2)$ recoupling move** on spin networks (like the $6j$-symbol identity for 2–2 Pachner in 3D, or $15j$ symbol for 4–1 in 4D). **EPRL spin foam amplitudes** give the coefficients for such moves【36†L19-L23】. It’s essentially the “allowed” way geometry can fold/unfold preserving gauge/invariants. | Engle–Pereira–Rovelli–Livine (EPRL) model, 2008 – defines vertex amplitude and thereby rules for gluings【36†L19-L23】; Banburski *et al.*, 2015 – studies Pachner move invariance in spin foams【17†L55-L63】; Barrett &amp; Crane, 1998 – initial spin foam with 4-simplex amplitudes. Also, Freidel &amp; Krasnov, 2008 (FK model) which is equivalent to EPRL for RFO’s purposes. |
| $\mathcal{H}_{in}$ (Exterior Fock space on $\mathcal{I}^-$) | *Incoming Hawking quanta &amp; infalling matter Hilbert space* – essentially the Fock space of quantum field modes at past infinity (before the BH formed or perturbations came). It’s the “input” Hilbert space of the black hole $S$-matrix. Usually taken as a bunch of free-falling vacuum modes (Unruh vacuum). | Hawking, 1975 – quantified flux from vacuum at $\mathcal{I}^-$; for QFT, $\mathcal{H}_{in}$ and $\mathcal{H}_{out}$ are used in $S$-matrix. In modern context, sometimes include an auxiliary purification system if considering an AMPS setup. |
| $\mathcal{H}_{hor}$ (Horizon Hilbert space) | *Black hole stretched horizon degrees of freedom* – in membrane paradigm or ‘t Hooft’s brick wall model, one assigns $\sim e^{A/4}$ states to the vicinity of the horizon. In LQG, $\mathcal{H}_{hor}$ is the Chern–Simons Hilbert space of the horizon punctures (microstates of area)【54†L53-L58】. In string theory (fuzzball or D-brane picture), this corresponds to the bound states representing the BH. RFO treats this as the primary repository of information initially. | Ashtekar *et al.*, 1998 (isolated horizon quantization)【54†L53-L58】; Strominger &amp; Vafa, 1996 (D-brane microstates for extremal BH, analogous horizon state space); Membrane paradigm (Thorne *et al.*, 1986) – while classical, it motivates attributing DOF to horizon. |
| $\mathcal{H}_{bulk}^{top}$ (Bulk topological space) | *Ancillary space for non-isometric encoding / baby universe sector* – this is not radiative but carries “redundant” info. It’s inspired by the presence of **null states or ensemble aspects** in gravity. In coding terms, it’s like a gauge space one traces over. E.g., in Akers *et al.* 2022, a large null space accounts for interior states beyond fundamental DOF count【50†L53-L61】. In wormhole language, this contains baby universe Hilbert space summing over which gives ensemble average. RFO includes it to allow non-isometric but *isometric on average* maps. | Akers *et al.*, 2022 (complexity-protected null states, non-isometric codes)【50†L53-L61】; Marolf &amp; Maxfield, 2020 (baby universes and ensemble of theories); Pennington &amp; Stanford, 2019 (spacetime wormholes leading to ensemble interpretation)【46†L59-L61】. This $\mathcal{H}_{bulk}^{top}$ is essentially a repository for state-dependent phases or global (superselection) data not accessible asymptotically. |
| $\mathcal{H}_{rad}$ (Radiation Hilbert space on $\mathcal{I}^+$) | *Outgoing Hawking radiation Fock space* – all quanta emitted to future infinity. Treated as an environment initially unentangled with the BH, which gains entanglement over time. In Page’s model, it’s just a set of $N$ qubits initially pure (in vacuum) that get entangled with BH qubits after each timestep. | Hawking, 1975 (Hawking radiation as thermal at $\mathcal{I}^+$); Page, 1993 (radiation subsystems entropies); for a more modern picture, see Almheiri *et al.*, 2013 (thought experiment with early vs late radiation). |

This mapping shows that each part of the RFO is not ad hoc, but rather aligned with known structures: encoding = holographic code, scrambling = chaotic mixing, evaporation = Hawking process, holographic fold = entanglement creation akin to perfect tensors, recovery fold = error-correcting recovery/Petz map, and Pachner fold = discrete geometric transition. The inclusion of a “topological” bulk space acknowledges subtleties like state-dependence and ensemble averaging by giving the RFO a slight generalization beyond strict unitarity (a necessary compromise to incorporate all modern insights).

## Observables &amp; Testable Diagnostics

A successful model of black hole information should suggest observables or diagnostics that could, *in principle*, differentiate it from alternatives or be measured (perhaps indirectly) to validate the mechanism. We list several key observables and how they manifest in the RFO framework:

- **Spectral Form Factor (SFF) and “Fold Depth”:** The spectral form factor $g(t) = |\Tr(e^{-i H t})|^2$ of a quantum black hole (or an ensemble thereof) exhibits the characteristic dip–ramp–plateau behavior of chaotic systems (as seen in SYK and Random Matrix Theory). In gravity, the **linear ramp** at intermediate times is attributed to *wormholes connecting two replica boundaries*, reflecting spectral correlations. In RFO, a “fold depth” $d$ corresponds to the presence of connected topology between $d$ replicas in the path integral picture. As $d$ increases, the ramp extends longer. Concretely, one expects a relation: deeper interior entanglement (more complex folds) $\Leftrightarrow$ more pronounced level repulsion in the energy spectrum. A diagnostic could be: **compare the ramp slope to the density of states.** For a two-dimensional model (JT gravity), the slope is proportional to the spectral variance introduced by wormholes【13†L19-L27】. If the RFO correctly encodes long-range correlations, then e.g. the late-time SFF for a given black hole should align with that of a random matrix ensemble of the appropriate universality class. *Test:* In an analogue system (like an SYK simulator), prepare states of different interior complexity and measure their spectral correlators to see if increased interior entanglement yields the expected ramp (indicating ensemble averaging internally). This would support the idea that RFO’s \(\mathcal{F}_{Pachner}\) (folding geometry) is creating the correct long-term correlations (as wormholes do in gravity) rather than the spectrum being Poisson (as it would be for an integrable or many-remnant scenario).

- **Page Curve via Radiation Entropy Measurements:** Perhaps the clearest “signature” of unitary evaporation is the entanglement entropy of Hawking radiation first rising and then falling. While measuring this for real black holes is currently infeasible, one might test it in lower-dimensional labs (quantum simulators, or in principle via analog Hawking radiation in ion traps or optical fibers). RFO predicts a specific Page curve: the entropy of radiation $S_{\text{rad}}(t)$ follows the min of Hawking’s curve and the Bekenstein–Hawking curve【44†L51-L59】. *Test:* Simulate an RFO on a quantum computer for a small model (say, using a HaPPY code for $\mathcal{E}$, some random Clifford for $U_{\text{scr}}$, and a toy evaporation circuit for $U_{\text{evap}}$) and verify that the mutual information between early and late radiation becomes significant after the Page time. In a more physical analog, measure the entanglement of modes in an analogue Hawking experiment (recent experiments with sonic black holes, for example, aim to verify Hawking radiation entanglement). A deviation from a monotonic entropy increase – e.g. seeing entanglement saturate and perhaps decrease (in a controlled setting with an effective horizon) – would back the island/RFO picture over a no-island scenario.

- **Out-of-Time-Order Correlators (OTOCs) and Scrambling Onset:** A hallmark of the fast scrambling conjecture is that simple perturbations become undetectable by local measurements after a scrambling time $t_*$, which for a BH is extremely short (microseconds for a solar mass BH). If one had access to a dual description (like a holographic CFT or a SYK model), one could prepare two copies of the system and measure an OTOC like $\langle V(0) W(t) V(0) W(t)\rangle$. RFO implies OTOCs should decay as $\sim e^{-\lambda_L t}$ with $\lambda_L$ hitting the $2\pi T$ bound【52†L53-L56】, and that adding one extra qubit to the BH increases scrambling time only logarithmically. *Test:* In a condensed matter emulator of holography (SYK quantum dot, perhaps), perturb the system and see how quickly a distant observable reacts. If it matches the fast scrambling rate (which can be compared to theoretical $2\pi/\beta$), that supports that nature’s scramblers (which BHs exemplify) are indeed maximal. This has partly been done in SYK experiments with OTOCs measured via Loschmidt echo techniques. Agreement with $\lambda_L = 2\pi T$ (and no faster growth for any probe) confirms that any consistent model – including RFO – must respect this and that RFO’s scrambling module is on point.

- **Late-Time Hawking Radiation Correlations:** While early Hawking radiation is nearly thermal and uncorrelated (except for small greybody factors), RFO (like Page’s argument) predicts that **Hawking quanta emitted at late times are highly entangled with those emitted at early times** (specifically, after Page time, each new quantum must come out purifying some part of the earlier radiation). If one could capture the Hawking radiation of an evaporating BH and perform quantum information processing on it (a fantastical scenario, but thought experiments consider this), one would find non-zero mutual information and even distillable entanglement between early and late portions of the radiation. For example, for a BH that has radiated 75% of its mass, a particular late photon would be almost maximally entangled with some subsystem of the early photons. *Test:* This is far out of experimental reach for astrophysical BHs. But analog systems or numerical simulations could mimic this: one can check in the RFO circuit that the mutual information $I(\text{early};\text{late})$ jumps from 0 to significant after the circuit passes the encoding threshold. In a matrix model simulation of BH evaporation, one could attempt to measure correlation functions between early and late “radiation” operators. Any detection of such correlations (versus a hypothesis of independent Hawking quanta) would be a win for unitarity. Note that black hole complementarity and firewall arguments revolve around these correlations – RFO by construction ensures they’re present in the radiation, which is why a would-be clone (inside vs outside) is resolved by interior operators being state-dependent.

- **Soft Hair Charges and Their Variation:** RFO could be indirectly tested through the **soft hair** it incorporates. If black holes have soft charges (supertranslations, superrotations), then when a BH forms or evaporates, there should be corresponding changes in the gravitational or electromagnetic field at infinity. For example, when a BH evaporates completely, the net BMS charge at future null infinity might differ from that at past null infinity, implying a “memory” effect (a permanent relative displacement of test masses). These are classical in principle, but their pattern could encode quantum information. Hawking *et al.*【57†L55-L63】 suggested an infinite number of conservation laws – if they hold, then one could try to measure a few of these (like total supertranslation charge) before and after and see if they account for information. *Test:* Look for gravitational wave memory signals or electromagnetic memory in black hole merger or evaporation scenarios. LIGO has the capability to detect GW memory from strong bursts; a detected memory could be attributed to BMS charge changes. If the pattern or magnitude of memory fits what’s needed to carry entropy (which presumably would be extremely tiny per emitted quantum, but integrated over many quanta could sum to a noticeable effect), that would hint that these soft modes participate in information release. Realistically, verifying that memory carries specific information content is extremely hard, but even verifying the existence of predicted memory modes (like spin memory for rotation) would strengthen the case that black holes have the hair RFO assumes. In RFO terms, measuring soft charge $Q_f$ on radiation versus initial state should yield a correlation – essentially $Q_f^{\text{initial}} - Q_f^{\text{final}} = \sum (\text{soft hair quanta radiated})$. Observing that would validate that soft hair is not “information-free” but tracks something about what fell in.

- **Entanglement Wedge Cross-Section (EWCS) or Reflected Entropy:** In AdS/CFT, one interesting quantity is the reflected entropy between two radiation subsystems, which is dual to the area of the entanglement wedge cross-section. A high reflected entropy between early and late radiation indicates purification via an interior connection. If one had a way to compute correlation measures like entanglement negativity between different parts of radiation, a non-zero value (after Page time) would directly signal the presence of an “island”. This is more of a theoretical diagnostic: e.g., using holography, one can compute the mutual information and negativity for two halves of the radiation and see it become nonzero only when an island forms. RFO being consistent with holography means it should reproduce such features. 

In summary, while direct empirical tests on real black holes remain beyond current technology, many of these observables can be tested in **thought experiments or analog simulations**. If RFO is correct, any consistent toy model (SYK, tensor networks, etc.) of black holes should exhibit:

1. A Page curve turnover in entropy.
2. Maximal chaos OTOC behavior.
3. Strong early–late radiation entanglement after half the lifespan.
4. Soft charge shifts correlating with radiation release.
5. Spectral statistics of a unitary ensemble (no persistent PSS (Poisson) spectrum of remnants, etc.).

So far, theoretical and numerical evidence (from SYK, random unitaries, etc.) aligns with points 1,2,3 being true in quantum gravity. Point 4 is speculative, and point 5 is partly verified in toy models. RFO basically synthesizes these points, and each of these is both a “diagnostic” of the RFO’s functioning and a target for future confirmation as quantum gravity research progresses.

## Risk Log

No new paradigm is free of assumptions or potential pitfalls. We catalog the key risks, ambiguities, and controversies surrounding the RFO formalism and its theoretical underpinnings:

- **Firewall Paradox and Internal Consistency:** The RFO assumes that the black hole interior can be described as part of a quantum Hilbert space that is *universal* (state-independent) and accessible via appropriate decoding of Hawking radiation. The **AMPS firewall argument** (Almheiri *et al.*, 2013) posits that if an infalling observer sees a smooth horizon (i.e., interior modes entangled with exterior late modes), then an outgoing late photon, already entangled with early radiation (after Page time), would violate monogamy of entanglement unless the interior mode it would have been entangled with is somehow absent – implying a “firewall” instead of a smooth interior. RFO addresses this by effectively **making the interior reconstruction state-dependent** (via $\mathcal{F}_{rec}$ and $\mathcal{H}_{bulk}^{top}$). This follows recent reasoning that a single unitary map cannot describe the interior for all microstates simultaneously【50†L53-L61】【44†L61-L69】. The risk is that state-dependence can lead to apparent violations of linearity of quantum mechanics or cloning paradoxes if mis-handled. Essentially, to avoid firewalls, RFO incorporates the idea that interior operators $a$ are really $a_i$ specific to each microstate (or each code subspace). While there is growing evidence this is the correct perspective (no experiment can detect the non-linearity because it requires operating on exponentially complex superpositions【50†L59-L65】), it remains controversial. If it’s wrong, RFO’s smooth interior assumption might be flawed and a firewall (or other new physics) might greet the infaller. This is a fundamental consistency issue: **if future theory insists on state-independent interior operators for all states, then either unitarity or smooth horizons must give (firewall), or we need novel post-quantum mechanics**. RFO leans on the consensus emerging that state-dependent QEC is fine. Yet, one must carefully avoid causing super-observers to be able to perform non-unitary operations (like in Mathur’s “bag-of-gold” paradox). This is an open research area; RFO’s approach will have to evolve with it.

- **Ambiguity in LQG Area Quantization (Immirzi and Subleading Corrections):** Loop Quantum Gravity provided one possible account of microstates, but it has a free parameter (Immirzi $\gamma$) fixed by matching entropy, and it tends to predict a specific logarithmic correction to BH entropy ($-\frac{1}{2}\ln A$ for large $A$) that might or might not match string theory or semiclassical calculations (which often get $-\frac{3}{2}\ln A$ in 4D). This suggests our understanding of horizon microstates is incomplete. If LQG’s picture is not the full story, RFO’s use of spin foam moves might be too naive. For example, LQG microstates might correspond to **quantum geometries that are overcomplete or require gauge-fixing choices** – the spin foam path integral still struggles with convergence and uniqueness. Additionally, the isolated horizon framework presumes quasi-static horizons; an evaporating horizon might need a more dynamical treatment. There’s a risk that the **$\mathcal{F}_{Pachner}$ moves and spin-network interpretation might break down in the highly dynamical regime** of full evaporation. Perhaps full quantum gravity might have additional degrees of freedom (like topology change, baby universes) not captured in current models. Thus, while RFO embraces LQG ideas for discrete geometry change, it could be that a different microscopic description (fuzzball microstates, or ensemble of AdS/CFT states) is the correct one. If so, one might need to map RFO’s folds to those frameworks – e.g., folds might correspond to tunneling between fuzzball solutions. The risk is not fatal – rather it means RFO is somewhat agnostic to the specific UV physics as long as it yields the correct entropy count and transition amplitudes. But it should be kept in mind that **the true quantum gravity dynamics might not be literally Pachner moves**, even if conceptually similar.

- **Computational Complexity and Decoding Practicality:** RFO assures that information is preserved and in principle decodable from Hawking radiation. However, the complexity of performing this decoding is likely exponential in the entropy. This aligns with Harlow &amp; Hayden’s argument that solving the decoding before the BH evaporates is computationally infeasible (quantum complexity $\sim e^{S}$) – thus saving complementarity from allowing AMPS experiment to actually be done. In RFO, $\mathcal{F}_{rec}$ can be thought of as such an exponentially complex unitary. *Risk:* If one demanded an explicit construction of interior operators with reasonable complexity, RFO might fail. It uses $\mathcal{H}_{bulk}^{top}$ essentially to smuggle in non-unitary effective behavior that avoids firewalls. In doing so, it concedes that **no simple unitary in polynomial time can decode the diary from radiation** – which is fine (even desirable to match physics arguments)【44†L61-L69】. But that means RFO might not give a *polynomial algorithm* for reconstruction, only an existence proof. For physics that’s acceptable; for a would-be observer trying to actually recover info, it’s practically a “weak” resolution. If future insights show some unexpected efficient decoding (maybe via quantum gravity specific tricks or new symmetries), then RFO might need to incorporate those (which could impose more structure on $\mathcal{F}_{rec}$ beyond generic Petz map). So the risk is that RFO remains somewhat *meta-theoretical*: it doesn’t necessarily provide the explicit circuit for decoding, just guarantees one exists by QEC arguments. It’s possible that’s the best we can ever do.

- **Potential New Physical Effects (Non-locality, Remnants):** RFO assumes standard quantum theory holds exactly and no new long-range interactions or stable remnants appear. Yet, some alternatives to resolving information loss include **non-local effects** (e.g. Maldacena–Susskind’s ER=EPR suggests maybe large wormholes connect interior and radiation – RFO effectively embraces that via encoding but keeps quantum mechanics local) or **planckian remnants** (an ever-shrinking black hole that retains info in an eternally small object). Remnants typically conflict with entropy bounds and predict infinite species of stable particles – RFO’s adherence to Page curve basically rules them out. But if remnants were possible, RFO would be incorrect since it presumes complete evaporation with info carried out. Similarly, if there is some subtle non-locality that, say, invalidates the semi-classical calculation on which islands are based (for example, if unitarity is restored by a subtle $O(e^{-S})$ coupling between inside and outside that isn’t captured in effective field theory), RFO’s formalism might miss it (though islands already capture $e^{-S}$ effects via wormholes). At present, islands are the leading candidate, so RFO aligns with them. But one should monitor e.g. arguments by Giddings or others about possible observable non-local effects. RFO, by being built on holography, implicitly uses the BH as fast scrambler and obeying quantum no-cloning etc. If nature instead allowed a mild violation of no-cloning (some hidden copy in a baby universe with probability $10^{-60}$ or something), that would undermine the strict QEC picture albeit probably not in a measurable way. Still, RFO might need adjustments if such possibilities aren’t fully ruled out by consistency.

- **Validity of Entanglement Wedge = Quantum Extremal Surface (Islands):** The island formula is derived using the gravitational path integral (replica trick + summing wormholes). It involves assuming an ensemble average or analytic continuation that is not rigorously proven in general. One risk is that for some reason entanglement wedge reconstruction might fail deep inside a black hole (perhaps due to unknown quantum gravity effects like singularity or strong quantum chaos). For instance, **do we really know interior operators *just inside the horizon* are safely reconstructible?** (Almheiri *et al.* 2015 hedged about points deep inside black hole maybe not being reconstructible【7†L67-L75】). RFO kinda assumes the nice slice all the way to singularity is encoded (at least until singularity approach). If something like **strong cosmic censorship** or singularity fuzz (fuzzballs) means the interior degrees saturate at some point, then RFO’s $\mathcal{E}$ might be over-complete. Perhaps only a subset of interior field modes are truly independent degrees, others might be redundancies that never fully appear outside. This would complicate the story but possibly not ruin it – it might just reduce the code subspace size such that typical states are what’s encoded, while very atypical ones (like those requiring fine details of trans-planckian modes near singularity) might not be representable. The risk is small from a pragmatic view (we anyway restrict to semi-classical code subspace), but conceptually it’s there.

- **Experimental Falsifiability:** A practical risk: if RFO’s predictions cannot be distinguished experimentally from a scenario where information is lost (for all feasible measurements), then is it truly a scientific theory or just a consistent mathematical story? In principle, information loss violates unitarity which has consequences (e.g. violation of energy-momentum conservation in correlations), but those effects might be extremely tiny for large BHs. RFO’s best hope is that certain observables like subtle Hawking radiation correlations or gravitational wave memory might someday be measured. If decades pass and no hint of these correlations is found (and maybe a better theory arises that shows they’re unobservable in principle due to fundamental limitations), one might lean to a more radical resolution (like maybe unitarity is violated slightly). The risk is more about empirical validation: RFO stands on theoretical consistency and analogy with known systems (QECC, holography, etc.), which is strong but not a direct proof. It could be that black holes do something outside our current paradigm – RFO would then be a beautiful but perhaps not physically realized construct. However, given current evidence, this risk seems low; theoretical convergence is strongly in favor of unitarity and something like islands.

In summary, the RFO formalism, while synthesizing the state-of-the-art understanding, must navigate these uncertainties. It assumes no firewalls (opting for state-dependent interior), trusts holographic QEC (which is supported by calculations but not derived from first principles of gravity yet), and uses LQG-like quanta for geometry (pending experimental proof, of course). Each risk highlights where further research is needed:

- **State-dependence vs firewalls:** continue to flesh out non-isometric codes and demonstrate consistency (e.g., show no observable violation of linearity, perhaps via complexity arguments).
- **Loop quantum gravity dynamics:** work on connecting spin foam moves to Hawking radiation more concretely, or find an equivalent in string theory (maybe relate to D-brane interactions).
- **Complexity:** formalize the computational complexity of $\mathcal{F}_{rec}$ (maybe using quantum complexity theory to show it’s exponentially hard as suspected, hence safe from causing observable issues).
- **Alternate scenarios:** keep an eye on any proposed alternatives (e.g. Maldacena’s island in the sky, or Gao–Jafferis–Wall traversable wormholes which show how carefully adding couplings can access info – RFO should be able to reproduce that scenario by effectively turning on an interaction that acts as $\mathcal{F}_{rec}$ explicitly).
- **Experimental thought:** conceive experiments for analogue Hawking radiation or retrodicting properties of primordial black hole evaporation from cosmological data (if PBHs evaporated in early universe, did that leave any statistical imprint? RFO would say the graviton and neutrino backgrounds from PBH evaporation should carry subtle long-range correlations – very hard to detect, but a curious line of thought).

By logging these risks, we remain aware that RFO, like any current quantum gravity conjecture, is a *work in progress* – but one that is built upon an increasingly coherent picture. Each risk item is in fact an avenue for future refinement of the theory, and none so far has decisively threatened the paradigm that black holes behave as ordinary quantum systems with large Hilbert spaces and fast scrambling dynamics. The coming years of research (and perhaps new observational input from gravitational waves, etc.) will tell how the RFO holds up, but at present it is our best synthesis of holography, quantum information, and quantum gravity.

---

