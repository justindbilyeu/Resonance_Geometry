# Modified Bitumen GPT Creation

- Conversation ID: 687fa38b-dab4-8325-b124-4836222f2fae
- Created: 2025-07-22T14:43:25.499262

---

**user:**

We have been tasked with creating a GPT that is specific to Modified Bitumen roofing, and everything that encompasses that type of roofing, its creation, implementation, installation, and lifespan.  We will incorporate other llm’s to do our research, and use GitHub to compress our data into upload able packets for our OpenAi GPT.  Is this something you can help me with?

---

**assistant:**

Absolutely—I can help end-to-end: scoping, research prompts for the other LLMs, GitHub structuring/chunking, and the final GPT instructions.

## 0. Fast Path Overview
1. **Define scope &amp; audience** (sales vs. PM/estimators vs. installers vs. QA/QC; residential vs. commercial; SBS vs. APP focus, etc.).
2. **Map the knowledge graph** (materials → specs → install methods → codes → failure modes → maintenance → costs/lifespan).
3. **Spin up the research swarm** (DeepSeek, Grok, Claude, Gemini) with tight, templated prompts and deliverables.
4. **Normalize &amp; chunk outputs** into Markdown packets with YAML headers.
5. **Build the GPT system prompt &amp; retrieval rules** (answer style, citation rules, out-of-scope behavior).
6. **QA / red-team the bot** (hallucination traps, code/citation checks, roleplay tests).
7. **Ship v1, add feedback hooks, iterate.**

---

## 1. Clarify Scope (need your answers)
- **Use cases:** Sales enablement? Estimating? Spec writing? Field installation QA? Insurance/forensics?
- **Regions &amp; codes:** Just Texas/IBC? Include Miami-Dade, FM 4470, UL 2218, ASTM D6162/63/64?
- **System types:** SBS vs. APP, torch-applied, cold-applied, self-adhered, hot-mop?
- **Depth:** Do we cover chemistry of bitumen modification, manufacturing lines, recycling/disposal?
- **Tone &amp; output format:** Short answers vs. mini white papers? Always cite? Diagrams allowed?

Answer these and I’ll lock the blueprint.

---

## 2. Knowledge Map Draft (top-level buckets)

**A. Fundamentals**
- What is Modified Bitumen (history, SBS vs. APP chemistry)
- Membrane architecture (plies, reinforcement: polyester, fiberglass)
- Comparison to BUR, TPO, PVC, EPDM

**B. Products &amp; Specs**
- Sheets, base/interply/cap distinctions
- Surfacing: granulated vs. smooth, reflective coatings
- Adhesives &amp; attachment: torch, cold, hot asphalt, self-adhered

**C. Design &amp; Codes**
- Slope requirements, drainage/ponding rules
- Wind uplift (FM 4470/4474), fire (UL 790), hail (UL 2218), energy (IECC), local code notes
- Edge metal / flashing standards (ANSI/SPRI ES-1)

**D. Installation &amp; QA**
- Substrate prep, priming
- Sequencing, lap widths, bleed-out criteria
- Torch safety, fire watch protocol
- Infrared scans, core cuts, adhesion tests

**E. Performance &amp; Lifespan**
- Typical service life ranges by climate &amp; system
- Common failure modes (blisters, splits, lap failures)
- Maintenance schedules &amp; repair methods

**F. Costing &amp; Insurance**
- Material &amp; labor ranges per square/sq ft
- Insurance classification (hail-class impacts, RCV/ACV differences)
- Warranty structures (manufacturer vs. contractor)

**G. Sustainability &amp; EOL**
- Re-roof vs. overlay decisions
- Cool roof coatings, recyclability, VOC regs

**H. Case Studies &amp; Regional Variants**
- Hot/humid Gulf Coast vs. arid Southwest performance notes
- Miami-Dade NOAs, Texas windstorm (TDI/WPI-8)

---

## 3. Research Swarm Prompt Kit (Templates)

### 3.1 Topic Harvest Prompt (for DeepSeek/Grok/etc.)
```
You are Research-GPT, tasked with producing a 400–500 word Markdown knowledge file on: **{topic}** within Modified Bitumen roofing.

Requirements:
1. Focus on low-slope commercial/residential in {region(s)}; cite authoritative sources (ASTM, NRCA, IIBEC, FM Global, UL, ICC-ES, manufacturer tech bulletins).
2. Include: definition, why it matters, key spec values (lap widths, temps, slopes), common errors, quick field checklist.
3. Add one simple ASCII diagram if helpful.
4. End with “## References” using numeric bracket keys [1], [2] mapped to a short citation list.
5. Add YAML front matter:

---
title: {slug}
region: {region}
tags: [category1, category2]
source_type: ASTM/NRCA/etc.
review_date: 2025-07-22
---

Deliver ONLY the Markdown file.
```

### 3.2 Standards Extraction Prompt
```
Pull the critical clauses for Modified Bitumen from {standard/code}. List:
- Section number
- Exact requirement (paraphrase, ≤20 words)
- Why it matters
- Field verification method

Deliver as a table in Markdown + YAML header.
```

### 3.3 Failure Mode Deep-Dive Prompt
```
Describe the failure mode &quot;{failure}&quot; in Modified Bitumen systems:
- Mechanism
- Root causes
- Visual symptoms
- Diagnostic tests
- Repair options
- Prevention during design/install

≤ 450 words, cite at least two sources.
```

(We’ll build ~10 of these templates.)

---

## 4. GitHub Repo &amp; Chunking Pattern

```
modified-bitumen-gpt/
├─ chunks/
│  ├─ fundamentals/
│  │   ├─ what_is_modbit.md
│  │   ├─ sbs_vs_app.md
│  ├─ install/
│  │   ├─ torch_applied_best_practices.md
│  │   ├─ cold_applied_qc.md
│  ├─ codes/
│  │   ├─ astm_d6162_summary.md
│  │   ├─ fm_4470_requirements.md
│  ├─ performance/
│  │   ├─ hail_ul2218.md
│  │   ├─ lifespan_by_climate.md
│  ├─ costs/
│  │   ├─ cost_ranges_texas_2025.md
│  ├─ maintenance/
│  │   ├─ annual_inspection_checklist.md
│  └─ ...
├─ prompts/
│  ├─ research_topic_template.md
│  ├─ standards_extract_template.md
│  └─ failure_mode_template.md
├─ system_prompt/
│  └─ modbit_gpt_system.md
├─ eval/
│  ├─ hallucination_traps.md
│  ├─ qa_checklist.md
│  └─ sample_queries.json
└─ README.md
```

**Chunk rules:**
- 300–600 words each.
- Strong YAML headers.
- Consistent tag taxonomy (performance, codes, install, maintenance, cost).
- One topic per file.

---

## 5. GPT System Prompt Skeleton

```
# ROLE
You are “ModBit Roofing Pro,” an expert assistant for modified bitumen roofing.

# PURPOSE
Provide fast, accurate, citation-backed answers about Modified Bitumen systems: design, install, QA/QC, codes, costs, maintenance, and troubleshooting.

# RULES
• Always cite at least one repo chunk at the end of the FIRST paragraph.  
• If user asks for something outside ModBit scope (e.g., TPO-only topic), provide brief compare/contrast, then refocus or redirect.  
• Prefer numeric data (lap widths, temperatures) and practical checklists.  
• If a real-world action is implied, offer a next step (e.g., “verify FM 1-90 rating for that deck”).  
• Never fabricate standards; if unsure, say so and suggest the specific doc to check.

# KNOWLEDGE SOURCE PRIORITY
1. Repo chunks (this GitHub dataset)
2. Official standards (ASTM D6162/63/64, FM 4470, UL 790, NRCA manuals)
3. Major manufacturer technical bulletins (Carlisle, Johns Manville, GAF, Soprema)
4. Secondary blogs ONLY to contextualize, not to claim specs.

# OUTPUT STYLE
Concise but complete. Use bullets. Avoid fluff. Diagrams allowed (ASCII).
```

---

## 6. QA / Red Teaming

- **Hallucination tests:** Ask code-clauses that don’t exist. Ensure bot says “not in my sources.”
- **Math sanity checks:** Torch temp ranges, lap widths, slope min (¼”/ft) – verify.
- **Citation checker:** Each output has a chunk link; no naked claims.
- **Roleplay:** Contractor calls from roof at 2AM—“blister under cap sheet; what now?” Evaluate guidance.

---

## 7. Next Steps From Me (once you answer scope Qs)

1. Deliver a finalized **Blueprint doc (v1.0)**.
2. Hand you **LLM prompt pack** (markdown files ready to paste).
3. Create **repo scaffold** text for you to drop into GitHub.
4. Draft the **System Prompt v0.1** for the GPT.
5. Spin up first **P1 topic list** (10–15 chunks) and assign to each LLM.

---

### Your Turn
- Drop answers to the scope questions in §1.
- Confirm any deadlines or team roles.
- Tell me if you want me to draft the repo and push via PR, or just hand you files.

Once I have that, I’ll start building.

---

